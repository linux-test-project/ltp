#!/bin/sh
echo "fail.sh: This test failed!"
exit -324
