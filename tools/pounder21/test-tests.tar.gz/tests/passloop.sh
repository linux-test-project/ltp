#!/bin/sh
$POUNDER_HOME/timed_loop 1 $POUNDER_HOME/tests/pass.sh
exit  $?
