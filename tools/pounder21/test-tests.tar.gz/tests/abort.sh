#!/bin/sh
echo "abort.sh: ack! aborting!"
exit 255
