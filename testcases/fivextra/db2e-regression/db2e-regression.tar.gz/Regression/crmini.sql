drop table t;
 create table t(i int, c char(50), v varchar(50));

