create index ix01 on table3(c1);
create index ix02 on table3(c2);
create index ix03 on table3(c3);
create index ix04 on table3(c4);
create index ix05 on table3(c5);

