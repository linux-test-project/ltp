-- create table for test
drop table t;
create table t(c int);

-- test autocommit on+commit (makes permanent)
autocommit on;
insert into t values(1);
insert into t values(2);
insert into t values(3);
select * from t;
commit;
select * from t;

-- test autocommit off+commit (commit should have no effect)
autocommit off;
insert into t values(4);
select * from t;
commit;
select * from t;

-- test autocommit off+rollback (rollback should have no effect)
autocommit off;
insert into t values(4);
select * from t;
rollback;
select * from t;

-- test autocommit on+rollback (undoes)
autocommit on;
insert into t values(5);
insert into t values(6);
insert into t values(7);
select * from t;
rollback;
select * from t;

-- test simple commit
insert into t values(8);
select * from t;
commit;
select * from t;

-- cleanup
autocommit off;
drop table t;

