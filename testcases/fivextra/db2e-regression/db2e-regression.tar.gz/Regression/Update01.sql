-- ----------------- FILE: UPDATE01.SQL -------------------
-- -                                                      - 
-- -          Validates UPDATE statement	          -
-- -                                                      -
-- --------------------------------------------------------
--

-- --------------------------------------------------------
-- This set of test cases validates the simplest updates.
-- This test the column data at 3 positions: begining, middle
-- and end.
-- This also test the limit value.
-- It tries also to validate some overflow or underflow cases
-- --------------------------------------------------------
-- --------------------------------------------------------
-- Delete tables
-- --------------------------------------------------------
DROP TABLE tI;
DROP TABLE tS;
DROP TABLE tE;
DROP TABLE tC;
DROP TABLE tV;
DROP TABLE tB;
DROP TABLE tD;
DROP TABLE tT;

-- --------------------------------------------------------
-- INITIALIZE THE TABLES
-- --------------------------------------------------------
CREATE TABLE tI (c1 INT, c2 INT, c3 INT);
CREATE TABLE tS (c1 SMALLINT, c2 SMALLINT, c3 SMALLINT);
CREATE TABLE tE (c1 DECIMAL(15,0), c2 DECIMAL(2,2), c3 DECIMAL(15,14));
CREATE TABLE tC (c1 CHAR(5), c2 CHAR(1), c3 CHAR(254));
CREATE TABLE tV (c1 VARCHAR(7), c2 VARCHAR(1), c3 VARCHAR(1000));
CREATE TABLE tB (c1 BLOB(10), c2 BLOB(1), c3 BLOB(32767));
CREATE TABLE tD (c1 DATE, c2 DATE, c3 DATE);
CREATE TABLE tT (c1 TIME, c2 TIME, c3 TIME);

INSERT INTO tI VALUES (-1234, +1234, 1234);
INSERT INTO tI VALUES (-2147483647, +0, 2147483647);
INSERT INTO tI VALUES (+0000000000000001234, -0000, -0000000001234);

INSERT INTO tS VALUES (-1234, +1234, 1234);
INSERT INTO tS VALUES (-32767, +0, +32767);
INSERT INTO tS VALUES (+0000000000000001234, -0000, -0000000001234);

INSERT INTO tE VALUES (-1234., +.12, 1.234);
INSERT INTO tE VALUES (-999999999999999., +0.00, +9.99999999999999);
INSERT INTO tE VALUES (+0000000000000000000000000000000000001234, -.00, +0.00000000000009);

INSERT INTO tC VALUES ('1234', '', '1234');
INSERT INTO tC VALUES ('1234', '', '123456789012345678901234567890123456789012345678901234
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890
1234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890');
INSERT INTO tC VALUES ('', '', '');

INSERT INTO tV VALUES ('1234', '1', '1234567890');
INSERT INTO tV VALUES ('1234567', '\', '\\\n\0\a\d');
INSERT INTO tV VALUES ('1234', '^', '!@#$%^&*()_+<>?.\|[]{}:-=');

-- INSERT INTO tB VALUES ('1234', '1', '1234567890');
-- INSERT INTO tB VALUES ('1234567', '\', '\\\n\0\a\d');
-- INSERT INTO tB VALUES ('', '^', '!@#$%^&*()_+<>?.\|[]{}-=');

INSERT INTO tD VALUES ('08/05/1999','08/06/1999','08/07/1999');
-- INSERT INTO tD VALUES ('01/01/0001','01/01/0001','01/01/0001');
-- Year cannot be less than 100
INSERT INTO tD VALUES ('01/01/0100','01/01/0100','01/01/0100');
INSERT INTO tD VALUES ('12/31/9999','12/31/1999','12/31/0999');

INSERT INTO tT VALUES ('22:55:00','22:55:01','22:56:00');
INSERT INTO tT VALUES ('00:00:00','00:00:00','00:00:00');
INSERT INTO tT VALUES ('23:59:59','01:02:03','03:02:01');


-- ********************************************************* 
-- 5BASIC0001-5BASIC0240
-- ********************************************************* 
-- TEST:5BASIC0001-5BASIC0030 UPDATE tI SET one column
-- PASS:5BASIC0001-5BASIC0030 no failure accures                       

UPDATE tI SET c1 = -0;
UPDATE tI SET c1 = -2147483647;
UPDATE tI SET c1 = +0000;
UPDATE tI SET c1 = +2147483647;
UPDATE tI SET c1 = 42;
UPDATE tI SET c1 = -314159265;
UPDATE tI SET c1 = +314159265;
UPDATE tI SET c1 = -1;
UPDATE tI SET c1 = 1;
UPDATE tI SET c1 = 0;

UPDATE tI SET c2 = -0;
UPDATE tI SET c2 = -2147483647;
UPDATE tI SET c2 = +0000;
UPDATE tI SET c2 = +2147483647;
UPDATE tI SET c2 = 42;
UPDATE tI SET c2 = -314159265;
UPDATE tI SET c2 = +314159265;
UPDATE tI SET c2 = -1;
UPDATE tI SET c2 = 1;
UPDATE tI SET c2 = 0;

UPDATE tI SET c3 = -0;
UPDATE tI SET c3 = -2147483647;
UPDATE tI SET c3 = +0000;
UPDATE tI SET c3 = +2147483647;
UPDATE tI SET c3 = 42;
UPDATE tI SET c3 = -314159265;
UPDATE tI SET c3 = +314159265;
UPDATE tI SET c3 = -1;
UPDATE tI SET c3 = 1;
UPDATE tI SET c3 = 0;
-- END TEST >>> 5BASIC0001-5BASIC0030 <<< END TEST



-- TEST:5BASIC0031-5BASIC0060 UPDATE tS SET one column
-- PASS:5BASIC0031-5BASIC0060 no failure accures                       

UPDATE tS SET c1 = -0;
UPDATE tS SET c1 = -32767;
UPDATE tS SET c1 = +0000;
UPDATE tS SET c1 = +32767;
UPDATE tS SET c1 = 42;
UPDATE tS SET c1 = -31415;
UPDATE tS SET c1 = +31415;
UPDATE tS SET c1 = -1;
UPDATE tS SET c1 = 1;
UPDATE tS SET c1 = 0;

UPDATE tS SET c2 = -0;
UPDATE tS SET c2 = -32767;
UPDATE tS SET c2 = +0000;
UPDATE tS SET c2 = +32767;
UPDATE tS SET c2 = 42;
UPDATE tS SET c2 = -31415;
UPDATE tS SET c2 = +31415;
UPDATE tS SET c2 = -1;
UPDATE tS SET c2 = 1;
UPDATE tS SET c2 = 0;

UPDATE tS SET c3 = -0;
UPDATE tS SET c3 = -32767;
UPDATE tS SET c3 = +0000;
UPDATE tS SET c3 = +32767;
UPDATE tS SET c3 = 42;
UPDATE tS SET c3 = -31415;
UPDATE tS SET c3 = +31415;
UPDATE tS SET c3 = -1;
UPDATE tS SET c3 = 1;
UPDATE tS SET c3 = 0;
-- END TEST >>> 5BASIC0031-5BASIC0060 <<< END TEST



-- TEST:5BASIC0061-5BASIC0090 UPDATE tE SET one column
-- PASS:5BASIC0061-5BASIC0090 no failure accures                       

UPDATE tE SET c1 = -0;
UPDATE tE SET c1 = -999999999999999.;
UPDATE tE SET c1 = +0000;
UPDATE tE SET c1 = +999999999999999.;
UPDATE tE SET c1 = 99999999999999.;
UPDATE tE SET c1 = -123456789012345.;
UPDATE tE SET c1 = +123456789012345.;
UPDATE tE SET c1 = -1;
UPDATE tE SET c1 = 1;
UPDATE tE SET c1 = 0;


UPDATE tE SET c2 = -0.;
UPDATE tE SET c2 = -.99;
UPDATE tE SET c2 = +00.00;
UPDATE tE SET c2 = +.99;
UPDATE tE SET c2 = 42;
UPDATE tE SET c2 = -.45;
UPDATE tE SET c2 = +.3;
UPDATE tE SET c2 = -.00;
UPDATE tE SET c2 = .1;
UPDATE tE SET c2 = .0;


UPDATE tE SET c3 = -0.;
UPDATE tE SET c3 = -9.99999999999999;
UPDATE tE SET c3 = +0.00;
UPDATE tE SET c3 = +9.99999999999999;
UPDATE tE SET c3 = .42;
UPDATE tE SET c3 = -1.12345678901234;
UPDATE tE SET c3 = +1.12345678901234;
UPDATE tE SET c3 = -1.;
UPDATE tE SET c3 = .1;
UPDATE tE SET c3 = .0;

-- END TEST >>> 5BASIC0061-5BASIC0090 <<< END TEST



-- TEST:5BASIC0091-5BASIC0120 UPDATE tC SET one column
-- PASS:5BASIC0091-5BASIC0120 no failure accures                       

UPDATE tC SET c1 = 'ABCDE';
UPDATE tC SET c1 = '12345';
UPDATE tC SET c1 = '';
UPDATE tC SET c1 = '!@#$%';
UPDATE tC SET c1 = '42';
UPDATE tC SET c1 = '-1234';
UPDATE tC SET c1 = '+1234';
UPDATE tC SET c1 = '-';
UPDATE tC SET c1 = '     ';
UPDATE tC SET c1 = '0.000';

UPDATE tC SET c2 = '';
UPDATE tC SET c2 = ' ';
UPDATE tC SET c2 = '#';
UPDATE tC SET c2 = '!';
UPDATE tC SET c2 = 'a';
UPDATE tC SET c2 = 'A';
UPDATE tC SET c2 = '*';
UPDATE tC SET c2 = '-';
UPDATE tC SET c2 = '"';
UPDATE tC SET c2 = '0';
 
UPDATE tC SET c3 = '';
UPDATE tC SET c3 = '                                                                                                                                                                                                                                                           ';
UPDATE tC SET c3 = '12345678901234567890123456789012345678901234567890 12345678901234567890123456789012345678901234567890 12345678901234567890123456789012345678901234567890 12345678901234567890123456789012345678901234567890 12345678901234567890123456789012345678901234567890';
UPDATE tC SET c3 = 'abcderfghfgkasotiwusd,kxncvlkjhoasidfaksdjfasvkjzxhvkjashdfwro23h59875twefu8asdf;hzxcv.jncvmapi8tq23trqweifjzxvjkzxvjasldgiuq984t7qiefasdkfahvzxjvhzxhvsaghastarw]qtiw092q8qwieutaskdjfkasgu9827tr2urliwesdhgpasgy928awifusdkfjaskdghas[89et7qw34t234fhjdfjkt!';
UPDATE tC SET c3 = '!@#$@#$^$%&%&(&))__+*$%&@${}|:'<>?<JGIFGJHFY$%^&$*%^&(^@$%^WERCFATWQ!$%~#^%&$%*TJKGK>ML?:KL:'P{}P|()_(PJKLM<:KPYOTY(&$&#&%^&*TYUTYUTRY*$^*UDFJefgueu35673rthERtjurt*%7eytERt6425615y356*ykj$#73&RTYILo[oip]:LjklJHKpp{iopiOuyOTyoOP[][]\[][|p[i[oPYuirtyq3%24a';
UPDATE tC SET c3 = '-1000000000000000000000000000000000000000000000000000000000000000000000000000000000000.00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000001';
UPDATE tC SET c3 = '+99999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999999.9';
UPDATE tC SET c3 = '"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""""';
UPDATE tC SET c3 = '�����������Ғ/    hhhR������������߿���������� ###��?�����������궺����\0\0\225';
UPDATE tC SET c3 = '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''';
-- END TEST >>> 5BASIC0091-5BASIC0120 <<< END TEST



-- TEST:5BASIC0121-5BASIC0150 UPDATE tV SET one column
-- PASS:5BASIC0121-5BASIC0150 no failure accures                       

UPDATE tV SET c1 = '';
UPDATE tV SET c1 = 'abcdefg'; 
UPDATE tV SET c1 = '       ';
UPDATE tV SET c1 = '1234567';
UPDATE tV SET c1 = '0.0000.';
UPDATE tV SET c1 = '';
UPDATE tV SET c1 = '!@#$%%^&';
UPDATE tV SET c1 = ' ';
UPDATE tV SET c1 = '''''''';
UPDATE tV SET c1 = '���';

UPDATE tV SET c2 = '';
UPDATE tV SET c2 = 'a'; 
UPDATE tV SET c2 = ' ';
UPDATE tV SET c2 = '1';
UPDATE tV SET c2 = '.';
UPDATE tV SET c2 = '';
UPDATE tV SET c2 = 'y';
UPDATE tV SET c2 = ' ';
UPDATE tV SET c2 = '""';
UPDATE tV SET c2 = 'y';

UPDATE tV SET c3 = '';
UPDATE tV SET c3 = 'abcdefg'; 
UPDATE tV SET c3 = '       ';
UPDATE tV SET c3 = '1234567';
UPDATE tV SET c3 = '0.0000.';
UPDATE tV SET c3 = '';
UPDATE tV SET c3 = '\1\2\3\4\5\6\7\8\9\10\255';
UPDATE tV SET c3 = '                                                                   ';
UPDATE tV SET c3 = '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''';
UPDATE tV SET c3 = '������������������߿��������';
-- END TEST >>> 5BASIC0121-5BASIC0150 <<< END TEST



-- TEST:5BASIC0151-5BASIC0180 UPDATE tB SET one column
-- PASS:5BASIC0151-5BASIC0180 no failure accures                       


-- END TEST >>> 5BASIC0151-5BASIC0180 <<< END TEST

-- Test for BLOB is missing

-- TEST:5BASIC0181-5BASIC0210 UPDATE tD SET one column
-- PASS:5BASIC0181-5BASIC0210 some expected failures accure

UPDATE tD SET c1 = '05/11/1978';
UPDATE tD SET c1 = '02/28/2000';
UPDATE tD SET c1 = '12/31/0999';
UPDATE tD SET c1 = '01/01/0100';
UPDATE tD SET c1 = '02/28/1999';
UPDATE tD SET c1 = '02/29/1999';
UPDATE tD SET c1 = '02/29/2000';
UPDATE tD SET c1 = '01/01/2000';
UPDATE tD SET c1 = '12/31/1999';
UPDATE tD SET c1 = '12/31/9999';

UPDATE tD SET c2 = '05.11.1978';
UPDATE tD SET c2 = '02.28.2000';
UPDATE tD SET c2 = '12.31.0999';
UPDATE tD SET c2 = '01.01.0100';
UPDATE tD SET c2 = '02.28.1999';
UPDATE tD SET c2 = '02.29.1999';
UPDATE tD SET c2 = '02.29.2000';
UPDATE tD SET c2 = '01.01.2000';
UPDATE tD SET c2 = '12.31.1999';
UPDATE tD SET c2 = '12.31.9999';

UPDATE tD SET c3 = '1978-05-11';
UPDATE tD SET c3 = '2000-02-28';
UPDATE tD SET c3 = '0999-12-31';
UPDATE tD SET c3 = '0100-01-01';
UPDATE tD SET c3 = '1999-02-28';
UPDATE tD SET c3 = '1999-02-29';
UPDATE tD SET c3 = '2000-02-29';
UPDATE tD SET c3 = '2000-01-01';
UPDATE tD SET c3 = '1999-12-31';
UPDATE tD SET c3 = '9999-12-31';
-- END TEST >>> 5BASIC0181-5BASIC0210 <<< END TEST



-- TEST:5BASIC0211-5BASIC0240 UPDATE tD SET one column
-- PASS:5BASIC0211-5BASIC0240 some expected failures accure

UPDATE tT SET c1 = '00:00:00';
UPDATE tT SET c1 = '00:00:01';
UPDATE tT SET c1 = '12:00:00';
UPDATE tT SET c1 = '23:59:59';
UPDATE tT SET c1 = '24:00:00';
UPDATE tT SET c1 = '12:12:12';
UPDATE tT SET c1 = '12:34:56';
UPDATE tT SET c1 = '01:02:03';
UPDATE tT SET c1 = '16:45:59';
UPDATE tT SET c1 = '23:45:16';

UPDATE tT SET c2 = '00.00.00';
UPDATE tT SET c2 = '00.00.01';
UPDATE tT SET c2 = '12.00.00';
UPDATE tT SET c2 = '23.59.59';
UPDATE tT SET c2 = '24.00.00';
UPDATE tT SET c2 = '12.12.12';
UPDATE tT SET c2 = '12.34.56';
UPDATE tT SET c2 = '01.02.03';
UPDATE tT SET c2 = '16.45.59';
UPDATE tT SET c2 = '23.45.16';

UPDATE tT SET c3 = '00:00 AM';
UPDATE tT SET c3 = '00:00 PM';
UPDATE tT SET c3 = '12:00 PM';
UPDATE tT SET c3 = '23:59 AM';
UPDATE tT SET c3 = '24:00 AM';
UPDATE tT SET c3 = '12:12 AM';
UPDATE tT SET c3 = '12:34 PM';
UPDATE tT SET c3 = '01:02 AM';
UPDATE tT SET c3 = '06:45 PM';
UPDATE tT SET c3 = '03:45 PM';
-- END TEST >>> 5BASIC0211-5BASIC0240 <<< END TEST

-- END TEST >>> 5BASIC0001-5BASIC0240 <<< END TEST
-- ***********************************************

-- ********************************************************* 
-- 5BASIC0241-5BASIC0240
-- ********************************************************* 
-- TEST:5BASIC0241-5BASIC0264 UPDATE tX SET one column = other column
-- PASS:5BASIC0241-5BASIC0264 no failure accures                       

UPDATE tI SET c1 = c2;
UPDATE tI SET c2 = c3;
UPDATE tI SET c3 = c1;

UPDATE tS SET c1 = c2;
UPDATE tS SET c2 = c3;
UPDATE tS SET c3 = c1;

UPDATE tE SET c1 = c2;
UPDATE tE SET c2 = c3;
UPDATE tE SET c3 = c1;

UPDATE tC SET c1 = c2;
UPDATE tC SET c2 = c3;
UPDATE tC SET c3 = c1;

UPDATE tV SET c1 = c2;
UPDATE tV SET c2 = c3;
UPDATE tV SET c3 = c1;

-- UPDATE tB SET c1 = c2;
-- UPDATE tB SET c2 = c3;
-- UPDATE tB SET c3 = c1;

UPDATE tD SET c1 = c2;
UPDATE tD SET c2 = c3;
UPDATE tD SET c3 = c1;

UPDATE tT SET c1 = c2;
UPDATE tT SET c2 = c3;
UPDATE tT SET c3 = c1;

-- END TEST >>> 5BASIC0241-5BASIC0264 <<< END TEST
-- ***********************************************

-- ********************************************************* 
-- 5BASIC0271-5BASIC0390
-- ********************************************************* 
-- TEST:5BASIC0271-5BASIC0300 UPDATE tI SET one column = +-*/CONCAT columns
-- PASS:5BASIC0271-5BASIC0300 expected failure accure                  

UPDATE tI SET c1 = +2147483647;
UPDATE tI SET c2 = -2147483647;
UPDATE tI SET c3 = c1 + c2;
UPDATE tI SET c3 = c1 + c1 - c1;
UPDATE tI SET c3 = -c1 - c2;
UPDATE tI SET c3 = c2 + c1;
UPDATE tI SET c3 = c2 + c2 - c2;
UPDATE tI SET c3 = -c2 - c1;
UPDATE tI SET c3 = c1 - 1 + 1;
UPDATE tI SET c3 = c2 + 1 - 1;

UPDATE tI SET c1 = +2147483647;
UPDATE tI SET c2 = -2147483647;
UPDATE tI SET c3 = c1 * c2;
UPDATE tI SET c3 = c1 * c1 / c1;
UPDATE tI SET c3 = -c1 / c2;
UPDATE tI SET c3 = c2 * c1;
UPDATE tI SET c3 = c2 * c2 / c2;
UPDATE tI SET c3 = -c2 / c1;
UPDATE tI SET c3 = c1 / 2 * 2;
UPDATE tI SET c3 = c2 * 2 / 2;

UPDATE tI SET c1 = +2147483647 / 1234;
UPDATE tI SET c1 = +2147483647 * -1;
UPDATE tI SET c1 = +2147483647 / 0;
UPDATE tI SET c1 = -2147483647 * -1;
UPDATE tI SET c1 = -2147483647 / 0;
UPDATE tI SET c1 = 0 / 0;
UPDATE tI SET c1 = +2147483647 CONCAT 0;
UPDATE tI SET c1 = +21477 CONCAT 0;
UPDATE tI SET c1 = +2147 CONCAT 483647;
UPDATE tI SET c1 = -2147 CONCAT 483647;

-- TEST:5BASIC0301-5BASIC0330 UPDATE tS SET one column = +-*/CONCAT columns
-- PASS:5BASIC0301-5BASIC0330 expected failure accure                  

UPDATE tS SET c1 = +32767;
UPDATE tS SET c2 = -32767;
UPDATE tS SET c3 = c1 + c2;
UPDATE tS SET c3 = c1 + c1 - c1;
UPDATE tS SET c3 = -c1 - c2;
UPDATE tS SET c3 = c2 + c1;
UPDATE tS SET c3 = c2 + c2 - c2;
UPDATE tS SET c3 = -c2 - c1;
UPDATE tS SET c3 = c1 - 1 + 1;
UPDATE tS SET c3 = c2 + 1 - 1;

UPDATE tS SET c1 = +32767;
UPDATE tS SET c2 = -32767;
UPDATE tS SET c3 = c1 * c2;
UPDATE tS SET c3 = c1 * c1 / c1;
UPDATE tS SET c3 = -c1 / c2;
UPDATE tS SET c3 = c2 * c1;
UPDATE tS SET c3 = c2 * c2 / c2;
UPDATE tS SET c3 = -c2 / c1;
UPDATE tS SET c3 = c1 / 2 * 2;
UPDATE tS SET c3 = c2 * 2 / 2;

UPDATE tS SET c1 = +32767 / 1234;
UPDATE tS SET c1 = +32767 * -1;
UPDATE tS SET c1 = +32767 / 0;
UPDATE tS SET c1 = -32767 * -1;
UPDATE tS SET c1 = -32767 / 0;
UPDATE tS SET c1 = 0 / 0;
UPDATE tS SET c1 = +32767 CONCAT 0;
UPDATE tS SET c1 = +327 CONCAT 0;
UPDATE tS SET c1 = +32 CONCAT 767;
UPDATE tS SET c1 = -32 CONCAT 767;

-- TEST:5BASIC0331-5BASIC0360 UPDATE tE SET one column = +-*/CONCAT columns
-- PASS:5BASIC0331-5BASIC0360 expected failure accure                  

UPDATE tE SET c1 = +999999999999999.;
UPDATE tE SET c2 = -999999999999999.;
SELECT * FROM tE ORDER BY c1;
UPDATE tE SET c3 = c1 + c2;
UPDATE tE SET c3 = c1 + c1 - c1;
UPDATE tE SET c3 = -c1 - c2;
UPDATE tE SET c3 = c2 + c1;
UPDATE tE SET c3 = c2 + c2 - c2;
UPDATE tE SET c3 = -c2 - c1;
UPDATE tE SET c3 = c1 - 1 + 1;
UPDATE tE SET c3 = c2 + 1 - 1;

UPDATE tE SET c1 = +999999999999999.;
UPDATE tE SET c2 = -999999999999999.;
SELECT * FROM tE ORDER BY c1;
UPDATE tE SET c3 = c1 * c2;
UPDATE tE SET c3 = c1 * c1 / c1;
UPDATE tE SET c3 = -c1 / c2;
UPDATE tE SET c3 = c2 * c1;
UPDATE tE SET c3 = c2 * c2 / c2;
UPDATE tE SET c3 = -c2 / c1;
UPDATE tE SET c3 = c1 / 2 * 2;
UPDATE tE SET c3 = c2 * 2 / 2;

UPDATE tE SET c1 = +999999999999999. / 1234.;
UPDATE tE SET c1 = 999999999999999. * -1;
UPDATE tE SET c1 = +999999999999999. / 0;
UPDATE tE SET c1 = -999999999999999. * -1;
UPDATE tE SET c1 = -999999999999999. / 0;
UPDATE tE SET c1 = 0 / 0;
UPDATE tE SET c1 = +99999999999999. CONCAT 0;
UPDATE tE SET c1 = +99999999999. CONCAT 0;
UPDATE tE SET c1 = +999999999999. CONCAT 999.;
UPDATE tE SET c1 = -999999999999. CONCAT 999.;

-- TEST:5BASIC0361-5BASIC0390 UPDATE tD SET one column = +-*/CONCAT columns
-- PASS:5BASIC0361-5BASIC0390 expected failure accure                  

-- NO DATE AND TIME ARITHMETIC

-- END TEST >>> 5BASIC0271-5BASIC0390 <<< END TEST
-- ***********************************************

-- ********************************************************* 
-- 5BASIC0391-5BASIC0430
-- ********************************************************* 
-- TEST:5BASIC0391-5BASIC0410 UPDATE tC SET one column = CONCAT columns
-- PASS:5BASIC0391-5BASIC0410 expected failure accure                  

UPDATE tC SET c1 = 'ABC' CONCAT 'DE';
UPDATE tC SET c1 = '' CONCAT 'ABCDE';
UPDATE tC SET c1 = 'ABCDE' CONCAT '';
UPDATE tC SET c1 = 'A' CONCAT 'B' CONCAT 'C' CONCAT 'D' CONCAT 'E';
UPDATE tC SET c1 = 'A' CONCAT 'B' CONCAT 'C' CONCAT 'D' CONCAT 'E' CONCAT '';
UPDATE tC SET c1 = '' CONCAT 'A' CONCAT 'B' CONCAT 'C' CONCAT 'D' CONCAT 'E';
-- UPDATE tC SET c1 = '' CONCAT 'A' CONCAT '' CONCAT 'B' CONCAT '' CONCAT 'C' CONCAT '' CONCAT 'D' CONCAT '' CONCAT 'E' CONCAT '';
UPDATE tC SET c1 = '   ' CONCAT '  ';
UPDATE tC SET c1 = '' CONCAT '     ';
UPDATE tC SET c1 = '     ' CONCAT '';

UPDATE tC SET c2 = '' CONCAT '';
UPDATE tC SET c2 = '' CONCAT 'A';
UPDATE tC SET c2 = 'A' CONCAT '';
UPDATE tC SET c2 = '' CONCAT '' CONCAT '' CONCAT '' CONCAT '';
UPDATE tC SET c2 = 'A' CONCAT 'B';
UPDATE tC SET c2 = '' CONCAT 'A' CONCAT 'B';
UPDATE tC SET c2 = '' CONCAT 'A' CONCAT '';
UPDATE tC SET c2 = ' ' CONCAT ' ';
UPDATE tC SET c2 = '' CONCAT ' ';
UPDATE tC SET c2 = ' ' CONCAT '';

-- TEST:5BASIC0411-5BASIC0430 UPDATE tV SET one column = CONCAT columns
-- PASS:5BASIC0411-5BASIC0430 expected failure accure                  

UPDATE tV SET c1 = 'ABC' CONCAT 'DEFG';
UPDATE tV SET c1 = '' CONCAT 'ABCDEFG';
UPDATE tV SET c1 = 'ABCDEFG' CONCAT '';
-- UPDATE tV SET c1 = 'A' CONCAT 'B' CONCAT 'C' CONCAT 'D' CONCAT 'E' CONCAT 'F' CONCAT 'G';
-- UPDATE tV SET c1 = 'A' CONCAT 'B' CONCAT 'C' CONCAT 'D' CONCAT 'E'  CONCAT 'F' CONCAT 'G'CONCAT '';
-- UPDATE tV SET c1 = '' CONCAT 'A' CONCAT 'B' CONCAT 'C' CONCAT 'D' CONCAT 'E' CONCAT 'F' CONCAT 'G';
-- UPDATE tV SET c1 = '' CONCAT 'A' CONCAT '' CONCAT 'B' CONCAT '' CONCAT 'C' CONCAT '' CONCAT 'D' CONCAT '' CONCAT 'E' CONCAT '' CONCAT 'F' CONCAT '' CONCAT 'G' CONCAT '';
UPDATE tV SET c1 = '    ' CONCAT '   ';
UPDATE tV SET c1 = '' CONCAT '       ';
UPDATE tV SET c1 = '       ' CONCAT '';

UPDATE tV SET c2 = '' CONCAT '';
UPDATE tV SET c2 = '' CONCAT 'A';
UPDATE tV SET c2 = 'A' CONCAT '';
UPDATE tV SET c2 = '' CONCAT '' CONCAT '' CONCAT '' CONCAT '';
UPDATE tV SET c2 = 'A' CONCAT 'B';
UPDATE tV SET c2 = '' CONCAT 'A' CONCAT 'B';
UPDATE tV SET c2 = '' CONCAT 'A' CONCAT '';
UPDATE tV SET c2 = ' ' CONCAT ' ';
UPDATE tV SET c2 = '' CONCAT ' ';
UPDATE tV SET c2 = ' ' CONCAT '';

-- END TEST >>> 5BASIC0391-5BASIC0430 <<< END TEST
-- ***********************************************

-- ********************************************************* 
-- 5BASIC0431-5BASIC0430
-- ********************************************************* 
-- TEST:5BASIC0431-5BASIC0410 UPDATE tC SET one column = CONCAT columns
-- PASS:5BASIC0431-5BASIC0410 expected failure accure                  


