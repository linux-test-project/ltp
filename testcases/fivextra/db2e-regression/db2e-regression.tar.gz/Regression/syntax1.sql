-- ----------------- FILE: SYNTAX1.SQL  -------------------
-- -                                                      - 
-- -          CHECK ALL STANDARD SQL SYNTAX ERROR         -
-- -                                                      -
-- --------------------------------------------------------
--

-- --------------------------------------------------------

DROP TABLE STAFF;
DROP TABLE PROJ;
DROP TABLE WORKS;

-- --------------------------------------------------------
-- INITIALIZE THE TABLES
-- --------------------------------------------------------

CREATE TABLE STAFF
   (EMPNUM   CHAR(3) NOT NULL PRIMARY KEY,
    EMPNAME  CHAR(20),
    GRADE    DECIMAL(4,0),
    CITY     CHAR(15));


CREATE TABLE PROJ
   (PNUM     CHAR(3) NOT NULL PRIMARY KEY,
    PNAME    CHAR(20),
    PTYPE    CHAR(6),
    BUDGET   DECIMAL(9,0),
    CITY     CHAR(15));


CREATE TABLE WORKS
   (EMPNUM   CHAR(3) NOT NULL,
    PNUM     CHAR(3) NOT NULL,
    HOURS    DECIMAL(5,0));


INSERT INTO STAFF VALUES ('E1','Alice',12,'Deale');
INSERT INTO STAFF VALUES ('E2','Betty',10,'Vienna');
INSERT INTO STAFF VALUES ('E3','Carmen',13,'Vienna');
INSERT INTO STAFF VALUES ('E4','Don',12,'Deale');
INSERT INTO STAFF VALUES ('E5','Ed',13,'Akron');

INSERT INTO PROJ VALUES  ('P1','MXSS','Design',10000,'Deale');
INSERT INTO PROJ VALUES  ('P2','CALM','Code',30000,'Vienna');
INSERT INTO PROJ VALUES  ('P3','SDP','Test',30000,'Tampa');
INSERT INTO PROJ VALUES  ('P4','SDP','Design',20000,'Deale');
INSERT INTO PROJ VALUES  ('P5','IRM','Test',10000,'Vienna');
INSERT INTO PROJ VALUES  ('P6','PAYR','Design',50000,'Deale');

INSERT INTO WORKS VALUES  ('E1','P1',40);
INSERT INTO WORKS VALUES  ('E1','P2',20);
INSERT INTO WORKS VALUES  ('E1','P3',80);
INSERT INTO WORKS VALUES  ('E1','P4',20);
INSERT INTO WORKS VALUES  ('E1','P5',12);
INSERT INTO WORKS VALUES  ('E1','P6',12);
INSERT INTO WORKS VALUES  ('E2','P1',40);
INSERT INTO WORKS VALUES  ('E2','P2',80);
INSERT INTO WORKS VALUES  ('E3','P2',20);
INSERT INTO WORKS VALUES  ('E4','P2',20);
INSERT INTO WORKS VALUES  ('E4','P4',40);
INSERT INTO WORKS VALUES  ('E4','P5',80);

-- COMMIT WORK;

SELECT COUNT(*) FROM PROJ;
-- PASS:Setup if count = 6?

SELECT COUNT(*) FROM STAFF;
-- PASS:Setup if count = 5?

SELECT COUNT(*) FROM WORKS;
-- PASS:Setup if count = 12?


-- ********************************************************* 
-- DML001 
-- ********************************************************* 

-- TEST:0001 SELECT with ORDER BY DESC!
-- PASS:0001 If 4 rows selected and last EMPNUM = 'E1'?

SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM='P2' ORDER BY EMPNUM DESC;

-- END TEST >>> 0001 <<< END TEST
-- ********************************************************* 


-- TEST:0002 SELECT with ORDER BY integer ASC!
-- PASS:0002 If 4 rows selected and last HOURS = 80?

SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM='P2' ORDER BY 2 ASC;

-- END TEST >>> 0002 <<< END TEST
-- *********************************************************


-- ********************************************************* 
-- DML019 
-- ********************************************************* 

-- TEST:0074 GROUP BY col with SELECT col., SUM!
-- PASS:0074 If 6 rows are selected?
-- PASS:0074 If PNUMs: 'P1', 'P2', 'P3', 'P4', 'P5', 'P6'?
-- PASS:0074 If SUM(HOURS) for 'P2' is 140 ?

SELECT PNUM, SUM(HOURS) FROM WORKS GROUP BY PNUM;

-- END TEST >>> 0074 <<< END TEST
-- **********************************************************

-- TEST:0075 GROUP BY clause!
-- PASS:0075 If 4 rows are selected with EMPNUMs: 'E1','E2','E3','E4'?

SELECT EMPNUM FROM WORKS GROUP BY EMPNUM;

-- END TEST >>> 0075 <<< END TEST
-- ************************************************************

-- TEST:0076 GROUP BY 2 columns!
-- PASS:0076 If 10 rows are selected and EMPNUM = 'E1' in 4 rows ?
-- PASS:0076 for 1 row EMPNUM = 'E1' and HOURS = 12?

SELECT EMPNUM,HOURS FROM WORKS GROUP BY EMPNUM,HOURS;

-- END TEST >>> 0076 <<< END TEST
-- ***********************************************************

-- TEST:0077 GROUP BY all columns with SELECT * !
-- PASS:0077 If 12 rows are selected ?

SELECT * FROM WORKS GROUP BY PNUM,EMPNUM,HOURS;

-- END TEST >>> 0077 <<< END TEST
-- ***********************************************************

-- TEST:0078 GROUP BY three columns, SELECT two!
-- PASS:0078 If 12 rows are selected  ?

SELECT PNUM,EMPNUM FROM WORKS GROUP BY EMPNUM,PNUM,HOURS;

-- END TEST >>> 0078 <<< END TEST
-- *********************************************************

-- TEST:0079 GROUP BY NULL value!

-- SETUP
-- PASS:0079 If 1 row is inserted?
INSERT INTO STAFF(EMPNUM,EMPNAME,GRADE) VALUES('E6','WANG',40);

-- PASS:0079 If 1 row is inserted?
INSERT INTO STAFF(EMPNUM,EMPNAME,GRADE) VALUES('E7','SONG',50);
              
-- PASS:0079 If SUM(GRADE) = 90?
SELECT SUM(GRADE) FROM STAFF WHERE CITY IS NULL GROUP BY CITY;

-- RESTORE
-- PASS:0079 If 2 rows deleted?
DELETE FROM STAFF WHERE CITY IS NULL;

-- PASS:0079 If count = 5?
SELECT COUNT(*) FROM STAFF;

-- END TEST >>> 0079 <<< END TEST
-- *********************************************************

