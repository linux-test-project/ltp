-- ------------------- FILE: TD09.SQL  --------------------
-- -                                                      - 
-- -                   General Testing                    -
-- -                                                      -
-- --------------------------------------------------------
-- 

DROP TABLE DEMANDTABLE;
DROP TABLE TUTORTABLE;
DROP TABLE USERTABLE;

-- if insert an empty string to a char/varchar column and 
-- issue a select query using like '%' in the where clause
-- then the row with empty string should be returned
drop table tb1;
drop table tb2;
create table tb1(a varchar(10));
create table tb2(a char(10));
insert into tb1 values('');
insert into tb2 values('');
select * from tb1 where a like '%';
select * from tb1 where a like '%';
insert into tb1 values('abc');
insert into tb2 values('def');
select * from tb1 where a like '%';
select * from tb2 where a like '%';
insert into tb1 values('');
insert into tb1 values('abcde');
insert into tb1 values(' ');
select * from tb1 where a = '';
select * from tb1 where a like '';
select * from tb1 where a like '%';
select * from tb1 where a like '%%%%%%';
select * from tb1 where a like '_';
select * from tb1 where a like '%abc%';
drop table tb2;
drop table tb1;


-- Valid date/timstamp string is a character string that starts with a digit and has a length of at least 8 -- characters. Trailing blanks may be included; leading zeros may be omitted from the month and day portions. 
-- following is to test the correctness of date/timstamp string format accepted by db2e
drop table tt;
create table tt (a timestamp);
insert into tt values('0001-01-21-12.22.23.000005');
insert into tt values('0000-01-21-12.22.23.000005');
insert into tt values('9999-01-21-12.22.23.000005');
insert into tt values('10000-01-21-12.22.23.000005');
insert into tt values ('0001-04-30-09.27.29.272000');
insert into tt values ('0001-1-1-09.27.29.272000');
insert into tt values ('0001-01-1-09.27.29.272000');
insert into tt values ('0001-1-01-09.27.29.272000');
insert into tt values ('0001-01-01-09.27.29.272000');
insert into tt values ('1-04-30-09.27.29.272000');  

drop table tb;
create table tb (a date);
insert into tb values('0001-01-21');
insert into tb values('0000-01-21');
insert into tb values('9999-01-21');
insert into tb values('10000-01-21');
insert into tb values ('0001-04-30');
insert into tb values ('0001-1-1');
insert into tb values ('0001-01-1');
insert into tb values ('0001-1-01');
insert into tb values ('0001-01-01');
insert into tb values ('1-04-30');  

drop table tt;
drop table tb;

