-- ------------------- FILE: TD09.SQL  --------------------
-- -                                                      - 
-- -                   General Testing                    -
-- -                                                      -
-- --------------------------------------------------------
-- 

-- testcase 1 - for the data corruption problem 
drop table t1;
create table t1 (c1 varchar(40));
create index idx1 on t1(c1);
insert into t1 values (null);
update t1 set c1='';
select * from t1;
select * from t1 order by c1;
select * from t1 where c1 = '';
update t1 set c1='yipyipyipyipyip';
select * from t1;
select * from t1 order by c1;
select * from t1 where c1 = 'yipyipyipyipyip';


--testcase 2 - for the index corruption problem
drop table Orders;
create table Orders (ORDERID INTEGER  PRIMARY KEY NOT NULL,COMPLETED INTEGER,COMPANY CHARACTER(2),CUSTOMERNUM VARCHAR(20), EMAIL VARCHAR(80),BILLCITY VARCHAR(40),BILLSTATE CHARACTER(2),BILLZIP VARCHAR(10),CCNUMBER VARCHAR(32),CCNAME VARCHAR(40),CCEXPDATE VARCHAR(19),PLACEDDATE VARCHAR(19),DATESHIPPED VARCHAR(19), CREATEDATE VARCHAR(19),COMMENTS VARCHAR(256),SALESPERSON	CHARACTER(3),REFNUM VARCHAR(40));
create index OR_REF on Orders(REFNUM);
insert into Orders (ORDERID) values (1);
update Orders set REFNUM='' where orderid=1;
select refnum from orders where refnum = '';
select * from orders;
select * from orders order by refnum;

--clean up
drop table t1;
drop table Orders;