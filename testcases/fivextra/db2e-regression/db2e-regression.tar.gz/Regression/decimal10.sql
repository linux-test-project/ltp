-- ---------------- FILE: DECIMAL10.SQL  -------------------
-- -                                                      - 
-- -     	 CHECK ALL ERROR IN "DECIMAL" DATA TYPE       -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE PROJ;
DROP TABLE PT004;
DROP TABLE STAFF;
DROP TABLE WORKS;

-- following for defect7271
enable physical delete;
CREATE TABLE PSDOMAINS (DOMAINID INT PRIMARY KEY, DOMAINNAME VARCHAR(768), DOMAININIT SMALLINT);
INSERT INTO PSDOMAINS (DOMAINID, DOMAINNAME, DOMAININIT) VALUES(0, 'Bootstrap Domain', 0);
UPDATE PSDOMAINS SET DOMAININIT=1 WHERE DOMAINID=0;
UPDATE PSDOMAINS SET DOMAININIT=0 WHERE DOMAINID=0;
UPDATE PSDOMAINS SET DOMAININIT=1 WHERE DOMAINID=0;
DELETE FROM PSDOMAINS;
INSERT INTO PSDOMAINS (DOMAINID, DOMAINNAME, DOMAININIT) VALUES(0, 'Bootstrap Domain', 1);
INSERT INTO PSDOMAINS (DOMAINID, DOMAINNAME, DOMAININIT) VALUES(1, 'tfitts120398      ', 0);
UPDATE PSDOMAINS SET DOMAININIT=1 WHERE DOMAINID=1;
DELETE FROM PSDOMAINS WHERE DOMAINID=1;
UPDATE PSDOMAINS SET DOMAININIT=0 WHERE DOMAINID=0;
UPDATE PSDOMAINS SET DOMAININIT=1 WHERE DOMAINID=0;
-- this delete will leave the data header free space chain with data even though the file is truncated to a smaller size.
DELETE FROM PSDOMAINS;  
-- this insert will fail because the free space will be picked to be used, but the data file is smaller than that
-- location.
INSERT INTO PSDOMAINS (DOMAINID, DOMAINNAME, DOMAININIT) VALUES(0, 'Bootstrap Domain', 1);
disable physical delete;
drop table PSDOMAINS;
-- test decimal truncation
-- d9594
create table d0 (c1 decimal(5,0) primary key not null);
insert into d0 values (1.1);
insert into d0 values (1.123);
insert into d0 values (1.2);
insert into d0 values (1.0);
insert into d0 values (1.12);
insert into d0 values (3.001);
insert into d0 values (-1.2);
insert into d0 values (null);
insert into d0 values (0.0);
insert into d0 values (2.123456789);
insert into d0 values (100.987654321);
select * from d0;
select * from d0 where c1 = 1.1;
select * from d0 where c1 = 1.0;
select * from d0 where c1 = 1.12;
select * from d0 where c1 = 1.123;
drop table d0;
-----
create table d1 (c1 decimal(8,5));
insert into d1 values (10.000111);
-- should only take 10.00011  (FIRST_MANTISSA_NIBBLE - non0integral + scale)
insert into d1 values (10.0101);
-- should take as is 10.0101  (non0mantissa2 - non0integral + 1)
insert into d1 values (10.01011);
-- should take as is 10.01011 
insert into d1 values (0.000111);
-- should take 0.00011  (scale - (non0mantissa1 - FIRST_MANTISSA_NIBBLE))
insert into d1 values (0.0001);
-- should take as is 0.0001 (non0mantissa2 - non0mantissa1 + 1)
insert into d1 values (null);
select * from d1;
select * from d1 where c1 = 0.000111;
select * from d1 where c1 = 0.00011;
select * from d1 where c1 = 0.0001;
drop table d1;
-----
create table d2 (c1 decimal(5,2));
insert into d2 values (10.123);
insert into d2 values (10.124);
insert into d2 values (10.12);
insert into d2 values (10.1);
insert into d2 values (10.0);
insert into d2 values (10.01);
insert into d2 values (null);
insert into d2 values (-10.10);
insert into d2 values (0.01);
insert into d2 values (0.1);
insert into d2 values (0.0);
insert into d2 values (0.987654321);
insert into d2 values (100.987654321);
insert into d2 values (1000.123);
select * from d2;
select * from d2 where c1 = 10.12;
select * from d2 where c1 = 10.123;
select * from d2 where c1 = 10.124;
select * from d2 where c1 > 10.12;
select * from d2 where c1 < 10.12;
select * from d2 where c1 >= 10.12;
select * from d2 where c1 <= 10.12;
select * from d2 where c1 <> 10.12;
create index d2idx on d2(c1);
select * from d2 where c1 = 10.12;
select * from d2 where c1 = 10.123;
select * from d2 where c1 = 10.124;
select * from d2 where c1 > 10.12;
select * from d2 where c1 < 10.12;
select * from d2 where c1 >= 10.12;
select * from d2 where c1 <= 10.12;
select * from d2 where c1 <> 10.12;
drop index d2idx;
drop table d2;
-----
create table s1 ( a int, b decimal (5,2));
insert into s1 values (1, 123.991);
insert into s1 values (2, 123.992);
select * from s1;
-- no row is selected
select * from s1 where b = 123.991;
select * from s1 where b = 123.992;
-- both rows are selected
select * from s1 where b = 123.99;
select * from s1 where b > 123.989;
select * from s1 where b < 123.993;
insert into s1 values (3, 123.9899);
insert into s1 values (4, 123.9);
insert into s1 values (5, 123.);
insert into s1 values (6, 0.0);
insert into s1 values (7, 0.01);
insert into s1 values (8, 0.011);
insert into s1 values (9, 0.019);
insert into s1 values (10, 0.009);
select * from s1;
create table s2 (a decimal (10, 5));
insert into s2 select b from s1;
select * from s2;
insert into s2 select -1*b from s1;
select * from s2;
drop table s1;
drop table s2;
-----
create table d3 (a decimal(5,2));
insert into d3 values (1.123);
insert into d3 values (2.23);
create table d4 (a decimal(5,3));
insert into d4 select * from d3;
select * from d4;
drop table d3;
drop table d4;
-----
create table tt (c1 decimal (5,2) primary key not null, c2 decimal(5,2));
insert into tt values (1.123, 1.123);
insert into tt values (1.124, 1.124); 
drop table tt;
-----
create table d1 (pk int, a decimal (5,0));
insert into d1 values (1, 1.);
insert into d1 values (2, 1.1);
insert into d1 values (3, 1.0);
insert into d1 values (4, 1.10);
select * from d1;
insert into d1 values (5, 0.);
insert into d1 values (6, 0.0001);
insert into d1 values (7, 0.101);
insert into d1 values (8, 0.1001);
select * from d1;
insert into d1 values (9, 0.0);
insert into d1 values (10, 0.00010);
select * from d1;
insert into d1 values (11, 2.);
insert into d1 values (12, 2.0001);
insert into d1 values (13, 2.101);
insert into d1 values (14, 2.1001);
select * from d1;
insert into d1 values (15, 2.0);
insert into d1 values (16, 2.00010);
insert into d1 values (17, -1.);
insert into d1 values (18, -1.1);
insert into d1 values (19, -0.);
insert into d1 values (20, -0.0001);
insert into d1 values (21, -0.101);
insert into d1 values (22, -0.1001);
insert into d1 values (23, -0.0);
insert into d1 values (24, -0.00010);
insert into d1 values (25, -2.);
insert into d1 values (26, -2.0001);
insert into d1 values (27, -2.101);
insert into d1 values (28, -2.1001);
insert into d1 values (29, -2.0);
insert into d1 values (30, -2.00010);
create table d2 (pk int, a decimal(10,5));
insert into d2 select * from d1;
select * from d2;
create index idxd1 on d1(a);
select * from d1 order by a;
drop table d1;
drop table d2;
-----
create table t (c1 int not null, c2 char(10), c3 decimal(10,2));

create index ti on t ($dirty);

insert into t values (1, 'a', 100.12);

select c1, c2, c3, $dirty from t;
enable application set dirty;

update t set c2 = 'b' where c1 = 1;

select c1, c2, c3, $dirty from t;


update t set $dirty = 0;

select c1, c2, c3, $dirty from t;


select c1, c2, c3, $dirty from t where $dirty > 0;



drop table t;
disable application set dirty;
-----
create table t100 (c1 int not null, c2 char(8), c3 decimal(10,2), primary key(c1));
create index ti on t100($dirty);
insert into t100 values (1, 'a', 10.12);
insert into t100 values (2, 'b', 20.12);
enable read deleted;
select c1, c2, c3, $dirty from t100;
select c1, c2, c3, $dirty from t100 where $dirty > 0;
enable application set dirty;
update t100 set c2='aa' where c1=1;
select c1, c2, c3, $dirty from t100;
select c1, c2, c3, $dirty from t100 where $dirty > 0;
delete from t100 where c1=2;
select c1, c2, c3, $dirty from t100 ;
select c1, c2, c3, $dirty from t100 where $dirty > 0;
insert into t100 values (3, 'c', 30.12);
select c1, c2, c3, $dirty from t100 ;
select c1, c2, c3, $dirty from t100 where $dirty > 0;
drop table t100;
disable read deleted;
disable application set dirty;

