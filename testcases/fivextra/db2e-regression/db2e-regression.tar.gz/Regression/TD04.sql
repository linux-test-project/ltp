-- ------------------- FILE: TD04.SQL  --------------------
-- -                                                      - 
-- -               UPDATE DATA IN TABLES                  -
-- -                                                      -
-- --------------------------------------------------------


update UserTable set Age=100 where UserId is null;
select * from UserTable;

update UserTable set Name='Chow' where Name='Jyh-Herng';
select * from UserTable;

update UserTable set Age=null where Name is null;
select * from UserTable;

update UserTable 
  set Age=10 
  where Age >3 and Age <9;
select * from UserTable;

update UserTable set Age=null where Name is null;
select * from UserTable;
-- 
update TutorTable
  set Subject='Dummy Item 0'
  where Subject='Dummy Item 1';
select * from TutorTable;

update TutorTable set Subject='Dummy Items' where Subject like '%ummy It%';
select * from TutorTable;
