-- ------------------- FILE: CHAR10.SQL  -------------------
-- -                                                      - 
-- -         CHECK ALL ERROR IN "CHAR" DATA TYPE          -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE TABLENAMEHAS19CHARS;