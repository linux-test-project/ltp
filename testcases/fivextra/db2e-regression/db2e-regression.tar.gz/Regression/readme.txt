The SQL test cases is designed to illustrate a network of knowledge. The network consists
of a set of persons willing to share knowledge with other persons in the network. Each
person is uniquely identified by a UserId, and is referenced by name and age. Each person
may request a subject that he/she want to learn. And finally each person can teach
any other person who desired to learn one subject. 

The database represented these test cases is composed of 3 tables:
 - User Table with 3 columns (UserId, Name, Age) which describes the set of persons in the
   network.
 - Demand Table with 2 columns (User Id, Subject) which describes the list of subjects
   that one person wish to learn.
 - Tutor Table with 3 columns (Teacher, Student, Subject) which describes the interactions
   between to persons in the network in order to share a knowledge about one subject.

Following are the list of test cases:
 - Test 0: Delete all 3 tables
 - Test 1: Create all 3 tables
 - Test 2: Insert initial data into all 3 tables
 - Test 3: Perform some query into these tables
 - Test 4: Update data in these tables
 - Test 5: Delete data from these tables
 - Test 6: Perform some join operations
 - Test 7: Perform some sorted joins operations
 - Test 8: Force a duplicate user and do distinct joins ???
