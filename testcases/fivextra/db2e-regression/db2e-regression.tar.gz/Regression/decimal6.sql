-- ----------------- FILE: DECIMAL6.SQL  ------------------
-- -                                                      - 
-- -       CHECK ALL ERROR IN "DROP TABLE" STATEMENT      -
-- -                                                      -
-- --------------------------------------------------------
--

-- ------------------  PERFORMANCE TEST  ------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  6PT001  -----------------------
-- --------------------------------------------------------
-- DELETE VALUES IN "STAFF" TABLE  
-- UDB2 RESULT = SUCC

DROP TABLE STAFF;



-- --------------------------------------------------------
-- -----------------------  6PT002  -----------------------
-- --------------------------------------------------------
-- DELETE VALUES IN "PROJ" TABLE  
-- UDB2 RESULT = SUCC

DROP TABLE PROJ;


-- --------------------------------------------------------
-- -----------------------  6PT003  -----------------------
-- --------------------------------------------------------
-- DELETE VALUES IN "WORKS" TABLE 
-- UDB2 RESULT = SUCC

DROP TABLE WORKS;


-- --------------------------------------------------------
-- -----------------------  6PT004  -----------------------
-- --------------------------------------------------------
-- DELETE VALUES IN "TMP1" TABLE 
-- UDB2 RESULT = SUCC

DROP TABLE TMP1;


-- --------------------------------------------------------
-- -----------------------  6PT005  -----------------------
-- --------------------------------------------------------
-- DELETE VALUES IN "TMP2" TABLE 
-- UDB2 RESULT = SUCC

DROP TABLE TMP2;




-- --------------------------------------------------------
-- ------------  SYNTAX ERROR TEST (SPELLING)  ------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  6SP001  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "DROP"
-- UDB2 RESULT = 42601

DOP TABLE TMP4;


-- --------------------------------------------------------
-- -----------------------  6SP002  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "TABLE"
-- UDB2 RESULT = 42601

DROP ABLE TMP4;




-- --------------------------------------------------------
-- -----  SYNTAX ERROR TEST (EXTRA OR MISSING WORD)  ------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  6EW001  -----------------------
-- --------------------------------------------------------
-- WORD "DELETE" IS MISSING
-- UDB2 RESULT = 42601

TABLE TMP4;


-- --------------------------------------------------------
-- -----------------------  6EW002  -----------------------
-- --------------------------------------------------------
-- WORD "FROM" IS MISSING
-- UDB2 RESULT = 42601

DROP TMP4;


-- --------------------------------------------------------
-- -----------------------  6EW003  -----------------------
-- --------------------------------------------------------
-- TABLE NAME IS MISSING
-- UDB2 RESULT = 42601

DROP TABLE;


-- --------------------------------------------------------
-- -----------------------  6EW004  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "DROP"
-- UDB2 RESULT = 42601

FAILED DROP TABLE TMP4;


-- --------------------------------------------------------
-- -----------------------  6EW005  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "TABLE"
-- UDB2 RESULT = 42601

DROP FAILED TABLE TMP4;


-- --------------------------------------------------------
-- -----------------------  6EW006  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF TABLE NAME
-- UDB2 RESULT = 42601

DROP TABLE FAILED TMP4;


-- --------------------------------------------------------
-- -----------------------  6EW007  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" AFTER TABLE NAME
-- UDB2 RESULT = 42601

DROP TABLE TMP4 FAILED;



-- --------------------------------------------------------
-- ---------  SYNTAX ERROR TEST (CASE SENSITIVE)  ---------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  6CS001  -----------------------
-- --------------------------------------------------------
-- CHECK IF "DROP" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

DrOp TABLE TMP4;


-- --------------------------------------------------------
-- -----------------------  6CS002  -----------------------
-- --------------------------------------------------------
-- CHECK IF "TABLE" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

DROP TaBlE TMP5;


-- --------------------------------------------------------
-- -----------------------  6CS003  -----------------------
-- --------------------------------------------------------
-- CHECK IF TABLE NAME IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

DROP TABLE TmP6;




-- --------------------------------------------------------
-- ---------  SYNTAX ERROR TEST (WRONG COMMAND)  ----------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  6WC001  -----------------------
-- --------------------------------------------------------
-- REPLACE "DROP TABLE" WITH "CREATE TABLE"
-- UDB2 RESULT = 42601

CREATE TABLE TMP4;


-- --------------------------------------------------------
-- -----------------------  6WC002  -----------------------
-- --------------------------------------------------------
-- REPLACE "DROP TABLE" WITH "INSERT"
-- UDB2 RESULT = 42704

INSERT INTO TMP4;


-- --------------------------------------------------------
-- -----------------------  6WC003  -----------------------
-- --------------------------------------------------------
-- REPLACE "DROP TABLE" WITH "SELECT"
-- UDB2 RESULT = 42601

SELECT TMP4;


-- --------------------------------------------------------
-- -----------------------  6WC004  -----------------------
-- --------------------------------------------------------
-- REPLACE "DROP TABLE" WITH "DELETE"
-- UDB2 RESULT = 42601

DELETE TMP4;


-- --------------------------------------------------------
-- -----------------------  6WC005  -----------------------
-- --------------------------------------------------------
-- REPLACE "DROP TABLE" WITH "UPDATE"
-- UDB2 RESULT = 42704

UPDATE TMP4;




-- --------------------------------------------------------
-- -----------------  SEMATIC ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  6ST001  -----------------------
-- --------------------------------------------------------
-- DROP UNKNOWN TABLE
-- UDB2 RESULT = 42704

DROP TABLE ST601;



-- ----------------  RUN-TIME ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  6RT001  -----------------------
-- --------------------------------------------------------
-- TO BE DETERMINED



-- --------------------------------------------------------
-- ------------------  LIMITATION TEST  -------------------
-- --------------------------------------------------------
--
-- NUMBER OF CHARACTERS ALLOWED IN A TABLE NAME, 
-- PLEASE REFER TO ERR001.SQL
--

-- --------------------------------------------------------
-- ------- FOLLOWING ARE ADDED TO TEST BIG DECIMAL --------
-- --------------------------------------------------------
-- ----------------- FILE: BIGDECIMAL.SQL -------------------
-- THIS TEST IS TO CHECK IF DECIMAL DATA UPTO 31 DIGIT ------
-- IS PROPERLY SUPPORTED                               ------
-- ----------------------------------------------------------

DROP TABLE tE;
DROP TABLE tA;

-- --------------------------------------------------------
-- INITIALIZE THE TABLES
-- --------------------------------------------------------

-- EXPECT FAILURE IN THE FOLLOWING
CREATE TABLE tA (C1 DECIMAL(32,5));
CREATE TABLE tA (C1 DECIMAL(32,32));

CREATE TABLE tE (c1 DECIMAL(31,30), c2 DECIMAL(31,0), 
                 c3 DECIMAL(31,16), C4 DECIMAL(15,5));

-- INSERT DATA INTO TABLE

-- INT VALUE IS EXPECTED TO BE ACCEPTED
INSERT INTO tE VALUES (-.11111, +22222, 33333.55555, 123.45); 
                        
INSERT INTO tE VALUES (-.0, +123456789., +.0, +1.00);

-- FOLLOWING INSERT EXPECT THE SAME EFFECT AS ABOVE 
INSERT INTO tE VALUES (+.0, +123456789., -.0, -1.00); 

INSERT INTO tE VALUES (.000000000000000000000000000009, 
                       1111111111111111111111111111111.,
                       777777777777777.8888888888888888,
                       101.02);

-- INSERT SOME NULL VALUE IN THE FOLLOWING AND CREATE INDEX                                      
INSERT INTO tE VALUES(NULL, 55555., 9.9, 7777777.77777);

INSERT INTO tE VALUES(.11111, NULL, 66666.66666, -9.9);

INSERT INTO tE VALUES(.11111, 55555., NULL, 7777777.77777);

INSERT INTO tE VALUES(.11111, 55555., 66666.66666, NULL);
 
--create index Ind1 on tE (c3 desc);

create index Ind2 on tE (c4 Asc); 

-- TESTING SELECT
select * from tE where c3 >= 9.9;
select * from tE where c3 >= -9.9;
select * from tE where c3 < 9.9;
select * from tE where c3 < -9.9;
select * from tE where c3 is NULL;
select * from tE where c3 is NOT NULLl;

select * from tE where c4 >= 9.9;
select * from tE where c4 >= -9.9;
select * from tE where c4 < 9.9;
select * from tE where c4 < -9.9;
select * from tE where c4 is NULL;
select * from tE where c4 is NOT NULL;

select * from tE where c3 >= .00001;
select * from tE where c3 >= -.00001;
select * from tE where c3 < .00001;
select * from tE where c3 < -.00001;
select * from tE where c3 is NULL;
select * from tE where c3 is NOT NULL;

select * from tE where c1 >= 0 and c1 < .999999999 order by c1;

SELECT * FROM tE;

SELECT c2,c1,c3 FROM tE;

-- go through the index on c3
select * from te where c3 = 777777777777777.8888888888888888;
select * from te where c3 = 777777777777777.888888888888888;
select * from te where c3 = .000000000000000000000000000009;

-- test DISTINCT on decimal columns
SELECT DISTINCT * FROM tE;

SELECT DISTINCT c2,c1,c3 FROM tE;

SELECT DISTINCT c1,c3 FROM tE WHERE c1 = c3;

SELECT DISTINCT c1,c3 FROM tE  WHERE c1 <> c3;

SELECT DISTINCT c4,c1,c3 FROM tE WHERE c3 < 99999 OR c4 >= -1.00 OR c1 < 1.23456;

SELECT DISTINCT c2,c3,c1 FROM tE WHERE c1 < .000001 AND C2 > 11111.;

SELECT DISTINCT c3,c4,c2 FROM tE WHERE C2 IS NOT NULL AND C1 < .000001 OR
                                       C3 IS NOT NULL AND C4 <= 123.45 ;

-- test limit clause
SELECT * FROM tE LIMIT 3;

-- orderby on big decimal columns
SELECT * FROM tE ORDER BY 1;

SELECT * FROM tE ORDER BY 2;

SELECT * FROM tE ORDER BY 3;

SELECT * FROM tE ORDER BY 2,1;

SELECT * FROM tE ORDER BY 3,2;

-- groupby on big decimal columns
SELECT COUNT(c1),AVG(c1),SUM(c1),MIN(c1),MAX(c1) FROM tE;
SELECT COUNT(c2),AVG(c2),SUM(c2),MIN(c2),MAX(c2) FROM tE;
SELECT COUNT(c3),AVG(c3),SUM(c3),MIN(c3),MAX(c3) FROM tE;

SELECT c1, sum(c2), avg(c3) FROM tE GROUP BY c1;

SELECT c2, sum(c1), min(c3) FROM tE GROUP BY c2;

SELECT c3, sum(c2), max(c1) FROM tE GROUP BY c3;

SELECT c1, c2,  avg(c3) FROM tE GROUP BY c1, c2;

-- arithmetics on big decimal columns
SELECT c1-c1+c1-c1+c1 FROM tE;

SELECT c2+c2-c2+c2-c2 FROM tE;
 
SELECT c1-c1,c1/c1,c1*1,1*c1 FROM tE;

SELECT c2+c2,c2/c2,c2*1,1*c2 FROM tE;

-- TEST UPDATE

UPDATE tE SET C3 = 12345.12345 WHERE C4 = -9.9;

select * from te;

UPDATE tE SET C3 = 12345 WHERE C4 = -9.9;

select * from te;

UPDATE tE SET C2 = 7777777 WHERE C2 = 22222;

select * from te;

-- TEST DELETE

DELETE FROM tE WHERE C3 = 66666.66666;

select * from te;

DELETE FROM tE WHERE c3 < 99999. OR c4 >= -1.00; 

select * from te;

drop table tE;

-------------

CREATE TABLE tE (c1 DECIMAL(31,30) not null, c2 DECIMAL(31,0) not null, 
                 c3 DECIMAL(31,16), C4 DECIMAL(15,5), primary key (c1, c2));


INSERT INTO tE VALUES (-.11111, +22222, 33333.55555, 123.45); 
INSERT INTO tE VALUES (-.0, +123456789., +.0, +1.00);
INSERT INTO tE VALUES (.000000000000000000000000000009, 
                       1111111111111111111111111111111.,
                       777777777777777.8888888888888888,
                       101.02);
INSERT INTO tE VALUES(.11111, 55555., NULL, 7777777.77777);
INSERT INTO tE VALUES(.11112, 55555., 66666.66666, NULL);

select * from te where c1 >= .11111; 
select * from te where c1 >= 1;
select * from te where c1 = .11111 and c2 = 55555;

-- one row
select * from te where c1 = .000000000000000000000000000009;

-- no row
select * from te where c1 = .000000000000000000000000000008;
-- no row
select * from te where c1 = .00000000000000000000000000009;

-- these should fail
INSERT INTO tE VALUES(.11112, 55555., 66666.66666, NULL);
INSERT INTO tE VALUES(null, 55555., 66666.66666, NULL);
INSERT INTO tE VALUES(.11112, null, 66666.66666, NULL);

select * from te;

drop table tE;

