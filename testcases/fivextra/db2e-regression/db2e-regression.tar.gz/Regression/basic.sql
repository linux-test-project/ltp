
--------------------------------------------------------------------------------
-- CREATING TABLES FOR BASIC TESTING
--------------------------------------------------------------------------------

CREATE TABLE Person 
(	SSN Char(9) PRIMARY KEY NOT NULL, 
	LastName Varchar(20), 
	FirstName Varchar(20),
  	MiddleInitial Char(1), 
	StreetAddress Varchar(50), 
	City Varchar(20), 
	State Char(2), 
	ZIP Char(5),
  	HomePhone Varchar(20), 
	WorkPhone Varchar(20), 
	MobilePhone Varchar(20)
);

CREATE TABLE MedicalRecord 
(
	RecordID Integer PRIMARY KEY NOT NULL, 
	Date_C Date, 
	Time_C Time,
  	PatientID Varchar(9), 
	BloodPressure Char(7), 
	PulseRate Smallint, 
	Temperature Decimal(4,1),
  	Weight Decimal(5,2), 
    Comments VarChar(60)
);

CREATE TABLE Contact 
(
	PatientID Char(9), 
	ContactID Char(9), 
	LastName Varchar(20), 
	FirstName Varchar(20), 
	Relationship Varchar(10)
);

CREATE TABLE Schedule 
(
	NurseID Varchar(9), 
	PatientID Varchar(9), 
	LastName Varchar(20), 
	FirstName Varchar(20), 
	Date_C Date, 
	Time_C Time
);

--------------------------------------------------------------------------------
-- INSERTING DATA INTO TABLES FOR BASIC TESTING
--------------------------------------------------------------------------------

INSERT INTO Person values ('900000001',	'Siekawitch', 	'Harris',	'A',	'51 7TH ST', 			'Seattle', 		'WA', '20005', '(202)783-4946', '(202)749-7506', '(202)442-3030');
INSERT INTO Person values ('900000101',	'Hass',			'Christine','H', 	'P.O. BOX 292', 		'Levittown', 	'PA', '19055', '(215)945-9168', '(215)664-0900', '(215)305-2591');
INSERT INTO Person values ('900000201',	'Thompson', 	'Michael', 	'Q',	'24299 GROVEN LN',		'Joaquin',		'TX', '75954', '(409)269-1655',	'(409)269-7410', '(409)305-6359');
INSERT INTO Person values ('900000301',	'Kwan', 		'Sally', 	'M',	'987 SPENCR HL RD',		'Midvale',		'OH', '44653', '(216)339-0537',	'(216)269-1548', '(216)898-6483');
INSERT INTO Person values ('900000401',	'Henderson', 	'Eileen', 	'J',	'1201 SABINE CT',		'Los Angeles',	'CA', '90061', '(213)755-4041',	'(213)945-3602', '(213)265-4350');
INSERT INTO Person values ('900000501',	'Clay', 		'Bradly', 	'V',	'7318 KINGSLAND DR',	'Grafton',		'WV', '26354', '(304)265-0836',	'(304)254-9374', '(304)897-1020');
INSERT INTO Person values ('900000601',	'Lucchessi', 	'Vincenzo', 'U',	'HC 1 BOX 13',			'Effingham',	'SC', '29541', '(803)665-4021',	'(803)664-7348', '(803)894-3199');
INSERT INTO Person values ('900000701',	'Walker', 		'Sean', 	'M',	'220 E SCHUETZ ST',		'Woodruff',		'WI', '54568', '(715)358-4484',	'(715)227-8281', '(715)339-4734');
INSERT INTO Person values ('900000801',	'Quintana', 	'Dolores', 	'B',	'175 LITTLETON RD',		'Norfolk',		'VA', '23517', '(804)622-1999',	'(804)945-6418', '(804)476-7938');

INSERT INTO Person values ('900000901',	'Yoshimura', 	'Masatoshi','K',	'4340-18TH',			'Effingham',	'SC', '29541', '(803)665-3788',	'(803)476-8127', '(803)339-0467');
INSERT INTO Person values ('900001001',	'Scoutten', 	'Marilyn', 	'K',	'8326 PORTSMOUTH DR',	'Nine Falls',	'WA', '99026', '(509)467-4893',	'(509)567-4648', '(509)764-2483');
INSERT INTO Person values ('900001101',	'Acevedo', 		'Marcos', 	'X',	'24299 GROVEN LN',		'New Market',	'MN', '55054', '(612)461-2421',	'(612)567-4310', '(612)575-6617');
INSERT INTO Person values ('900001201',	'Shenton', 		'Sarah', 	'L',	'6320 W PAINT BRUSH TR','Columbus',		'OH', '43204', '(614)274-9514',	'(614)476-4309', '(614)254-7616');
INSERT INTO Person values ('900001301',	'Brown', 		'David',	'A',	'175 LITTLETON RD',		'Lyndonville',	'NY', '14098', '(716)765-2082',	'(716)898-2929', '(716)945-6541');
INSERT INTO Person values ('900001401',	'Lutz',			'Jennifer',	'H', 	'231-1 2 E MARKET ST',	'Norfolk',		'VA', '23517', '(804)622-1840',	'(804)231-4966', '(804)765-7376');
INSERT INTO Person values ('900001501',	'Parker', 		'John', 	'Q',	'147 W TREMONT AVE',	'Hammonton',	'NJ', '08037', '(609)567-9741',	'(609)837-7529', '(609)381-0778');
INSERT INTO Person values ('900001601',	'Perez', 		'Maria', 	'M',	'220 ARROWHEAD RD',		'Fordland',		'MO', '65652', '(417)738-4604',	'(417)381-3902', '(417)274-0153');
INSERT INTO Person values ('900001701',	'Gounot', 		'Jason', 	'J',	'720 POST LAKE PL',		'Charlotte',	'FL', '33953', '(941)764-3035',	'(941)567-2190', '(941)305-1842');
INSERT INTO Person values ('900001801',	'Lee', 			'Jane', 	'V',	'118 BAKER ST',			'Bay City',		'MI', '48708', '(517)894-5724',	'(517)665-1478', '(517)765-9358');
INSERT INTO Person values ('900001901',	'Smith', 		'Philip', 	'U',	'6320 W PAINT BRUSH TR','Baltimore',	'MD', '21212', '(410)435-6729',	'(410)837-4370', '(410)476-5350');
INSERT INTO Person values ('900002001',	'Schneider', 	'Ethel', 	'M',	'11713 MILBERN DR',		'El Campo',		'TX', '77437', '(409)543-6827',	'(409)461-9961', '(409)242-0491');
INSERT INTO Person values ('900002101',	'Jones', 		'William', 	'B',	'5034 CURTIS CREEK RD',	'Bakersfield',	'CA', '93311', '(805)664-2382',	'(805)374-7421', '(805)533-8716');

INSERT INTO Contact values ('900000001',	'900001201',	'Shenton', 		'Sarah',	'Friend');
INSERT INTO Contact values ('900000001',	'900001101',	'Acevedo', 		'Marcos',	'Boss');
INSERT INTO Contact values ('900000001',	'900001001',	'Scoutten', 	'Marilyn', 	'Sister');
INSERT INTO Contact values ('900000001',	'900000901',	'Yoshimura', 	'Masatoshi','Friend');

INSERT INTO Contact values ('900000101',	'900001501',	'Parker', 		'John',		'Co-Worker');
INSERT INTO Contact values ('900000101',	'900001301',	'Brown', 		'David',	'Uncle');
INSERT INTO Contact values ('900000101',	'900001401',	'Lutz',			'Jennifer',	'Sister');

INSERT INTO Contact values ('900000201',	'900001701',	'Gounot', 		'Jason',	'Co-Worker');
INSERT INTO Contact values ('900000201',	'900001601',	'Perez', 		'Maria',	'Mother');
INSERT INTO Contact values ('900000201',	'900001801',	'Lee', 			'Jane', 	'God-Mother');

INSERT INTO Contact values ('900000301',	'900001901',	'Smith', 		'Philip', 	'Friend');
INSERT INTO Contact values ('900000301',	'900002101',	'Jones', 		'William', 	'Boss');
INSERT INTO Contact values ('900000301',	'900002001',	'Schneider', 	'Ethel', 	'Brother');
INSERT INTO Contact values ('900000301',	'900001201',	'Shenton', 		'Sarah',	'Sister');

INSERT INTO Contact values ('900000401',	'900001101',	'Acevedo', 		'Marcos',	'Friend');
INSERT INTO Contact values ('900000401',	'900001401',	'Lutz',			'Jennifer',	'Co-Worker');
INSERT INTO Contact values ('900000401',	'900000401',	'Henderson', 	'Eileen',	'Boss');
INSERT INTO Contact values ('900000401',	'900002101',	'Jones', 		'William',	'Friend');

INSERT INTO Contact values ('900000501',	'900001801',	'Lee', 			'Jane',		'Co-Worker');
INSERT INTO Contact values ('900000501',	'900001001',	'Scoutten', 	'Marilyn', 	'Sister');
INSERT INTO Contact values ('900000501',	'900001201',	'Shenton', 		'Sarah',	'Friend');
INSERT INTO Contact values ('900000501',	'900001101',	'Acevedo', 		'Marcos',	'Boss');

INSERT INTO Contact values ('900000601',	'900001301',	'Brown', 		'David',	'God-Father');
INSERT INTO Contact values ('900000601',	'900001501',	'Parker', 		'John',		'Co-Worker');
INSERT INTO Contact values ('900000601',	'900001701',	'Gounot', 		'Jason',	'Uncle');
INSERT INTO Contact values ('900000601',	'900001901',	'Smith', 		'Philip',	'Uncle');

INSERT INTO Contact values ('900000701',	'900001101',	'Acevedo', 		'Marcos',	'Brother');
INSERT INTO Contact values ('900000701',	'900001001',	'Scoutten', 	'Marilyn',	'Boss');
INSERT INTO Contact values ('900000701',	'900001201',	'Shenton', 		'Sarah', 	'Friend');
INSERT INTO Contact values ('900000701',	'900001501',	'Parker', 		'John',		'Co-Worker');

INSERT INTO Contact values ('900000801',	'900001101',	'Acevedo', 		'Marcos',	'Brother');
INSERT INTO Contact values ('900000801',	'900001901',	'Smith', 		'Philip',	'Co-Worker');
INSERT INTO Contact values ('900000801',	'900001401',	'Lutz',			'Jennifer',	'Mother');
INSERT INTO Contact values ('900000801',	'900001701',	'Gounot', 		'Jason',	'Uncle');

INSERT INTO Schedule values ('Nurse 1',	'900000001',	'Siekawitch', 	'Harris',	'07/04/1999',	'08:00:00');
INSERT INTO Schedule values ('Nurse 1',	'900000501',	'Clay', 		'Bradly',	'07/04/1999',	'09:00:00');
INSERT INTO Schedule values ('Nurse 1',	'900000701',	'Walker', 		'Sean', 	'07/04/1999',	'10:00:00');
INSERT INTO Schedule values ('Nurse 1',	'900000801',	'Quintana', 	'Dolores',	'07/04/1999',	'11:00:00');
INSERT INTO Schedule values ('Nurse 1',	'900000201',	'Thompson', 	'Michael',	'07/04/1999',	'13:00:00');
INSERT INTO Schedule values ('Nurse 1',	'900000401',	'Henderson', 	'Eileen',	'07/04/1999',	'14:00:00');
INSERT INTO Schedule values ('Nurse 1',	'900000101',	'Haas',			'Christine','07/04/1999',	'15:00:00');
INSERT INTO Schedule values ('Nurse 1',	'900000601',	'Lucchessi', 	'Vincenzo',	'07/04/1999',	'16:00:00');
INSERT INTO Schedule values ('Nurse 1',	'900000301',	'Kwan', 		'Sally',	'07/04/1999',	'17:00:00');

INSERT INTO MedicalRecord values (1,'07/20/1999','09:10:00','900000001','160/95',65,104.2,150.52, 'Emergency! Needs to go to the hospital');
INSERT INTO MedicalRecord values (2,'07/19/1999','19:53:00','900000001','155/90',72,99.5, 175.5,'Seriously ill, should contact relatives.');
INSERT INTO MedicalRecord values (3,'06/13/1999','18:42:00','900000001','130/80',80,100.2,165,'Need to take a day off from work.');
INSERT INTO MedicalRecord values (4,'05/07/1999','17:54:00','900000001','140/83',83,101,160.2,   NULL);
INSERT INTO MedicalRecord values (5,'04/14/1999','14:56:00','900000101','130/84',59,95.4,172,'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (6,'03/15/1999','12:49:00','900000101','120/85',60,103,192,'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (7,'02/07/1999','01:02:00','900000101','115/86',51,109,189,'Seriously ill, should contact relatives');
INSERT INTO MedicalRecord values (8,'07/15/1999','11:02:00','900000201','135/87',73,104.2,169,'Emergency! Needs to go to the hospital.');
INSERT INTO MedicalRecord values (9,'07/13/1999','11:47:00','900000201','180/98',70,90,113,'Suggest move into hospital for better care.');
INSERT INTO MedicalRecord values (10,'06/08/1999','01:17:00','900000301','200/99',55,90,148,'Seriously ill, should contact relatives');
INSERT INTO MedicalRecord values (11,'05/12/1999','16:40:00','900000301','175/80',56,97.0,80.3,'Need to take a day off for work.');
INSERT INTO MedicalRecord values (12,'04/19/1999','00:11:00','900000301','166/81',51,91,113,'Emergency! Needs to go to the hospital.');
INSERT INTO MedicalRecord values (13,'03/19/1999','03:38:00','900000401','175/82',76,94,117,'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (14,'02/17/1999','09:04:00','900000401','152/83',51,96,183,'Need to take a day off from work.');
INSERT INTO MedicalRecord values (15,'01/20/1999','00:50:00','900000401','132/84',72,95,110.2,NULL);
INSERT INTO MedicalRecord values (16,'08/08/1999','03:25:00','900000501','174/85',72,94,171.2,'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (17,'07/08/1999','11:31:00','900000501','165/86',69,90,171,'Need to take a day off from work.');
INSERT INTO MedicalRecord values (18,'06/04/1999','13:44:00','900000501','180/87',68,95,181,'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (19,'05/04/1999','02:46:00','900000601','110/88',77,98,125,NULL);
INSERT INTO MedicalRecord values (20,'04/22/1999','02:03:00','900000601','175/89',60,93,113,'Seriously ill, should contact relatives.');
INSERT INTO MedicalRecord values (21,'03/04/1999','04:46:00','900000701','183/90',51,96,120,NULL);
INSERT INTO MedicalRecord values (22,'02/16/1999','19:20:00','900000701','107/91',60,98,132,NULL);
INSERT INTO MedicalRecord values (23,'01/23/1999','15:47:00','900000701','122/92',54,102,178,'Need to take a day off from work.');
INSERT INTO MedicalRecord values (24,'07/20/1999','11:37:00','900000801','162/93',73,99,180,'Seriously ill, should contact relatives');
INSERT INTO MedicalRecord values (25,'07/06/1999','17:16:00','900000801','163/94',51,99,127,'Suggest move into hospital for better care.');
INSERT INTO MEDICALRECORD VALUES(999,'02/28/2001','23:45','890909087','155/86',76,100.3,175.2,'Temperature rising');
INSERT INTO medicalrecord(date_c,temperature,recordid,time_c,comments,pulserate) 
	   VALUES('06/23/2001',(-1)*(-100 /10)*9,1001,'03:57:00',('this' concat (' is ' concat 'a ')) concat 'test',567/12);

select * from schedule;
select * from contact;
select * from person;
select * from medicalrecord;

--------------------------------------------------------------------------------
-- TESTING UPDATES
--------------------------------------------------------------------------------
-- 10/30/99  akl  created
--
--
--
-------------------------------------------------------------------------------
-- TODO:
-- use functions in where clause
-- use CURRENT_DATE & CURRENT_TIME in expressions
-------------------------------------------------------------------------------

UPDATE contact 
   SET firstname = 'Mickey', lastname = 'Mouse' 
 WHERE firstname concat ' ' concat lastname  LIKE 'David Brown';

 UPDATE contact
    SET lastname = 'Mickey', firstname = 'Mouse' 
  WHERE patientid = '900000001' 
    AND relationship = 'Friend' 
     OR relationship = 'Boss'  
    AND firstname NOT LIKE 'Sarah' 
    AND lastname <> 'Acevedo';

 UPDATE contact
    SET lastname = 'Doo', firstname = 'Scooby' 
  WHERE patientid = '900000001' 
    AND (relationship = 'Friend' OR relationship = 'Boss')  
    AND firstname NOT LIKE 'Sarah' 
    AND lastname <> 'Acevedo';

  SELECT * FROM contact; 

 SELECT * FROM medicalrecord 
  WHERE (-weight/temperature + 0.03 < -0.80 AND weight/temperature < 1.245) 
    AND comments IS NULL;


 SELECT * FROM medicalrecord 
  WHERE (-weight/temperature + 0.03 < -0.80 
    AND weight/temperature < 1.245)
    AND comments IS NOT NULL;

-- UPDATE medicalrecord
--    SET firstname = 'Chacha', lastname = 'Chaudhry'
--  WHERE (-weight/temperature + 0.03 < -0.80 
--    AND weight/temperature < 1.245)
--    AND comments IS NOT NULL;

SELECT * FROM CONTACT;
SELECT * FROM MEDICALRECORD;

--------------------------------------------------------------------------------
-- We messed up table data with updated earlier, so reinitialize tables
--------------------------------------------------------------------------------

DROP TABLE medicalrecord;
DROP TABLE contact;

CREATE TABLE MedicalRecord 
(
	RecordID Integer PRIMARY KEY NOT NULL, 
	Date_C Date, 
	Time_C Time,
  	PatientID Varchar(9), 
	BloodPressure Char(7), 
	PulseRate Smallint, 
	Temperature Decimal(4,1),
  	Weight Decimal(5,2), 
    Comments VarChar(60)
);

CREATE TABLE Contact 
(
	PatientID Char(9), 
	ContactID Char(9), 
	LastName Varchar(20), 
	FirstName Varchar(20), 
	Relationship Varchar(10)
);


INSERT INTO Contact values ('900000001',	'900001201',	'Shenton', 		'Sarah',	'Friend');
INSERT INTO Contact values ('900000001',	'900001101',	'Acevedo', 		'Marcos',	'Boss');
INSERT INTO Contact values ('900000001',	'900001001',	'Scoutten', 	'Marilyn', 	'Sister');
INSERT INTO Contact values ('900000001',	'900000901',	'Yoshimura', 	'Masatoshi','Friend');

--For patient 900000101
INSERT INTO Contact values ('900000101',	'900001501',	'Parker', 		'John',		'Co-Worker');
INSERT INTO Contact values ('900000101',	'900001301',	'Brown', 		'David',	'Uncle');
INSERT INTO Contact values ('900000101',	'900001401',	'Lutz',			'Jennifer',	'Sister');

--For patient 900000201
INSERT INTO Contact values ('900000201',	'900001701',	'Gounot', 		'Jason',	'Co-Worker');
INSERT INTO Contact values ('900000201',	'900001601',	'Perez', 		'Maria',	'Mother');
INSERT INTO Contact values ('900000201',	'900001801',	'Lee', 			'Jane', 	'God-Mother');

--For patient 900000301
INSERT INTO Contact values ('900000301',	'900001901',	'Smith', 		'Philip', 	'Friend');
INSERT INTO Contact values ('900000301',	'900002101',	'Jones', 		'William', 	'Boss');
INSERT INTO Contact values ('900000301',	'900002001',	'Schneider', 	'Ethel', 	'Brother');
INSERT INTO Contact values ('900000301',	'900001201',	'Shenton', 		'Sarah',	'Sister');

--For patient 900000401
INSERT INTO Contact values ('900000401',	'900001101',	'Acevedo', 		'Marcos',	'Friend');
INSERT INTO Contact values ('900000401',	'900001401',	'Lutz',			'Jennifer',	'Co-Worker');
INSERT INTO Contact values ('900000401',	'900000401',	'Henderson', 	'Eileen',	'Boss');
INSERT INTO Contact values ('900000401',	'900002101',	'Jones', 		'William',	'Friend');

-- For patient 900000501
INSERT INTO Contact values ('900000501',	'900001801',	'Lee', 			'Jane',		'Co-Worker');
INSERT INTO Contact values ('900000501',	'900001001',	'Scoutten', 	'Marilyn', 	'Sister');
INSERT INTO Contact values ('900000501',	'900001201',	'Shenton', 		'Sarah',	'Friend');
INSERT INTO Contact values ('900000501',	'900001101',	'Acevedo', 		'Marcos',	'Boss');

-- For patient 900000601
INSERT INTO Contact values ('900000601',	'900001301',	'Brown', 		'David',	'God-Father');
INSERT INTO Contact values ('900000601',	'900001501',	'Parker', 		'John',		'Co-Worker');
INSERT INTO Contact values ('900000601',	'900001701',	'Gounot', 		'Jason',	'Uncle');
INSERT INTO Contact values ('900000601',	'900001901',	'Smith', 		'Philip',	'Uncle');

-- For patient 900000701
INSERT INTO Contact values ('900000701',	'900001101',	'Acevedo', 		'Marcos',	'Brother');
INSERT INTO Contact values ('900000701',	'900001001',	'Scoutten', 	'Marilyn',	'Boss');
INSERT INTO Contact values ('900000701',	'900001201',	'Shenton', 		'Sarah', 	'Friend');
INSERT INTO Contact values ('900000701',	'900001501',	'Parker', 		'John',		'Co-Worker');

-- For patient 900000801
INSERT INTO Contact values ('900000801',	'900001101',	'Acevedo', 		'Marcos',	'Brother');
INSERT INTO Contact values ('900000801',	'900001901',	'Smith', 		'Philip',	'Co-Worker');
INSERT INTO Contact values ('900000801',	'900001401',	'Lutz',			'Jennifer',	'Mother');
INSERT INTO Contact values ('900000801',	'900001701',	'Gounot', 		'Jason',	'Uncle');


INSERT INTO MedicalRecord values (1,	'07/20/1999',	'09:10:00',	'900000001',	'160/95',	65,	104.2,	150.52, 'Emergency! Needs to go to the hospital immediately.');
INSERT INTO MedicalRecord values (2,	'07/19/1999',	'19:53:00',	'900000001',	'155/90',	72,	99.5, 	175.5,	'Seriously ill, should contact relatives immediatel.');
INSERT INTO MedicalRecord values (3,	'06/13/1999',	'18:42:00',	'900000001',	'130/80',	80,	100.2,	165,	'Need to take a day off from work.');
INSERT INTO MedicalRecord values (4,	'05/07/1999',	'17:54:00',	'900000001',	'140/83',	83,	101,	160.2,   NULL);

INSERT INTO MedicalRecord values (5,	'04/14/1999',	'14:56:00',	'900000101',	'130/84',	59,	95.4,	172,	'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (6,	'03/15/1999',	'12:49:00',	'900000101',	'120/85',	60,	103,	192,	'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (7,	'02/07/1999',	'01:02:00',	'900000101',	'115/86',	51,	109,	189,	'Seriously ill, should contact relatives immediatel.');
INSERT INTO MedicalRecord values (8,	'07/15/1999',	'11:02:00',	'900000201',	'135/87',	73,	104.2,	169,	'Emergency! Needs to go to the hospital immediately.');
INSERT INTO MedicalRecord values (9,	'07/13/1999',	'11:47:00',	'900000201',	'180/98',	70,	90,		113,	'Suggest move into hospital for better care.');
INSERT INTO MedicalRecord values (10,	'06/08/1999',	'01:17:00',	'900000301',	'200/99',	55,	90,		148,	'Seriously ill, should contact relatives immediatel.');
INSERT INTO MedicalRecord values (11,	'05/12/1999',	'16:40:00',	'900000301',	'175/80',	56,	97.0,	80.3,		'Need to take a day off for work.');
INSERT INTO MedicalRecord values (12,	'04/19/1999',	'00:11:00',	'900000301',	'166/81',	51,	91,		113,	'Emergency! Needs to go to the hospital immediately.');
INSERT INTO MedicalRecord values (13,	'03/19/1999',	'03:38:00',	'900000401',	'175/82',	76,	94,		117,	'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (14,	'02/17/1999',	'09:04:00',	'900000401',	'152/83',	51,	96,		183,	'Need to take a day off from work.');
INSERT INTO MedicalRecord values (15,	'01/20/1999',	'00:50:00',	'900000401',	'132/84',	72,	95,		110.2,	NULL);
INSERT INTO MedicalRecord values (16,	'08/08/1999',	'03:25:00',	'900000501',	'174/85',	72,	94,		171.2,	'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (17,	'07/08/1999',	'11:31:00',	'900000501',	'165/86',	69,	90,		171,	'Need to take a day off from work.');
INSERT INTO MedicalRecord values (18,	'06/04/1999',	'13:44:00',	'900000501',	'180/87',	68,	95,		181,	'Need a special nurse 24/7.');
INSERT INTO MedicalRecord values (19,	'05/04/1999',	'02:46:00',	'900000601',	'110/88',	77,	98,		125,	NULL);
INSERT INTO MedicalRecord values (20,	'04/22/1999',	'02:03:00',	'900000601',	'175/89',	60,	93,		113,	'Seriously ill, should contact relatives immediatel.');
INSERT INTO MedicalRecord values (21,	'03/04/1999',	'04:46:00',	'900000701',	'183/90',	51,	96,		120,	NULL);
INSERT INTO MedicalRecord values (22,	'02/16/1999',	'19:20:00',	'900000701',	'107/91',	60,	98,		132,	NULL);
INSERT INTO MedicalRecord values (23,	'01/23/1999',	'15:47:00',	'900000701',	'122/92',	54,	102,	178,	'Need to take a day off from work.');
INSERT INTO MedicalRecord values (24,	'07/20/1999',	'11:37:00',	'900000801',	'162/93',	73,	99,		180,	'Seriously ill, should contact relatives immediatel');
INSERT INTO MedicalRecord values (25,	'07/06/1999',	'17:16:00',	'900000801',	'163/94',	51,	99,		127,	'Suggest move into hospital for better care.');


INSERT INTO MEDICALRECORD VALUES(999,'02/28/2001','23:45','890909087','155/86',76,100.3,175.2,'Temperature rising');
INSERT INTO medicalrecord(date_c,temperature,recordid,time_c,comments,pulserate) VALUES('01/02/2000',(-1)*(-100 /10)*9,1001,'23:33:00',('this' concat (' is ' concat 'a ')) concat 'test',567/12);


--------------------------------------------------------------------------------
-- DB2E TEST CASES FOR DELETE STATEMENT (verified on DB2 UDB)
--------------------------------------------------------------------------------

 DELETE FROM schedule 
  WHERE date_c < CURRENT DATE 
    AND patientid NOT LIKE '9%8_1' 
    AND firstname LIKE '%i%';

 SELECT * FROM schedule;

SELECT * FROM medicalrecord 
 WHERE comments IS NULL 
   AND ( ( date_c >= '04/04/1999' 
	       AND date_c <= CURRENT DATE 
	       AND date_c <> current date 
 		   AND temperature = 101
 	     )  OR recordid = 19
       );

DELETE FROM medicalrecord
 WHERE comments IS NULL
   AND ( ( date_c >= '04/04/1999'
	       AND date_c <= CURRENT DATE
	       AND date_c <> CURRENT DATE
	       AND temperature = 101
	     ) OR recordid = 19);

SELECT * FROM SCHEDULE;
SELECT * FROM MEDICALRECORD;

--------------------------------------------------------------------------------
-- TEST SELECT STATEMENTS
--------------------------------------------------------------------------------

SELECT lastname, SSN  
FROM person  
WHERE middleinitial > 'E' AND state <= 'CA' OR NOT state < 'SC'  
ORDER BY lastname; 
 
SELECT +sum(-weight), (max(pulseRate)+min(pulseRate))/2 
FROM medicalrecord 
WHERE (date_c >= '03/03/1999' or time_c > '03:00:00') AND comments IS NOT NULL; 
 
SELECT avg(weight+temperature-pulserate), count(bloodpressure) 
FROM medicalrecord 
WHERE recordid <> 1 AND weight > pulserate OR current date <> date_c OR current time < current time; 
 
SELECT lastname concat ', ' CONCAT firstname 
FROM contact 
WHERE relationship LIKE '%God%' OR contactId IS NULL; 
 
SELECT DISTINCT state, lastname, count(lastname) 
FROM person 
WHERE state > 'PA'
GROUP BY lastname, state 
ORDER BY 3,1, lastname ASC;
 
SELECT middleinitial, count(*) 
FROM person 
WHERE homephone not like '(_16)%' 
GROUP BY middleinitial; 
 
SELECT s1.date_c, count(s2.time_c) 
FROM SCHEDULE AS s2, schedule AS s1 
WHERE s1.lastname > s2.lastname AND s1.patientid > '900000301' 
GROUP BY s1.date_c 
ORDER BY 2, 1;
 
SELECT c.lastname, sum(m.weight) 
FROM PERSON AS p, medicalrecord AS m, contact AS c 
WHERE m.pulserate<60 AND p.lastname=c.lastname AND c.patientid = m.patientid AND m.recordid=5 
GROUP BY c.lastname;
 
SELECT DISTINCT p.lastname, s.firstname 
FROM person AS p, schedule AS s 
WHERE ssn > '900000001' AND p.lastname CONCAT p.firstname = s.lastname CONCAT s.firstname; 
 
SELECT s.patientid, avg(m.temperature / weight) 
FROM schedule AS s, medicalrecord AS m 
WHERE s.patientid = m.patientid OR NOT m.pulserate > weight-100 
GROUP BY s.patientid; 
 
SELECT p.lastname,  max(date_c), min(state concat nurseid)
FROM person as p, schedule s 
WHERE p.lastname > s.lastname AND p.firstname < s.firstname AND p.ssn < '900001501' and p.ssn > '900000201'
GROUP BY p.lastname; 

----------------------------------------------------------------------------------------
-- END OF BASIC TEST / DELETE OR TABLES
----------------------------------------------------------------------------------------

DROP TABLE schedule;
DROP TABLE medicalrecord;
DROP TABLE person;
DROP TABLE contact;

