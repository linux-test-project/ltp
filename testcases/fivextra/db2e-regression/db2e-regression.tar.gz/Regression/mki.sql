--connect to mki;

create table one
(
	a int NOT NULL,
	b smallint NOT NULL,
	c char(7) NOT NULL,
	d char(20),
	PRIMARY KEY(a,b,c)
);

create table two
(
	a int NOT NULL,
	b smallint NOT NULL,
	c char(20),
	PRIMARY KEY(a,b)
);

insert into one values(1,1,'b','test1');
insert into one values(1,1,'i','test1');
insert into one values(1,1,'a','test1');
insert into one values(1,1,'c','test1');
insert into one values(2,1,'b','test1');
insert into one values(2,1,'i','test1');
insert into one values(2,1,'m','test1');
insert into one values(1,1,'o','test1');
insert into one values(1,1,'p','test1');
insert into one values(1,1,'q','test1');
insert into one values(2,1,'a','test1');
insert into one values(8,2,'p','test1');
insert into one values(8,2,'q','test1');
insert into one values(8,7,'l','test1');
insert into one values(8,7,'n','test1');
insert into one values(8,2,'d','test1');
insert into one values(8,2,'e','test1');
insert into one values(8,3,'j','test1');
insert into one values(8,3,'h','test1');
insert into one values(8,7,'b','test1');
insert into one values(2,2,'c','test1');
insert into one values(2,2,'d','test1');


insert into one values(2,7,'b','test1');
insert into one values(2,8,'c','test1');
insert into one values(8,2,'m','test1');
insert into one values(4,1,'b','test1');
insert into one values(1,1,'char-0','test1');
insert into one values(4,1,'i','test1');
insert into one values(4,1,'m','test1');
insert into one values(4,1,'char-0','test1');
insert into one values(2,3,'a','test1');
insert into one values(4,4,'l','test1');
insert into one values(4,4,'n','test1');
insert into one values(8,2,'c','test1');
insert into one values(4,4,'o','test1');
insert into one values(4,4,'p','test1');
insert into one values(4,1,'q','test1');
insert into one values(4,1,'a','test1');
insert into one values(2,1,'char-0','test1');
insert into one values(2,4,'f','test1');
insert into one values(2,4,'l','test1');
insert into one values(2,4,'n','test1');
insert into one values(1,2,'p','test1');
insert into one values(1,2,'q','test1');

insert into one values(1,3,'b','test1');
insert into one values(1,3,'a','test1');
insert into one values(2,7,'l','test1');
insert into one values(1,3,'c','test1');

insert into one values(8,3,'a','test1');
insert into one values(8,8,'c','test1');
insert into one values(2,1,'c','test1');
insert into one values(1,2,'l','test1');
insert into one values(1,2,'m','test1');
insert into one values(8,3,'k','test1');
insert into one values(1,2,'n','test1');
insert into one values(1,2,'c','test1');
insert into one values(1,2,'d','test1');

insert into one values(1,1,'m','test1');
insert into one values(1,1,'f','test1');
insert into one values(1,1,'l','test1');
insert into one values(2,1,'q','test1');
insert into one values(1,1,'n','test1');
insert into one values(4,1,'c','test1');
insert into one values(2,2,'p','test1');
insert into one values(2,2,'q','test1');
insert into one values(2,2,'m','test1');
insert into one values(4,4,'f','test1');
insert into one values(2,7,'n','test1');
insert into one values(2,4,'o','test1');
insert into one values(2,4,'p','test1');
insert into one values(8,3,'g','test1');

insert into two values(1,3,'test1');
insert into two values(1,1,'test1');
insert into two values(2,1,'test1');
insert into two values(8,2,'test1');
insert into two values(8,7,'test1');
insert into two values(8,3,'test1');
insert into two values(2,2,'test1');
insert into two values(2,3,'test1');
insert into two values(2,8,'test1');
insert into two values(4,1,'test1');
insert into two values(4,4,'test1');
insert into two values(2,4,'test1');
insert into two values(1,2,'test1');
insert into two values(2,7,'test1');
insert into two values(8,8,'test1');



 
 select a,b
 from one 
 where a > 2 and b > 3;
 
 select a,b,c
 from one
 where a = 4 and b > 2 and c > 'i';
 
 select a,b,c
 from one
 where a < 4 and b > 5 and c < 'n';
 
 select *
 from one
 where a > b + 2;
 
 select *
 from one
 where b > 2 and c > 'f';
 
 select o.a,o.b,t.c
 from one as o,two as t
 where o.a = t.a
   and o.b > t.b
   and o.a > 5
   and o.b > 3
   and o.c > 'char-';
 
 select o.a,o.b,t.c
 from one as o,two as t
 where o.a = t.a
   and o.b > t.b
   and o.b > 3
   and o.c > 'char-';
 

drop table one;
drop table two;
