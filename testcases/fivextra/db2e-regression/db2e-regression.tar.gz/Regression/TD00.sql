-- ------------------- FILE: TD00.SQL  --------------------
-- -                                                      - 
-- -                  Delete All Table                    -
-- -                                                      -
-- --------------------------------------------------------
-- 

-- Testcase for defect 10805.  Has to be executed with a newly established connection!
connect to ./;
autocommit off;
SELECT * FROM ME_TABMAP WHERE CONVID = 'CD3BC0B511297740A1E7E9B308924FC9';
autocommit on;
CREATE TABLE ME_TABMAP ( INCNO INTEGER , CONVID VARCHAR(384) NOT NULL  , CLASSTYPE VARCHAR(384) NOT NULL  , LINKEXIST CHAR(1) , PRIMARY KEY( CONVID , CLASSTYPE));
autocommit off;
INSERT INTO ME_TABMAP VALUES (1,'CD3BC0B511297740A1E7E9B308924FC9','k.RowDescriptor','X');
SELECT * FROM ME_TABMAP WHERE CONVID = '34E540435F7EA3479977AC805AF278D1';
SELECT MAX(INCNO) FROM ME_TABMAP;
connect to ./;
autocommit off;
autocommit on;
INSERT INTO ME_TABMAP VALUES (1,'CD3BC0B511297740A1E7E9B308924FC9','k.RowDescriptor','X');
SELECT * FROM ME_TABMAP WHERE CONVID = 'CD3BC0B511297740A1E7E9B308924FC9';
drop table me_tabmap;

DROP TABLE UserTable;
DROP TABLE DemandTable;
DROP TABLE TutorTable;

