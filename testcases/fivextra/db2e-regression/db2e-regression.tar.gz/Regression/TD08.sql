-- ------------------- FILE: TD08.SQL  --------------------
-- -                                                      - 
-- -              TEST DISTINCT OPERATIONS                -
-- -                                                      -
-- --------------------------------------------------------

-- -------------------------------------------------------- 
-- -             FIND THE PEOPLE OF AGE < 10              -
-- --------------------------------------------------------

select * from UserTable;
select distinct * from UserTable;


-- -------------------------------------------------------- 
-- -      FIND THE LIST OF PEOPLE WHO RAISE A DEMAND      -
-- --------------------------------------------------------

select distinct Name,Age from UserTable,DemandTable where UserTable.UserId=DemandTable.UserId order by Age;


-- -------------------------------------------------------- 
-- -   FIND THE LIST OF TEACHER TEACHING DUMMY SUBJECTS   -
-- --------------------------------------------------------

select distinct Name from UserTable,TutorTable where UserId=Teacher and Subject='Dummy%' order by Name;
