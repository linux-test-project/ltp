-- ------------------ FILE: TRYO10.SQL  -------------------
-- -                                                      - 
-- -   Multiple stmt handle test                          -
-- -                                                      -
-- --------------------------------------------------------
--
drop table t1;
create stmt handle :3;
create stmt handle :4;

-- test unprepared statement handle cannot execute
execute :3;

-- test invalid syntax cannot be executed
prepare :3 create table table table(c1 int);
execute :3;

-- test invalid syntax after a successful prepare is invalid
prepare :3 create table t1 (c1 int);
prepare :3 craate table table table (c1 int);
execute :3;

-- test conflict on creating same object...2nd execute should fail 
prepare :3 create table t1(c1 int);
prepare :4 create table t1(c1 char(4));
execute :3;
execute :4;

-- test conflict on dropping same object...2nd execute should fail
prepare :3 drop table t1;
prepare :4 drop table t1;
execute :3;
execute :4;

-- test conflict of creating same index...2nd execute should fail
create table t1 (c1 int,c2 int,c3 int);
prepare :3 create index xxx on t1(c1);
prepare :4 create index xxx on t1(c2);
execute :3;
execute :4;

-- in the future, should not produce drop error at prepare time but for now, it does
prepare :3 drop table noname;

-- prepare some data
insert into t1 values(1,1,1);
insert into t1 values(10,10,10);
insert into t1 values(5,5,5);

-- test executing delete after dropping an index that was picked
prepare :3 delete from t1 where c1 > 9;
drop index xxx;
execute :3;

create index xxx on t1(c1);

-- test executing update after dropping an index that was picked
prepare :3 update t1 set c1 = c1+1 where c1 > 0;
drop index xxx;
execute :3;

-- make sure delete and update were successful
select * from t1;

-- test that statement handle is invalid after object is dropped
prepare :3 delete from t1;
drop table t1;
execute :3;

-- test that execute of a select works after index that was picked during prepare is dropped
create table t1 (c1 int,c2 int);
create index xxx on t1 (c1);
insert into t1 values(1,2);
insert into t1 values(3,4);
prepare :3 select * from t1 where c1 > 0;
drop index xxx;
execute :3;
fetch :3;
fetch :3;

-- test that fetch doesn't work after dropping the index that was picked
create index xxx on t1(c1);
prepare :3 select * from t1 where c1 > 0;
execute :3;
drop index xxx;
fetch :3;
fetch :3;

-- test that fetch doesn't work after fetching with index already began and index is dropped
create index xxx on t1(c1);
prepare :3 select * from t1 where c1 > 0;
execute :3;
fetch :3;
drop index xxx;
fetch :3;


-- test that an update will make the select with index scan not usable
drop table t1;
create table t1 (c1 int);
create index xxx on t1(c1);
insert into t1 values(4);
insert into t1 values(5);
insert into t1 values(10);
insert into t1 values(8);
execdirect :3 select c1 from t1 order by 1;
fetch :3;
update t1 set c1=9 where c1=5;
fetch :3;

-- test that a delete will make the select with index scan not usable
execdirect :3 select c1 from t1 order by 1;
fetch :3;
delete from t1 where c1=10;
fetch :3;

drop table t2;
create table t2 (c1 int);
insert into t2 values(9000);
-- test that an insert with select will make the select with index scan not usable
execdirect :3 select c1 from t1 order by 1;
fetch :3;
insert into t1 select * from t2;
fetch :3;
drop table t2;

-- test that an insert will make the select with index scan not usable
execdirect :3 select c1 from t1 order by 1;
fetch :3;
insert into t1 values(50);
fetch :3;
execute :3;

-- test that a fetch is invalid after an insert occurs.
-- then, after execute, it can fetch again.
prepare :3 select c1 from t1 order by 1;
execute :3;
fetch :3;
insert into t1 values(100);
fetch :3;
execute :3;
fetch :3;
fetch :3;
fetch :3;
fetch :3;
fetch :3;

-- test the special case of select on catalog tables with an index.
-- the drop should make the fetch with index scan invalid
create table b (c1 int);
create table c (c1 int);
execdirect :3 select tname from "DB2eSYSTABLES" where tname > 'A';
fetch :3;
drop table b;
fetch :3;
 
drop table t1;
drop table c;
drop stmt handle :3;
drop stmt handle :4;
