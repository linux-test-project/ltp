-- let's drop to be able to run again, and again...
drop table a1;
drop table a2;
drop table a3;
drop table a4;
drop table a5;
drop table a6;
drop table a7;
drop table a8;
drop table a9;
drop table a10;

drop table a11;
drop table a12;
drop table a13;
drop table a14;
drop table a15;
drop table a16;
drop table a17;
drop table a18;
drop table a19;
drop table a20;

-- creating many files is not problem, since in no transaction
create table a1 (c int);
create table a2 (c int);
create table a3 (c int);
create table a4 (c int);
create table a5 (c int);
create table a6 (c int);
create table a7 (c int);
create table a8 (c int);
create table a9 (c int);
create table a10 (c int);

create table a11 (c int);
create table a12 (c int);
create table a13 (c int);
create table a14 (c int);
create table a15 (c int);
create table a16 (c int);
create table a17 (c int);
create table a18 (c int);
create table a19 (c int);
create table a20 (c int);

-- inserting into 20 tables is 40+ files,
-- we cannot currently handle that in a transaction
insert into a1 values(1);
insert into a2 values(1);
insert into a3 values(1);
insert into a4 values(1);
insert into a5 values(1);
insert into a6 values(1);
insert into a7 values(1);
insert into a8 values(1);
insert into a9 values(1);
insert into a10 values(1);

insert into a11 values(1);
insert into a12 values(1);
insert into a13 values(1);
insert into a14 values(1);
insert into a15 values(1);
insert into a16 values(1);
insert into a17 values(1);
insert into a18 values(1);
insert into a19 values(1);
insert into a20 values(1);

select count(*) from a1;
select count(*) from a10;
select count(*) from a11;
select count(*) from a20;

-- inserting into 20 tables is 40+ files,
-- we cannot currently handle that in a transaction
transaction begin;

insert into a1 values(1);
insert into a2 values(1);
insert into a3 values(1);
insert into a4 values(1);
insert into a5 values(1);
insert into a6 values(1);
insert into a7 values(1);
insert into a8 values(1);
insert into a9 values(1);
insert into a10 values(1);

insert into a11 values(1);
insert into a12 values(1);
insert into a13 values(1);
insert into a14 values(1);
insert into a15 values(1);
insert into a16 values(1);
insert into a17 values(1);
insert into a18 values(1);
insert into a19 values(1);
insert into a20 values(1);

transaction commit;

select count(*) from a1;
select count(*) from a10;
select count(*) from a11;
select count(*) from a20;

-- inserting into 20 tables is 40+ files,
-- we cannot currently handle that in a transaction
-- but, we should be able to use any files, between
-- transaction
transaction begin;

-- start with higher
insert into a11 values(1);
insert into a12 values(1);
insert into a13 values(1);
insert into a14 values(1);
insert into a15 values(1);
insert into a16 values(1);
insert into a17 values(1);
insert into a18 values(1);
insert into a19 values(1);
insert into a20 values(1);

insert into a1 values(1);
insert into a2 values(1);
insert into a3 values(1);
insert into a4 values(1);
insert into a5 values(1);
insert into a6 values(1);
insert into a7 values(1);
insert into a8 values(1);
insert into a9 values(1);
insert into a10 values(1);

transaction commit;

-- select * from a1, a2, a3, a4, a5, a6, a7, a8, a9, a10, a11, a12, a13, a14, a15, a16, a17, a18, a19, a20;

select count(*) from a1;
select count(*) from a10;
select count(*) from a11;
select count(*) from a20;

-- let's drop to be able to run again, and again...
drop table a1;
drop table a2;
drop table a3;
drop table a4;
drop table a5;
drop table a6;
drop table a7;
drop table a8;
drop table a9;
drop table a10;

drop table a11;
drop table a12;
drop table a13;
drop table a14;
drop table a15;
drop table a16;
drop table a17;
drop table a18;
drop table a19;
drop table a20;

