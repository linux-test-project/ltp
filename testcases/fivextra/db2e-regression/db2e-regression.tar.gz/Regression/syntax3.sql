-- ----------------- FILE: SYNTAX3.SQL  -------------------
-- -                                                      - 
-- -          CHECK ALL STANDARD SQL SYNTAX ERROR         -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE TEST6;
CREATE TABLE TEST6(c1 char(5) NOT NULL PRIMARY KEY, c2 char(10), vc1 varchar(15), vc2 varchar(20));
INSERT INTO TEST6 VALUES('NULL', NULL, NULL, NULL);
INSERT INTO TEST6 VALUES('char5', 'char10', 'varchar15', 'varchar20');
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');
INSERT INTO TEST6 VALUES('T5', '10', '15', '20');
INSERT INTO TEST6 VALUES('5', '10', '5    ', '10        ');
INSERT INTO TEST6 VALUES('5  ', '10', '5    ', '10        ');
INSERT INTO TEST6 VALUES('5    ', '10', '5    ', '10        ');
 
SELECT * FROM TEST6;
SELECT * FROM TEST6 WHERE c1 = vc1;
SELECT * FROM TEST6 WHERE c2 = vc2;
SELECT * FROM TEST6 WHERE c1 > vc1;
SELECT * FROM TEST6 WHERE c1 < vc1;

UPDATE TEST6 SET c1 = c2 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET c1 = vc1 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET c1 = vc2 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET c2 = c1 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET c2 = vc1 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET c2 = vc2 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET vc1 = c1 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET vc1 = c2 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET vc1 = vc2 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET vc2 = c1 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET vc2 = c2 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

UPDATE TEST6 SET vc2 = vc1 WHERE c1 = 'test5';
SELECT * FROM TEST6;
DELETE FROM TEST6 WHERE c1 = 'test5';
INSERT INTO TEST6 VALUES('test5', 'charchar10', 'varcharvarchar5', 'varcharvarcharchar20');

-- --------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------
-- GROUP BY TEST6
DROP TABLE TEST5;
CREATE TABLE TEST5 (c1 INT, c2 INT, c3 INT);
INSERT INTO TEST5 VALUES(null,null,null);
INSERT INTO TEST5 VALUES( 10,  2,   13);
INSERT INTO TEST5 VALUES(-15,-16,  -17);
INSERT INTO TEST5 VALUES(  3,  4,    6);
INSERT INTO TEST5 VALUES(  5,  8,    7);
INSERT INTO TEST5 VALUES(null,null,null);
INSERT INTO TEST5 VALUES( -5, -8,   -7);
INSERT INTO TEST5 VALUES(  5,  6,  -10);
INSERT INTO TEST5 VALUES( -5, -6,   10);
INSERT INTO TEST5 VALUES(null,null,null);

SELECT c1, sum(c2) FROM TEST5 GROUP BY c1;
SELECT c1, avg(c2) FROM TEST5 GROUP BY c1;
SELECT min(c2), max(c2), c1 FROM TEST5 GROUP BY c1;
SELECT sum(c2), avg(c2), min(c2), max(c2), count(c2) FROM TEST5;
SELECT c1, c2, sum(c3), avg(c3) FROM TEST5 GROUP BY c1, c2;
SELECT c1, c2, sum(c3), avg(c3) FROM TEST5 GROUP BY c1, c2 ORDER BY c2;
SELECT c1, c2, sum(c3), avg(c3) FROM TEST5 GROUP BY c1, c2 ORDER BY c2, c1;


-- --------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------
-- GROUP BY TEST6
drop table beanie;
-- AGE AND RANK SHOULD BE CHANGED TO SMALLINT LATER
create table beanie(name varchar(15), age int, salary int, retired char(1), ranking int);
INSERT INTO beanie (name,retired) VALUES('Boldy','Y');
INSERT INTO beanie VALUES('Erin', 19, 199999, 'N', 2);
INSERT INTO beanie VALUES('Glory', 29, 20000, 'N', 3);
INSERT INTO beanie VALUES('Maple', 27, 22000, 'N', 2);
INSERT INTO beanie VALUES('Britanian', 37, 32000, 'Y', 1);
INSERT INTO beanie (name) VALUES('Twig');
INSERT INTO beanie VALUES('Valentino', 30, 12000, 'Y', 2);
INSERT INTO beanie VALUES('Princess', 33, 32000, 'Y', 1);
INSERT INTO beanie VALUES('Signature', 43, 42000, 'N', 2);
INSERT INTO beanie (ranking) VALUES(3);
INSERT INTO beanie VALUES('Clubby', 53, 40000, 'Y', 3);
INSERT INTO beanie VALUES('Peace', 13, 10000, 'Y', 3);
INSERT INTO beanie VALUES('Curly', 23, 20000, 'Y', 3);
INSERT INTO beanie (name) VALUES('Hope');

-- stmt 16
SELECT avg(age), avg(ranking), min(salary), max(salary) 
	FROM beanie;

SELECT avg(age), avg(ranking), min(salary), max(salary) 
	FROM beanie 
	GROUP BY ranking;

-- SELECT retired, avg(age), avg(ranking), min(salary), max(salary) 
	FROM beanie 
	GROUP BY retired;

SELECT retired, count(*), count(ranking) 
	FROM beanie 
	GROUP BY retired;

SELECT retired, ranking, avg(salary) 
	FROM beanie 
	GROUP BY retired, ranking 
	ORDER BY ranking;

SELECT min(salary+age)+ max(salary-age) 
	FROM beanie 
	WHERE ranking = 2;

SELECT min(salary+age)+ max(salary-age) 
	FROM beanie 
	WHERE retired='Y' 
	GROUP BY ranking;

SELECT avg(x.salary), y.ranking 
	FROM beanie x, beanie y 
	WHERE x.ranking > y.ranking 
	GROUP BY y.ranking;

SELECT avg(x.salary), x.ranking, y.ranking 
	FROM beanie x, beanie y 
	WHERE x.ranking > y.ranking 
	GROUP BY y.ranking, x.ranking 
	ORDER BY y.ranking;

SELECT avg(x.salary), x.ranking, y.ranking 
	FROM beanie x, beanie y 
	WHERE x.ranking > y.ranking 
	GROUP BY y.ranking, x.ranking 
	ORDER BY y.ranking;

SELECT distinct retired, count(*) 
	FROM beanie 
	GROUP BY retired, ranking;


