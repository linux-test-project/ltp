-- ------------------- FILE: TD07.SQL  --------------------
-- -                                                      - 
-- -             TEST SORTED JOIN OPERATIONS              -
-- -                                                      -
-- --------------------------------------------------------

-- -------------------------------------------------------- 
-- -  FIND THE SUBJECT THAT PEOPLE OF AGE (31, 39) LEARN  -
-- --------------------------------------------------------

select Name,Subject from UserTable,TutorTable where Age>30 and Age<40 and UserId=Student order by Name;


-- -------------------------------------------------------- 
-- -    FIND THE SUBJECT THAT PEOPLE OF AGE (37, ABOVE)   -
-- --------------------------------------------------------

select Name,Subject,Age 
  from UserTable,DemandTable 
  where Age>36 and UserTable.UserId=DemandTable.UserId 
  order by Age;
