delete from table3 where c1 = 'a01';
delete from table3 where c1 = 'a25';
delete from table3 where c1 = 'a03';
delete from table3 where c1 = 'a05';
delete from table3 where c1 = 'a23';
