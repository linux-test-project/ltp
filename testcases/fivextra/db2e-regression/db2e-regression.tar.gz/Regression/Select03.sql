-- ----------------- FILE: SELECT03.SQL -------------------
-- -                                                      - 
-- -        CHECK ALL ERROR IN "SELECT" STATEMENT         -
-- -                                                      -
-- --------------------------------------------------------
--

drop table tt;

create table tt (a char(10), b varchar(10), c blob(50));

insert into tt values ('a', 'b', 'c');
insert into tt values ('a ', 'b ', 'c ');
insert into tt values ('a  ', 'b  ', 'c  ');
insert into tt values (' a ', ' b ', ' c ');
insert into tt values (' ', ' ', ' ');
insert into tt values (null, null, null);

select a, length(a), rtrim(a), a, length(a), length(rtrim(a)) from tt;
select a, length(a), rtrim(a), 'z' concat rtrim(a) concat 'z', a, length(a), length(rtrim(a)) from tt;

select b, length(b), rtrim(b), b, length(b), length(rtrim(b)) from tt;
select b, length(b), rtrim(b), 'z' concat rtrim(b) concat 'z', b, length(b), length(rtrim(b)) from tt;

select c, length(c), rtrim(c), c, length(c), length(rtrim(c)) from tt;

select a concat b, length(a concat b), rtrim(a concat b), a concat b, length(a concat b), length(rtrim(a concat b)) from tt;

select a, b from tt where rtrim('   ') = ' ';
select rtrim('       '), a from tt order by 1,2;

describe select a, length(a), rtrim(a), length(rtrim(a)) from tt;
describe select a concat b, length(a concat b), rtrim(a concat b), a concat b, length(a concat b), length(rtrim(a concat b)) from tt;

-- how about length/rtrim of constant values??
select length('a ') from tt;
select length(' ') from tt;
select length('') from tt;
select rtrim('a ') from tt;
select rtrim('a') from tt;
select rtrim(' ') from tt;

drop table tt;

-- Error cases
create table tt (a int, b smallint, c decimal(7,2), d date, e time, f timestamp);
insert into tt values (11, 22, 33.0, '01/01/2001', '01:01:01', '2001-03-21-13.58.50.250001');

select length(a) from tt;
select length(b) from tt;
select length(c) from tt;
select length(d) from tt;
select length(e) from tt;
select length(f) from tt;

select rtrim(a) from tt;
select rtrim(b) from tt;
select rtrim(c) from tt;
select rtrim(d) from tt;
select rtrim(e) from tt;
select rtrim(f) from tt;

drop table tt;
