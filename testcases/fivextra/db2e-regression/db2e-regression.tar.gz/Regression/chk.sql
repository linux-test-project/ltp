--------------------------------------------------------------------
-- CHECK CONSTRAINT TESTS (SIMPLE)
--------------------------------------------------------------------

create table x
(
	a int check(a < 3),
	b int check(b > -3),
	check( a+b < 5)
);

-- basic insertion tests.
insert into x values(1,3);
insert into x values(-1,2);
insert into x values(-3,7);
-- 5
insert into x values(-8,4);
insert into x values(0,-6);
insert into x values(-2,-3);
insert into x values(1,-1);
insert into x values(2,7);
-- 10
insert into x values(5,11);
insert into x values(2,3);
insert into x values(-2,-1);
insert into x values(10,0);
insert into x(a) values(-1);
--15
insert into x(a) values(-2);
insert into x(a) values(-3);
insert into x(b) values(-1);
insert into x(b) values(3);
insert into x(b) values(2);

--20
select * from x;

-- is it orthogonal
update x set a = 1 where a = -1;
update x set a = -1 where a = 1;
update x set a = 1 where a = -1;

select * from x;

-- are constraints satisfied for updates.
--25
update x set a = 5 where a = 1;
update x set b = -14 where b = 3;
update x set a = 0, b = 0 where b is NULL;
update x set a = -2, b = 5 where a is NULL;

drop table x;
--------------------------------------------------------------------
-- CHECK CONSTRAINT TEST (complicated)
--------------------------------------------------------------------

create table z
(
	city 		varchar(20) NOT NULL check(city = 'San Jose' OR city = 'San Demas' OR city = 'Kent' OR city = 'Ontario'),
	state		char(2) NOT NULL check(state <> 'ZZ'),
	population	int check(population > 50),
	avg_max_temp	decimal(5,2),
	avg_min_temp	decimal(5,2),
	check(avg_max_temp >= avg_min_temp),
	check(avg_max_temp < 200.3 AND avg_min_temp > -100),
	check(city <> 'San Jose' AND state NOT LIKE 'O_')
);

--30
insert into z values('San Jose', 'CA',1000000, 75,75);
insert into z values('San Jose', 'OH',1000000, 75,75);
insert into z values('San Jose', 'CA',1000000, 75,75);      
insert into z values('Kent', 'OH',333,199,-99);		
insert into z values('Kent','OH',2342323,210,-30);
--35
insert into z values('San Demas','ZZ',14123,12,3);
insert into z values('San Demas','CA',12344,123,23);
insert into z values('San Demas','CA',50,100,100);
insert into z values('Kent','OH',12222,12,122);
insert into z values('Kent','OH',999,12,10);

--40
update z set city = 'Rapid Falls' where city LIKE 'San Jose%';
update z set state = 'ZZ' where state = 'CA';
update z set avg_max_temp = 12, avg_min_temp = 100 where city = 'Kent';
update z set city = 'San Jose', state = 'CA' where city = 'San Demas' AND avg_max_temp = 123;

select * from z;
drop table z;
--------------------------------------------------------------------








