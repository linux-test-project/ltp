drop table afj11prsa;
CREATE TABLE AFJ11PRSa (
	AFJ11NAME	 	CHAR(10),
	AFJ11USCR		CHAR(10)
);
Create index AFJ11PRS2a on AFJ11PRSa (AFJ11USCR);
Create index AFJ11PRS1a on AFJ11PRSa (AFJ11NAME);

insert into AFJ11PRSa (AFJ11NAME,AFJ11USCR) values('TEST','A');

update AFJ11PRSa 
  set AFJ11USCR= 'A',AFJ11NAME= 'TEST1';

update AFJ11PRSa 
  set AFJ11USCR= 'A',AFJ11NAME= 'TEST';

select * from afj11prsa;

drop table afj11prsa;

drop table t;
CREATE TABLE T (A VARCHAR(5), B VARCHAR(20));
CREATE INDEX IDX ON T (A);
INSERT INTO T VALUES ('1', 'abcd');
INSERT INTO T VALUES ('1', 'ab');
INSERT INTO T VALUES ('2', 'cd');
INSERT INTO T VALUES ('2', 'cded');
INSERT INTO T VALUES ('3', 'edfg');

drop stmt handle :2;
create stmt handle :2;
prepare :2 select * from t;
execute :2;
fetch :2;
drop table t;
fetch :2;
execute :2;
prepare :2 select * from t;

drop stmt handle :2;


---------------------------------------------------------------------
-- -        READ/SCROLLABLE CURSOR SURVIVES R/W CONFLICT d7662 tge  -
-- ------------------------------------------------------------------
--

-- Here's a customer's (flyingSPARK) case: 

-- Prepare the table 

DROP TABLE TICKET; 
CREATE TABLE TICKET ( THEATREID INT NOT NULL, 
   TICKETID INT NOT NULL, 
   SHOWNUMBER INT NOT NULL, 
   OWNER VARCHAR(32), 
   VALUE INT, 
   NUMSOLD INT, 
   DURATION INT, 
   PRIMARY KEY (THEATREID,TICKETID,SHOWNUMBER) ); 

INSERT INTO TICKET VALUES (608,16,0,'Jack',8003,7233,0); 
INSERT INTO TICKET VALUES (608,17,0,'Jack',8023,7612,0); 
INSERT INTO TICKET VALUES (608,18,0,'Jack',8033,7677,0); 
INSERT INTO TICKET VALUES (51,11,0,'Tom',8103,4567,0); 
INSERT INTO TICKET VALUES (51,12,0,'Tom',8203,5467,0); 
INSERT INTO TICKET VALUES (51,13,0,'Tom',8303,6453,0); 
INSERT INTO TICKET VALUES (51,14,0,'Tom',8403,7239,0); 
INSERT INTO TICKET VALUES (96,11,0,'Susan',3003,2345,0); 
INSERT INTO TICKET VALUES (96,12,0,'Susan',4003,3456,0); 
INSERT INTO TICKET VALUES (96,13,0,'Susan',5003,4567,0); 

-- Now create the two statement handles 

CREATE STMT HANDLE :1; 
CREATE STMT HANDLE :2; 

-- And finally start the tests. 

-- Insert case. After the insert the cursor should be able to continue fetching. 

EXECDIRECT :1  SELECT TICKETID 
  FROM TICKET 
  WHERE THEATREID = 51 AND SHOWNUMBER = 0; 
FETCH :1; 
FETCH :1; 

EXECDIRECT :2 INSERT INTO TICKET 
  VALUES (608,42,0,'Jack',8003,7233,0); 
FETCH :1; 
FETCH :1; 
FETCH :1; 

-- Delete case. After the delete the cursor should still be open 

PREPARE :1  SELECT OWNER,VALUE,NUMSOLD
  FROM TICKET 
  WHERE THEATREID = 51 AND TICKETID = 11;

PREPARE :2  DELETE FROM TICKET 
  WHERE THEATREID = 608 AND TICKETID = 16; 

EXECUTE :1; 

EXECUTE :2; 

FETCH :1; 

-- Update case. The cursor won't be closed after update. 

PREPARE :1  SELECT OWNER,VALUE,NUMSOLD 
  FROM TICKET 
  WHERE THEATREID = 51; 

PREPARE :2  UPDATE TICKET 
  SET NUMSOLD = 0 
  WHERE THEATREID = 51 AND TICKETID = 13; 

EXECUTE :1; 

FETCH :1; 
FETCH :1; 

EXECUTE :2; 

FETCH :1;

-- Test desc order

PREPARE :1  SELECT THEATREID
  FROM TICKET 
  WHERE THEATREID > 1 ORDER BY THEATREID DESC; 

EXECUTE :1; 

FETCH :1; 
FETCH :1;

EXECDIRECT :2 INSERT INTO TICKET VALUES (6,111,8,'Tingjian',3003,2345,0);

FETCH :1; 
FETCH :1;

drop table ticket;

-- End of customer case.


-- Test Order By Desc with duplicates

drop table t1;
create table t1(c1 int, c2 int);
create index idxt1c1 on t1(c1);

insert into t1 values (5, 5);
insert into t1 values (7, 7);
insert into t1 values (2, 2);
insert into t1 values (-1, -1);
insert into t1 values (5, 55);
insert into t1 values (2, 22);
insert into t1 values (2, 222);
insert into t1 values (7, 77);
insert into t1 values (5, 555);
insert into t1 values (7, 777);

select * from t1 where c1 > 1 order by c1 desc;

execdirect :1 select * from t1 where c1 > 1 order by c1 desc;

fetch :1;

execdirect :2 delete from t1 where c2 = 7;

fetch :1;

execdirect :2 insert into t1 values (5, 5555);

fetch :1;
fetch :1;

-- drastic change

execdirect :2 delete from t1 where c2 > 2;

fetch :1;
fetch :1;


-- Test Scrollable Cursor

delete from t1;
insert into t1 values (7, 7);
insert into t1 values (8, 8);
insert into t1 values (8, 88);
insert into t1 values (7, 77);
insert into t1 values (10, 10);
insert into t1 values (-3, -3);
insert into t1 values (7, 777);
insert into t1 values (2, 2);
insert into t1 values (7, 7777);
insert into t1 values (5, 5);
insert into t1 values (8, 888);

select * from t1 where c1 > 1;

enable scrollable cursor :1;

prepare :1 select * from t1 where c1 > 1;
execute :1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
execdirect :2 insert into t1 values (9, 9);
fetchscroll :1 sql_fetch_prior 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_absolute 10;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;

select * from t1 where c1 > 1;

prepare :1 select * from t1 where c1 > 1;
execute :1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
-- delete row 4
execdirect :2 delete from t1 where c2 = 777;
fetchscroll :1 sql_fetch_prior 1;
fetchscroll :1 sql_fetch_next 1;
-- delete row 2
execdirect :2 delete from t1 where c2 = 5;
fetchscroll :1 sql_fetch_absolute 6;

select * from t1 where c1 > 1;

prepare :1 select * from t1 where c1 > 1;
execute :1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
-- update already fetched index key
update t1 set c1 = 11 where c2 = 7777;

fetchscroll :1 sql_fetch_absolute 2;
fetchscroll :1 sql_fetch_absolute 1;
fetchscroll :1 sql_fetch_absolute 3;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;

-- row set size > 1
enable scrollable cursor :1 3;

delete from t1;
insert into t1 values (7, 7);
insert into t1 values (8, 8);
insert into t1 values (8, 88);
insert into t1 values (7, 77);
insert into t1 values (10, 10);
insert into t1 values (-3, -3);
insert into t1 values (7, 777);
insert into t1 values (2, 2);
insert into t1 values (7, 7777);
insert into t1 values (5, 5);
insert into t1 values (8, 888);

select * from t1 where c1 > 1;

prepare :1 select * from t1 where c1 > 1;
execute :1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;

-- delete the row right at CRS
execdirect :2 delete from t1 where c2 = 777;

-- next should be really the next unseen row
fetchscroll :1 sql_fetch_next 1;

-- prior should be really the set before current set, and without deleted row
fetchscroll :1 sql_fetch_prior 1;

-- delete a row after the CRS
execdirect :2 delete from t1 where c2 = 888;

-- could we jump to the deleted row? ...no, slip to the row after that
fetchscroll :1 sql_fetch_relative 3;

-- ok, look around, see anything suspicious?
fetchscroll :1 sql_fetch_prior 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;

-- CRS is AFTER_END already, delete a row before CRS
execdirect :2 delete from t1 where c2 = 5;
-- roll backward up
fetchscroll :1 sql_fetch_relative -5;

-- oops hit the ceiling
fetchscroll :1 sql_fetch_prior 1;

-- BEFORE_START
fetchscroll :1 sql_fetch_prior 1;

-- we got all the rows in RIDset, insert should not affect us at all, and new row unseen
execdirect :2 insert into t1 values (5, 5);
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;

-- let's do some joins

delete from t1;
insert into t1 values (4, 2);
insert into t1 values (8, 0);
insert into t1 values (9, 9);
insert into t1 values (7, 0);
insert into t1 values (12, 0);
insert into t1 values (10, 0);
insert into t1 values (15, 0);

drop table t2;
create table t2(c1 int, c2 int);
create index idxt2c1 on t2(c1);
insert into t2 values (7, 7);
insert into t2 values (8, 8);
insert into t2 values (8, 88);
insert into t2 values (7, 77);
insert into t2 values (10, 10);
insert into t2 values (-3, -3);
insert into t2 values (7, 777);
insert into t2 values (2, 2);
insert into t2 values (7, 7777);
insert into t2 values (5, 5);
insert into t2 values (8, 888);

select * from t1, t2 where t1.c1 = t2.c1;

prepare :1 select * from t1, t2 where t1.c1 = t2.c1;
execute :1;
fetchscroll :1 sql_fetch_next 1;

-- delete the next unshown row
execdirect :2 delete from t2 where c2 = 77;

-- should skip deleted row
fetchscroll :1 sql_fetch_next 1;

-- only 1 row in last set
fetchscroll :1 sql_fetch_next 1;

fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_absolute 3;

-- insert it back
insert into t2 values (7, 77);

select * from t1, t2 where t1.c1 = t2.c1;

prepare :1 select * from t1, t2 where t1.c1 = t2.c1;
execute :1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_relative 1;

-- delete two rows right before CRS

execdirect :2 delete from t2 where c2 = 7777 or c2 = 777;

-- should be able to forget and remember
fetchscroll :1 sql_fetch_relative -1;

-- should get the rows and a warning of back too far
fetchscroll :1 sql_fetch_prior 1;

fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;

drop stmt handle :1;
drop stmt handle :2;
drop table t1;
drop table t2;

-- The following contains a testcase for index scan on varchar columns, that once exposed a bug.
-- This bug was in versions 8.1 through 8.1.2

create table cm_relation (clt_id varchar(50) not null, relate_id varchar(50) not null, primary key (clt_id, relate_id));
create table fp_rpt_main (clt_id varchar(50) not null, ver_id int not null, primary key (clt_id, ver_id));

insert into cm_relation values('0617110545239248121' , '0617110545241449062');
insert into cm_relation values('06171105453205057861', '06171105453233103162');
insert into cm_relation values('06171105453205057861', '06171105453233103163');
insert into cm_relation values('06171105453471564071', '06171105453477176572');
insert into cm_relation values('', '06171105462085865685');
insert into fp_rpt_main values('', 1);
insert into fp_rpt_main values('06171105453471564071', 2);

-- On versions that carry that bug, the first SELECT results in a SQLState 58004.
-- On fixed versions, both queries are okay.
select * from cm_relation a, fp_rpt_main b where a.clt_id = b.clt_id;
select * from fp_rpt_main a, cm_relation b where a.clt_id = b.clt_id;

drop table cm_relation;
drop table fp_rpt_main;

-- Some more testing related to the bug above.
-- On versions that contain the bug, some of the SELECTs come back with 0 rows.
-- On versions with this bug fixed, all SELECTs return at least one row.

create table t1 (c1 varchar(10), c2 varchar(10));
create index idx1 on t1(c1, c2);
insert into t1 values ('', 'abc');
select * from t1 where c1 = '';
drop table t1;

create table t1 (c1 varchar(10), c2 varchar(10), c3 varchar(10), c4 varchar(10));
create index idx1 on t1(c1, c2, c3, c4);
insert into t1 values ('', '', '', 'abcd');
select * from t1 where c1 = '';
select * from t1 where c2 = '';
select * from t1 where c3 = '';
select * from t1 where c1 = '' and c2 = '';
select * from t1 where c1 = '' and c3 = '';
select * from t1 where c1 = '' and c2 = '' and c3 = '';
insert into t1 values ('', '', 'abcd', 'abcd');
select * from t1 where c1 = '';
select * from t1 where c2 = '';
select * from t1 where c3 = '';
select * from t1 where c1 = '' and c2 = '';
select * from t1 where c1 = '' and c3 = '';
select * from t1 where c1 = '' and c2 = '' and c3 = '';
insert into t1 values ('', 'abcd', '', 'abcd');
select * from t1 where c1 = '';
select * from t1 where c2 = '';
select * from t1 where c3 = '';
select * from t1 where c1 = '' and c2 = '';
select * from t1 where c1 = '' and c3 = '';
select * from t1 where c1 = '' and c2 = '' and c3 = '';
insert into t1 values ('', 'abcd', 'abcd', 'abcd');
select * from t1 where c1 = '';
select * from t1 where c2 = '';
select * from t1 where c3 = '';
select * from t1 where c1 = '' and c2 = '';
select * from t1 where c1 = '' and c3 = '';
select * from t1 where c1 = '' and c2 = '' and c3 = '';
insert into t1 values ('abcd', 'abcd', 'abcd', 'abcd');
select * from t1 where c1 = '';
select * from t1 where c2 = '';
select * from t1 where c3 = '';
select * from t1 where c1 = '' and c2 = '';
select * from t1 where c1 = '' and c3 = '';
select * from t1 where c1 = '' and c2 = '' and c3 = '';
insert into t1 values ('', '', '', '');
select * from t1 where c1 = '';
select * from t1 where c2 = '';
select * from t1 where c3 = '';
select * from t1 where c1 = '' and c2 = '';
select * from t1 where c1 = '' and c3 = '';
select * from t1 where c1 = '' and c2 = '' and c3 = '';
drop table t1;
