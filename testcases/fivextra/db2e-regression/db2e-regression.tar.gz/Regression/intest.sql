-- --------------------FILE:  INTEST.SQL  -----------------------------------------
-- --------------------------------------------------------------------------------
-- --  Test IN predicate and EXPLAIN statement and other miscellaneous defect fixes
-- --------------------------------------------------------------------------------
drop table intest1;
create table intest1 (c1 int,c2 date,c3 smallint,c4 decimal(12,4) not null,c5 time,c6 char(20),c7 varchar(23));
insert into intest1 values(-5,'04/12/2001',123,123.43,'10:10:12','1323424','2312323');
insert into intest1 values(-4,'10/10/1992',-2321,1233.432,'11:11:00','abcdef','afdsfdasf');
insert into intest1 values(-3,'12/25/2000',0,2323,'08:09:08','a','');
insert into intest1 values(-2,'08/16/1962',43,324,'02:03:12','bvc','abasdflkj');
insert into intest1 values(-1,'05/13/1962',12123,432.34,'01:01:01','sf','ds');
insert into intest1 values(0,'12/12/1992',-321,-123.32,'05:30:23','131','fasddasf');
insert into intest1 values(1,'04/01/1999',1234,-123213,'02:15:00','dfasfds','b');
insert into intest1 values(2,'07/04/2000',-32768,-34344,'01:17:34','afdsf','ds');
insert into intest1 values(3,'10/3/1900',324,3244,'06:56:43','abc','def');
insert into intest1 values(4,'11/28/1854',2,3441,'09:14:43','ax','de');
insert into intest1 values(5,'02/14/1985',12323,543,'03:24:43','sxc','dsaxdsfsdfafdaf');
insert into intest1 values(-15,'12/31/1999',323,123.03,'10:12:12','1323x24','23x2323');
insert into intest1 values(-14,'11/10/1992',-14,1033.432,'11:12:00','axcdef','afxsfdasf');
insert into intest1 values(-13,'10/25/2000',5,2320,'08:02:08','x','');
insert into intest1 values(-12,'08/15/1962',63,320,'02:02:12','bxc','abxsdflkj');
insert into intest1 values(-11,'05/18/1962',2183,432.04,'01:02:01','xf','xs');
insert into intest1 values(10,'12/19/1992',-821,-123.02,'05:32:23','1x1','faxddasf');
insert into intest1 values(11,'04/11/1999',1934,-123013,'02:12:00','dfaxfds','x');
insert into intest1 values(12,'07/24/2000',-30768,-34044,'01:12:34','axdsf','dx');
insert into intest1 values(13,'10/1/1900',320,3204,'06:52:43','axc','dxf');
insert into intest1 values(14,'11/30/1854',3044,3401,'09:12:43','xd','dx');
insert into intest1 values(15,'12/14/1985',10323,503,'03:22:43','xdc','dsaxdsfsdfafdaf');
insert into intest1 values(-55,'04/12/2001',128,193.43,'10:19:12','1323924','2312393');
insert into intest1 values(-54,'10/10/1999',-2391,1933.432,'11:11:09','a9cdef','af9sfdasf');
insert into intest1 values(-53,'12/25/2009',0,2303,'08:09:08','9','');
insert into intest1 values(-52,'08/16/1969',43,304,'09:03:12','b9c','abasdf8kj');
insert into intest1 values(-51,'05/13/1969',12623,492.34,'01:01:01','sf','d8');
insert into intest1 values(50,'12/12/1999',-361,-193.32,'05:30:23','131','fasdd8sf');
insert into intest1 values(51,'04/01/1999',1236,-129213,'02:15:00','dfasf8s','8');
insert into intest1 values(52,'07/04/2009',-32768,-31344,'01:17:34','afd8f','d8');
insert into intest1 values(53,'10/3/1909',394,3264,'09:56:43','abc','de8');
insert into intest1 values(54,'11/28/1859',3394,3941,'09:14:43','ax','d7');
insert into intest1 values(55,'02/14/1989',12923,593,'03:24:43','sxc','dsaxdsfsdf7fdaf');
insert into intest1 values(-615,'12/31/2989',393,196.03,'10:12:12','1323x24','23x2723');
insert into intest1 values(-614,'11/10/2892',-4921,9633.432,'11:12:00','axcd7f','a7xsfdasf');
insert into intest1 values(-613,'10/25/2009',5,2320,'06:02:08','x','');
insert into intest1 values(-612,'08/15/1969',63,320,'02:06:12','bxc','abxsd7lkj');
insert into intest1 values(-611,'05/18/1869',2173,432.04,'06:02:01','xf','xs');
insert into intest1 values(610,'12/19/1899',-821,-123.02,'06:32:23','1x1','f7xddasf');
insert into intest1 values(611,'04/11/1899',1934,-123013,'06:12:00','dfax7ds','x');
insert into intest1 values(612,'07/24/2089',-30768,-34044,'06:12:34','a7dsf','dx');
insert into intest1 values(613,'10/1/1990',320,3204,'06:52:46','a7c','d7f');
insert into intest1 values(614,'11/30/1894',3044,3401,'09:12:46','7d','d7');
insert into intest1 values(615,'12/14/1995',10323,503,'03:22:46','x7c','dsaxdsfsdfafdaf');
select * from intest1;
select * from intest1 where c1 in (1,2,3);
select * from intest1 where 1.0 + .5 in (1,2,3);
select * from intest1 where 1.0 + .5 in (1,2,1.5,3);
select * from intest1 where c1 IN (2);
select * from intest1 where c1+1 IN (2,3,6);
select * from intest1 where c1 in (1,2,-4) and c1 > 1;
select * from intest1 where c1 in (1,2,-5,-3.0) or c1 = 0;
select * from intest1 where c1 in (1+0,.5+.5+.5+.25+.25,50-53);
select * from intest1 where c1 in (1+0,5*5-20,6/6+1,4.0);
select * from intest1 where c1 in (mod(5,3),0);
select * from intest1 where NOT (c1 in (mod(5,3),0));
select * from intest1 where c1 in (c1,12);
select * from intest1 where c1 in (c1/2,3.5,5);
select * from intest1 where current date in (current date,'12/12/1893');
select * from intest1 where c1 in (?,?,?);
select * from intest1 where c3 in (1,5,-2391);
select * from intest1 where c3 IN (2);
select * from intest1 where c3 IN (-30768);
select * from intest1 where c3+1 IN (44,3,6,-123);
select * from intest1 where c3 in (1111,63,-4) and c3 > 60;
select * from intest1 where c3 in (1,2,5,320.0) or c3 = 0;
select * from intest1 where c3 in (320+0,3+.5+.5+.5+.25+.25,0-361,12-1234);
select * from intest1 where c3 in (mod(5,3),0);
select * from intest1 where NOT (c3 in (mod(11,6),0));
select * from intest1 where c3 in (c1,12);
select * from intest1 where c3 in (c1/2,3.5,5);

select * from intest1 where c3 not in (12323,5,0,3,43,320,342,23,2,3);
select * from intest1 where c4 in (543,-123.03,3204,320.00);
select * from intest1 where c4 in (543,-123.02000,3204,320.00001);
select * from intest1 where c4 IN (2);
select * from intest1 where c4 IN (432.0400);
select * from intest1 where c4+1 IN (-123012,433.0400,6);
select * from intest1 where c4 in (9633.4320,1,-129213.0) and c3 > 1;
select * from intest1 where c2 in ('10/10/1992','12/12/1212');
select * from intest1 where c2 not in ('12/14/1995','04/11/1899','12/12/1212','12/31/1999','01/01/2000');
select * from intest1 where c5 in ('11:12:00','12:12:12','09:12:46');
select * from intest1 where Not(c5 in ('06:02:08','12:12:12','08:09:08'));
select * from intest1 where c5 not in('01:02:01','11:11:11','11:11:09');
select * from intest1 where c6 in ('bxc','131','fdsfdfs','x');
select * from intest1 where c6 in ('dfasfds','11232','3143','1343','3143') and c1 = 1;
select * from intest1 where c6 in ('1234567890123456789032434','dfasfds','3143','1343','3143') and c1 = 1;
select * from intest1 where c6 in ('32434','sf','3143','abc','3143') or c1 = 1;
select * from intest1 where rtrim(c6) in ('32434','afd8f','3143','x7c  ','7d  ') or c1 = 11;
select * from intest1 where length(c7) in (12,10,9,2,5);
select * from intest1 where length(c7) not in (12,10,2,4,5);
select * from intest1 where c7 in ('','xs','12331','12312','8');
select * from intest1 where c7 not in ('dx','     ','afxsfdasf','12312','1233');
select * from intest1 where c7 in (rtrim('xs          '),'dxf','12331','x','1233');
select * from intest1 where c7 in (rtrim(c7),'12332','12331','12312','1233');
select * from intest1 where c1 in (1,2,3) and c3 = 1234;
select * from intest1 where c1 in (1,2,4) and c3 > 0;
select * from intest1 where c1 in (1,2,4) and c3 <=10;
select * from intest1 where c1  = 1 and c3 in (1,1234,4);
select * from intest1 where c1 in (1,2,5,3,2) and c3 in (1,1234,1,3,4);
select * from intest1 where c1 in (1,2,3,4,5,6,7,8,9,10,11);
create index ab1 on intest1(c1);
create index ab2 on intest1(c2);
create index ab3 on intest1(c3);
create index ab4 on intest1(c4);
create index ab5 on intest1(c5);
create index ab6 on intest1(c6);
create index ab7 on intest1(c7);
create index ab8 on intest1(c1,c3);
select * from intest1;
select * from intest1 where c1 in (1,2,3);
select * from intest1 where 1.0 + .5 in (1,2,3);
select * from intest1 where 1.0 + .5 in (1,2,1.5,3);
select * from intest1 where c1 IN (2);
select * from intest1 where c1+1 IN (2,3,6);
select * from intest1 where c1 in (1,2,-4) and c1 > 1;
select * from intest1 where c1 in (1,2,-5,-3.0) or c1 = 0;
select * from intest1 where c1 in (1+0,.5+.5+.5+.25+.25,50-53);
select * from intest1 where c1 in (1+0,5*5-20,6/6+1,4.0);
select * from intest1 where c1 in (mod(5,3),0);
select * from intest1 where NOT (c1 in (mod(5,3),0));
select * from intest1 where c1 in (c1,12);
select * from intest1 where c1 in (c1/2,3.5,5);
select * from intest1 where current date in (current date,'12/12/1893');
select * from intest1 where c1 in (?,?,?);
select * from intest1 where c3 in (1,5,-2391);
select * from intest1 where c3 IN (2);
select * from intest1 where c3 IN (-30768);
select * from intest1 where c3+1 IN (44,3,6,-123);
select * from intest1 where c3 in (1111,63,-4) and c3 > 60;
select * from intest1 where c3 in (1,2,5,320.0) or c3 = 0;
select * from intest1 where c3 in (320+0,3+.5+.5+.5+.25+.25,0-361,12-1234);
select * from intest1 where c3 in (mod(5,3),0);
select * from intest1 where NOT (c3 in (mod(11,6),0));
select * from intest1 where c3 in (c1,12);
select * from intest1 where c3 in (c1/2,3.5,5);

select * from intest1 where c3 not in (12323,5,0,3,43,320,342,23,2,3);
select * from intest1 where c4 in (543,-123.03,3204,320.00);
select * from intest1 where c4 in (543,-123.02000,3204,320.00001);
select * from intest1 where c4 IN (2);
select * from intest1 where c4 IN (432.0400);
select * from intest1 where c4+1 IN (-123012,433.0400,6);
select * from intest1 where c4 in (9633.4320,1,-129213.0) and c3 > 1;
select * from intest1 where c2 in ('10/10/1992','12/12/1212');
select * from intest1 where c2 not in ('12/14/1995','04/11/1899','12/12/1212','12/31/1999','01/01/2000');
select * from intest1 where c5 in ('11:12:00','12:12:12','09:12:46');
select * from intest1 where Not(c5 in ('06:02:08','12:12:12','08:09:08'));
select * from intest1 where c5 not in('01:02:01','11:11:11','11:11:09');
select * from intest1 where c6 in ('bxc','131','fdsfdfs','x');
select * from intest1 where c6 in ('dfasfds','11232','3143','1343','3143') and c1 = 1;
select * from intest1 where c6 in ('1234567890123456789032434','dfasfds','3143','1343','3143') and c1 = 1;
select * from intest1 where c6 in ('32434','sf','3143','abc','3143') or c1 = 1;
select * from intest1 where rtrim(c6) in ('32434','afd8f','3143','x7c  ','7d  ') or c1 = 11;
select * from intest1 where length(c7) in (12,10,9,2,5);
select * from intest1 where length(c7) not in (12,10,2,4,5);
select * from intest1 where c7 in ('','xs','12331','12312','8');
select * from intest1 where c7 not in ('dx','     ','afxsfdasf','12312','1233');
select * from intest1 where c7 in (rtrim('xs          '),'dxf','12331','x','1233');
select * from intest1 where c7 in (rtrim(c7),'12332','12331','12312','1233');
select * from intest1 where c1 in (1,2,3) and c3 = 1234;
select * from intest1 where c1 in (1,2,4) and c3 > 0;
select * from intest1 where c1 in (1,2,4) and c3 <=10;
select * from intest1 where c1  = 1 and c3 in (1,1234,4);
select * from intest1 where c1 in (1,2,5,3,2) and c3 in (1,1234,1,3,4);
select * from intest1 where c1 in (1,2,3,4,5,6,7,8,9,10,11);

update intest1 set c3=12345 where c1 in (1,2,3,4,5) and c5 in ('02:15:00','03:24:43');
select * from intest1;
delete from intest1 where c5 in ('01:21:21','03:22:46');
select * from intest1;
update intest1 set c6 = 'abcdefghi' where c3 in (1,2,3,4) or c1 in (1,2,3,4);
select * from intest1;
drop table intest1;
drop table intest2;
create table intest2 (c1 decimal(12,4) not null, c2 integer,c3 char(100),
check (c1 in (-10,-20,0,10,20) and c2 not in (-9,14,15)));
insert into intest2 values(123,123,'abc');
insert into intest2 values(10,123,'abc');
insert into intest2 values(-10,15,'abc');
insert into intest2 values(-1,15,'abc');
insert into intest2 values(0,-9,'abc');

update intest2 set c1 = -9;
update intest2 set c2 = 0;
update intest2 set c2 = 15;
update intest2 set c1 = 20;
create index xxx on intest2(c1);
create index yyy on intest2(c2);
insert into intest2 values(123,123,'abc');
insert into intest2 values(10,123,'abc');
insert into intest2 values(-10,15,'abc');
insert into intest2 values(-1,15,'abc');
insert into intest2 values(0,-9,'abc');

update intest2 set c1 = -9;
update intest2 set c2 = 0;
update intest2 set c2 = 15;
update intest2 set c1 = 20;
drop table intest2;
drop table intest3;
create table intest3 (c1 decimal(10,3),c2 varchar(10));
insert into intest3 values(-5.23,'abc');
insert into intest3 values(-3.333,'abcd');
insert into intest3 values(1234567.891,'def');
insert into intest3 values(12.345,'dfggg');
insert into intest3 values(0.001,'11111');
insert into intest3 values(12.34,'111111');
insert into intest3 values(12,'211111');
select * from intest3 where c1 in (12,2,3);
select * from intest3 where c1 in (12.0000,2.00000,-5.2300000);
select * from intest3 where c1 IN (12.34,.001);
select * from intest3 where c1+1 IN (1234568.891,1.0010,13.0000000001);
select * from intest3 where c2 in ('abc','def');
select * from intest3 where c2 in ('11111','abcd');
create index abc1 on intest3(c1);
create index abc2 on intest3 (c2);
select * from intest3 where c1 in (12,2,3);
select * from intest3 where c1 in (12.0000,2.00000,-5.2300000);
select * from intest3 where c1 IN (12.34,.001);
select * from intest3 where c1+1 IN (1234568.891,1.0010,13.0000000001);
select * from intest3 where c2 in ('abc','def');
select * from intest3 where c2 in ('11111','abcd');
drop table intest3;
drop table xxt1;
drop table xxt2;
drop table xxt3;
drop table xxt4;
create table xxt1 (c1 int,c2 int,check (c1 in (1,2,3,4)));
create table xxt2 (c1 int,c2 int,check (c1 in (c2+1,2,3,4)));
create table xxt3 (c1 decimal(10,3),c2 decimal(10,3),check (c1 in (c2+.001)),
check (c2 in (4,1.234,2.345)));
create table xxt4 (c1 decimal(10,3),c2 decimal(10,3),check (c1 not in (c2+.001)),
check (c2 in (4,1.234,2.345)));
insert into xxt1 values(1,1);
insert into xxt2 values(-5,-6);
insert into xxt2 values(4.000,-34);
insert into xxt3 values(4.001,4);
insert into xxt4 values(4.001,2.345);

insert into xxt4 values(4.001,4);
insert into xxt4 values(4.001,24);
insert into xxt4 values(2.346,2.345);
insert into xxt3 values(4.00,3.999);
insert into xxt3 values(4.00,1.234);
insert into xxt3 values(54.00,31.234);
insert into xxt1 values(0,1);
insert into xxt2 values(-5,5.0000);
drop table xxt1;
drop table xxt2;
drop table xxt3;
drop table xxt4;
drop table yyt1;
create table yyt1 (c1 int,c2 date);
insert into yyt1 values(-5,current date);
insert into yyt1 values(-4,'10/10/1992');
insert into yyt1 values(-3,'12/25/2000');
insert into yyt1 values(-2,'08/16/1962');
insert into yyt1 values(-1,'05/13/1962');
insert into yyt1 values(0,'12/12/1992');
insert into yyt1 values(1,'04/01/1999');
insert into yyt1 values(2,'07/04/2000');
insert into yyt1 values(3,'10/3/1900');
insert into yyt1 values(4,'11/28/1854');
insert into yyt1 values(5,'02/14/1985');

select * from yyt1 where c1 in ('1','2','3');
select * from yyt1 where c2 in ('10/10/1923','123213123');
select * from yyt1 where c1 in (1,'1',4);
select * from yyt1 where ? IN (?,?,?);
select * from yyt1 where sum(c1) in (1,2,3);
select * from yyt1 where c1 in (max(c1),2,3);
select * from yyt1 where '1231231233' in (current date,c2);
select * from yyt1 where '1231231233' in (current date,'10/10/1901');
drop table yyt1;

drop table xyz;
create table xyz (c1 int, c2 date);
insert into xyz values(1,current date);
select c1 from xyz where c2 = current date;
select c1 from xyz where current date = c2;
create index ixyz on xyz(c2);
select c1 from xyz where c2 = current date;
select c1 from xyz where current date = c2;
select c1 from xyz a, xyz b;
delete from xyz;
insert into xyz values(1,'1 /10/1992');
insert into xyz values(1,'10/ 1/1992');
insert into xyz values(1,'10/10/19 2');
select * from xyz;

drop table xyz;
create table xyz (c1 time);
insert into xyz values('1 :10:10');
insert into xyz values('10:1 :10');
insert into xyz values('10:10: 1');
select * from xyz;
drop table xyz;

create table xyz (c1 char(10));
insert into xyz values(current date);
insert into xyz values('1111');
update xyz set c1 = current date;
drop table xyz;

create table xyz (c1 smallint);
insert into xyz values(1);
insert into xyz values(-1);
insert into xyz values(2);
create index ixyz on xyz(c1);
select * from xyz a, xyz b where a.c1= b.c1;
drop table xyz;

create table xyz (c1 char(1024), c2 char(24), c3 char(1025));
create index ix1 on xyz (c1,c2,c3);
create index ix2 on xyz (c1,c2);
drop table xyz;

drop table "DB2ePLANTABLE";
drop table t1exp;
create table t1exp (c1 smallint, c2 int, c3 decimal(15,3), c4 char(4), 
c5 date, c6 time, c7 timestamp, c8 varchar(12));
drop table t2exp;
-- for encryption (d5019 xh)
--select * from enc;
create table t2exp (c1 smallint, c2 int, c3 decimal(15,3), c4 char(4), 
c5 date, c6 time, c7 timestamp, c8 varchar(12));
create index t2exp1 on t2exp(c1);
create index t2exp2 on t2exp(c2);
create index t2exp3 on t2exp(c3);
create index t2exp4 on t2exp(c4);
create index t2exp5 on t2exp(c5);
create index t2exp6 on t2exp(c6);
create index t2exp7 on t2exp(c7);
create index t2exp8 on t2exp(c8);
explain set queryno = 100for select * from t2exp;
explain set queryno=1 for select * from t2exp where c1=1;
select query_no, plan_no, table_name, index_name, sort_temp from
 "DB2ePLANTABLE" order by query_no, plan_no;
drop table "DB2ePLANTABLE";
create table "DB2ePLANTABLE" (query_no int, plan_no decimal(11,0), table_name char(18), 
index_name char(18), sort_temp char(1), expl_timestamp timestamp, 
remarks varchar(300));
explain set queryno=1 for select * from t2exp;
drop table "DB2ePLANTABLE";
create table "DB2ePLANTABLE" (query_no int, plan_no int, table_name char(18), 
index_name char(18), sort_temp char(1), expl_timestamp timestamp, 
remarks varchar(300));
explain set queryno=1 for select * from t2exp where c1=1;
explain set queryno=2 for select * from t2exp where c2=1;
explain set queryno=3 for select * from t2exp where c3=1;
explain set queryno=4 for select * from t2exp where c4='1';
explain set queryno=5 for select * from t2exp where c5= current date;
explain set queryno=6 for select * from t2exp where c6= current time;
explain set queryno=7 for select * from t2exp where c7= current timestamp;
explain set queryno=8 for select * from t2exp where c8='1';
explain set queryno=9 for select * from t1exp x, t2exp y where x.c1=y.c1;
explain set queryno=10 for select * from t1exp x, t2exp y where x.c2=y.c2;
explain set queryno=11 for select * from t1exp x, t2exp y where x.c3=y.c3;
explain set queryno=12 for select * from t1exp x, t2exp y where x.c4=y.c4;
explain set queryno=13 for select * from t1exp x, t2exp y where x.c5=y.c5;
explain set queryno=14 for select * from t1exp x, t2exp y where x.c6=y.c6;
explain set queryno=15 for select * from t1exp x, t2exp y where x.c7=y.c7;
explain set queryno=16 for select * from t1exp x, t2exp y where x.c8=y.c8;
explain set queryno = 17 for select * from t2exp order by 1;
explain set queryno = 18 for select * from t1exp order by 1;
--for encryption
--connect to .\ using db2e db2e;
--select * from enc;
explain set queryno = 20 for select * from t2exp where c1 = ?;
explain set queryno = 21 for select * from t2exp where c2 = ?;
explain set queryno = 22 for select * from t2exp where c3 = ?;
explain set queryno = 23 for select * from t2exp where c4 = ?;
explain set queryno = 24 for select * from t2exp where c5 = ?;
explain set queryno = 25 for select * from t2exp where c6 = ?;
explain set queryno = 26 for select * from t2exp where c7 = ?;
explain set queryno = 27 for select * from t2exp where c8 = ?;
--connect to .\ using user1 user1;
--select * from enc;
select query_no, plan_no, table_name, index_name, sort_temp from
 "DB2ePLANTABLE" order by query_no, plan_no;
drop table t1exp;
drop table t2exp;
drop table "DB2ePLANTABLE";

	   CREATE TABLE ROUTE (
             ROUTEID                                         INTEGER NOT NULL,
             ROUTEDATE                                       DATE,
             ROUTECODE                                       VARCHAR(8),
             PRIMARY KEY(ROUTEID)
     );
     CREATE TABLE CUSTOMER (
             ROUTEID                                         INTEGER NOT NULL,
             CUSTCODE                                        VARCHAR(8) NOT NULL,
             NAME                                            VARCHAR(50),
             PRIMARY KEY(ROUTEID, CUSTCODE),
             FOREIGN KEY(ROUTEID) REFERENCES ROUTE
     );
     CREATE TABLE PRODUCT (
             PRODCODE                        VARCHAR(8) NOT NULL,
             SEQUENCE                        INTEGER,
             DESCRIPTION                     VARCHAR(50),
             PRIMARY KEY(PRODCODE) 
     );

     CREATE TABLE PRICING (
             PRICINGID                       INTEGER NOT NULL,
             PRODCODE                        VARCHAR(8),
             CUSTCODE                        VARCHAR(8),
             PRIMARY KEY(PRICINGID),
             FOREIGN KEY(PRODCODE) REFERENCES PRODUCT,
             FOREIGN KEY(ROUTEID, CUSTCODE) REFERENCES CUSTOMER
     );
DROP TABLE ROUTE;
DROP TABLE CUSTOMER;
DROP TABLE PRODUCT;

-- test join reordering for ORDER BY

drop table t;
drop table s;
CREATE TABLE T (A INT, B INT);
CREATE TABLE S (X INT, Y INT);
CREATE INDEX IDXY ON S(Y);
insert into t values(1,1);
insert into t values(1,2);
insert into t values(2,0);
insert into t values(-1,4);
insert into t values(4, -5);
insert into s select * from t;


explain set queryno = 5 for SELECT T.A, T.B, S.X, S.Y FROM T, S WHERE A=X ORDER BY Y;
SELECT T.A, T.B, S.X, S.Y FROM T, S WHERE A=X ORDER BY Y;

explain set queryno = 50 for SELECT T.A, T.B, S.X, S.Y FROM S, T WHERE A=X ORDER BY Y;
SELECT T.A, T.B, S.X, S.Y FROM S, T WHERE A=X ORDER BY Y;

drop table t;
drop table s;


drop table t1;
drop table t2;
create table t1(c1 int,c2 int,c3 int);
create table t2(c1 int,c2 int,c3 int);
create index ixxxx1 on t1(c1,c2);
create index ixxxx2 on t2(c1,c2);
insert into t1 values(1,1,1);
insert into t1 values(0,0,0);
insert into t1 values(1,2,3);
insert into t1 values(-1,0,5);
insert into t1 values(0,-1,2);
insert into t1 values(2,2,2);
insert into t1 values(2,1,-3);
insert into t1 values(2,3,0);
insert into t1 values(0,1,4);
insert into t2 select * from t1;
insert into t2 values(2,10,3);
insert into t1 values(0,3,-3);

explain set queryno = 105 for select t1.c1, t1.c2, t2.c1, t2.c2 from t2, t1
  where t1.c3 = t2.c3 order by 3,4;

select t1.c1, t1.c2, t2.c1, t2.c2 from t2, t1
  where t1.c3 = t2.c3 order by 3,4;

explain set queryno = 150 for select t1.c1, t1.c2, t2.c1, t2.c2 from t1, t2
  where t1.c3 = t2.c3 order by 3,4;

select t1.c1, t1.c2, t2.c1, t2.c2 from t1, t2
  where t1.c3 = t2.c3 order by 3,4;

create table t3 (c1 int,c2 int,c3 int);
create index ixxxx3 on t3(c1,c2);
insert into t3 values(1,1,1);
insert into t3 values(1,2,0);
insert into t3 values(0,1,-5);
insert into t3 values(2,-1,0);
insert into t3 values(2,1,5);

explain set queryno = 205 for select t1.c1, t1.c2, t2.c1,t2.c2, t3.c1,t3.c2 from t1,t2,t3
  where t1.c1 = t2.c1 and t2.c1 = t3.c1 and t1.c1 = t3.c1 order by 1,2;

select t1.c1, t1.c2, t2.c1,t2.c2, t3.c1,t3.c2 from t1,t2,t3
  where t1.c1 = t2.c1 and t2.c1 = t3.c1 and t1.c1 = t3.c1 order by 1,2;

explain set queryno = 215 for select t1.c1, t1.c2, t2.c1,t2.c2, t3.c1,t3.c2 from t2,t1,t3
  where t1.c1 = t2.c1 and t2.c1 = t3.c1 and t1.c1 = t3.c1 order by 1,2;

select t1.c1, t1.c2, t2.c1,t2.c2, t3.c1,t3.c2 from t2,t1,t3
  where t1.c1 = t2.c1 and t2.c1 = t3.c1 and t1.c1 = t3.c1 order by 1,2;

explain set queryno = 225 for select t1.c1, t1.c2, t2.c1,t2.c2, t3.c1,t3.c2 from t3,t2,t1
  where t1.c1 = t2.c1 and t2.c1 = t3.c1 and t1.c1 = t3.c1 order by 1,2;

select t1.c1, t1.c2, t2.c1,t2.c2, t3.c1,t3.c2 from t3,t2,t1
  where t1.c1 = t2.c1 and t2.c1 = t3.c1 and t1.c1 = t3.c1 order by 1,2;

-- make sure order by multiple inner tables still does sort.
explain set queryno = 500 for select t1.c1, t1.c2, t2.c1, t2.c2, t3.c1,t3.c2 from t3, t2, t1
  where t1.c1 = t2.c1 and t2.c1 = t3.c1 and t3.c1 = t1.c1 order by 1, 4;

select t1.c1, t1.c2, t2.c1, t2.c2, t3.c1,t3.c2 from t3, t2, t1
  where t1.c1 = t2.c1 and t2.c1 = t3.c1 and t3.c1 = t1.c1 order by 1, 4;


select query_no, plan_no, table_name, index_name, sort_temp from
 "DB2ePLANTABLE" order by query_no, plan_no;

drop table t1;
drop table t2;
drop table t3;
drop table "DB2ePLANTABLE";

-- order by optimization   d8679 tge

create table t2 (c1 int, c2 int, c3 int, c4 int, c5 int);
create index i21 on t2 (c2 desc, c1 asc, c3 desc, c4 desc, c5);
create index i22 on t2 (c1, c2 desc, c3);
create index i23 on t2 (c1 desc, c2 desc, c3, c4);
create index i24 on t2 ($dirty);
insert into t2 values (20, 3, 6, 7, 6);
insert into t2 values (0, 2, 5, 8, 1);
insert into t2 values (9, 9, 6, 20, 1);
insert into t2 values (6, 2, 0, 8, 10);
insert into t2 values (2, 12, 6, 18, 1);
insert into t2 values (6, 2, 0, 8, 10);
insert into t2 values (6, 2, -1, 8, 1);
insert into t2 values (4, 3, 6, 9, 1);
insert into t2 values (4, 3, 6, 8, 1);
insert into t2 values (4, 3, 5, 9, 1);

-- let $dirty join the fun, d9489 tge
explain set queryno=1 for select $dirty, c1 from t2 where $dirty>0 order by 1;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;
select $dirty, c1 from t2 where $dirty>0 order by 1;
delete from "DB2ePLANTABLE";

-- this case index doesn't cover all rows, don't use it
explain set queryno=1 for select $dirty, c1 from t2 order by 1;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;
select $dirty, c1 from t2 order by 1;
delete from "DB2ePLANTABLE";

-- no temp, should choose i21, since it has the longest key
explain set queryno=1 for select * from t2 where c1 > 1 and c2 = 2 and c3 < 6 and c4 = 8 and c5 > 0 order by c1 desc, c3;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;
select * from t2 where c1 > 1 and c2 = 2 and c3 < 6 and c4 = 8 and c5 > 0 order by c1 desc, c3;
delete from "DB2ePLANTABLE";

-- no temp, should choose i23, it has longer key than i22
explain set queryno=1 for select * from t2 where c1 > 1 and c2 > 2 and c3 = 6 and c4 > 8 order by c1, c2 desc, c3 desc;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;
select * from t2 where c1 > 1 and c2 > 2 and c3 = 6 and c4 > 8 order by c1, c2 desc, c3 desc;
delete from "DB2ePLANTABLE";

-- no temp, should choose i23, it is a non-sensible index (no start/stop key)
explain set queryno=1 for select * from t2 where c3 = 6 order by c1 desc, c2, c4;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;
select * from t2 where c3 = 6 order by c1 desc, c2, c4;
delete from "DB2ePLANTABLE";

CREATE TABLE TEST3 ("NAME" VARCHAR (128) NOT NULL);
CREATE INDEX IDXTEST3 ON TEST3("NAME");

-- we should not form a temp table
-- we should use an index but we cannot tell if the start/stop keys are set properly
explain set queryno=1 for SELECT NAME FROM TEST3 WHERE NAME LIKE '1 Bra%' ORDER BY NAME;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- we should not form a temp table
-- we should use an index but we cannot tell if the start/stop keys are set properly
explain set queryno=2 for SELECT 1, NAME FROM TEST3 WHERE NAME LIKE '1 Bra%' ORDER BY 1, 2;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- we should not form a temp table
-- we should use an index but we cannot tell if the start/stop keys are set properly, no start/stop key
explain set queryno=3 for SELECT 1, NAME FROM TEST3 WHERE NAME LIKE '%' ORDER BY 1, 2;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- we should use an index but we cannot tell if the start/stop keys are set properly
delete from "DB2ePLANTABLE";
explain set queryno=2 for SELECT NAME FROM TEST3 WHERE NAME LIKE '1 Bra%';
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- we could avoid creating the temp
delete from "DB2ePLANTABLE";
explain set queryno=3 for SELECT DISTINCT NAME FROM TEST3 WHERE NAME LIKE '1 Bra%';
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

delete from "DB2ePLANTABLE";
explain set queryno=2 for SELECT NAME FROM TEST3 WHERE NAME LIKE '1 Bra%' and Name > '0' and Name < '2';
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

delete from "DB2ePLANTABLE";
explain set queryno=2 for SELECT NAME FROM TEST3 WHERE NAME LIKE '1 Bra%' and Name > '0' and Name < '2' order by name;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

create table linpedido (
  numlpd decimal(5,0) not null,
  canlpd decimal(5,0) not null,
  venlpd decimal(10,0) not null,
  linlpd decimal(3,0) not null,
  prelpd decimal(7,2) not null,
  implpd decimal(5,0) not null,
  artlpd decimal(13,0) not null,
  fenlpd char(8) not null,
  anblpd char(30) not null,
  ac1lpd decimal(3,0) not null,
  ac2lpd decimal(3,0) not null, primary key (numlpd, venlpd, linlpd));

create index idxlinpedido on linpedido (numlpd, ac1lpd, ac2lpd );

-- we should use the index but form a temp
delete from "DB2ePLANTABLE";
explain set queryno=11 for select canlpd, prelpd, implpd, artlpd, fenlpd, anblpd, ac1lpd, ac2lpd from linpedido where numlpd=1.0 order by ac2lpd ;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- we should use the index
-- customer problem
delete from "DB2ePLANTABLE";
explain set queryno=10 for select canlpd, prelpd, implpd, artlpd, fenlpd, anblpd, ac1lpd, ac2lpd from linpedido where numlpd=1.0 order by ac1lpd,ac2lpd ;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

delete from "DB2ePLANTABLE";
explain set queryno=12 for select numlpd, canlpd, prelpd, implpd, artlpd, fenlpd, anblpd, ac1lpd, ac2lpd from linpedido where ac1lpd=1.0 order by numlpd, ac2lpd ;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

delete from "DB2ePLANTABLE";
explain set queryno=13 for select numlpd, ac2lpd from linpedido where ac1lpd=1.0 order by numlpd, ac2lpd ;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- we use the index and no temp
delete from "DB2ePLANTABLE";
explain set queryno=14 for select distinct numlpd, ac1lpd, ac2lpd from linpedido;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- we form a temp; use index
delete from "DB2ePLANTABLE";
explain set queryno=14 for select distinct numlpd, ac1lpd, ac2lpd from linpedido where numlpd=1.0;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-------------


CREATE TABLE T1 (a int, b int, c int);
create index idxt1 on t1(c, b, a);

-- use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select * from t1 order by c;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select * from t1 order by c, b;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- don't use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select * from t1 order by c, a;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select 1, a, b, c from t1 order by 1, 4;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 order by 1, 5;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- don't use index yet because of expression rather than constant
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1-1 from t1 order by 1, 5;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where c = 1 order by 3, 5;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where c = ? order by 3, 5;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where b = ? order by 1, 5;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where b = ? order by 1, 2;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- don't use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where b = ? order by 1, 1;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- don't use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where b = ? order by 1, 4;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- don't use index
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where b = ? order by 2, 5;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index!!
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where b = ? order by 5, 5;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index!!
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where b = ? order by 4, 5;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- use index!!
delete from "DB2ePLANTABLE";
explain set queryno=15 for select c, a, b, c, 1 from t1 where b = ? order by 5, 4;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

drop table t2;
CREATE TABLE T2 (e int, f int, g int);
create index idxt2 on t2(e, f, g);


-- indexes on both tables
delete from "DB2ePLANTABLE";
explain set queryno=20 for select * from t1, t2 where a = e order by c;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- index on the first table
delete from "DB2ePLANTABLE";
explain set queryno=20 for select * from t1, t2 where a = f order by c;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- index on the inner only; optimizer reorder tables, still use index and no temp
delete from "DB2ePLANTABLE";
explain set queryno=20 for select * from t1, t2 where a = e order by e;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

delete from "DB2ePLANTABLE";
explain set queryno=20 for  select * from t1, t2 where a = e order by c, b, a; 
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

delete from "DB2ePLANTABLE";
explain set queryno=20 for  select * from t1, t2 where a = e and c > 10 order by c, b, a; 
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

delete from "DB2ePLANTABLE";
explain set queryno=20 for  select * from t1, t2 where a = e and c > 10;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- index on the inner only; optimizer reorder tables, still use index and no temp
delete from "DB2ePLANTABLE";
explain set queryno=20 for select * from t1, t2 where a = e order by e;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

-- Simple join reordering
-- if index on the inner only, optimizer reorder tables, still use index and no temp
delete from "DB2ePLANTABLE";
explain set queryno=20 for select * from t2, t1 where a = e order by e, f, g;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

delete from "DB2ePLANTABLE";
explain set queryno=20 for select * from t1, t2 where a = e order by e, f, g;
select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by query_no, plan_no;

DROP TABLE T1;
DROP TABLE T2;
DROP TABLE TEST3;
DROP TABLE LINPEDIDO;
DROP TABLE "DB2ePLANTABLE";
