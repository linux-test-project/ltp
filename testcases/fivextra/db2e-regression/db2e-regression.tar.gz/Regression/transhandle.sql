----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------
--- Test Multiple Stmt Handles With Transactions (should be cleared)
----------------------------------------------------------------------------------------
-- drop table tb;
-- drop table tb1;

create table tb(a char(10));

create stmt handle :1;
create stmt handle :2;

prepare :1 insert into tb values(?);

-- expected error for following command instead of crashing 
execute :1;

bind :1 1 aaa;
execute :1;
bind :1 1 bbb;
execute :1;

select * from tb;

execdirect :2 select * from tb;
fetch :2;

autocommit off;
commit work;

-- expected failure for fetch after a transaction
fetch :2;

bind :1 1 ccc;
execute :1;

select * from tb;

execdirect :2 select * from tb;
fetch :2;
fetch :2;
fetch :2;
-- next fetch is supposed to return nothing
fetch :2;

-- next stmt will as it is inside the scope of a transaction 
create table tb1(b char(10), c int);

autocommit on;
-- next one should work
create table tb1(b char(10), c int);

insert into tb1 values('abc', 5);

autocommit off;
prepare :1 insert into tb1 values(?, 10);
prepare :2 insert into tb1 values(?, 15);

bind :1 1 enu;
bind :2 1 deu;
rollback work;

execute :1;
execute :2;

-- prepare stmt shouldn't be impacted by transaction
select * from tb1;

-- stmt handle can be reused, tests "order by" in the following
execdirect :1 select b,c from tb1 order by c desc;
fetch :1;
fetch :1;
fetch :1;
fetch :1;

select a, b from tb, tb1 where a < b;
-- stmt handle can be reused, tests "table join" in the following
execdirect :2 select a, b from tb, tb1 where a < b;
fetch :2;
fetch :2;
fetch :2; 
fetch :2;
fetch :2;
fetch :2;
fetch :2;
fetch :2;

insert into tb1 values('abc', 123);
insert into tb1 values('abc', 234);

select * from tb1;
select distinct b from tb1;
-- test "distinct"
execdirect :1 select distinct b from tb1;
fetch :1;
fetch :1;
fetch :1;
fetch :1;

-- test "group by"
select MAX(c) from tb1 group by b; 
execdirect :2 select MAX(c) from tb1 group by b; 
fetch :2;
fetch :2;
fetch :2;

-- following 2 stmts will fail as they are inside transaction
drop table tb;
drop table tb1;

autocommit on;
-- following 2 should work
drop table tb;
drop table tb1;

 create table tb2(a char(20));
 prepare :1 insert into tb2 values(?);
 bind :1 1 test;
 execute : 1;

 execdirect :2 drop table tb2;
-- expected failure of the following
 execute :1;

 execdirect :2 create table tb2(a char(20));
-- following one is not allowed to work either
 execute :1;

 insert into tb2 values('string1');
 insert into tb2 values('string2');

 execdirect :1 select * from tb2;
 fetch :1;

 execdirect :2 drop table tb2;
-- expected failure of the following
 fetch :1;

drop stmt handle :1;
drop stmt handle :2;

blastdb;