connect to enctest1\ user db2e using db2e;
