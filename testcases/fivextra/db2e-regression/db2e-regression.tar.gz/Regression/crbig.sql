drop table t;
-- use several pages for each record
 create table t(i int, c char(4100), v varchar(50));

