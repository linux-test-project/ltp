--
-----------------------------------------------------------------------------------
-- This testcase tests create/drop index on encrypted table for
-- authenticated user and non-authenticated user
-----------------------------------------------------------------------------------
-- 
connect to enctest3\ user user using passwd;
--
grant encrypt on database to "user" using "passswd" new "passwd";
--
create table enc(a int, b char(100, c varchar(20)) encryption;
--
create table enc(a int, b char(10), c varchar(20), d decimal(15,4)) with encryption;
--
insert into enc values(10, 'test1', 'Hello!kitty', 12.34);
--
insert into enc values(20, 'test2', 'Is this funny?', 0.001);
--
insert into enc values(30, 'test3', 'probably not', -9999.99);
--
insert into enc values(20, 'test2', 'I think so', 9999.99);
--
insert into enc values(30, 'test3', 'Yeah..yeah', -0.001);
--
create index ind1 on enc(a);
--
create index ind2 on enc(b);
--
select * from enc;
--
connect to enctest3\ user db2e using db2e;
--
select * from enc;
--
create index ind3 on enc(c);
--
drop index ind1;
--
connect to enctest3\ user user using passwd;
--
select * from enc order by b;
--
select min(a), max(d) from enc group by d;
--
select distinct(a) from enc;
--
select sum(d), avg(a) from enc;
-- 
drop index ind1;
--
drop index ind2;
--
----------------------------------------------------------------------------------
-- Following are doing encryption inside transaction                            --
----------------------------------------------------------------------------------
--
connect to enctest3\ user user using passwd;
--
create table tb(a int, b char(10)) with encryption;
--
autocommit off;
--
insert into tb values(10, 'abcd');
--
rollback work;
--
select * from tb;
--
insert into tb values(10, 'abcd');
--
insert into tb values(20, 'bcda');
--
commit work;
--
delete from tb where a = 20;
--
commit work;
--
select * from tb;
--
-----------------------------------------------------------------------------------
-- This testcases uses SampleCLP "Import/Export" command to test data encryption --
-----------------------------------------------------------------------------------
--
connect to enctest3\ user user using passwd;
--
create table enc1(a int, b char(10), c decimal(15,4));
--
insert into enc1 values(10, 'aaa', 9.99);
insert into enc1 values(15, 'bbb', 12.333);
insert into enc1 values(20, 'ccc', 23.232);
insert into enc1 values(25, 'xyzxy', 33.44);
insert into enc1 values(100, 'aaa', 9.99);
insert into enc1 values(150, 'bbb', 12.333);
insert into enc1 values(200, 'ccc', 23.232);
insert into enc1 values(250, 'xyzxy', 33.44);
insert into enc1 values(101, 'aaa', 9.99);
insert into enc1 values(152, 'bbb', 12.333);
insert into enc1 values(202, 'ccc', 23.232);
insert into enc1 values(253, 'xyzxy', 33.44);
insert into enc1 values(1010, 'aaa', 9.99);
insert into enc1 values(1510, 'bbb', 12.333);
insert into enc1 values(2012, 'ccc', 23.232);
insert into enc1 values(2523, 'xyzxy', 33.44);
--
create table enc2(a int, b char(10), c decimal(15,4)) with encryption;
--
-- read rawdata from file
--
-- import from .\enctest3\encinput.txt of del insert into enc1;
--
-- can use export command to import/export data to/from an encrypted table
--
export to .\enctest3\encdata.txt of del select * from enc1;
--
import from .\enctest3\encdata.txt of del insert into enc2;
--
select * from enc2;
--
export to .\enctest3\encout.txt of del select * from enc2;
--
update enc2 set c = 12.345 where a = 15;
--
delete from enc2 where a = 20;
--
-- Connect as a non-registered user
--
connect to enctest3\ user foo using bar;
--
list tables;
--
-- can not use import to insert data to an encypted table
-- 
import from .\enctest3\encdata.txt of del insert into enc2;
--
-- can not use export to export data from an encrypted table
--
export to .\enctest3\encoutput2.txt of del select * from enc2;
--
-- can still export from an unecrypted table
--
export to .\enctest3\encoutput1.txt of del select * from enc1;
--
drop table enc1;
-- 
drop table enc2;
--
connect to enctest3\ user user using passwd;
--
drop table enc2;
--
--
------------------------------------------------------------------------------
--            create 20 encrypted tables                                    --
------------------------------------------------------------------------------
connect to enctest3\ user user using passwd;
--
create table enc1(a int) with encryption;
--
create table enc2(a int) with encryption;
--
create table enc3(a int) with encryption;
--
create table enc4(a int) with encryption;
--
create table enc5(a int) with encryption;
--
create table enc6(a int) with encryption;
--
create table enc7(a int) with encryption;
--
create table enc8(a int) with encryption;
--
create table enc9(a int) with encryption;
--
create table enc10(a int) with encryption;
--
create table enc11(a int) with encryption;
--
create table enc12(a int) with encryption;
--
create table enc13(a int) with encryption;
--
create table enc14(a int) with encryption;
--
create table enc15(a int) with encryption;
--
create table enc16(a int) with encryption;
--
create table enc17(a int) with encryption;
--
create table enc18(a int) with encryption;
--
create table enc19(a int) with encryption;
--
create table enc20(a int) with encryption;
--
list tables;
--
--blastdb;
--------------------------------------------------------------------------
-- create a wide table (with blob column)
--------------------------------------------------------------------------
connect to enctest3\ user user using passwd;
--
list tables;
--
create table dt(c1 date not null, c2 time not null, c3 timestamp not null,
c4 char(20) not null, c5 varchar(20) not null, c6 blob(20) not null, 
c7 decimal(10,2) not null, c8 smallint not null, c9 int not null, c10 blob(20),
c11 blob(20), c12 varchar(25) not null) with encryption;
--
insert into dt values('2002-08-13', '01:00:00', '2002-08-13-01.00.00.339001', 
'abcd', 'wxyz', 'blob', 12.34, 0, 0, 'charbit', 'varcharbit', '0.0');
--
select c1,c2,c3,c4,c5,c7,c8,c9,c12 from dt;
--
--blastdb;
---------------------------------------------------------------------------
-- create a big table
---------------------------------------------------------------------------
connect to enctest3\ user user using passwd;
--
list tables;
--
create table bigenc(a char(8192), b varchar(8196), c char(8196));
--
insert into bigenc values('a1', 'b1', 'c1');
--
insert into bigenc values('a2', 'b2', 'c2');
--
insert into bigenc values('a3', 'b3', 'c3');
--
insert into bigenc values('a4', 'b4', 'c4');
--
insert into bigenc values('a5', 'b5', 'c5');
--
insert into bigenc values('a6', 'b6', 'c6');
--
insert into bigenc values('a7', 'b7', 'c7');
--
insert into bigenc values('a8', 'b8', 'c8');
--
insert into bigenc values('a9', 'b9', 'c9');
--
insert into bigenc values('a10', 'b10', 'c10');
--
select $rid from bigenc;
--
blastdb;
--
 
