drop table def;
drop table def2;

-- okay
create table def (c1 char(200) default '1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111112222211', c2 int);



drop table def;

-- before fix ...crashes because trailing blank before comma.
create table def (c1 char(200) default '1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111112222211' , c2 int);



drop table def;
-- before fix....crashes because leading blank before value
create table def (c1 char(200) default  '1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111112222211');

drop table def;

create table def (c1 char(200) default '11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111122222311');

drop table def;

create table def (c1 char(200) default '111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111222223411');

drop table def;

create table def (c1 char(200) default '1111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111112222234511');

drop table def;

create table def (c1 char(200) default '11111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111122222345611');

drop table def;

create table def (c1 char(200) default '111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111222223456711');

create table def2 (c1 char(200) default '111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111222223411', 
c2 varchar(200) default '111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111222223411', c3 smallint default 123, c4 integer default 456, c5 decimal(12,4) default 123.45, 
c6 date default '10/10/1992', c7 time default current time, c8 timestamp default current timestamp);

insert into def2 (c1) values('abc');
insert into def2 (c2) values('def');
insert into def2 (c3) values(1);
insert into def2 (c4) values(1);
insert into def2 (c5,c6) values(1.1, '01/01/1901');

select c1,c2,c3,c4,c5,c6
 from def2;

drop table def;
drop table def2;

-- TEST IDENTITY COLUMN

drop table t1;
drop table t2;
drop table t3;
drop table t4;

-- negative tests

-- can not have more than 1 identity columns, sqlstate 428C1
create table t1 (c1 int generated always as identity, c2 smallint generated always as identity);

-- only allow int, smallint and decimal types, sqlstate 42815
create table t1 (c1 int, c2 char(6) generated always as identity);

-- can not have default value, sqlstate 42623
create table t1 (c1 int, c2 int default 8 generated always as identity);

create table t1 (c1 int primary key generated always as identity, c2 int);
create table t2 (c1 smallint generated always as identity primary key, c2 int);
create table t3 (c1 int generated always as identity, c2 int, check (c1 + c2 < 10) );
create table t4 (c1 decimal(31,0) generated always as identity, c2 int);

-- identity column can not be target column of INSERT, INSERT SELECT, UPDATE, sqlstate 428C9
insert into t1 values (2, 5);
insert into t1(c1) values (5);
insert into t1 select * from t2;
insert into t1(c1) select c1 from t2;
update t3 set c1 = 5 where c2 = 5;
update t3 set c2 = 5 where c1 = 5;

insert into t1(c2) values (2);
insert into t1(c2) values (3);
insert into t1(c2) values (4);
insert into t1(c2) values (5);
select * from t1;
delete from t1 where c2 = 3;
delete from t1 where c1 = 3;
select * from t1;
insert into t1(c2) values (6);
insert into t1(c2) values (7);
insert into t1(c2) values (8);
select * from t1;
-- try primary key index
select * from t1 where c1 > 2;

-- test out of range, smallint limit is 32K
-- t2 now 5 rows
insert into t2(c2) select c1 from t1;
-- 10
insert into t1(c2) select c1 from t2;
-- 15
insert into t2(c2) select c1 from t1;
-- 25
insert into t1(c2) select c1 from t2;
-- 40
insert into t2(c2) select c1 from t1;
-- 65
insert into t1(c2) select c1 from t2;
-- 105
insert into t2(c2) select c1 from t1;
-- 170
insert into t1(c2) select c1 from t2;
-- 275
insert into t2(c2) select c1 from t1;
-- 445
insert into t1(c2) select c1 from t2;
-- 720
insert into t2(c2) select c1 from t1;
-- 1165
insert into t1(c2) select c1 from t2;
-- 1885
insert into t2(c2) select c1 from t1;
-- 3050
insert into t1(c2) select c1 from t2;
-- 4935
insert into t2(c2) select c1 from t1;
-- 7985
insert into t1(c2) select c1 from t2;
delete from t2;
-- 12920
insert into t2(c2) select c1 from t1;
delete from t2;
-- 20905
insert into t2(c2) select c1 from t1;
delete from t2;
-- 28890
insert into t2(c2) select c1 from t1;
delete from t2;
-- 36875, this is too much for smallint, range exausted, sqlstate 23522
insert into t2(c2) select c1 from t1;

-- is index still there?
select * from t1 where c1 > 7970 and c1 < 7980;

-- test check constraints
insert into t3(c2) values (8);
-- this is fine
insert into t3(c2) values (7);
-- this violates check constraint
insert into t3(c2) values (7);
-- this violates check constraint
insert into t3(c2) values (10);

select * from t3;

-- test decimal autoincrement
insert into t4(c2) values (2);
insert into t4(c2) values (3);
insert into t4(c2) values (4);
insert into t4(c2) values (5);
select * from t4;
delete from t4;
insert into t4(c2) values (2);
insert into t4(c2) values (3);
insert into t4(c2) values (4);
insert into t4(c2) values (5);
select * from t4;

-- with transaction
autocommit off;
-- should be 7987 (deleted 2 rows)
select max(c1) from t1;
insert into t1(c2) values (555);
insert into t1(c2) values (555);
select * from t1 where c1 > 7987;
rollback;
select * from t1 where c1 > 7987;
delete from t1 where c1 > 7982;
select max(c1) from t1;
rollback;
select max(c1) from t1;
insert into t1(c2) values (555);
insert into t1(c2) values (555);
commit;
select * from t1 where c1 > 7987;

autocommit on;
drop table t1;
drop table t2;
drop table t3;
drop table t4;

-- with NOT NULL
create table t1 (c1 int, c2 int NOT NULL generated always as identity);
create table t2 (c1 int, c2 smallint NOT NULL generated always as identity, c3 decimal(7,0));
create table t3 (c1 int, c2 decimal(10,0) NOT NULL generated always as identity, c3 decimal(7,0));

-- testing of syscolumns
select cname, tname, attr, length from "DB2eSYSCOLUMNS" order by tname, cname;

drop table t1;
drop table t2;
drop table t3;

-- primary key
create table t1 (c1 int, c2 int NOT NULL generated always as identity primary key);
create table t2 (c1 int, c2 smallint NOT NULL generated always as identity primary key, c3 decimal(7,0));
create table t3 (c1 int, c2 decimal(10,0) NOT NULL generated always as identity primary key, c3 decimal(7,0));

list tables;

drop table t1;
drop table t2;
drop table t3;

-- primary key
create table t1 (c1 int, c2 int NOT NULL generated always as identity, primary key(c2));
create table t2 (c1 int, c2 smallint NOT NULL generated always as identity, c3 decimal(7,0), primary key(c2));
create table t3 (c1 int, c2 decimal(10,0) NOT NULL generated always as identity, c3 decimal(7,0), primary key(c2));

list tables;

insert into t1 (c1) values (1);
insert into t1 (c1) values (2);
insert into t1 (c1) values (3);

select * from t1;

insert into t1 (c1) values (3);

-- using index
select * from t1 order by c2 asc;
select * from t1 order by c2 desc;

select c2, c2 + 1 from t1 order by c2 asc;
select c2, c2 + 1 from t1 order by c2 desc;

select * from t1 where c2 > 2;
select * from t1 where c2 < 2;

select cname, tname, attr, length from "DB2eSYSCOLUMNS" order by tname, cname;

drop table t1;
drop table t2;
drop table t3;

-- create indexes
create table t1 (c1 int, c2 int NOT NULL generated always as identity);
create table t2 (c1 int, c2 smallint NOT NULL generated always as identity, c3 decimal(7,0));
create table t3 (c1 int, c2 decimal(10,0) NOT NULL generated always as identity, c3 decimal(7,0));

create index idx1 on t1(c2);
create index idx2 on t2(c2);
create index idx3 on t3(c2);

-- using index
insert into t1 (c1) values (1);
insert into t1 (c1) values (2);
insert into t1 (c1) values (3);

select * from t1 order by c2 asc;
select * from t1 order by c2 desc;

-- using index
insert into t2 (c1) values (1);
insert into t2 (c1) values (2);
insert into t2 (c1) values (3);

select * from t2 order by c2 asc;
select * from t2 order by c2 desc;

-- using index
insert into t3 (c1) values (1);
insert into t3 (c1) values (2);
insert into t3 (c1) values (3);

select * from t3 order by c2 asc;
select * from t3 order by c2 desc;

drop table t1;
drop table t2;
drop table t3;

-- multiple columns primary key

create table t3 (c1 int not null, c2 decimal(10,0) NOT NULL generated always as identity, c3 decimal(7,0), primary key(c1,c2));
insert into t3 (c1, c3) values (10, 10);
insert into t3 (c1, c3) values (10, 10);
insert into t3 (c1, c3) values (10, 10);

insert into t3 (c1, c3) values (20, 20);
insert into t3 (c1, c3) values (20, 20);
insert into t3 (c1, c3) values (20, 20);

insert into t3 (c1, c3) values (30, 20);
insert into t3 (c1, c3) values (30, 20);
insert into t3 (c1, c3) values (30, 20);

select * from t3;

select * from t3 where c2 > 3;
select * from t3 where c1 = 20;

drop table t3;


-- multiple stmt handles on insert

create table t1 (c1 int, c2 int NOT NULL generated always as identity);

create stmt handle :1;
create stmt handle :2;

autocommit off;

prepare :1 insert into t1 (c1) values (10);
prepare :2 insert into t1 (c1) values (20);

execute :1;
execute :1;

select * from t1;

execute :2;
execute :2;

select * from t1;

execute :1;
execute :1;

select * from t1;

execute :2;
execute :2;

select * from t1;

rollback;

prepare :1 insert into t1 (c1) values (100);
prepare :2 insert into t1 (c1) values (200);

execute :1;
execute :1;

select * from t1;

execute :2;
execute :2;

select * from t1;

execute :1;
execute :1;

select * from t1;

execute :2;
execute :2;

select * from t1;

commit;

autocommit on;

drop stmt handle :1;
drop stmt handle :2;

drop table t1;
