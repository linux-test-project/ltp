-- ------------------- FILE: TD01.SQL  --------------------
-- -                                                      - 
-- -                  CREATE All Table                    -
-- -                                                      -
-- --------------------------------------------------------


CREATE TABLE UserTable
(UserId varchar(5) primary key not null, Name varchar(20), Age int);
CREATE TABLE 
  DemandTable (UserId varchar(5), Subject varchar(20));
CREATE TABLE 
  TutorTable 
  (Teacher varchar(5), Student varchar(5), Subject varchar(20));
