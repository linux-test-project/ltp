-- ------------------ FILE: SYNTAX.SQL  -------------------
-- -                                                      - 
-- -          CHECK ALL STANDARD SQL SYNTAX ERROR         -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE Testing;

-- Test memory leak when syntax error, d5906
CREATE TABLE Testing (a int,
                      aaaaa char(10) default 'amrish',
                      bbbbb char(10) default 'mickey',
                      primaary key(a));

CREATE TABLE Testing (Tint 		INT,
		      Tsmallint  	SMALLINT, 
		      Tdec 		DECIMAL(5,2), 
		      Tvarchar 		VARCHAR(10), 
		      Tchar 		CHAR(15),
		      Ttmp		VARCHAR(20));

INSERT INTO Testing VALUES(101, 1, 11.5, 'DATA 1', 'O O O O O', NULL);
INSERT INTO Testing VALUES(102, 2, 12.55, 'DATA 2', 'O O O O O', NULL);
INSERT INTO Testing VALUES(103, 3, 13.555, 'DATA 3', 'O O O O O', NULL);
INSERT INTO Testing VALUES(104, 4, 14.5555, 'DATA 4', 'O O O O O',NULL);
INSERT INTO Testing VALUES(105, 5, 15.55555, 'DATA 5', 'O O O O O', NULL);
INSERT INTO Testing VALUES(106, 6, 16.555555, 'DATA 6', 'O O O O O', NULL);
INSERT INTO Testing VALUES(107, 7, 17.5555555, 'DATA 7', 'O O O O O', NULL);
INSERT INTO Testing VALUES(108, 8, 18.55555555, 'DATA 8', 'O O O O O', NULL);
INSERT INTO Testing VALUES(109, 9, 19.555555555, 'DATA 9', 'O O O O O', NULL);
INSERT INTO Testing VALUES(110, 10, 20., 'DATA 10', 'O O O O O', NULL);
INSERT INTO Testing VALUES(111, 11, .555, 'DATA 11', 'O O O O O', NULL);
INSERT INTO Testing VALUES(112, 12, 0.555, 'DATA 12', 'O O O O O', NULL);

SELECT * FROM Testing;

DROP TABLE Testing;

CREATE TABLE Testing (Tint 		INT,
		      Tsmallint  	SMALLINT, 
		      Tdec 		DECIMAL(5,2), 
		      Tvarchar 		VARCHAR(10), 
		      Tchar 		CHAR(15),
		      Ttmp		VARCHAR(20));

INSERT INTO Testing VALUES(101, 1, 11.0, 'DATA 1', 'O O O O O', NULL);
INSERT INTO Testing VALUES(102, 2, 12.00, 'DATA 2', 'O O O O O', NULL);
INSERT INTO Testing VALUES(103, 3, 13.000, 'DATA 3', 'O O O O O', NULL);
INSERT INTO Testing VALUES(104, 4, 14.0000, 'DATA 4', 'O O O O O',NULL);
INSERT INTO Testing VALUES(105, 5, 15.00000, 'DATA 5', 'O O O O O', NULL);
INSERT INTO Testing VALUES(106, 6, 16.000000, 'DATA 6', 'O O O O O', NULL);
INSERT INTO Testing VALUES(107, 7, 17.0000000, 'DATA 7', 'O O O O O', NULL);
INSERT INTO Testing VALUES(108, 8, 18.00000000, 'DATA 8', 'O O O O O', NULL);
INSERT INTO Testing VALUES(109, 9, 19.000000000, 'DATA 9', 'O O O O O', NULL);
INSERT INTO Testing VALUES(110, 10, 20., 'DATA 10', 'O O O O O', NULL);

SELECT * FROM Testing;

-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = column name II WHERE various search conditions. 
-- Column name I = INT, column name II = SMALLINT, DEC, CHAR, VARCHAR
-------------------------------------------------------------------------------------------

--SUCC
UPDATE Testing SET Tint = Tsmallint WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;
UPDATE Testing SET Tint = Tsmallint + 100 WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22003
INSERT INTO Testing VALUES(111, 2147483647, 11, 'DATA 11', 'X O O O O', NULL);
UPDATE Testing SET Tint = Tsmallint WHERE Tchar = 'X O O O O';
SELECT * FROM Testing;

-----------------------------
-- SUCC 
UPDATE Testing SET Tint = Tdec WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;
UPDATE Testing SET Tint = Tsmallint + 100 WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22003
INSERT INTO Testing VALUES(111, 11, 2147483647, 'DATA 11', 'O O X O O', NULL);
UPDATE Testing SET Tint = Tdec WHERE Tchar = 'O O X O O';
SELECT * FROM Testing;

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tint = Tchar WHERE Tchar = 'O O O O O';


-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tint = Tvarchar WHERE Tchar = 'O O O O O';


-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = column name II WHERE various search conditions. 
-- Column name I = SMALL INT, column name II =INT, DEC, CHAR, VARCHAR
-------------------------------------------------------------------------------------------

--SUCC
UPDATE Testing SET Tsmallint = Tint WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;
UPDATE Testing SET Tsmallint = Tint - 100 WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22003
INSERT INTO Testing VALUES(32768, 11, 10.11, 'DATA 11', 'X O O O O', NULL);
UPDATE Testing SET Tsmallint = Tint WHERE Tchar = 'X O O O O';
SELECT * FROM Testing;
DELETE FROM Testing WHERE Tchar = 'X O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VALUE, SQLSTATE = 22003
UPDATE Testing SET Tsmallint = 32768 WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;


-----------------------------
-- SUCC 
UPDATE Testing SET Tsmallint = Tdec WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;
UPDATE Testing SET Tsmallint = Tint - 100 WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22003
INSERT INTO Testing VALUES(111, 11, 32768, 'DATA 11', 'O O X O O', NULL);
UPDATE Testing SET Tsmallint = Tint WHERE Tchar = 'O O X O O';
SELECT * FROM Testing;


-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tsmallint = Tchar WHERE Tchar = 'O O O O O';

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tsmallint = Tvarchar WHERE Tchar = 'O O O O O';


-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = column name II WHERE various search conditions. 
-- Column name I = DEC, column name II = SMALLINT, INT, CHAR, VARCHAR
-------------------------------------------------------------------------------------------

--SUCC
UPDATE Testing SET Tdec = Tint WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;
UPDATE Testing SET Tdec = Tsmallint + 10 WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22003
INSERT INTO Testing VALUES(1000, 11, 11, 'DATA 11', 'X O O O O', NULL);
UPDATE Testing SET Tdec = Tint WHERE Tchar = 'X O O O O';
SELECT * FROM Testing;
DELETE FROM Testing WHERE Tchar = 'X O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VALUE, SQLSTATE = 22003
UPDATE Testing SET Tdec = 1000 WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;


-----------------------------
-- SUCC 
UPDATE Testing SET Tdec = Tsmallint WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;
UPDATE Testing SET Tdec = Tsmallint + 10 WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22003
INSERT INTO Testing VALUES(111, 11, 1000, 'DATA 11', 'O O X O O', NULL);
UPDATE Testing SET Tdec = Tsmallint WHERE Tchar = 'O O X O O';
SELECT * FROM Testing;

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tdec = Tchar WHERE Tchar = 'O O O O O';

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tdec = Tvarchar WHERE Tchar = 'O O O O O';

-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = column name II WHERE various search conditions. 
-- Column name I = CHAR, column name II = SMALLINT, DEC, INT, VARCHAR
-------------------------------------------------------------------------------------------

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tchar = Tint WHERE Tchar = 'O O O O O';

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tchar = Tsmallint WHERE Tchar = 'O O O O O';

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tchar = Tdec WHERE Tchar = 'O O O O O';


-----------------------------
--SUCC
UPDATE Testing SET Ttmp = Tchar WHERE Tchar = 'O O O O O';
UPDATE Testing SET Tchar = Tvarchar WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;
UPDATE Testing SET Tchar = Ttmp WHERE Ttmp = 'O O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22001
DROP TABLE Testing1;
CREATE TABLE Testing1(Tvarchar 	VARCHAR(15), 
		      Tchar 	CHAR(10),
		      Ttmp	VARCHAR(20));

INSERT INTO Testing1 VALUES( 'DATA > 10 CH', NULL, NULL);
UPDATE Testing1 SET Tchar = Tvarchar WHERE Tchar IS NULL;
SELECT * FROM Testing1;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22001
UPDATE Testing1 SET Tchar = 'DATA > 10 CH' WHERE Tchar IS NULL;
SELECT * FROM Testing1;

-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = column name II WHERE various search conditions. 
-- Column name I = VARCHAR, column name II = SMALLINT, DEC, CHAR, INT
-------------------------------------------------------------------------------------------

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tvarchar = Tint WHERE Tchar = 'O O O O O';

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tvarchar = Tsmallint WHERE Tchar = 'O O O O O';

-----------------------------
-- FAILED SQLSTATE = 42821
UPDATE Testing SET Tvarchar = Tdec WHERE Tchar = 'O O O O O';

-----------------------------
--SUCC
UPDATE Testing SET Ttmp = Tvarchar WHERE Tchar = 'O O O O O';
UPDATE Testing SET Tvarchar = Tchar WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;
UPDATE Testing SET Tvarchar = Ttmp WHERE Tchar = 'O O O O O';
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22001
DROP TABLE Testing1;
CREATE TABLE Testing1(Tvarchar 	VARCHAR(10), 
		      Tchar 	CHAR(15),
		      Ttmp	VARCHAR(20));

INSERT INTO Testing1 VALUES( NULL, 'DATA > 10 CH', NULL);
UPDATE Testing1 SET Tvarchar = Tchar WHERE Ttmp IS NULL;
SELECT * FROM Testing1;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22001
UPDATE Testing1 SET Tvarchar = 'DATA > 10 CH' WHERE Tchar IS NULL;
SELECT * FROM Testing1;


-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = column name II WHERE various search conditions. 
-- Column II Is DECIMALIMALlared as DECIMALIMAL(5,2) and set value = 0, -0, 0.0, -0.0, -1, 100, 1000, 1.0000 
-- SELECT column name FROM table name WHERE column name = value
-- Column Is DECIMALIMALlared as DECIMALIMAL(5,2) and set value = 0, -0, 0.0, -0.0, -1, , 100, 1000, 1.0000
-------------------------------------------------------------------------------------------

DROP TABLE Testing2;
CREATE TABLE Testing2(Tdec1 DECIMAL(5,2), Tdec2 DECIMAL(10,5));
INSERT INTO Testing2 VALUES(1.0, 10);
INSERT INTO Testing2 VALUES(1.0, 100);
INSERT INTO Testing2 VALUES(1.0, 1000);
INSERT INTO Testing2 VALUES(1.0, 10000);
INSERT INTO Testing2 VALUES(1.0, 0);

UPDATE Testing2 SET Tdec1 = 0 WHERE Tdec2 = 10;
SELECT * FROM Testing2 WHERE Tdec1 = 0;

UPDATE Testing2 SET Tdec1 = -0 WHERE Tdec2 = 10;
SELECT * FROM Testing2 WHERE Tdec1 = -0;

UPDATE Testing2 SET Tdec1 = 0.0 WHERE Tdec2 = 10;
SELECT * FROM Testing2 WHERE Tdec1 = 0.0;

UPDATE Testing2 SET Tdec1 = -0.0 WHERE Tdec2 = 10;
SELECT * FROM Testing2 WHERE Tdec1 = -0.0;

UPDATE Testing2 SET Tdec1 = -1 WHERE Tdec2 = 10;
SELECT * FROM Testing2 WHERE Tdec1 = -1;

UPDATE Testing2 SET Tdec1 = 100 WHERE Tdec2 = 10;
SELECT * FROM Testing2 WHERE Tdec1 = 100;

UPDATE Testing2 SET Tdec1 = 1.0000 WHERE Tdec2 = 10;
SELECT * FROM Testing2 WHERE Tdec1 = 1.0000;

DROP TABLE Testing2;
CREATE TABLE Testing2(Tsmallint1 SMALLINT, Tsmallint2 SMALLINT);
INSERT INTO Testing2 VALUES(1.0, 10);
INSERT INTO Testing2 VALUES(1.0, 100);
INSERT INTO Testing2 VALUES(1.0, 1000);
INSERT INTO Testing2 VALUES(1.0, 10000);
INSERT INTO Testing2 VALUES(1.0, 0);

UPDATE Testing2 SET Tsmallint1 = 0 WHERE Tsmallint2 = 10;
SELECT * FROM Testing2 WHERE Tsmallint1 = 0;

UPDATE Testing2 SET Tsmallint1 = -0 WHERE Tsmallint2 = 10;
SELECT * FROM Testing2 WHERE Tsmallint1 = -0;

UPDATE Testing2 SET Tsmallint1 = -1 WHERE Tsmallint2 = 10;
SELECT * FROM Testing2 WHERE Tsmallint1 = -1;

UPDATE Testing2 SET Tsmallint1 = 100 WHERE Tsmallint2 = 10;
SELECT * FROM Testing2 WHERE Tsmallint1 = 100;

UPDATE Testing2 SET Tsmallint1 = 1.0000 WHERE Tsmallint2 = 10;
SELECT * FROM Testing2 WHERE Tsmallint1= 1.0000;

DROP TABLE Testing2;
CREATE TABLE Testing2(Tint1 SMALLINT, Tint2 SMALLINT);
INSERT INTO Testing2 VALUES(1.0, 10);
INSERT INTO Testing2 VALUES(1.0, 100);
INSERT INTO Testing2 VALUES(1.0, 1000);
INSERT INTO Testing2 VALUES(1.0, 10000);
INSERT INTO Testing2 VALUES(1.0, 0);

UPDATE Testing2 SET Tint1 = 0 WHERE Tint2 = 10;
SELECT * FROM Testing2 WHERE Tint1 = 0;

UPDATE Testing2 SET Tint1 = -0 WHERE Tint2 = 10;
SELECT * FROM Testing2 WHERE Tint1 = -0;

UPDATE Testing2 SET Tint1 = -1 WHERE Tint2 = 10;
SELECT * FROM Testing2 WHERE Tint1 = -1;

UPDATE Testing2 SET Tint1 = 100 WHERE Tint2 = 10;
SELECT * FROM Testing2 WHERE Tint1 = 100;

UPDATE Testing2 SET Tint1 = 1.0000 WHERE Tint2 = 10;
SELECT * FROM Testing2 WHERE Tint1= 1.0000;


-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- DECIMALIMAL declaration should be tested.  Such as DECIMAL(5,0), DECIMAL(0,5), DECIMAL(5, 5).
-------------------------------------------------------------------------------------------

DROP TABLE Testing2;
CREATE TABLE Testing2(Tdec DECIMAL(5,0));
INSERT INTO Testing2 VALUES(10000);
INSERT INTO Testing2 VALUES(1000.0);
INSERT INTO Testing2 VALUES(100.00);
SELECT * FROM Testing2;

DROP TABLE Testing2;
-- FAILED SQLSTATE = 42611
CREATE TABLE Testing2(Tdec DECIMAL(0,5));

DROP TABLE Testing2;
CREATE TABLE Testing2(Tdec DECIMAL(5,5));
INSERT INTO Testing2 VALUES(0.00001);
INSERT INTO Testing2 VALUES(0.0001);
INSERT INTO Testing2 VALUES(1);
INSERT INTO Testing2 VALUES(.00001);
SELECT * FROM Testing2;

-- FAILED SQLSTATE = 22003
INSERT INTO Testing2 VALUES(1.0);
INSERT INTO Testing2 VALUES(1000.0);

-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = value WHERE column name 1 = column name II
-- WHERE Column name I = INT, column name II = SMALLINT, DEC, CHAR, VARCHAR
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------

DROP TABLE Testing2;
CREATE TABLE Testing2(Tint INT, Tsmallint SMALLINT, Tdec DECIMAL(5,2));
INSERT INTO Testing2 VALUES(0, 0, 0.0);
INSERT INTO Testing2 VALUES(1, 1, 1.0);
INSERT INTO Testing2 VALUES(200, 2, 1.2);
INSERT INTO Testing2 VALUES(300, 3, 1.3);
INSERT INTO Testing2 VALUES(400, 4, 1.4);
INSERT INTO Testing2 VALUES(500, 5, 1.5);

------------------------------------------------------------------------------------------------
UPDATE Testing2 SET Tint = 999 WHERE Tint = Tsmallint;
SELECT * FROM Testing2 WHERE Tint = 999;
DELETE FROM Testing2 WHERE Tint = 999;
INSERT INTO Testing2 VALUES(0, 0, 0.0);
INSERT INTO Testing2 VALUES(1, 1, 1.0);

UPDATE Testing2 SET Tint = 999 WHERE Tint = Tdec;
SELECT * FROM Testing2 WHERE Tint = 999;
DELETE FROM Testing2 WHERE Tint = 999;
INSERT INTO Testing2 VALUES(0, 0, 0.0);
INSERT INTO Testing2 VALUES(1, 1, 1.0);

UPDATE Testing2 SET Tint = 999 WHERE Tint > Tsmallint;
SELECT * FROM Testing2 WHERE Tint = 999;
DELETE FROM Testing2 WHERE Tint = 999;
INSERT INTO Testing2 VALUES(200, 2, 1.2);
INSERT INTO Testing2 VALUES(300, 3, 1.3);
INSERT INTO Testing2 VALUES(400, 4, 1.4);
INSERT INTO Testing2 VALUES(500, 5, 1.5);


-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = value WHERE column name 1 = column name II
-- WHERE Column name I = SMALL INT, column name II =INT, DEC, CHAR, VARCHAR
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------

UPDATE Testing2 SET Tint = 999 WHERE Tsmallint = Tint;
SELECT * FROM Testing2 WHERE Tint = 999;
DELETE FROM Testing2 WHERE Tint = 999;
INSERT INTO Testing2 VALUES(0, 0, 0.0);
INSERT INTO Testing2 VALUES(1, 1, 1.0);

UPDATE Testing2 SET Tint = 999 WHERE Tsmallint = Tdec;
SELECT * FROM Testing2 WHERE Tint = 999;
DELETE FROM Testing2 WHERE Tint = 999;
INSERT INTO Testing2 VALUES(0, 0, 0.0);
INSERT INTO Testing2 VALUES(1, 1, 1.0);

-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = value WHERE column name 1 = column name II
-- WHERE Column name I = DEC, column name II = SMALLINT, INT, CHAR, VARCHAR
-------------------------------------------------------------------------------------------

UPDATE Testing2 SET Tint = 999 WHERE Tdec = Tint;
SELECT * FROM Testing2 WHERE Tint = 999;
DELETE FROM Testing2 WHERE Tint = 999;
INSERT INTO Testing2 VALUES(0, 0, 0.0);
INSERT INTO Testing2 VALUES(1, 1, 1.0);

UPDATE Testing2 SET Tint = 999 WHERE Tdec = Tsmallint;
SELECT * FROM Testing2 WHERE Tint = 999;
DELETE FROM Testing2 WHERE Tint = 999;
INSERT INTO Testing2 VALUES(0, 0, 0.0);
INSERT INTO Testing2 VALUES(1, 1, 1.0);

UPDATE Testing2 SET Tint = 999 WHERE Tdec < Tsmallint;
SELECT * FROM Testing2 WHERE Tint = 999;
DELETE FROM Testing2 WHERE Tint = 999;
INSERT INTO Testing2 VALUES(200, 2, 1.2);
INSERT INTO Testing2 VALUES(300, 3, 1.3);
INSERT INTO Testing2 VALUES(400, 4, 1.4);
INSERT INTO Testing2 VALUES(500, 5, 1.5);


-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- UPDATE tablename SET column name 1 = value WHERE column name 1 = column name II
-- WHERE Column name I = CHAR, column name II = SMALLINT, DEC, INT, VARCHAR
-- WHERE Column name I = VARCHAR, column name II = SMALLINT, DEC, CHAR, INT
-------------------------------------------------------------------------------------------
DROP TABLE Testing2;
CREATE TABLE Testing2(ID INT, Tchar CHAR(10), Tvarchar VARCHAR(15));
INSERT INTO Testing2 VALUES(1, 'TEST', 'TEST');
INSERT INTO Testing2 VALUES(2, 'test', 'TEST');
INSERT INTO Testing2 VALUES(3, ' TEST', 'TEST');
INSERT INTO Testing2 VALUES(4, 'TEST ', 'TEST');
INSERT INTO Testing2 VALUES(5, 'TEST', ' TEST');
INSERT INTO Testing2 VALUES(6, 'TEST', 'TEST ');

-- SELECT ID = 1, 4, 6
UPDATE Testing2 SET Tchar = 'SUCC' WHERE Tchar = Tvarchar;
SELECT * FROM Testing2 WHERE Tchar = 'SUCC';
DELETE FROM Testing2 WHERE Tchar = 'SUCC';
INSERT INTO Testing2 VALUES(1, 'TEST', 'TEST');
INSERT INTO Testing2 VALUES(4, 'TEST ', 'TEST');
INSERT INTO Testing2 VALUES(6, 'TEST', 'TEST ');

UPDATE Testing2 SET Tchar = 'SUCC' WHERE Tvarchar = Tchar;
SELECT * FROM Testing2 WHERE Tchar = 'SUCC';
DELETE FROM Testing2 WHERE Tchar = 'SUCC';


-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-- CHECK DATE AND TIME DATATYPE
-------------------------------------------------------------------------------------------

DROP TABLE Testing2;
CREATE TABLE Testing2(ID INT, Tdate1 DATE, Ttime1 TIME, Tdate2 DATE, Ttime2 TIME);

-- INSERT ISO FORMAT DATE:
INSERT INTO Testing2 VALUES(101, '1999-06-23', '13.30.05', '07/04/1999', '03.03.50');
INSERT INTO Testing2 VALUES(102, '1999-6-23', '13.30.05', '04.07.1999', '03.03.50');
-- SQLSTATE = 22007	
INSERT INTO Testing2 VALUES(103, '99-06-23', '13.30.05', '07/04/1999', '03.03.50');	

-- INSERT IBM USA FORMAT DATE:
INSERT INTO Testing2 VALUES(201, '06/23/1999', '13.30.05', '1999-07-04', '03.03.50');
INSERT INTO Testing2 VALUES(202, '6/23/1999', '13.30.05', '04.07.1999', '03.03.50');
-- SQLSTATE = 22007
INSERT INTO Testing2 VALUES(203, '06/23/99', '13.30.05', '04.07.1999', '03.03.50');

-- INSERT EUROPEAN USA FORMAT DATE:
INSERT INTO Testing2 VALUES(301, '23.06.1999', '13.30.05', '1999-07-04', '03.03.50');
INSERT INTO Testing2 VALUES(302, '23.6.1999', '13.30.05', '07/04/1999', '03.03.50');
-- SQLSTATE = 22007	
INSERT INTO Testing2 VALUES(303, '23.06.99', '13.30.05', '07/04/1999', '03.03.50');	

-- INSERT ISO FORMAT TIME:
INSERT INTO Testing2 VALUES(401, '1999-06-23', '13.30.05', '1999-07-04', '12:30 AM');
INSERT INTO Testing2 VALUES(402, '1999-06-23', '13.30.05', '1999-07-04', '12:30:00');
-- SQLSTATE = 22007	
INSERT INTO Testing2 VALUES(403, '1999-06-23', '6.30.5', '1999-07-04', '12:30 AM' );

-- INSERT IBM USA FORMAT TIME:
INSERT INTO Testing2 VALUES(501, '06/23/1999', '1:30 AM', '1999-07-04', '12:30:00');
INSERT INTO Testing2 VALUES(502, '06/23/1999', '01:30 AM', '1999-07-04', '13.30.05');
INSERT INTO Testing2 VALUES(503, '06/23/1999', '1:30 PM', '1999-07-04', '13.30.05');
INSERT INTO Testing2 VALUES(504, '06/23/1999', '01:30 PM', '1999-07-04', '13.30.05');

-- INSERT JAPANESE FORMAT TIME:
INSERT INTO Testing2 VALUES(601, '23.06.1999', '13:30:05', '1999-07-04', '12:30 AM');
INSERT INTO Testing2 VALUES(602, '23.06.1999', '13:30:04', '1999-07-04', '13.30.05');
-- SQLSTATE = 22007	
INSERT INTO Testing2 VALUES(603, '23.06.1999', '3:3:5', '1999-07-21', '13.30.05');

-- INSERT OUT OF RANGE VALUE IN DATE(YEAR):
INSERT INTO Testing2 VALUES(701, '1999-06-23', '13.30.05', '1999-06-21', '12:30:00');

-- INSERT OUT OF RANGE VALUE IN DATE(MONTH): (SQLSTATE = 22007)
INSERT INTO Testing2 VALUES(702, '2001-13-23', '13.30.05', '1999-06-21', '12:30:00');

-- INSERT OUT OF RANGE VALUE IN DATE(DAY): (SQLSTATE = 22007)
INSERT INTO Testing2 VALUES(703, '2001-11-33', '13.30.05', '1999-06-21', '12:30:00');
INSERT INTO Testing2 VALUES(704, '2001-02-30', '13.30.05', '1999-06-21', '12:30:00');
INSERT INTO Testing2 VALUES(705, '2001-04-31', '13.30.05', '1999-06-21', '12:30:00');

-- INSERT OUT OF RANGE VALUE IN TIME(HOUR): (SQLSTATE = 22007)
INSERT INTO Testing2 VALUES(706, '2001-04-30', '13.30.05', '1999-06-21', '25:30:00');
INSERT INTO Testing2 VALUES(707, '2001-04-30', '13.30.05', '1999-06-21', '13:30 AM');
INSERT INTO Testing2 VALUES(708, '2001-04-30', '13.30.05', '1999-06-21', '30.30.00');

-- INSERT OUT OF RANGE VALUE IN TIME(MINUTE): (SQLSTATE = 22007)
INSERT INTO Testing2 VALUES(709, '2001-04-30', '13.30.05', '1999-06-21', '13:70:00');
INSERT INTO Testing2 VALUES(710, '2001-04-30', '13.30.05', '1999-06-21', '01:80 AM');
INSERT INTO Testing2 VALUES(711, '2001-04-30', '13.30.05', '1999-06-21', '13.90.00');

-- INSERT OUT OF RANGE VALUE IN TIME(SECOND): (SQLSTATE = 22007)
INSERT INTO Testing2 VALUES(712, '2001-04-30', '13.30.05', '1999-06-21', '13:30:70');
INSERT INTO Testing2 VALUES(713, '2001-04-30', '13.30.05', '1999-06-21', '01:30 FM');
INSERT INTO Testing2 VALUES(714, '2001-04-30', '13.30.05', '1999-06-21', '13.30.90');

-- INSERT NULL VALUE IN TIME AND DATE:
INSERT INTO Testing2 VALUES(715, NULL, '13.30.05', '1999-06-21', '01:30:00');
INSERT INTO Testing2 VALUES(716, '2001-04-30', NULL, '1999-06-21', '13.30.50');
INSERT INTO Testing2 VALUES(717, '2001-04-30', '13.30.05', NULL, '01:30:00');

-- MIXED FORMATE OF DATE: (SQLSTATE = 22007)
INSERT INTO Testing2 VALUES(718, '2001/04-30', '13.30.05', NULL, '01:30:00');
INSERT INTO Testing2 VALUES(719, '2001-04/30', '13.30.05', NULL, '01:30:00');

-- MIXED FORMATE OF TIME: (SQLSTATE = 22007)
INSERT INTO Testing2 VALUES(720, '2001-04-30', '13.30.05', NULL, '01.30:00');
INSERT INTO Testing2 VALUES(721, '2001-04-30', '13.30.05', NULL, '01:30.00');

SELECT * FROM Testing2;

-- Simple Update
UPDATE Testing2 SET Tdate1 = '1999-12-31' WHERE ID = 701;
SELECT * FROM Testing2 WHERE Tdate1 = '1999-12-31';

-- SET DATE VALUES
UPDATE Testing2 SET Tdate1 = Tdate2 WHERE ID < 105;
SELECT * FROM Testing2 WHERE Tdate1 = Tdate2;

-- SET TIME VALUES
UPDATE Testing2 SET Ttime1 = Ttime2 WHERE ID < 105;
SELECT * FROM Testing2 WHERE Ttime1 = Ttime2;

-- SQLSTATE = 42821
UPDATE Testing2 SET Tdate1 = Ttime1 WHERE ID < 105;

-- UPDATE USING WHERE CLAUSE
UPDATE Testing2 SET Tdate1 = '1999-12-31' WHERE Tdate1 = Tdate2;
SELECT * FROM Testing2 WHERE Tdate1 = '1999-12-31';

UPDATE Testing2 SET Tdate2 = '1999-12-31' WHERE Tdate1 > Tdate2;
SELECT * FROM Testing2 WHERE Tdate2 = '1999-12-31';


-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22007, 02000
INSERT INTO Testing2 VALUES(702, '2001-13-23', '13.30.05', '1999-06-21', '12:30:00');
UPDATE Testing2 SET Tdate2 = Tdate1 WHERE ID = 702;
SELECT * FROM Testing;

-- FAILED OUT OF RANGE VARIABLE, SQLSTATE = 22007, 02000
INSERT INTO Testing2 VALUES(702, '2001-11-23', '13.30.05', '1999-06-21', '12:30:00');
UPDATE Testing2 SET Tdate2 = '0000-00-00' WHERE ID = 702;
SELECT * FROM Testing2;


-------------------------------------------------------------------------------------------
DROP TABLE Testing2;


