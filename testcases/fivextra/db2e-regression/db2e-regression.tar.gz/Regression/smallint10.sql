-- ----------------- FILE: SMALLINT10.SQL  -----------------
-- -                                                      - 
-- -       CHECK ALL ERROR IN "SMALLINT" DATA TYPE        -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE TABLENAMEHAS19CHARS;