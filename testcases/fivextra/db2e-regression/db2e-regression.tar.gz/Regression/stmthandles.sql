
-- Created by Cliff Leung.
-- 

-- This test file tests the re-execution of queries using
-- the same statement handle for different parameters, and multiple handles.


-- expect 42704
drop table t1;
-- expect 42704
drop table t2;

create stmt handle :3;
create stmt handle :4;

-- create T1
prepare :3 create table t1(c1 char(10) primary key, c2 char(10));
execute :3;

-- no rows
select * from t1;

-- create T2
prepare :4 create table t2(c1 char(10) primary key, c2 char(10));
execute :4;

prepare :4 create index idx1 on t2(c2);
execute :4;

-- no rows
select * from t2;

--------------------------------------------
-- prepare and insert data into T1
prepare :3 insert into t1 values (?, ?);

-- insert 3 rows
bind :3 1 aaa;
bind :3 2 bbb;
execute :3;

bind :3 1 bbb;
bind :3 2 ccc;
execute :3;

bind :3 1 ccc;
bind :3 2 ccc;
execute :3;

-- should fail due to duplicate primary key (23505)
execute :3;

-- verify that we have 3 rows
select * from t1;

-- 
-- fetch all rows
prepare :4 select * from t1;
execute :4;

fetch :4;
fetch :4;
fetch :4;

-- should return nothing
fetch :4;

-- re-execute using the prepared statement handle
execute :4;

-- should see all 3 rows
fetch :4;
fetch :4;
fetch :4;

--------------------------------------------

-- 
-- USE A PARAMETER MARKER TO ACCESS ROWS
-- VIA TABLE SCAN
--

prepare :4 select * from t1 where c2 = ?;
bind :4 1 bbb;

execute :4;

-- 1 row
fetch :4;

-- nothing
fetch :4;

-- repeat the execution

execute :4;

-- 1 row
fetch :4;

-- nothing
fetch :4;

-- bind a different value
bind :4 1 ccc;

execute :4;

-- a couple rows
fetch :4;
fetch :4;

-- nothing
fetch :4;

-- bind a different value that doesn't exist
bind :4 1 fff;

execute :4;

-- nothing
fetch :4;


--------------------------------------------

-- 
-- USE A PARAMETER MARKER TO ACCESS ROWS
-- VIA INDEX SCAN
--

prepare :4 select * from t1 where c1 = ?;
bind :4 1 bbb;

execute :4;

-- 1 row
fetch :4;

-- nothing
fetch :4;

-- repeat the execution

execute :4;

-- 1 row
fetch :4;

-- nothing
fetch :4;

-- bind a different value
bind :4 1 ccc;

execute :4;

-- a row
fetch :4;

-- nothing
fetch :4;

-- bind a different value that doesn't exist
bind :4 1 fff;

execute :4;

-- nothing
fetch :4;


--------------------------------------------
-- prepare and insert data into T2
prepare :4 insert into t2 values (?, ?);

-- insert 4 rows
bind :4 1 bbb;
bind :4 2 ccc;
execute :4;

bind :4 1 ccc;
bind :4 2 ccc;
execute :4;

bind :4 1 ddd;
bind :4 2 bbb;
execute :4;

-- verify that we have 3 rows
select * from t2;

---------------------

-- do some joins between T1 and T2

select * from t1;
select * from t2;
select * from t1, t2 where t1.c2 = t2.c1;

select * from t2, t1 where t1.c1 = t2.c2;

select * from t1, t2 where t1.c2 = t2.c2;

----------------------

-- OKAY, let's do some joins using 2 statement handles

-- case (1)
-- do: select * from t1, t2 where t1.c2 = t2.c1;
-- the inner will be index-scanned

prepare :3 select * from t1;

prepare :4 select * from t2 where c1 = ?;

execute :3;

-- Get a row from T1: should get <aaa, bbb>
fetch :3;

-- get the matching row from T2
bind :4 1 bbb;
execute :4;

-- fetch <bbb, ccc>
fetch :4;

-- fetch nothing
fetch :4;

-- Get the next row from T1: should get <bbb, ccc>
fetch :3;

-- get the matching row from T2
bind :4 1 ccc;
execute :4;

-- fetch <ccc, ccc>
fetch :4;

-- fetch nothing
fetch :4;

-- Get the next row from T1: should get <ccc, ccc>
fetch :3;

-- get the matching row from T2
bind :4 1 ccc;
execute :4;

-- fetch <ccc, ccc>
fetch :4;

-- fetch nothing
fetch :4;

-------------------------------------

-- case (2)
-- do: select * from t2, t1 where t1.c2 = t2.c2;
-- the inner will be table-scanned

prepare :3 select * from t2;

prepare :4 select * from t1 where c2 = ?;

execute :3;

-- Get a row from T2: should get <bbb, ccc>
fetch :3;

-- get the matching row from T1
bind :4 1 ccc;
execute :4;

-- fetch <bbb, ccc>
fetch :4;

-- fetch <ccc, ccc>
fetch :4;

-- fetch nothing
fetch :4;

-- Get the next row from T2: should get <ccc, ccc>
fetch :3;

-- get the matching row from T1
bind :4 1 ccc;
execute :4;

-- fetch <bbb, ccc>
fetch :4;

-- fetch <ccc, ccc>
fetch :4;

-- fetch nothing
fetch :4;

-- Get the next row from T2: should get <ddd, bbb>
fetch :3;

-- get the matching row from T2
bind :4 1 bbb;
execute :4;

-- fetch <aaa, bbb>
fetch :4;

-- fetch nothing
fetch :4;




----------------------
-- clean up
prepare :3 drop table t1;
execute :3;

prepare :3 drop table t2;
execute :3;

-- no such table (42704)
select * from t1;
select * from t2;

drop stmt handle :3;
drop stmt handle :4;
