-- Tests various insert with selects with primary keys

-- defect 6172 key size limit on primary key
create table tchar (c1 char(1024) primary key, c2 char (1024));
create index itchar on tchar (c2);
drop table tchar;
-- should fail
create table tchar (c1 char(1025) primary key, c2 char (1024));
create table tchar (c1 char(1024) primary key, c2 char (1025));
-- should fail
create index itchar on tchar (c2);
drop table tchar;

-- CREATE BASE TABLE
create table dt (c1 date not null, c2 time not null, c3 timestamp not null, c4 char(20) not null, c5 varchar(20) not null, c6 blob(20) not null, c7 decimal(10,2) not null, c8 smallint not null, c9 int not null, c10 blob(20), c11 blob(20), c12 varchar(22) not null);

insert into dt values ('2002-06-03', '17:45:39', '2002-06-03-17.45.39.339001', 'abcd', 'xyz', 'blob', 0.0, 0, 0, 'charbit', 'varcharbit', '0.0');

insert into dt values ('2002-06-04', '18:45:39', '2002-06-04-17.45.39.339001', 'ABCD', 'XYZ', 'BLOB', 7.7, 7, 7, 'CHARBIT', 'VARCHARBIT', '7.7');

insert into dt values ('2002-06-02', '16:45:39', '2002-06-02-17.45.39.339001', 'ABcd', 'Xyz', 'Blob', -7.7, -7, -7, 'CHARbit', 'VARCHARbit', '-7.7');

----------------------------------------

-- CREATE TABLES OF PRIMARY KEY OF DIFFERENT DATATYPES
create table tdate 	(x date not null primary key, y int);
insert into tdate select c1, c9 from dt;

select * from tdate;

-- X          Y          
-- ---------- -----------
-- 2002-06-03           0
-- 2002-06-04           7
-- 2002-06-02          -7
-- 3 row(s) returned.

-- try "select distinct"
delete from tdate;

insert into tdate select distinct c1, c9 from dt;

select * from tdate;

----------------------------------------

create table ttime 	(x time not null primary key, y int);
insert into ttime select c2, c9 from dt;

select * from ttime;

-- X        Y          
-- -------- -----------
-- 17:45:39           0
-- 18:45:39           7
-- 16:45:39          -7
-- 3 row(s) returned.

-- try "select distinct"
delete from ttime;
insert into ttime select distinct c2, c9 from dt;

select * from ttime;

----------------------------------------

create table tts   	(x timestamp not null primary key, y int);
insert into tts select c3, c9 from dt;

select * from tts;

-- C3                         C9         
-- -------------------------- -----------
-- 2002-06-03-17.45.39.339001           0
-- 2002-06-03-17.45.39.339001           7
-- 2002-06-03-17.45.39.339001          -7
-- 3 row(s) returned.

-- try "select distinct"
delete from tts;
insert into tts select distinct c3, c9 from dt;

select * from tts;

----------------------------------------

create table tchar 	(x char(20) not null primary key, y int);
insert into tchar select c4, c9 from dt;

select * from tchar;

-- X                    Y          
-- -------------------- -----------
-- abcd                           0
-- ABCD                           7
-- ABcd                          -7
-- 3 row(s) returned.

-- try "select distinct"
delete from tchar;
insert into tchar select distinct c4, c9 from dt;

select * from tchar;

----------------------------------------

create table tvc   	(x varchar(20) not null primary key, y int);
insert into tvc select c5, c9 from dt;

select * from tvc;

-- X                    Y          
-- -------------------- -----------
-- xyz                            0
-- XYZ                            7
-- Xyz                           -7
-- 3 row(s) returned.

-- try "select distinct"
delete from tvc;
insert into tvc select c5, c9 from dt;

select * from tvc;

----------------------------------------

create table tblob 	(x int not null primary key, y blob(20));
insert into tblob select c9, c6 from dt;

select x from tblob;

-- X           
-- ----------- 
--           0 
--           7 
--          -7 
-- 3 row(s) returned.

----------------------------------------

create table tdec  	(x decimal(10,2) not null primary key, y int);
insert into tdec select c7, c9 from dt;

select * from tdec;

-- X            Y          
-- ------------ -----------
--         0.00           0
--         7.70           7
--        -7.70          -7
-- 3 row(s) returned.

-- try "select distinct"
delete from tdec;
insert into tdec select c7, c9 from dt;

select * from tdec;

----------------------------------------

create table tsint 	(x smallint not null primary key, y int);
insert into tsint select c8, c9 from dt;

select * from tsint;

-- X      Y          
-- ------ -----------
--      0           0
--      7           7
--     -7          -7
-- 3 row(s) returned.

-- try "select distinct"
delete from tsint;
insert into tsint select c8, c9 from dt;

select * from tsint;

----------------------------------------

create table tint  	(x int not null primary key, y int);
insert into tint select c9, c9 from dt;

select * from tint;

-- X           Y          
-- ----------- -----------
--           0           0
--           7           7
--          -7          -7
-- 3 row(s) returned.

-- try "select distinct"
delete from tint;
insert into tint select distinct c9, c9 from dt;

select * from tint;

----------------------------------------

create table tcbit 	(x int not null primary key, y blob(20));
insert into tcbit select c9, c10 from dt;

select x from tcbit;

-- X    
-- ----------- 
--           0 
--           7 
--          -7 
-- 3 row(s) returned.

----------------------------------------

create table tvcbit (x int not null primary key, y blob(20));
insert into tvcbit select c9, c11 from dt;

select x from tvcbit;

-- X           
-- ----------- 
--           0 
--           7 
--          -7 
-- 3 row(s) returned.

----------------------------------------

create table td (x varchar(22) not null primary key, y int);
insert into td select c12, c9 from dt;

select * from td;

-- X                      Y          
-- ---------------------- -----------
-- 0.0                              0
-- 7.7                              7
-- -7.7                            -7
-- 3 row(s) returned.

-- try "select distinct"
delete from td;
insert into td select distinct c12, c9 from dt;

select * from td;

create table foo (x int not null primary key, y varchar(20));

insert into foo select c9, c11 from dt;
select * from foo;


-- test multiple promoted values

create table intxx (c1 int, c2 int);
insert into intxx values(1, 2);
create table decxx (c1 decimal(11,2), c2 decimal(11,2));
insert into decxx select * from intxx;
select * from decxx;

-- create a table where primary key column doesn't exist

create table primnocol (c1 int not null, c2 int not null, primary key(c1,c3));

-- clean up
drop table intxx;
drop table decxx;
drop table dt;
drop table foo;
drop table tdate;
drop table ttime;
drop table tts  ;
drop table tchar;
drop table tvc  ;
drop table tblob;
drop table tdec ;
drop table tsint;
drop table tint ;
drop table tcbit;
drop table tvcbit;
drop table td;
