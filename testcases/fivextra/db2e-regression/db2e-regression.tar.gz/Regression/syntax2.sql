-- ----------------- FILE: SYNTAX2.SQL  -------------------
-- -                                                      - 
-- -          CHECK ALL STANDARD SQL SYNTAX ERROR         -
-- -                                                      -
-- --------------------------------------------------------
--

-- --------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------
-- DELIMITED IDENTIFIER USING DOUBLE QUOTE
CREATE TABLE "!@#$ - %%^" ("!" 		INT, 
			   "()"		SMALLINT, 
			   "DS^&FA 89"	DECIMAL(5,2),
			   "89 "	CHAR(10),
			   " %^"	VARCHAR(10));	 

INSERT INTO "!@#$ - %%^" VALUES (1, 100, 10.00, '!!!!', '!!!!!!!');
INSERT INTO "!@#$ - %%^" VALUES (2, 200, 20.00, '@@@@', '@@@@@@@');
INSERT INTO "!@#$ - %%^" VALUES (3, 300, 30.00, '####', '#######');

SELECT "!" FROM "!@#$ - %%^";

DELETE FROM "!@#$ - %%^" WHERE "!" = 1;
DELETE FROM "!@#$ - %%^" WHERE "89" = '@@@@';
DELETE FROM "!@#$ - %%^" WHERE "89 " = '@@@@';

UPDATE "!@#$ - %%^" SET "!" = 2;

DROP TABLE "!@#$ - %%^";


-- --------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------
-- CHAR(32767)
-- CREATE TABLE TEST(T1 CHAR(32767));
DROP TABLE TEST;

-- CREATE TABLE TEST(T1 CHAR(32768));
DROP TABLE TEST;

CREATE TABLE TEST(T1 CHAR(0));
DROP TABLE TEST;

CREATE TABLE TEST(T1 CHAR(-1));
DROP TABLE TEST;

-- CREATE TABLE TEST(T1 VARCHAR(32767));
DROP TABLE TEST;

-- CREATE TABLE TEST(T1 VARCHAR(32768));
DROP TABLE TEST;

CREATE TABLE TEST(T1 VARCHAR(0));
DROP TABLE TEST;

CREATE TABLE TEST(T1 VARCHAR(-1));
DROP TABLE TEST;


-- --------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------
-- ARITHMETIC OPERATOR - INT IN INSERT STATEMENT
DROP TABLE TEST1;
CREATE TABLE TEST1 (Tint 	INT,
	           Tsmallint  	SMALLINT, 
		   Tdec 	DECIMAL(5,2), 
	           Tchar	CHAR(10),
	           Tvarchar 	VARCHAR(15));

INSERT INTO TEST1 VALUES (0+1, 	100, 10.00, '!!!!', '!!!!!!!');
INSERT INTO TEST1 VALUES (200-198, 	200, 20.00, '@@@@', '@@@@@@@');
INSERT INTO TEST1 VALUES (1*3, 300,	30.00, '####', '#######');
INSERT INTO TEST1 VALUES (4000/1000, 400, 10.00, '$$$$', '$$$$$$$');
INSERT INTO TEST1 VALUES (500/(3), 	500, 20.00, '%%%%%' CONCAT ' ^^^^', '@@@@@@@');

-- DIVIDED BY ZERO -22012
INSERT INTO TEST1 VALUES (600/0, 	600, 30.00, '####', '#######');
-- OUT OF RANGE - 22003
INSERT INTO TEST1 VALUES (80000*30000, 700, 30.00, '####', '#######');
INSERT INTO TEST1 VALUES (80/(-3), 800, 20.00, '@@@@@' CONCAT '$$$$$' , '@@@@@@@');
INSERT INTO TEST1 VALUES (80/(-3)*2, 900, 20.00, '@@@@@' CONCAT '$$$$$' , '@@@@@@@');
-- DIVIDED BY DECIMAL - SUCC
INSERT INTO TEST1 VALUES (100/(-2.5)*2, 1000, 20.00, '@@@@@' CONCAT '$$$$$' , '@@@@@@@');

-- SELECT WHERE CLAUSE WITH ARITHMETIC OPERATION
SELECT * FROM TEST1 WHERE Tint = 0+1;
SELECT * FROM TEST1 WHERE Tint = (-1)+3;
SELECT * FROM TEST1 WHERE Tint = 3*(-1)(-1);
SELECT * FROM TEST1 WHERE Tint = 36/(-1)*(-9);
SELECT * FROM TEST1;

-- UPDATE WITH SET VALUE USING ARITHMETIC OPERATION

UPDATE TEST1 SET Tint = (-1000)+1000  WHERE Tint = 0+1;
SELECT * FROM TEST1;
UPDATE TEST1 SET Tint = (1000)-1000  WHERE Tint = (-1)+3;
SELECT * FROM TEST1;
UPDATE TEST1 SET Tint = 1000*0  WHERE Tint = 3*(-1)(-1);
SELECT * FROM TEST1;
UPDATE TEST1 SET Tint = 0/5  WHERE Tint = 36/(-1)*(-9);
SELECT * FROM TEST1;


-- --------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------
-- ARITHMETIC OPERATOR - SMALLINT IN INSERT STATEMENT
DROP TABLE TEST2;
CREATE TABLE TEST2 (Tint INT, Tsmallint SMALLINT, Tdecimal DECIMAL(5,2), Tchar CHAR(10), Tvarchar VARCHAR(10));	  
INSERT INTO TEST2 VALUES (1, 50+50,     10.00, '!!!!', '!!!!!!!');
INSERT INTO TEST2 VALUES (2, 600-400,   20.00, '@@@@', '@@@@@@@');
INSERT INTO TEST2 VALUES (3, 100*3,     30.00, '####', '#######');
INSERT INTO TEST2 VALUES (4, 1600/4,    10.00, '$$$$', '$$$$$$$');
INSERT INTO TEST2 VALUES (5, 1500/(3),  20.00, '%%%%%' CONCAT ' ^^^^', '@@@@@@@');

-- DIVIDED BY ZERO -22012
INSERT INTO TEST2 VALUES (6, 500/0,     30.00, '####', '#######');
-- OUR OF RANGE - 22003
INSERT INTO TEST2 VALUES (7, 500*70,    30.00, '####', '#######');
-- TOO MANY CHAR IN CONCAT - 22001
INSERT INTO TEST2 VALUES (8, 1500/(-3), 20.00, '@@@@@' CONCAT ' $$$$$' , '@@@@@@@');
-- DIVIDED BY DECIMAL - SUCC
INSERT INTO TEST2 VALUES (9, 100/(-2.5)*2, 20.00, '@@@@@' CONCAT '$$$$$' , '@@@@@@@');

-- SELECT WHERE CLAUSE WITH ARITHMETIC OPERATION
SELECT * FROM TEST2 WHERE Tsmallint = 200+(-100);
SELECT * FROM TEST2 WHERE Tsmallint = 200-0;
SELECT * FROM TEST2 WHERE Tsmallint = 3*(-100)*(-1);
SELECT * FROM TEST2 WHERE Tsmallint = 400/(-100)*(-1);
SELECT * FROM TEST2;

-- UPDATE WITH SET VALUE USING ARITHMETIC OPERATION

UPDATE TEST2 SET Tsmallint = (-1000)+1000  WHERE Tsmallint = 200+(-100);
SELECT * FROM TEST2;
--------UPDATE TEST2 SET Tsmallint = (1000)-1000  WHERE Tsmallintt = 200-0;
UPDATE TEST2 SET Tsmallint = (1000)-1000  WHERE Tsmallint = 200-0;
SELECT * FROM TEST2;
UPDATE TEST2 SET Tsmallint = 1000*0  WHERE Tsmallint = 3*(-100)*(-1);
SELECT * FROM TEST2;
UPDATE TEST2 SET Tsmallint = 0/5  WHERE Tsmallint = 400/(-100)*(-1);
SELECT * FROM TEST2;

-- --------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------
-- ARITHMETIC OPERATOR - DECIMAL IN INSERT STATEMENT
DROP TABLE TEST3;
CREATE TABLE TEST3 (Tint 	INT, 
		   Tsmallint	SMALLINT, 
		   Tdecimal	DECIMAL(5,2),
	           Tchar	CHAR(10),
	           Tvarchar	VARCHAR(10));	 

INSERT INTO TEST3 VALUES (1, 100, 9.00+0.99, '!!!!', '!!!!!!!');
INSERT INTO TEST3 VALUES (2, 200, 380.0-360, '@@@@', '@@@@@@@');
INSERT INTO TEST3 VALUES (3, 300, 7.5*4, '####', '#######');
INSERT INTO TEST3 VALUES (4, 400, 100/2.5, '$$$$', '$$$$$$$');
INSERT INTO TEST3 VALUES (5, 500, 100/(2), '%%%%%' CONCAT ' ^^^^', '@@@@@@@');
-- DIVIDED BY ZERO -22012
INSERT INTO TEST3 VALUES (6, 600, 1.00/0, '####', '#######');
INSERT INTO TEST3 VALUES (7, 700, 1.111*3, '####', '#######');
INSERT INTO TEST3 VALUES (8, 800, 100/(-2), '@@@@@' CONCAT '$$$$$' , '@@@@@@@');

SELECT * FROM TEST3 WHERE Tdecimal = 9.00+.99;
SELECT * FROM TEST3 WHERE Tdecimal = 380-360.0;
SELECT * FROM TEST3 WHERE Tdecimal = 7.5*(-4)*(-1);
SELECT * FROM TEST3 WHERE Tdecimal = 100/(2.5)*(1);
SELECT * FROM TEST3 WHERE Tdecimal = 9.0000+9.99999;
SELECT * FROM TEST3;

UPDATE TEST3 SET Tdecimal = (-1000)+1000  WHERE Tsmallint = 9.00+.99;
SELECT * FROM TEST3;
--------UPDATE TEST3 SET Tdecimal = (1000)-1000  WHERE Tsmallintt = 380-360.0;
UPDATE TEST3 SET Tdecimal = (1000)-1000  WHERE Tsmallint = 380-360.0;
SELECT * FROM TEST3;
UPDATE TEST3 SET Tdecimal = 1000*0  WHERE Tsmallint = 7.5*(-4)*(-1);
SELECT * FROM TEST3;
UPDATE TEST3 SET Tdecimal = 0/5  WHERE Tsmallint = 100/(2.5)*(1);
SELECT * FROM TEST3;

-- --------------------------------------------------------------------------------
-- --------------------------------------------------------------------------------
-- DECIMAL TEST
DROP TABLE TEST4;
CREATE TABLE TEST4(Tdecimal1	DECIMAL(5,2),
		   Tdecimal2	DECIMAL(8,4));

INSERT INTO TEST4 VALUES (1.11, 1.1);
INSERT INTO TEST4 VALUES (2.22, 22.2);
INSERT INTO TEST4 VALUES (3.33, 333.3);
INSERT INTO TEST4 VALUES (4.44, 44.444);
INSERT INTO TEST4 VALUES (5.55, 5555.55);
INSERT INTO TEST4 VALUES (6.66, 6666.66);
INSERT INTO TEST4 VALUES (7.77, 7777.77);
INSERT INTO TEST4 VALUES (7.77, NULL);

UPDATE TEST4 SET Tdecimal1 = Tdecimal2 WHERE Tdecimal2 = 1.1;
SELECT * FROM TEST4;
SELECT * FROM TEST4 WHERE Tdecimal2 = 1.1;

UPDATE TEST4 SET Tdecimal1 = Tdecimal2 WHERE Tdecimal2 = 44.444;
SELECT * FROM TEST4;
SELECT * FROM TEST4 WHERE Tdecimal2 = 44.444;

UPDATE TEST4 SET Tdecimal1 = Tdecimal2 WHERE Tdecimal2 = 5555.55;
SELECT * FROM TEST4;
SELECT * FROM TEST4 WHERE Tdecimal2 = 5555.55;


