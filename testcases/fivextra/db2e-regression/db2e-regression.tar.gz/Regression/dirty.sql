-- ------------------ FILE: DIRTY.SQL  -------------------
-- -                                                      		     - 
-- -   CHECK DIRTY BITS		  	     -
-- -                                                      		     -	
-- -------------------------------------------------------------
--
-- Drop and re-create table
DROP TABLE d;
CREATE TABLE d (id INT NOT NULL, name VARCHAR(50) NOT NULL, value INT NOT NULL, PRIMARY KEY (id));

-- Insert data
-- Expected result: 10 records
INSERT INTO d VALUES (1, 'Test Data 01 - Inserted', 111111);
INSERT INTO d VALUES (2, 'Test Data 02 - Deleted', 222);
INSERT INTO d VALUES (3, 'Test Data 03 - Updated', 33);
INSERT INTO d VALUES (4, 'Test Data 04 - Updated', 44444);
INSERT INTO d VALUES (-1, 'Test Data 05 - Inserted', 555);
INSERT INTO d VALUES (-2, 'Test Data 06 - Inserted', 666);
INSERT INTO d VALUES (-3, 'Test Data 07 - Inserted', 777777);
INSERT INTO d VALUES (0, 'Test Data 08 - Deleted', 8);
INSERT INTO d VALUES (10, 'Test Data 09 - Inserted', 99);
INSERT INTO d VALUES (100, 'Test Data 10 - Inserted', 10101010);
SELECT * FROM d;
SELECT * FROM d ORDER BY id;
SELECT $dirty,id,name,value FROM d;

-- Simulate delete and update operation on client side
-- Expected result: 8 records
DELETE FROM d WHERE id=2;
DELETE FROM d WHERE value=8;
SELECT * FROM d;
SELECT * FROM d ORDER BY id;
SELECT $dirty,id,name,value FROM d;

UPDATE d SET value=0 WHERE id>=3;
SELECT * FROM d;
SELECT * FROM d ORDER BY id;
SELECT $dirty,id,name,value FROM d;

-- Read delete/inserted/updated records
-- For PalmOS use $chmod c;
-- For other platforms use $chmod 3;
-- Expected result: 10 records
$chmod 3;
SELECT $dirty,id,$rid FROM d ORDER BY $dirty;

-- Read delete and physically delete all logical deleted records
-- For PalmOS use $chmod e;
-- For other platforms use $chmod 5;
-- Expected result: 8 records
$chmod 5;
DELETE FROM d WHERE $dirty=1;
SELECT * FROM d ORDER BY id;
SELECT $dirty,id,name,value FROM d;

-- Reset the dirty bit attribute to default (read normal records and logical delete)
-- For PalmOS use $chmod f;
-- For other platforms use $chmod 6;
$chmod 6;

-- Change all dirty bits to 0 (meaning synchronization complete)
-- Dirty bit set by application
-- For PalmOS use $chmod a;
-- For other platforms use $chmod 1;
-- Expected result: 8 records
$chmod 1;
UPDATE d set $dirty=0 where $dirty>0;
SELECT * FROM d ORDER BY id;
SELECT $dirty,id,name,value FROM d;

-- Reset the dirty bit attribute to default (dirty bits set by system)
-- For PalmOS use $chmod b;
-- For other platforms use $chmod 2;
$chmod 2;

-- Simulate data removed by the server
-- Read logical deleted record and physically delete records
-- For PalmOS use $chmod e;
-- For other platforms use $chmod 5;
-- Expected result: 5 records
$chmod 5;
DELETE FROM d WHERE id=100;
DELETE FROM d WHERE id<-1;
SELECT * FROM d;
SELECT * FROM d ORDER BY id;
SELECT $dirty,id,name,value FROM d;

-- Reset the dirty bit attribute to default (read normal records and logical delete)
-- For PalmOS use $chmod f;
-- For other platforms use $chmod 6;
$chmod 6;

-- Simulate data added by the server
-- Dirty bit set by application
-- For PalmOS use $chmod a;
-- For other platforms use $chmod 1;
-- Expected result: 9 records
$chmod 1;
INSERT INTO d VALUES (200, 'Test Server 01 - Inserted', 12345);
INSERT INTO d VALUES (-201, 'Test Server 02 - Inserted', 1212121);
INSERT INTO d VALUES (202, 'Test Server 03 - Inserted', 887766);
INSERT INTO d VALUES (77777, 'Test Server 04 - Inserted', -123456789);
SELECT * FROM d;
SELECT * FROM d ORDER BY id;
SELECT $dirty,id,name,value FROM d;

-- Simulate data updated by the server
-- Dirty bit set by application
-- For PalmOS use $chmod a;
-- For other platforms use $chmod 1;
-- Expected result: 9 records. All dirty bits should be equal 0.
$chmod 1;
UPDATE d SET value=0 WHERE id=1;
UPDATE d SET value=-9999 WHERE id=-1;
SELECT * FROM d;
SELECT * FROM d ORDER BY id;
SELECT $dirty,id,name,value FROM d;

-- Verify the result (including the logically deleted records)
-- For PalmOS use $chmod c;
-- For other platforms use $chmod 3;
-- Expected result: 9 records. All dirty bits should be equal 0.
$chmod 3;
SELECT $dirty,id,name,value FROM d;

-- Reset the dirty bit attribute to default (logical delete)
-- For PalmOS use $chmod d;
-- For other platforms use $chmod 4;
$chmod 4;

-- Delete the table
drop table d;

--
-- Test Case 1 (d2851kmt)
--
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY);
CREATE INDEX T_dirtya ON T ($dirty ASC);
CREATE INDEX T_dirtyd ON T ($dirty DESC);

INSERT INTO T VALUES (167);
INSERT INTO T VALUES (1);
INSERT INTO T VALUES (2);
INSERT INTO T VALUES (3);
INSERT INTO T VALUES (4);
INSERT INTO T VALUES (5);

SELECT A, $dirty,$rid FROM t;

SELECT $dirty,$rid FROM T ORDER BY 1 ASC,2;
SELECT $dirty,$rid FROM T ORDER BY $dirty ASC,$rid;

SELECT $dirty,$rid FROM T ORDER BY 1,2 DESC;
SELECT $dirty,$rid FROM T ORDER BY $dirty,$rid DESC;

SELECT $dirty,$rid FROM T ORDER BY 1 DESC,2;
SELECT $dirty,$rid FROM T ORDER BY $dirty DESC,$rid;

SELECT $dirty,$rid FROM T ORDER BY 1 DESC,2 DESC;
SELECT $dirty,$rid FROM T ORDER BY $dirty DESC,$rid DESC;

SELECT $dirty,$rid FROM T ORDER BY 1;
SELECT $dirty,$rid FROM T ORDER BY $dirty;

SELECT $dirty,$rid FROM T ORDER BY 1 DESC;
SELECT $dirty,$rid FROM T ORDER BY $dirty DESC;

SELECT $dirty,$rid FROM T WHERE $dirty > 0;
SELECT $dirty,$rid FROM T WHERE 1 > 0;

SELECT $dirty,$rid FROM T WHERE $dirty = 0;
SELECT $dirty,$rid FROM T WHERE $dirty > 0;
SELECT $dirty,$rid FROM T WHERE $dirty < 0;
SELECT DISTINCT $dirty FROM T WHERE $dirty = 0;
SELECT DISTINCT $dirty FROM T WHERE $dirty = 1;
SELECT DISTINCT $dirty FROM T WHERE $dirty = 2;
SELECT DISTINCT $dirty FROM T WHERE $dirty = 3;
SELECT MAX($dirty) FROM T;
SELECT $dirty,$rid FROM T WHERE $dirty = 2;
SELECT $dirty,$rid FROM T WHERE $dirty = 2 AND $rid > 0;
SELECT $dirty,$rid FROM T WHERE $rid > 0 AND $dirty = 2;
SELECT A, $dirty, $rid FROM T WHERE $dirty <> -1 ORDER BY $dirty ASC, $rid DESC;

SELECT $dirty,$rid FROM T ORDER BY 2, 1;
SELECT $dirty,$rid FROM T ORDER BY $rid DESC, $dirty DESC;
SELECT $dirty,$rid FROM T WHERE $rid > 0;
SELECT MAX($rid) FROM T;

DROP TABLE T;

--
-- Test Case 2 (d2851kmt)
--
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY);

INSERT INTO T VALUES (167);
INSERT INTO T VALUES (1);
INSERT INTO T VALUES (2);
INSERT INTO T VALUES (3);
INSERT INTO T VALUES (4);
INSERT INTO T VALUES (5);

SELECT A, $dirty,$rid FROM t;

SELECT $dirty,$rid FROM T ORDER BY 1 ASC,2;
SELECT $dirty,$rid FROM T ORDER BY $dirty ASC,$rid;

SELECT $dirty,$rid FROM T ORDER BY 1,2 DESC;
SELECT $dirty,$rid FROM T ORDER BY $dirty,$rid DESC;

SELECT $dirty,$rid FROM T ORDER BY 1 DESC,2;
SELECT $dirty,$rid FROM T ORDER BY $dirty DESC,$rid;

SELECT $dirty,$rid FROM T ORDER BY 1 DESC,2 DESC;
SELECT $dirty,$rid FROM T ORDER BY $dirty DESC,$rid DESC;

SELECT $dirty,$rid FROM T ORDER BY 1;
SELECT $dirty,$rid FROM T ORDER BY $dirty;

SELECT $dirty,$rid FROM T ORDER BY 1 DESC;
SELECT $dirty,$rid FROM T ORDER BY $dirty DESC;

SELECT $dirty,$rid FROM T WHERE $dirty > 0;
SELECT $dirty,$rid FROM T WHERE 1 > 0;

SELECT $dirty,$rid FROM T WHERE $dirty = 0;
SELECT $dirty,$rid FROM T WHERE $dirty > 0;
SELECT $dirty,$rid FROM T WHERE $dirty < 0;
SELECT DISTINCT $dirty FROM T WHERE $dirty = 0;
SELECT DISTINCT $dirty FROM T WHERE $dirty = 1;
SELECT DISTINCT $dirty FROM T WHERE $dirty = 2;
SELECT DISTINCT $dirty FROM T WHERE $dirty = 3;
SELECT MAX($dirty) FROM T;
SELECT $dirty,$rid FROM T WHERE $dirty = 2;
SELECT $dirty,$rid FROM T WHERE $dirty = 2 AND $rid > 0;
SELECT $dirty,$rid FROM T WHERE $rid > 0 AND $dirty = 2;
SELECT A, $dirty, $rid FROM T WHERE $dirty <> -1 ORDER BY $dirty ASC, $rid DESC;

SELECT $dirty,$rid FROM T ORDER BY 2, 1;
SELECT $dirty,$rid FROM T ORDER BY $rid DESC, $dirty DESC;
SELECT $dirty,$rid FROM T WHERE $rid > 0;
SELECT MAX($rid) FROM T;

DROP TABLE T;

--
-- Test Case 3 (d2851kmt)
--
$chmod 2;
$chmod 6;

DROP TABLE T;
CREATE TABLE T (A VARCHAR(5), B DECIMAL(31,2) NOT NULL, C INT NOT NULL, PRIMARY KEY(C,B));
CREATE INDEX I ON T (A);
CREATE INDEX T_dirty ON T ($dirty);

INSERT INTO T VALUES('ABC', -10.15, 18);
INSERT INTO T VALUES(NULL, 0.0, 0);
INSERT INTO T VALUES('XY', 1.0, 0);
INSERT INTO T VALUES('IJK', -10.15, -17);
INSERT INTO T VALUES('G', 1234567890123456789012345.99, 0);
INSERT INTO T VALUES(NULL, 20.36, 78);
INSERT INTO T VALUES('ABC', 67.99, 56);
INSERT INTO T VALUES('DEFG', 756890.1, -2);
INSERT INTO T VALUES('HHFFD', 100.00, 100);
INSERT INTO T VALUES('I', 18, 19);
INSERT INTO T VALUES('J', 19, 18);
INSERT INTO T VALUES('OP', 45.45, -66);
INSERT INTO T VALUES(NULL, 36.38, -188);
INSERT INTO T VALUES('VNB', 60.8, 999);

SELECT C, B, A, $dirty, $rid FROM T;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;

-- not allowed to set $rid (d3971kmt)
UPDATE T SET $rid = 180, A = 'ABCD' WHERE A = 'ABC';
UPDATE T SET $rid = 180 WHERE A = 'ABC';
UPDATE T SET A = 'ABCD', $rid = 180 WHERE A = 'ABC';

UPDATE T SET A = 'ABCD' WHERE A = 'ABC';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT COUNT(*) FROM T;

$chmod 7;

--
-- In application mode, can see and change logically deleted records.
--
UPDATE T SET $dirty = 0;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE A IS NULL;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

-- OK
UPDATE T SET A = 'XXYY' WHERE A IS NULL AND C = 0;
UPDATE T SET A = 'YYZZZ' WHERE A IS NULL AND C > 0;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

-- 1 record
SELECT C, B, A, $dirty, $rid FROM T WHERE A IS NULL;

-- 1 record
SELECT C, B, A, $dirty, $rid FROM T WHERE A = 'XXYY';

-- OK
UPDATE T SET $dirty = 2 WHERE A = 'YYZZZ' AND C > 0;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE A IS NULL;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

-- not allowed to set $rid
UPDATE T SET A = 'XYABC', $rid = 1234 WHERE A = 'ABCD';
UPDATE T SET $rid = 1234 WHERE A = 'ABCD';
UPDATE T SET $rid = 1234, A = 'XYABC' WHERE A = 'ABCD';
--
-- The system will not update $dirty to 3 in application mode.
--
UPDATE T SET A = 'XYABC' WHERE A = 'ABCD';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE C = 0;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

UPDATE T SET A = NULL, $dirty = 1 WHERE A = 'HHFFD';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

--
-- Can't see logically deleted records.
--
$chmod 4;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

--
-- Can't insert logically deleted records in this mode because it can "see" them.
--
$chmod 7;
INSERT INTO T VALUES(NULL, 36.38, -188);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

INSERT INTO T VALUES('XY', 1.0, 0);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

--
-- Can insert logically deleted records
--
$chmod 2;
INSERT INTO T VALUES(NULL, 36.38, -188);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

INSERT INTO T VALUES('XY', 1.0, 0);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

INSERT INTO T VALUES('HELLO', 234, 432);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

UPDATE T SET A = 'HHFFD', $dirty = 2 WHERE A IS NULL AND B = 100.00 AND C = 100;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;

--
-- physical delete
--
$chmod 5;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;

DELETE FROM T WHERE A IS NULL;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE A = 'XXYY';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE A = 'YYZZZ';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE C = 18;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DROP TABLE T;

$chmod 2;
$chmod 6;

--
-- Test Case 4 (d2851kmt)
--
$chmod 2;
$chmod 6;

DROP TABLE T;
CREATE TABLE T (A VARCHAR(5), B DECIMAL(31,2) NOT NULL, C INT NOT NULL, PRIMARY KEY(C,B));
CREATE INDEX I ON T (A);

INSERT INTO T VALUES('ABC', -10.15, 18);
INSERT INTO T VALUES(NULL, 0.0, 0);
INSERT INTO T VALUES('XY', 1.0, 0);
INSERT INTO T VALUES('IJK', -10.15, -17);
INSERT INTO T VALUES('G', 1234567890123456789012345.99, 0);
INSERT INTO T VALUES(NULL, 20.36, 78);
INSERT INTO T VALUES('ABC', 67.99, 56);
INSERT INTO T VALUES('DEFG', 756890.1, -2);
INSERT INTO T VALUES('HHFFD', 100.00, 100);
INSERT INTO T VALUES('I', 18, 19);
INSERT INTO T VALUES('J', 19, 18);
INSERT INTO T VALUES('OP', 45.45, -66);
INSERT INTO T VALUES(NULL, 36.38, -188);
INSERT INTO T VALUES('VNB', 60.8, 999);

SELECT C, B, A, $dirty, $rid FROM T;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;

UPDATE T SET A = 'ABCD' WHERE A = 'ABC';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT COUNT(*) FROM T;

$chmod 7;


--
-- Set $dirty to invalid values (d4053kmt)
--
DROP TABLE X;
CREATE TABLE X (A INT PRIMARY KEY);

INSERT INTO X VALUES (1);
INSERT INTO X VALUES (2);
INSERT INTO X VALUES (3);
INSERT INTO X VALUES (4);
INSERT INTO X VALUES (5);

UPDATE X SET $dirty = 10 WHERE A = 2;
UPDATE X SET $rid = 18, $dirty = 10 WHERE A = 2;
UPDATE X SET $dirty = 10, $rid = 22 WHERE A = 2;
UPDATE X SET $dirty = 0 WHERE A = 3;
UPDATE X SET $dirty = 2 WHERE A = 3;
UPDATE X SET $dirty = 3 WHERE A = 3;
UPDATE X SET $dirty = 1 WHERE A = 3;
UPDATE X SET $dirty = -16;

DROP TABLE X;


--
-- In application mode, can see and change logically deleted records.
--
UPDATE T SET $dirty = 0;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE A IS NULL;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

-- OK
UPDATE T SET A = 'XXYY' WHERE A IS NULL AND C = 0;
UPDATE T SET A = 'YYZZZ' WHERE A IS NULL AND C > 0;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

-- 1 record
SELECT C, B, A, $dirty, $rid FROM T WHERE A IS NULL;

-- 1 record
SELECT C, B, A, $dirty, $rid FROM T WHERE A = 'XXYY';

-- OK
UPDATE T SET $dirty = 2 WHERE A = 'YYZZZ' AND C > 0;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE A IS NULL;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

--
-- The system will not update $dirty to 3 in application mode.
--
UPDATE T SET A = 'XYABC' WHERE A = 'ABCD';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE C = 0;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

UPDATE T SET A = NULL, $dirty = 1 WHERE A = 'HHFFD';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

--
-- Can't see logically deleted records.
--
$chmod 4;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

--
-- Can't insert logically deleted records in this mode because it can "see" them.
--
$chmod 7;
INSERT INTO T VALUES(NULL, 36.38, -188);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

INSERT INTO T VALUES('XY', 1.0, 0);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

--
-- Can insert logically deleted records
--
$chmod 2;
INSERT INTO T VALUES(NULL, 36.38, -188);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

INSERT INTO T VALUES('XY', 1.0, 0);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

INSERT INTO T VALUES('HELLO', 234, 432);
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

UPDATE T SET A = 'HHFFD', $dirty = 2 WHERE A IS NULL AND B = 100.00 AND C = 100;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;

--
-- physical delete
--
$chmod 5;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;

DELETE FROM T WHERE A IS NULL;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE A = 'XXYY';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE A = 'YYZZZ';
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DELETE FROM T WHERE C = 18;
SELECT C, B, A, $dirty, $rid FROM T WHERE $dirty > 0;
SELECT C, B, A, $dirty, $rid FROM T ORDER BY C ASC, B ASC;
SELECT A, B, C, $dirty, $rid FROM T ORDER BY A ASC;
SELECT C, B, A, $dirty, $rid FROM T;
SELECT COUNT(*) FROM T;

DROP TABLE T;

$chmod 2;
$chmod 6;

--
-- Test Case 5 (d2851kmt)
--
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT);
CREATE INDEX T_DIRTY ON T ($dirty);
CREATE INDEX I ON T ($dirty ASC);
CREATE INDEX J ON T ($dirty DESC);
CREATE INDEX T_DIRTY ON T (B);
CREATE INDEX T_DIRTY ON T ($dirty);
DROP INDEX T_DIRTY;
CREATE INDEX T_VERYDIRTY ON T ($dirty);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT);
CREATE INDEX T_DIRTY ON T ($dirty ASC);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT);
CREATE INDEX T_DIRTY ON T ($dirty DESC);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT);
CREATE INDEX T_DIRTY ON T ($dirty, $rid);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT);
CREATE INDEX T_DIRTY ON T ($rid);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT);
CREATE INDEX T_DIRTY ON T ($rid, $dirty);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT);
CREATE INDEX T_DIRTY ON T ($dirty, A);
CREATE INDEX T_DIRTY ON T ($dirty, B);
CREATE INDEX T_DIRTY ON T ($dirty, A, B);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT);
CREATE INDEX T_DIRTY ON T (A, $dirty);
CREATE INDEX T_DIRTY ON T (B, $dirty);
CREATE INDEX T_DIRTY ON T (A, $dirty, B);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT, $dirty INT);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, B INT, $rid INT);
DROP TABLE T;

CREATE TABLE T (A INT PRIMARY KEY, $dirty INT, B INT, $rid INT);
DROP TABLE T;


--
-- Primary key index shouldn't share index with others. (d3118kmt)
--
$chmod 7;
--* setting is SQL_DIRTY_BIT_SET_BY_APPLICATION
drop table t1;
create table t1 (c1 int not null primary key, c2 int);
insert into t1 values (1,1);
--* the following delete leaves the value 1 in the index.
delete from t1 where c1=1;
--* the following insert fails.
--with dirty_bit_set_by_application, the primary key duplicate is not checked in dInsertRecord
--* but it is checked when inserting the index node
insert into t1 values (1,1);
create index xxx on t1(c1,c2);
insert into t1 values (1,1);
insert into t1 values (1,3);

drop table t1;
$chmod 2;
$chmod 6;

-- for encryption (d5019 xh)
-- connect to .\ user user1 using user1;
-- grant encrypt on database to "user1" using "user1" new "user1";
-- create table enc(a int) with encryption;
-- insert into enc values(15);
-- select * from enc;

--
-- Simulating Sync Client (d4943kmt)
--
drop table VNPerson;
drop table VNMedicalRecord;
drop table VNContact;
drop table VNSchedule;

CREATE TABLE VNPerson (ID Char(9) not null PRIMARY KEY,
                       Name Varchar(40),
                       Address Varchar(50),
                       City Varchar(25),
                       HomePhone Varchar(20),
                       WorkPhone Varchar(20),
                       MobilePhone Varchar(20));

CREATE TABLE VNMedicalRecord (RecordID Integer not null PRIMARY KEY,
                              Date_C Date,
                              Time_C Time,
                              PatientID Varchar(9),
                              BloodPressure Char(7),
                              PulseRate Smallint,
                              Temperature Decimal(4,1),
                              Weight Decimal(5,2),
                              Comment Varchar(100));

CREATE TABLE VNContact (PatientID Char(9) not null,
                        ContactID Char(9) not null,
                        Relationship Varchar(10), Primary Key (PatientID, ContactID));

CREATE TABLE VNSchedule (PatientID Varchar(9), Time_C Time not null PRIMARY KEY);

$chmod 3;

CREATE INDEX DSYIX1615352389N ON VNMEDICALRECORD($dirty ASC);

$chmod 1;

INSERT INTO VNPerson VALUES ('900000001',	'Clay, Harris',	  	    '517th Street', 			      'Seattle, WA 20005',      '(202)783-4946', '(202)749-7506', '(202)442-3030');
INSERT INTO VNPerson VALUES ('900000101',	'Hass, Christine',	    'P.O. Box 292', 		        'Levittown, PA 19055',    '(215)945-9168', '(215)664-0900', '(215)305-2591');
INSERT INTO VNPerson VALUES ('900000201',	'Thompson, Michael', 		'24299 Groven Lane',		    'Joaquin, TX 75954',      '(409)269-1655',	'(409)269-7410', '(409)305-6359');
INSERT INTO VNPerson VALUES ('900000301',	'Kwan, Sally', 	  	    '987 Spencr Hl. Road',		  'Midvale, OH 44653',      '(216)339-0537',	'(216)269-1548', '(216)898-6483');
INSERT INTO VNPerson VALUES ('900000401',	'Henderson, Eileen', 		'1201 Sabine Court',		    'Los Angeles, CA 90061',  '(213)755-4041',	'(213)945-3602', '(213)265-4350');
INSERT INTO VNPerson VALUES ('900000501',	'Clay, Bradly', 		    '7318 Kingsland Drive',	    'Grafton, WV 26354',      '(304)265-0836',	'(304)254-9374', '(304)897-1020');
INSERT INTO VNPerson VALUES ('900000601',	'Lucchessi, Vincenzo', 	'P.O. Box 13',			        'Effingham, SC 29541',    '(803)665-4021',	'(803)664-7348', '(803)894-3199');
INSERT INTO VNPerson VALUES ('900000701',	'Acevedo, Sean', 	  	  '220 E Schuetz Street',		  'Woodruff, WI 54568',     '(715)358-4484',	'(715)227-8281', '(715)339-4734');
INSERT INTO VNPerson VALUES ('900000801',	'Quintana, Dolores', 		'175 Littleton Road',		    'Norfolk, VA 23517',      '(804)622-1999',	'(804)945-6418', '(804)476-7938');
INSERT INTO VNPerson VALUES ('900000901',	'Yoshimura, Masatoshi', '4340-18th Street',			    'Effingham, SC 29541',    '(803)665-3788',	'(803)476-8127', '(803)339-0467');
INSERT INTO VNPerson VALUES ('900001001',	'Scoutten, Marilyn', 		'8326 Portsmouth Drive',	  'Nine Falls, WA 99026',   '(509)467-4893',	'(509)567-4648', '(509)764-2483');
INSERT INTO VNPerson VALUES ('900001101',	'Acevedo, Marcos', 		  '24299 Groven Lane',		    'New Market, MN 55054',   '(612)461-2421',	'(612)567-4310', '(612)575-6617');
INSERT INTO VNPerson VALUES ('900001201',	'Shenton, Sarah', 	  	'6320 W Paint Brush Lane',  'Columbus, OH 43204',     '(614)274-9514',	'(614)476-4309', '(614)254-7616');
INSERT INTO VNPerson VALUES ('900001301',	'Brown, David',	  	    '175 Littleton Road',		    'Lyndonville, NY 14098',  '(716)765-2082',	'(716)898-2929', '(716)945-6541');
INSERT INTO VNPerson VALUES ('900001401',	'Acevedo, Jennifer', 	  '231-1 2 E Market Street',	'Norfolk, VA 23517',      '(804)622-1840',	'(804)231-4966', '(804)765-7376');
INSERT INTO VNPerson VALUES ('900001501',	'Parker, John', 	  	  '147 W Tremont Avenue',	    'Hammonton, NJ 08037',    '(609)567-9741',	'(609)837-7529', '(609)381-0778');
INSERT INTO VNPerson VALUES ('900001601',	'Thompson, Maria', 	  	'220 Arrowhead Road',		    'Fordland, MO 65652',     '(417)738-4604',	'(417)381-3902', '(417)274-0153');
INSERT INTO VNPerson VALUES ('900001701',	'Gounot, Jason', 	  	  '720 Post Lake Place',		  'Charlotte, FL 33953',    '(941)764-3035',	'(941)567-2190', '(941)305-1842');
INSERT INTO VNPerson VALUES ('900001801',	'Lee, Jane', 	  	      '118 Baker Street',			    'Bay City, MI 48708',     '(517)894-5724',	'(517)665-1478', '(517)765-9358');
INSERT INTO VNPerson VALUES ('900001901',	'Smith, Philip', 		    '6520 Apple Blossom Road',  'Baltimore, MD 21212',    '(410)435-6729',	'(410)837-4370', '(410)476-5350');
INSERT INTO VNPerson VALUES ('900002001',	'Schneider, Martin',	  '11713 Milbern Drive',		  'El Campo, TX 77437',     '(409)543-6827',	'(409)461-9961', '(409)242-0491');
INSERT INTO VNPerson VALUES ('900002101',	'Jones, William', 		  '5034 Curtis Creek Road',	  'Bakersfield, CA 93311',  '(805)664-2382',	'(805)374-7421', '(805)533-8716');

INSERT INTO VNContact VALUES ('900000001',	'900001201',	'Friend');
INSERT INTO VNContact VALUES ('900000001',	'900001101',	'Boss');
INSERT INTO VNContact VALUES ('900000001',	'900001001',	'Sister');
INSERT INTO VNContact VALUES ('900000001',	'900000901',	'Friend');
INSERT INTO VNContact VALUES ('900000101',	'900001501',	'Co-Worker');
INSERT INTO VNContact VALUES ('900000101',	'900001301',	'Uncle');
INSERT INTO VNContact VALUES ('900000101',	'900001401',	'Sister');
INSERT INTO VNContact VALUES ('900000201',	'900001701',	'Co-Worker');
INSERT INTO VNContact VALUES ('900000201',	'900001601',	'Mother');
INSERT INTO VNContact VALUES ('900000201',	'900001801',	'God-Mother');
INSERT INTO VNContact VALUES ('900000301',	'900001901',	'Friend');
INSERT INTO VNContact VALUES ('900000301',	'900002101',	'Boss');
INSERT INTO VNContact VALUES ('900000301',	'900002001',	'Brother');
INSERT INTO VNContact VALUES ('900000301',	'900001201',	'Sister');
INSERT INTO VNContact VALUES ('900000401',	'900001101',	'Friend');
INSERT INTO VNContact VALUES ('900000401',	'900001401',	'Co-Worker');
INSERT INTO VNContact VALUES ('900000401',	'900000701',	'Boss');
INSERT INTO VNContact VALUES ('900000401',	'900002101',	'Friend');
INSERT INTO VNContact VALUES ('900000501',	'900001801',	'Co-Worker');
INSERT INTO VNContact VALUES ('900000501',	'900001001',	'Sister');
INSERT INTO VNContact VALUES ('900000501',	'900001201',	'Friend');
INSERT INTO VNContact VALUES ('900000501',	'900001101',	'Friend');
INSERT INTO VNContact VALUES ('900000601',	'900001301',	'God-Father');
INSERT INTO VNContact VALUES ('900000601',	'900001501',	'Co-Worker');
INSERT INTO VNContact VALUES ('900000601',	'900001701',	'Uncle');
INSERT INTO VNContact VALUES ('900000601',	'900001901',	'Uncle');
INSERT INTO VNContact VALUES ('900000701',	'900001101',	'Brother');
INSERT INTO VNContact VALUES ('900000701',	'900001001',	'Boss');
INSERT INTO VNContact VALUES ('900000701',	'900001201',	'Friend');
INSERT INTO VNContact VALUES ('900000701',	'900001501',	'Co-Worker');
INSERT INTO VNContact VALUES ('900000801',	'900001101',	'Brother');
INSERT INTO VNContact VALUES ('900000801',	'900001901',	'Co-Worker');
INSERT INTO VNContact VALUES ('900000801',	'900001401',	'Mother');
INSERT INTO VNContact VALUES ('900000801',	'900001701',	'Uncle');

INSERT INTO VNSchedule VALUES ('900000001',	'08:00:00');
INSERT INTO VNSchedule VALUES ('900000701',	'08:45:00');
INSERT INTO VNSchedule VALUES ('900000101',	'10:00:00');
INSERT INTO VNSchedule VALUES ('900000801',	'11:15:00');
INSERT INTO VNSchedule VALUES ('900000201',	'11:45:00');
INSERT INTO VNSchedule VALUES ('900000401',	'14:15:00');
INSERT INTO VNSchedule VALUES ('900000501',	'15:30:00');
INSERT INTO VNSchedule VALUES ('900000601',	'16:15:00');
INSERT INTO VNSchedule VALUES ('900000301',	'17:00:00');

INSERT INTO VNMedicalRecord VALUES (1,	  '1999-07-20',	'09:10:00',	'900000001',	'160/95',	80,	104.2,	150.5,  'Called 911. Checked into Hospital.');
INSERT INTO VNMedicalRecord VALUES (2,	  '1999-07-19',	'19:53:00',	'900000001',	'155/90',	72,	100.5, 	154.5,	'Gave stronger medicine for pain.');
INSERT INTO VNMedicalRecord VALUES (3,	  '2000-06-13',	'18:42:00',	'900000001',	'130/80',	65,	100.2,	170,	  'Needs to take a day off from work.');
INSERT INTO VNMedicalRecord VALUES (4,	  '2000-05-07',	'17:54:00',	'900000001',	'140/83',	68,	101,	  175.2,  'Suggest creating a diet plan');
INSERT INTO VNMedicalRecord VALUES (5,	  '2000-04-14',	'14:56:00',	'900000101',	'130/84',	59,	99.4,	  192,	  'Needs a special nurse next week.');
INSERT INTO VNMedicalRecord VALUES (6,	  '2000-03-15',	'12:49:00',	'900000101',	'120/85',	60,	103,	  192,	  'Needs a special nurse tomorrow.');
INSERT INTO VNMedicalRecord VALUES (7,	  '1999-02-07',	'01:02:00',	'900000101',	'115/86',	51,	102.8,	189,	  'Wounds desinfected and bandaged.');
INSERT INTO VNMedicalRecord VALUES (8,	  '1999-07-15',	'11:02:00',	'900000201',	'135/87',	73,	104.2,	169,	  'Suggest moving to hospital for better care.');
INSERT INTO VNMedicalRecord VALUES (9,	  '1999-07-13',	'11:47:00',	'900000201',	'180/98',	70,	100.7,	174,	  'Patient is recovering, but still needs rest.');
INSERT INTO VNMedicalRecord VALUES (10,	'1999-06-08',	'01:17:00',	'900000301',	'200/99',	55,	99,		  148,	  'Gave medicine for headache.');
INSERT INTO VNMedicalRecord VALUES (11,	'1999-05-12',	'16:40:00',	'900000301',	'175/80',	56,	99.6,	  154,		'Needs to take a day off from work.');
INSERT INTO VNMedicalRecord VALUES (12,	'2000-04-19',	'00:11:00',	'900000301',	'166/81',	51,	106,		145,	  'Called 911. Checked into Hospital.');
INSERT INTO VNMedicalRecord VALUES (13,	'2000-03-19',	'03:38:00',	'900000401',	'175/82',	76,	98.6,   117,	  'No Change.');
INSERT INTO VNMedicalRecord VALUES (14,	'2000-02-17',	'09:04:00',	'900000401',	'152/83',	65,	98,		  115,	  'Need to take a day off from work.');
INSERT INTO VNMedicalRecord VALUES (15,	'2000-01-20',	'00:50:00',	'900000401',	'132/84',	72,	98,		  110.2,	'Needs to take a day off from work.');
INSERT INTO VNMedicalRecord VALUES (16,	'1999-08-08',	'03:25:00',	'900000501',	'174/85',	72,	98,		  171.2,	'Healthy.');
INSERT INTO VNMedicalRecord VALUES (17,	'1999-07-08',	'11:31:00',	'900000501',	'165/86',	69,	97.9,	  171,	  'Twisted ankle bandaged.');
INSERT INTO VNMedicalRecord VALUES (18,	'1999-06-04',	'13:44:00',	'900000501',	'180/87',	68,	98.2,	  181,	  'Broken finger bandaged.');
INSERT INTO VNMedicalRecord VALUES (19,	'2000-05-04',	'02:46:00',	'900000601',	'110/88',	77,	98.4,	  250,	  'Ok');
INSERT INTO VNMedicalRecord VALUES (20,	'1999-04-22',	'02:03:00',	'900000601',	'175/89',	60,	105,	  245,	  'Very ill, recommend hospital check-in.');
INSERT INTO VNMedicalRecord VALUES (21,	'2000-03-04',	'04:46:00',	'900000701',	'183/90',	51,	99,		  182,	  'Just talked to him.');
INSERT INTO VNMedicalRecord VALUES (22,	'2000-02-16',	'19:20:00',	'900000701',	'107/91',	60,	99.5,	  175,	  'Needs to take a day off from work.');
INSERT INTO VNMedicalRecord VALUES (23,	'1999-01-23',	'15:47:00',	'900000701',	'122/92',	54,	100,	  178,	  'Needs to take a day off from work.');
INSERT INTO VNMedicalRecord VALUES (24,	'2000-07-20',	'11:37:00',	'900000801',	'162/93',	73,	104.5,  130,	  'Seriously ill, contact relatives immediately.');
INSERT INTO VNMedicalRecord VALUES (25,	'1999-07-06',	'17:16:00',	'900000801',	'163/94',	51,	101.9,  127,	  'Suggest moving into hospital for better care.');

reorg table VNPerson 50 6000;
reorg table VNMedicalRecord 50 6000;
reorg table VNContact 50 6000;
reorg table VNSchedule 50 6000;

$chmod 2;

update vnmedicalrecord set comment = 'blah' where recordid = 25;
update vnmedicalrecord set comment = 'blah' where recordid = 2;
update vnmedicalrecord set comment = 'blah' where recordid = 10;

select * from vnmedicalrecord;

drop table VNPerson;
drop table VNMedicalRecord;
drop table VNContact;
drop table VNSchedule;

$chmod 2;
$chmod 6;

drop table test;
create table test (c1 int not null primary key, c2 varchar(1000));
insert into test values(1,'1');
update test set c2 = '1111111111111111111111';
ENABLE APPLICATION SET DIRTY;
update test set $dirty = 0;
DISABLE APPLICATION SET DIRTY;
delete from test where c1=1;
select * from test where c1=1;
select * from test where c1=1+0;
ENABLE READ DELETED;
select * from test where c1=1;
select * from test where c1=1+0;
DISABLE READ DELETED;
drop table test;

----------------------------------------------------
-- Test $dirty attribute with update, inserts, etc.
----------------------------------------------------

DROP TABLE DT;

CREATE TABLE DT (A INT NOT NULL PRIMARY KEY, B CHAR(50), C VARCHAR(200));

ENABLE APPLICATION SET DIRTY;

-- CLEAN: insert clean rows, i.e., dirty bit is 0
INSERT INTO DT VALUES (1, 'a', 'a');
INSERT INTO DT VALUES (2, 'b', 'b');
INSERT INTO DT VALUES (3, 'c', 'c');

INSERT INTO DT VALUES (11, 'ax', 'ax');
INSERT INTO DT VALUES (12, 'bx', 'bx');
INSERT INTO DT VALUES (13, 'cx', 'cx');

-- verify the dirty bit is 0
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           0           1 a                                                 
--           0           2 b                                                 
--           0           3 c                                                 
--           0          11 ax                                                
--           0          12 bx                                                
--           0          13 cx                                                
-- 6 row(s) returned.


DISABLE APPLICATION SET DIRTY;

-- DIRTY-INSERT: insert some new rows with dirty bit

-- verify the dirty bit is 2
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           0           1 a                                                 
--           0           2 b                                                 
--           0           3 c                                                 
--           0          11 ax                                                
--           0          12 bx                                                
--           0          13 cx                                                
--           2           4 d                                                 
--           2           5 e                                                 
--           2          14 dx                                                
--           2          15 ex                                                
-- 10 row(s) returned.

ENABLE APPLICATION SET DIRTY;

-- CLEAN: insert clean rows, i.e., dirty bit is 0
INSERT INTO DT VALUES (21, 'ay', 'ay');
INSERT INTO DT VALUES (22, 'by', 'by');
INSERT INTO DT VALUES (23, 'cy', 'cy');

DISABLE APPLICATION SET DIRTY;

-- verify the dirty bit is 0
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           0           1 a                                                 
--           0           2 b                                                 
--           0           3 c                                                 
--           0          11 ax                                                
--           0          12 bx                                                
--           0          13 cx                                                
--           2           4 d                                                 
--           2           5 e                                                 
--           2          14 dx                                                
--           2          15 ex                                                
--           0          21 ay                                                
--           0          22 by                                                
--           0          23 cy                                                
-- 13 row(s) returned.

-- CLEAN-UPDATE: update some clean rows
UPDATE DT SET B = 'aa' WHERE A = 1;
UPDATE DT SET B = 'aax' WHERE A = 11;

-- verify that we have 2 rows of dirty bit value 3.
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           3           1 aa                                                
--           0           2 b                                                 
--           0           3 c                                                 
--           3          11 aax                                               
--           0          12 bx                                                
--           0          13 cx                                                
--           2           4 d                                                 
--           2           5 e                                                 
--           2          14 dx                                                
--           2          15 ex                                                
--           0          21 ay                                                
--           0          22 by                                                
--           0          23 cy                                                
-- 13 row(s) returned.


-- DIRTY-INSERT: update some new rows
UPDATE DT SET B = 'dd' WHERE A = 4;

-- verify the column B value is 'dd' for A==4
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           3           1 aa                                                
--           0           2 b                                                 
--           0           3 c                                                 
--           3          11 aax                                               
--           0          12 bx                                                
--           0          13 cx                                                
--           2           4 dd                                                
--           2           5 e                                                 
--           2          14 dx                                                
--           2          15 ex                                                
--           0          21 ay                                                
--           0          22 by                                                
--           0          23 cy                                                
-- 13 row(s) returned.



-- LOGICAL-DELETE: delete some clean rows

DELETE FROM DT WHERE A IN (2, 22);

ENABLE READ DELETED;

-- verify two rows of dirty bit values 1
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           3           1 aa                                                
--           1           2 b                                                 
--           0           3 c                                                 
--           3          11 aax                                               
--           0          12 bx                                                
--           0          13 cx                                                
--           2           4 dd                                                
--           2           5 e                                                 
--           2          14 dx                                                
--           2          15 ex                                                
--           0          21 ay                                                
--           1          22 by                                                
--           0          23 cy                                                
-- 13 row(s) returned.

DISABLE READ DELETED;

-- Physically deleted row

ENABLE APPLICATION SET DIRTY;
ENABLE PHYSICAL DELETE;

DELETE FROM DT WHERE A = 12;

DISABLE APPLICATION SET DIRTY;
DISABLE PHYSICAL DELETE;

ENABLE READ DELETED;

-- verify row of A==12 is gone
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           3           1 aa                                                
--           1           2 b                                                 
--           0           3 c                                                 
--           3          11 aax                                               
--           0          13 cx                                                
--           2           4 dd                                                
--           2           5 e                                                 
--           2          14 dx                                                
--           2          15 ex                                                
--           0          21 ay                                                
--           1          22 by                                                
--           0          23 cy                                                
-- 12 row(s) returned.

SELECT $dirty, A, B FROM DT ORDER BY A DESC;

SELECT $dirty, A, B FROM DT ORDER BY B;
SELECT $dirty, A, B FROM DT ORDER BY 1;

-- Read individual rows one by one
SELECT $dirty, A, B FROM DT WHERE A = 1;
SELECT $dirty, A, B FROM DT WHERE A = 2;
SELECT $dirty, A, B FROM DT WHERE A = 3;
SELECT $dirty, A, B FROM DT WHERE A = 4;
SELECT $dirty, A, B FROM DT WHERE A = 5;
SELECT $dirty, A, B FROM DT WHERE A = 11;
SELECT $dirty, A, B FROM DT WHERE A = 13;
SELECT $dirty, A, B FROM DT WHERE A = 14;
SELECT $dirty, A, B FROM DT WHERE A = 21;
SELECT $dirty, A, B FROM DT WHERE A = 22;
SELECT $dirty, A, B FROM DT WHERE A = 23;

-- no row
SELECT $dirty, A, B FROM DT WHERE A = 30;
SELECT $dirty, A, B FROM DT WHERE A = 12;

DISABLE READ DELETED;

--------------------------------------------------------------------
-- Do updates so that rows will be forwarded.

ENABLE APPLICATION SET DIRTY;

-- Rows should have been forwarded due to increase in tuple width.
UPDATE DT SET C = 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa';

ENABLE READ DELETED;

SELECT $dirty, A, B, C FROM DT;

-- Read individual rows one by one
SELECT $dirty, A, B FROM DT WHERE A = 1;
SELECT $dirty, A, B FROM DT WHERE A = 2;
SELECT $dirty, A, B FROM DT WHERE A = 3;
SELECT $dirty, A, B FROM DT WHERE A = 4;
SELECT $dirty, A, B FROM DT WHERE A = 5;
SELECT $dirty, A, B FROM DT WHERE A = 11;
SELECT $dirty, A, B FROM DT WHERE A = 13;
SELECT $dirty, A, B FROM DT WHERE A = 14;
SELECT $dirty, A, B FROM DT WHERE A = 21;
SELECT $dirty, A, B FROM DT WHERE A = 22;
SELECT $dirty, A, B FROM DT WHERE A = 23;

-- no row
SELECT $dirty, A, B FROM DT WHERE A = 30;
SELECT $dirty, A, B FROM DT WHERE A = 12;

-- verify tht the row order is probably changed indicating rows have been forwarded
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           1           2 b                                                 
--           1          22 by                                                
--           3           1 aa                                                
--           0           3 c                                                 
--           3          11 aax                                               
--           0          13 cx                                                
--           2           4 dd                                                
--           2           5 e                                                 
--           2          14 dx                                                
--           2          15 ex                                                
--           0          21 ay                                                
--           0          23 cy                                                
-- 12 row(s) returned.

DISABLE READ DELETED;

DISABLE APPLICATION SET DIRTY;

-- LOGICAL-DELETE: delete some clean rows that have been forwarded

DELETE FROM DT WHERE A = 21;

ENABLE READ DELETED;

-- verify that the dirty bit for A==21 is set to 1
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           1           2 b                                                 
--           1          22 by                                                
--           3           1 aa                                                
--           0           3 c                                                 
--           3          11 aax                                               
--           0          13 cx                                                
--           2           4 dd                                                
--           2           5 e                                                 
--           2          14 dx                                                
--           2          15 ex                                                
--           1          21 ay                                                
--           0          23 cy                                                
-- 12 row(s) returned.

SELECT $dirty, A, B FROM DT where a = 21;
DISABLE READ DELETED;

-- DIRTY-INSERT: update some new rows
UPDATE DT SET B = 'ee' WHERE A = 5;

ENABLE READ DELETED;
SELECT $dirty, A, B FROM DT;

-- verify that the dirty bit is 2
SELECT $dirty, A, B FROM DT WHERE A = 5;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           2           5 ee                                                
-- 1 row(s) returned.

DISABLE READ DELETED;

-- DIRTY-INSERT: update some new rows, and move the row forward
UPDATE DT SET C = 'xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
WHERE A = 5;

ENABLE READ DELETED;
SELECT $dirty, A, B FROM DT;

-- verify that the row has dirty bit value 2.
SELECT $dirty, A, B FROM DT WHERE A = 5;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           2           5 ee                                                
-- 1 row(s) returned.

DISABLE READ DELETED;

-- LOGICAL-DELETE: delete some new rows that have been forwarded
-- the row will actually be removed physically
DELETE FROM DT WHERE A = 5;

DISABLE READ DELETED;

SELECT $dirty, A, B FROM DT WHERE A = 5;

DISABLE READ DELETED;




-- Physically deleted row that has been forwarded

ENABLE PHYSICAL DELETE;

DELETE FROM DT WHERE A = 13;

DISABLE PHYSICAL DELETE;

ENABLE READ DELETED;

-- verify that the row with A==13 is gone
SELECT $dirty, A, B FROM DT;

-- $dirty      A           B                                                 
-- ----------- ----------- --------------------------------------------------
--           1           2 b                                                 
--           1          22 by                                                
--           3           1 aa                                                
--           0           3 c                                                 
--           3          11 aax                                               
--           2           4 dd                                                
--           2          14 dx                                                
--           2          15 ex                                                
--           1          21 ay                                                
--           0          23 cy                                                
-- 10 row(s) returned.

DISABLE READ DELETED;

DROP TABLE DT;


-- Test some simple group by with varchar

drop table gb;
create table gb (c1 char(10), c2 varchar(10), c3 integer);
insert into gb values('abc','abc',1);
insert into gb values(' ',' ',1);
insert into gb values('  ','  ',2);
insert into gb values('zzz','zzzzzz',2);
insert into gb values('abcdef','abcdef',0);
insert into gb values('1111','1111',-2);
insert into gb values('22111','1b111',-2);
insert into gb values('111','11c11',-2);
insert into gb values('14111','b111',-2);
insert into gb values('a11','A111',-2);
select max(c1),min(c2) from gb group by c3;
select min(c1),max(c2) from gb group by c3;

drop table gb;

-- Test some other group by scenarios

-- data corruption in V721 and V81
-- simple select
drop table t1;
create table t1 (c1 int not null primary key, c2 int not null);
insert into t1 values(1,1);
insert into t1 values(2,2);

create stmt handle :1;
prepare :1 select * from t1;
execute :1;
fetch :1;
insert into t1 values(10,10);
execute :1;
select count(*) from t1;
select * from t1 where 1=1;

-- data corruption in V721
-- simple select w/ order by
drop stmt handle :1;
drop table t1;
create table t1 (c1 int not null primary key, c2 int not null);
insert into t1 values(1,1);
insert into t1 values(2,2);

create stmt handle :1;
prepare :1 select * from t1 order by 1;
execute :1;
fetch :1;
insert into t1 values(10,10);
execute :1;
select count(*) from t1;
select * from t1 where 1=1;

-- NO data corruption in V721
-- simple select w/ order by
drop stmt handle :1;
drop table t1;
create table t1 (c1 int not null primary key, c2 int not null);
insert into t1 values(1,1);
insert into t1 values(2,2);

create stmt handle :1;
prepare :1 select * from t1 order by 2;
execute :1;
fetch :1;
insert into t1 values(10,10);
execute :1;
select count(*) from t1;
select * from t1 where 1=1;

-- NO data corruption in V721 but crashes on the second "execute :1"
-- group by
drop stmt handle :1;
drop table t1;
create table t1 (c1 int not null primary key, c2 int not null);
insert into t1 values(1,1);
insert into t1 values(2,2);

create stmt handle :1;
prepare :1 select c1, count(*) from t1 group by c1;
execute :1;
fetch :1;
insert into t1 values(10,10);
execute :1;
select count(*) from t1;
select * from t1 where 1=1;

-- NO data corruption in V721
-- distinct
drop stmt handle :1;
drop table t1;
create table t1 (c1 int not null primary key, c2 int not null);
insert into t1 values(1,1);
insert into t1 values(2,2);

create stmt handle :1;
prepare :1 select distinct * from t1;
execute :1;
fetch :1;
insert into t1 values(10,10);
execute :1;
select count(*) from t1;
select * from t1 where 1=1;

-- NO data corruption in V721 but crashes on the second "execute :1"
-- crash on V81
-- group by and order by
drop table t1;
drop stmt handle :1;
create table t1 (c1 int not null primary key, c2 int not null);
insert into t1 values(1,1);
insert into t1 values(2,2);

create stmt handle :1;
prepare :1 select c1, count(*) from t1 group by c1 order by 2;
execute :1;
fetch :1;
insert into t1 values(10,10);
execute :1;
select count(*) from t1;
select * from t1 where 1=1;


-- crashing in re-executing a prepared groupby query 
drop table t1;
drop stmt handle :1;
create table t1 (c1 int not null primary key, c2 int not null);
insert into t1 values(1,1);
insert into t1 values(2,2);

create stmt handle :1;
prepare :1 select c1, count(*) from t1 group by c1;
execute :1;
fetch :1;
execute :1;
fetch :1;
select count(*) from t1;
select * from t1 where 1=1;

-- No crash
drop table t1;
drop stmt handle :1;
create table t1 (c1 int not null primary key, c2 int not null);
insert into t1 values(1,1);
insert into t1 values(2,2);

select c1, count(*) from t1 group by c1;

drop table t1;
drop stmt handle :1;

-- test some multiple stmt handles
drop stmt handle :1;
drop table t1;
create table t1 (c1 int not null primary key, c2 int not null);
insert into t1 values(1,1);
insert into t1 values(2,2);
create stmt handle :1;
prepare :1 select * from t1 order by 1;
execute :1;
fetch :1;
insert into t1 values(10,10);
execute :1;
select count(*) from t1;
select * from t1 where 1=1;

drop table t1;
drop stmt handle :1;


-- test dirty bit index
create table t1 (c1 int primary key not null, c2 varchar(10));
create index idx1 on t1 ($dirty);
enable application set dirty;
insert into t1 values (1, 'a');
disable application set dirty;
enable read deleted;
update t1 set c2='X' where c1 <= 1;
select c1,c2,$dirty from t1;
select c1,c2,$dirty from t1 where $dirty > 0;
delete from t1 where c1 <= 1;
select c1,c2,$dirty from t1;
select c1,c2,$dirty from t1 where $dirty > 0;
select c1,c2,$dirty from t1 where c1 = 1;
disable read deleted;
drop table t1;

-- test dirty bit index
create table t1 (c1 int, c2 int);
create index idx1 on t1($dirty);
insert into t1 values (1, 1);
insert into t1 values (2, 2);
insert into t1 values (3, 3);
update t1 set c1=4,c2=4,$dirty=0;
enable application set dirty;
update t1 set c1=4,c2=4,$dirty=0;
select c1,c2,$dirty from t1;
select c1,c2,$dirty from t1 where $dirty > 0;
select c1,c2,$dirty from t1 where $dirty = 0;
disable application set dirty;
drop table t1;

-- test statement handles
create table t (a varchar(10));
insert into t values ('ROY');
insert into t values ('ROD');
insert into t values ('STU');
insert into t values ('ROYB');
create index idx on t(a);
select * from t where a > 'ROX' and a < 'ROZ' and a like 'ROY%';
create stmt handle :1;
prepare :1 select * from t where a > ? and a < ? and a like ?;
bind :1 1 ROX;
bind :1 2 ROZ;
bind :1 3 ROY%;
execute :1;
fetch :1;
fetch :1;
fetch :1;
execute :1;
fetch :1;
fetch :1;
drop stmt handle :1;
drop table t;
