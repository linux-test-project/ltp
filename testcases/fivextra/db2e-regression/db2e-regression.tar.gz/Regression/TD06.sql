-- ------------------- FILE: TD06.SQL  --------------------
-- -                                                      - 
-- -             TEST SIMPLE JOIN OPERATIONS              -
-- -                                                      -
-- --------------------------------------------------------
-- 

-- -------------------------------------------------------- 
-- -         FIND WHO TEACH THE SUBJECT PALM OS           -
-- --------------------------------------------------------

select Name,Age from UserTable,TutorTable where UserId=Teacher and Subject='PalmOS';


-- -------------------------------------------------------- 
-- -       FIND WHO LEARN THE SUBJECT APPLICATION         -
-- --------------------------------------------------------

select Name,Age from UserTable,TutorTable where UserId=Student and Subject='Application';


-- -------------------------------------------------------- 
-- -    FIND WHAT SUBJECT THE USER THANH IS LOOKING FOR   -
-- --------------------------------------------------------

select Name,Subject 
  from UserTable,DemandTable 
  where Name='Thanh' and UserTable.UserId=DemandTable.UserId;


-- -------------------------------------------------------- 
-- -           FIND WHO LEARN THE SUBJECT DUMMY           -
-- --------------------------------------------------------

select Name,Subject from UserTable,TutorTable where Subject like 'Dummy%' and UserId=Student;
