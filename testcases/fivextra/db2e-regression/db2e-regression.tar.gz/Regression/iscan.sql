--------------------------------------------------------------------------------
-- TEST FOR ISCAN
--------------------------------------------------------------------------------

--1-
--connect to iscan;
--drop table x;
--drop table y;
--drop table xp;
--drop table yp;

--6--

select * from xp, y where xp.a = y.a;

create table x
(
	a	int,
	c	int,
	b	char(1)	primary key	not null
);

create table y
(
	a	int,
	c 	int,
	b	char(1) primary key	not null
);


create table xp
(
	a	int	primary key	not null,
	b 	int,
	c	int
);

create table yp
(
	a	int	primary key	not null,
	b	int,
	c 	int
);


-- 10 --
insert into x values(1 , 1  , 'a');
insert into x values(2 , 1  , 'c');
insert into x values(3 , 10 , 'd');
insert into x values(4 , 2  , 's');
insert into x values(5 , 2  , 'n');
insert into x values(2 , -7 , 'y');
insert into x values(7 , 11 , 'x');
insert into x values(8 , 2  , 'r');
insert into x values(9 , -3 , 'u');
insert into x values(-1, 7  , 'e');
insert into x values(-2, 2  , 'o');
insert into x values(-3, -1 , 't');
insert into x values(-5, 3  , 'w');
insert into x values(-5, 2  , 'z');
insert into x values(0 , 4  , 'v');
insert into x values(-6, 5  , 'q');

--26
insert into y values(1 , 1  , 'p');
insert into y values(2 , 1  , 't');
insert into y values(6 , 10 , 'l');
insert into y values(2 , 2  , 'm');
insert into y values(5 , 2  , 'v');
insert into y values(6 , -7 , 'a');
insert into y values(6 , 11 , 'z');
insert into y values(8 , 2  , 's');
insert into y values(2 , -3 , 'u');
insert into y values(-1, 7  , 'r');
insert into y values(-2, 2  , 'o');
insert into y values(-3, -1 , 'q');
insert into y values(-1, 3  , 'k');
insert into y values(-5, 2  , 'b');
insert into y values(0 , 4  , 'c');
insert into y values(-6, 5  , 'd');

-- 42 --
insert into xp values(1 , 1  , 1);
insert into xp values(2 , 1  , 4);
insert into xp values(3 , 10 , -3);
insert into xp values(4 , 2  , 6);
insert into xp values(5 , 2  , 5);
insert into xp values(6 , -7 , -2);
insert into xp values(7 , 11 , 8);
insert into xp values(8 , 2  , 2);
insert into xp values(9 , -3 , -1);
insert into xp values(-1, 7  , 0);
insert into xp values(-2, 2  , 6);
insert into xp values(-3, -1 , 2);
insert into xp values(-4, 3  , -5);
insert into xp values(-5, 2  , 3);
insert into xp values(0 , 4  , -3);
insert into xp values(-6, 5  , 1);

-- 58--
insert into yp values(1 , 1  , 1);
insert into yp values(2 , 1  , 4);
insert into yp values(3 , 10 , -3);
insert into yp values(4 , 2  , 6);
insert into yp values(5 , 2  , 5);
insert into yp values(6 , -7 , -2);
insert into yp values(7 , 11 , 8);
insert into yp values(8 , 2  , 2);
insert into yp values(9 , -3 , -1);
insert into yp values(-1, 7  , 0);
insert into yp values(-2, 2  , 6);
insert into yp values(-3, -1 , 2);
insert into yp values(-4, 3  , -5);
insert into yp values(-5, 2  , 3);
insert into yp values(0 , 4  , -3);
insert into yp values(-6, 5  , 1);

-- 74 --
select * from xp, y where xp.a = y.a;

-- 75 --
select * from xp,y where y.a = xp.a;

-- 76 --
select * from y,xp where xp.a = y.a;

-- 77 --
select * from y,xp where y.a = xp.a;

-- 78 --
select * from xp,yp where xp.a = yp.a;

-- 79 --
select * from xp,yp where yp.a = xp.a;

-- 80 --
select * from xp as l, xp as m where l.a = m.b;

-- 81 --
select * from x where x.b = 'c';

-- 82 --
select * from y where 'c' = y.b;

-- 83 --
select * from x where x.a >= 2;

-- 84 --
select xp.a, x.b from xp,x where xp.a > 3 and xp.a = x.a;

-- 85 --
select x.b,xp.a from x,xp where xp.a > 3 and xp.a < x.a;


drop table x;
drop table y;
drop table xp;
drop table yp;






