-- Create tables for the test
CREATE TABLE HOLDCURSOR (c INT);
INSERT INTO HOLDCURSOR VALUES (42);
INSERT INTO HOLDCURSOR VALUES (43);
INSERT INTO HOLDCURSOR VALUES (44);
CREATE TABLE ToBeFilled (c INT);
-- Initialization done
-- Create a new statement handle and execute it outside any transactional 
-- context
CREATE STMT HANDLE :1;
EXECDIRECT :1 SELECT * FROM HOLDCURSOR;
-- First we simulate the grouping of inserts into a transaction. 
-- We also pretend that 
-- we have to constantly fetch data from another table to do the inserts.
AUTOCOMMIT OFF;
FETCH :1;
INSERT INTO ToBeFilled VALUES (42);
COMMIT;
FETCH :1;
INSERT INTO ToBeFilled VALUES (43);
COMMIT;
FETCH :1;
INSERT INTO ToBeFilled VALUES (44);
COMMIT;
FETCH :1;
COMMIT;
-- This time we execute the statement inside a transaction
-- Furthermore, we use the same table for the inserts and fetches.
EXECDIRECT :1 SELECT * FROM ToBeFilled;
FETCH :1;
INSERT INTO ToBeFilled VALUES (45);
COMMIT;
FETCH :1;
INSERT INTO ToBeFilled VALUES (46);
COMMIT;
FETCH :1;
INSERT INTO ToBeFilled VALUES (47);
COMMIT;
FETCH :1;
AUTOCOMMIT ON;
DROP STMT HANDLE :1;
BLASTDB;

