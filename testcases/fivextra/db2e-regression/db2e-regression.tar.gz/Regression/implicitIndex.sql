-- ---------------------------------------------------------------------------------------------
-- Test of the creation of implicit indexes (involved in order by, group by, distinct)
-- The limit of the column size for an explicit index is 1024. It is 32676 for an implicit index
-- ---------------------------------------------------------------------------------------------

-- varchar

create table implicitIndex(a varchar(1024), b varchar(32676));

insert into implicitIndex values('coucou', 'coucoucoucou');

insert into implicitIndex values ('hello', 'hellohello');

select * from implicitIndex order by b;

select b from implicitIndex group by b;

select distinct b from implicitIndex;

select * from implicitIndex order by a;

select a from implicitIndex group by a;

select distinct a from implicitIndex;

create index indexB on implicitIndex(b);

create index indexA on implicitIndex(a);

drop table implicitIndex;

create table implicitIndex(a varchar(1025), b varchar(32677));

insert into implicitIndex values('coucou', 'coucoucoucou');

insert into implicitIndex values ('hello', 'hellohello');

select * from implicitIndex order by b;

select b from implicitIndex group by b;

select distinct b from implicitIndex;

select * from implicitIndex order by a;

select a from implicitIndex group by a;

select distinct a from implicitIndex;

create index indexB  on implicitIndex(b);

create index indexA on implicitIndex(a);

drop table implicitIndex;

create table implicitIndex(a varchar(1024), b varchar(32676), c varchar(32676));

insert into implicitIndex values('coucou', 'coucoucoucou', 'coucoucoucoucoucou');

insert into implicitIndex values ('hello', 'hellohello', 'hellohellohello');

select * from implicitIndex order by b,c;

select distinct b,c from implicitIndex;

drop table implicitIndex;

-- char

create table implicitIndex(a char(1024), b char(32676));

insert into implicitIndex values('coucou', 'coucoucoucou');

insert into implicitIndex values ('hello', 'hellohello');

select * from implicitIndex order by b;

select b from implicitIndex group by b;

select distinct b from implicitIndex;

select * from implicitIndex order by a;

select a from implicitIndex group by a;

select distinct a from implicitIndex;

create index indexB on implicitIndex(b);

create index indexA on implicitIndex(a);

drop table implicitIndex;

create table implicitIndex(a char(1025), b char(32677));

insert into implicitIndex values('coucou', 'coucoucoucou');

insert into implicitIndex values ('hello', 'hellohello');

select * from implicitIndex order by b;

select b from implicitIndex group by b;

select distinct b from implicitIndex;

select * from implicitIndex order by a;

select a from implicitIndex group by a;

select distinct a from implicitIndex;

create index indexB  on implicitIndex(b);

create index indexA on implicitIndex(a);

drop table implicitIndex;

create table implicitIndex(a char(1024), b char(2676), c char(32676));

insert into implicitIndex values('coucou', 'coucoucoucou', 'coucoucoucoucoucou');

insert into implicitIndex values ('hello', 'hellohello', 'hellohellohello');

select * from implicitIndex order by b,c;

select distinct b,c from implicitIndex;

drop table implicitIndex;

-- blob

create table implicitIndex(a blob(1024), b blob(32676));

select * from implicitIndex order by b;

select b from implicitIndex group by b;

select distinct b from implicitIndex;

select * from implicitIndex order by a;

select a from implicitIndex group by a;

select distinct a from implicitIndex;

create index indexB on implicitIndex(b);

create index indexA on implicitIndex(a);

drop table implicitIndex;

create table implicitIndex(a blob(1025), b blob(32677));

select * from implicitIndex order by b;

select b from implicitIndex group by b;

select distinct b from implicitIndex;

select * from implicitIndex order by a;

select a from implicitIndex group by a;

select distinct a from implicitIndex;

create index indexB  on implicitIndex(b);

create index indexA on implicitIndex(a);

drop table implicitIndex;

create table implicitIndex(a blob(1024), b blob(32676), c blob(32676));

select * from implicitIndex order by b,c;

select distinct b,c from implicitIndex;

drop table implicitIndex;

-- int

create table implicitIndex(a int);

insert into implicitIndex values(1);

insert into implicitIndex values (2);

select * from implicitIndex order by a;

select a from implicitIndex group by a;

select distinct a from implicitIndex;

create index indexA on implicitIndex(a);

drop table implicitIndex;