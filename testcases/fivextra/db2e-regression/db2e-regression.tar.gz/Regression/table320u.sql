update table3 set c1 = 'abadfdasfdasff' where c1 = 'a02';
update   table3 set c1 = 'adswfdafdsfdsfsfz' where c1 = 'a24';
update   table3 set c1 = 'adswfdafdsfdsfsfy' where c1 = 'a06';
update   table3 set c1 = 'adswfdafdsfdsfsfs' where c1 = 'a22';
update   table3 set c1 = 'adswfdafdsfdsfsfx' where c1 = 'a04';
update table3 set c1 = 'adswfdaf' where c1 = 'adswfdafdsfdsfsfs';
