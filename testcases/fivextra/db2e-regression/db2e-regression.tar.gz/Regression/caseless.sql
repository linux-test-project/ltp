drop table caseless1;
drop table caseless2;
drop table caseless3;
-- test table and index already created before inserting rows..
-- test all values can be upper cased and lower cased
-- test predicates to make sure index scan works as well as non-index predicate processing
-- test order by case function works with index being picked
-- test order by when no index exists 
-- test distinct
-- make sure update with case function works
-- make sure insert with select with case function works

create table caseless1 (c1 char(26), c2 varchar(26), c3 int not null primary key);
create index ucase1 on caseless1 (ucase(c1));
create index lcase1 on caseless1 (lcase(c1));
create index ucase2 on caseless1 (ucase(c2) desc);
create index lcase2 on caseless1 (lcase(c2));
list index caseless1;
insert into caseless1 values('abcDef', 'abcDef', 1);
insert into caseless1 values('abcdefghijklmnopqrstuvwxyz', 'abcdefghijklmnopqrstuvwxyz', 2);
insert into caseless1 values('aBC', 'aBC', 3);
insert into caseless1 values('AbcDef', 'AbcDef', 4);
insert into caseless1 values('ABcdef', 'ABcdef', 5);
insert into caseless1 values('abCDef', 'abCDef', 6);
insert into caseless1 values('abcDEF', 'abcDEF', 7);
insert into caseless1 values('AbcdeF', 'AbcdeF', 8);
insert into caseless1 values('D', 'D', 9);
insert into caseless1 values('a', 'a', 10);
insert into caseless1 values('A', 'A', 11);
insert into caseless1 values('ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',12);
-- index predicates
select c1, ucase(c1)
  from caseless1 where ucase(c1) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
select c2, ucase(c2)
  from caseless1 where ucase(c2) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
select c1, ucase(c1) 
  from caseless1 where ucase(c1) > 'ABC';
select c2, ucase(c2)
  from caseless1 where ucase(c1) > 'ABC';
select c1, lcase(c1)
  from caseless1 where lcase(c1) = 'abcdefghijklmnopqrstuvwxyz';
select c2, lcase(c2)
  from caseless1 where lcase(c2) = 'abcdefghijklmnopqrstuvwxyz';
select c1, lcase(c1) 
  from caseless1 where lcase(c1) < 'abcdef';
select c2, lcase(c2)
  from caseless1 where lcase(c1) < 'abcdef';
select x.c1, ucase(x.c1), y.c1, ucase(y.c1)
  from caseless1 x, caseless1 y where x.c1 = ucase(y.c1);
select x.c1, lcase(x.c1), y.c1, lcase(y.c1)
  from caseless1 x, caseless1 y where x.c1 = lcase(y.c1);
explain set queryno = 101 for 
  select c1, ucase(c1)
  from caseless1 where ucase(c1) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
explain set queryno = 102 for 
  select c2, ucase(c2)
  from caseless1 where ucase(c2) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
explain set queryno = 103 for 
  select c1, ucase(c1) 
  from caseless1 where ucase(c1) > 'ABC';
explain set queryno = 104 for 
  select c2, ucase(c2)
  from caseless1 where ucase(c1) > 'ABC';
explain set queryno = 105 for 
  select c1, lcase(c1)
  from caseless1 where lcase(c1) = 'abcdefghijklmnopqrstuvwxyz';
explain set queryno = 106 for 
  select c2, lcase(c2)
  from caseless1 where lcase(c2) = 'abcdefghijklmnopqrstuvwxyz';
explain set queryno = 107 for 
  select c1, lcase(c1) 
  from caseless1 where lcase(c1) < 'abcdef';
explain set queryno = 108 for 
  select c2, lcase(c2)
  from caseless1 where lcase(c1) < 'abcdef';
explain set queryno = 109 for 
  select x.c1, ucase(x.c1), y.c1, ucase(y.c1)
  from caseless1 x, caseless1 y where x.c1 = ucase(y.c1);
explain set queryno = 110 for 
  select x.c1, lcase(x.c1), y.c1, lcase(y.c1)
  from caseless1 x, caseless1 y where x.c1 = lcase(y.c1); 
-- non-index predicates
select c1, ucase(c1)
  from caseless1 where ucase(rtrim(c1)) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
select c2, ucase(c2)
  from caseless1 where ucase(rtrim(c2)) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
select c1, lcase(c1)
  from caseless1 where lcase(rtrim(c1)) = 'abcdefghijklmnopqrstuvwxyz';
select c2, lcase(c2)
  from caseless1 where lcase(rtrim(c2)) = 'abcdefghijklmnopqrstuvwxyz';
explain set queryno = 2001 for 
  select c1, ucase(c1)
  from caseless1 where ucase(rtrim(c1)) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
explain set queryno = 2002 for 
  select c2, ucase(c2)
  from caseless1 where ucase(rtrim(c2)) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
explain set queryno = 2003 for 
  select c1, lcase(c1)
  from caseless1 where lcase(rtrim(c1)) = 'abcdefghijklmnopqrstuvwxyz';
explain set queryno = 2004 for 
  select c2, lcase(c2)
  from caseless1 where lcase(rtrim(c2)) = 'abcdefghijklmnopqrstuvwxyz';
-- test order by index is picked
select ucase(c1), lcase(c1) from caseless1 order by 1;
select ucase(c1), lcase(c1) from caseless1 order by 1 desc;
select ucase(c1), lcase(c1) from caseless1 order by 2;
select ucase(c1), lcase(c1) from caseless1 order by 2 desc;
select ucase(c2), lcase(c2) from caseless1 order by 1;
select ucase(c2), lcase(c2) from caseless1 order by 1 desc;
select ucase(c2), lcase(c2) from caseless1 order by 2;
select ucase(c2), lcase(c2) from caseless1 order by 2 desc;
explain set queryno = 111 for 
  select ucase(c1), lcase(c1) from caseless1 order by 1;
explain set queryno = 112 for 
  select ucase(c1), lcase(c1) from caseless1 order by 1 desc;
explain set queryno = 113 for 
  select ucase(c1), lcase(c1) from caseless1 order by 2;
explain set queryno = 114 for 
  select ucase(c1), lcase(c1) from caseless1 order by 2 desc;
explain set queryno = 115 for 
  select ucase(c2), lcase(c2) from caseless1 order by 1;
explain set queryno = 116 for 
  select ucase(c2), lcase(c2) from caseless1 order by 1 desc;
explain set queryno = 117 for 
  select ucase(c2), lcase(c2) from caseless1 order by 2;
explain set queryno = 118 for 
  select ucase(c2), lcase(c2) from caseless1 order by 2 desc;
-- test order by where no index exists
create table caseless2 (c1 char(10), c2 varchar(10), c3 int);
insert into caseless2 values('abcdefghij', 'abcdefghij',1);
insert into caseless2 values('abc','abc',2);
insert into caseless2 values('aBc','aBc',3);
insert into caseless2 values('Abcd','Abcd',4);
insert into caseless2 values('ABcde','ABcde',5);
select ucase(c1), lcase(c1), c3 from caseless2 order by 1;
select ucase(c1), lcase(c1), c3 from caseless2 order by 1 desc;
select ucase(c1), lcase(c1), c3 from caseless2 order by 2;
select ucase(c1), lcase(c1), c3 from caseless2 order by 2 desc;
select ucase(c2), lcase(c2), c3 from caseless2 order by 1;
select ucase(c2), lcase(c2), c3 from caseless2 order by 1 desc;
select ucase(c2), lcase(c2), c3 from caseless2 order by 2;
select ucase(c2), lcase(c2), c3 from caseless2 order by 2 desc;
explain set queryno = 2005 for 
  select ucase(c1), lcase(c1), c3 from caseless2 order by 1;
explain set queryno = 2006 for 
  select ucase(c1), lcase(c1), c3 from caseless2 order by 1 desc;
explain set queryno = 2007 for 
  select ucase(c1), lcase(c1), c3 from caseless2 order by 2;
explain set queryno = 2008 for 
  select ucase(c1), lcase(c1), c3 from caseless2 order by 2 desc;
explain set queryno = 2009 for 
  select ucase(c2), lcase(c2), c3 from caseless2 order by 1;
explain set queryno = 2010 for  
  select ucase(c2), lcase(c2), c3 from caseless2 order by 1 desc;
explain set queryno = 2011 for 
  select ucase(c2), lcase(c2), c3 from caseless2 order by 2;
explain set queryno = 2012 for 
  select ucase(c2), lcase(c2), c3 from caseless2 order by 2 desc;
-- test distinct case function
select distinct ucase(c1) from caseless2;
select distinct lcase(c1) from caseless2;
select distinct ucase(c2) from caseless2;
select distinct lcase(c2) from caseless2;
explain set queryno = 2013 for 
  select distinct ucase(c1) from caseless2;
explain set queryno = 2014 for 
  select distinct lcase(c1) from caseless2;
explain set queryno = 2015 for 
  select distinct ucase(c2) from caseless2;
explain set queryno = 2016 for 
  select distinct lcase(c2) from caseless2;
-- test insert with select
create table caseless3 (c1 char(10), c2 varchar(10), c3 int);
insert into caseless3 select ucase(c1), lcase(c2), c3 from caseless2;
select * from caseless3;
update caseless3 set c1 = lcase(c1), c2 = ucase(c2) where c3 = 3;
select * from caseless3;
-- make sure index is selected for update and delete operations
delete from caseless1 where ucase(c1) = 'ABC';
select c1 from caseless1;
update caseless1 set c1 = 'hello' where lcase(c2) = 'abcdefghijklmnopqrstuvwxyz';
select c1, c2 from caseless1;


-- test scenario in which index is created halfway through the table population to make sure index is built properly 
drop table caseless1;
create table caseless1 (c1 char(26), c2 varchar(26), c3 int not null primary key);
insert into caseless1 values('abcDef', 'abcDef', 1);
insert into caseless1 values('abcdefghijklmnopqrstuvwxyz', 'abcdefghijklmnopqrstuvwxyz', 2);
insert into caseless1 values('aBC', 'aBC', 3);
insert into caseless1 values('AbcDef', 'AbcDef', 4);
insert into caseless1 values('ABcdef', 'ABcdef', 5);
insert into caseless1 values('abCDef', 'abCDef', 6);
insert into caseless1 values('abcDEF', 'abcDEF', 7);
insert into caseless1 values('AbcdeF', 'AbcdeF', 8);
insert into caseless1 values('D', 'D', 9);
insert into caseless1 values('a', 'a', 10);
insert into caseless1 values('A', 'A', 11);
insert into caseless1 values('ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'ABCDEFGHIJKLMNOPQRSTUVWXYZ',12);
create index ucase1 on caseless1 (ucase(c1) desc);
create index lcase1 on caseless1 (lcase(c1));
create index ucase2 on caseless1 (ucase(c2));
create index lcase2 on caseless1 (lcase(c2));
insert into caseless1 values('ABcdef', 'ABcdef', 13);
insert into caseless1 values('abCDEF', 'abCDEF', 14);
insert into caseless1 values('abcDEF', 'abcDEF', 15);
insert into caseless1 values('AbcdeFg', 'AbcdeFg', 16);
insert into caseless1 values('Z', 'Z', 17);
insert into caseless1 values('a', 'a', 18);
list index caseless1;

-- index predicates
select c1, ucase(c1)
  from caseless1 where ucase(c1) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
select c2, ucase(c2)
  from caseless1 where ucase(c2) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
select c1, ucase(c1) 
  from caseless1 where ucase(c1) > 'ABC';
select c2, ucase(c2)
  from caseless1 where ucase(c1) > 'ABC';
select c1, lcase(c1)
  from caseless1 where lcase(c1) = 'abcdefghijklmnopqrstuvwxyz';
select c2, lcase(c2)
  from caseless1 where lcase(c2) = 'abcdefghijklmnopqrstuvwxyz';
select c1, lcase(c1) 
  from caseless1 where lcase(c1) < 'abcdef';
select c2, lcase(c2)
  from caseless1 where lcase(c1) < 'abcdef';
select x.c1, ucase(x.c1), y.c1, ucase(y.c1)
  from caseless1 x, caseless1 y where x.c1 = ucase(y.c1);
select x.c1, lcase(x.c1), y.c1, lcase(y.c1)
  from caseless1 x, caseless1 y where x.c1 = lcase(y.c1);
explain set queryno = 1101 for 
  select c1, ucase(c1)
  from caseless1 where ucase(c1) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
explain set queryno = 1102 for 
  select c2, ucase(c2)
  from caseless1 where ucase(c2) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
explain set queryno = 1103 for 
  select c1, ucase(c1) 
  from caseless1 where ucase(c1) > 'ABC';
explain set queryno = 1104 for 
  select c2, ucase(c2)
  from caseless1 where ucase(c1) > 'ABC';
explain set queryno = 1105 for 
  select c1, lcase(c1)
  from caseless1 where lcase(c1) = 'abcdefghijklmnopqrstuvwxyz';
explain set queryno = 1106 for 
  select c2, lcase(c2)
  from caseless1 where lcase(c2) = 'abcdefghijklmnopqrstuvwxyz';
explain set queryno = 1107 for 
  select c1, lcase(c1) 
  from caseless1 where lcase(c1) < 'abcdef';
explain set queryno = 1108 for 
  select c2, lcase(c2)
  from caseless1 where lcase(c1) < 'abcdef';
explain set queryno = 1109 for 
  select x.c1, ucase(x.c1), y.c1, ucase(y.c1)
  from caseless1 x, caseless1 y where x.c1 = ucase(y.c1);
explain set queryno = 1110 for 
  select x.c1, lcase(x.c1), y.c1, lcase(y.c1)
  from caseless1 x, caseless1 y where x.c1 = lcase(y.c1); 
-- non-index predicates
select c1, ucase(c1)
  from caseless1 where ucase(rtrim(c1)) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
select c2, ucase(c2)
  from caseless1 where ucase(rtrim(c2)) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
select c1, lcase(c1)
  from caseless1 where lcase(rtrim(c1)) = 'abcdefghijklmnopqrstuvwxyz';
select c2, lcase(c2)
  from caseless1 where lcase(rtrim(c2)) = 'abcdefghijklmnopqrstuvwxyz';
explain set queryno = 22001 for 
  select c1, ucase(c1)
  from caseless1 where ucase(rtrim(c1)) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
explain set queryno = 22002 for 
  select c2, ucase(c2)
  from caseless1 where ucase(rtrim(c2)) = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
explain set queryno = 22003 for 
  select c1, lcase(c1)
  from caseless1 where lcase(rtrim(c1)) = 'abcdefghijklmnopqrstuvwxyz';
explain set queryno = 22004 for 
  select c2, lcase(c2)
  from caseless1 where lcase(rtrim(c2)) = 'abcdefghijklmnopqrstuvwxyz';
-- test order by index is picked
select ucase(c1), lcase(c1) from caseless1 order by 1;
select ucase(c1), lcase(c1) from caseless1 order by 1 desc;
select ucase(c1), lcase(c1) from caseless1 order by 2;
select ucase(c1), lcase(c1) from caseless1 order by 2 desc;
select ucase(c2), lcase(c2) from caseless1 order by 1;
select ucase(c2), lcase(c2) from caseless1 order by 1 desc;
select ucase(c2), lcase(c2) from caseless1 order by 2;
select ucase(c2), lcase(c2) from caseless1 order by 2 desc;
explain set queryno = 1111 for 
  select ucase(c1), lcase(c1) from caseless1 order by 1;
explain set queryno = 1112 for 
  select ucase(c1), lcase(c1) from caseless1 order by 1 desc;
explain set queryno = 1113 for 
  select ucase(c1), lcase(c1) from caseless1 order by 2;
explain set queryno = 1114 for 
  select ucase(c1), lcase(c1) from caseless1 order by 2 desc;
explain set queryno = 1115 for 
  select ucase(c2), lcase(c2) from caseless1 order by 1;
explain set queryno = 1116 for 
  select ucase(c2), lcase(c2) from caseless1 order by 1 desc;
explain set queryno = 1117 for 
  select ucase(c2), lcase(c2) from caseless1 order by 2;
explain set queryno = 1118 for 
  select ucase(c2), lcase(c2) from caseless1 order by 2 desc;
-- make sure index is selected for update and delete operations
delete from caseless1 where ucase(c1) = 'ABC';
select c1 from caseless1;
update caseless1 set c1 = 'there' where lcase(c2) = 'd';
select c1, c2 from caseless1;

select query_no, plan_no, table_name, index_name, sort_temp from "DB2ePLANTABLE" order by 1,2;
drop table "DB2ePLANTABLE";
drop table caseless1;
drop table caseless2;
drop table caseless3;
