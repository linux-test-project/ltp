-- ----------------- FILE: INSER01.SQL -------------------
-- -                                                      - 
-- -          Validates INSERT statement	          -
-- -                                                      -
-- --------------------------------------------------------
--

-- --------------------------------------------------------
-- This set of test cases validates more complex inserts.
-- It tries also to validate some overflow or underflow cases
-- --------------------------------------------------------
-- --------------------------------------------------------
-- Delete tables
-- --------------------------------------------------------
DROP TABLE tA;

-- --------------------------------------------------------
-- INITIALIZE THE TABLES
-- --------------------------------------------------------
CREATE TABLE tA (c1 SMALLINT, c2 INT, c3 DECIMAL(15,0), c4 DECIMAL(3,2), c5 DECIMAL(15,14), c6 VARCHAR(1), C7 VARCHAR(7), C8 VARCHAR(1000), C9  CHAR(1), C10 CHAR(4), C11 CHAR(254), C12 DATE, C13 TIME); 


-- ********************************************************* 
-- 2BASIC0001-2BASIC0102
-- ********************************************************* 
-- TEST:2BASIC0001-2BASIC0102 INSERT INTO one column                     
-- PASS:2BASIC0001-2BASIC0102 EXPECTED FAILURE OCCURES                       


-- -----------------------------------------------

INSERT INTO tA (c1, c5, c3, c4, c2) VALUES (234, +214748364, +999999999999999., +9.99, +9.99999999999999);
INSERT INTO tA (c1, c4, c3, c2, c5) VALUES (-32767, -32767, -123456789012345., -1.34, -1.345687687687);
INSERT INTO tA (c1, c3, c2, c4, c5) VALUES (+32767, +32767, +123456789012345., +1.40, +1.43456345634560); 
INSERT INTO tA (c1, c2, c5, c4, c3) VALUES (-00000, -00000, -000000.000000, -000000.000000, -000000.000000000000000000); 
INSERT INTO tA (c1, c2, c4, c3, c5) VALUES (0000, 0000, 000000.00, 000000.00, 000000.000000000000000000);
INSERT INTO tA (c1, c2, c3, c5, c4) VALUES (-67, -2147483647, -999999999999999., -9.99, -9.99999999999999); 
	SELECT c1 FROM tA ORDER BY;
	SELECT c2 FROM tA ORDER BY;
	SELECT c3 FROM tA ORDER BY;
	SELECT c4 FROM tA ORDER BY;
	SELECT c5 FROM tA ORDER BY;

-- -----------------------------------------------
INSERT INTO tA (c2, c1, c3, c4, c5) VALUES (234, +214748364, +999999999999999., +9.99, +9.99999999999999);
INSERT INTO tA (c3, c2, c1, c4, c5) VALUES (-32767, -32767, -123456789012345., -1.34, -1.345687687687);
INSERT INTO tA (c4, c2, c3, c1, c5) VALUES (+32767, +32767, +123456789012345., +1.40, +1.43456345634560); 
INSERT INTO tA (c5, c2, c3, c4, c1) VALUES (-00000, -00000, -000000.000000, -000000.000000, -000000.000000000000000000); 
INSERT INTO tA (c5, c4, c3, c2, c1) VALUES (0000, 0000, 000000.00, 000000.00, 000000.000000000000000000);
INSERT INTO tA (c2, c4, c5, c1, c3) VALUES (-67, -2147483647, -999999999999999., -9.99, -9.99999999999999); 
	SELECT c1 FROM tA ORDER BY;
	SELECT c2 FROM tA ORDER BY;
	SELECT c3 FROM tA ORDER BY;
	SELECT c4 FROM tA ORDER BY;
	SELECT c5 FROM tA ORDER BY;

-- -----------------------------------------------

INSERT INTO tA (c6, c7, c8, c9, c9) VALUES (234, +214748364, +999999999999999., +9.99, +9.99999999999999);
INSERT INTO tA (c9, c8, c7, c9, c7) VALUES (-32767, -32767, -123456789012345., -1.34, -1.345687687687);
INSERT INTO tA (c7, c2, c8, c9, c8) VALUES (+32767, +32767, +123456789012345., +1.40, +1.43456345634560); 
INSERT INTO tA (c6, c9, c7, c7, c8) VALUES (-00000, -00000, -000000.000000, -000000.000000, -000000.000000000000000000); 
INSERT INTO tA (c9, c8, c7, c6, c9) VALUES (0000, 0000, 000000.00, 000000.00, 000000.000000000000000000);
INSERT INTO tA (c6, c7, c6, c8, c6) VALUES (-67, -2147483647, -999999999999999., -9.99, -9.99999999999999); 
	SELECT c6 FROM tA ORDER BY;
	SELECT c7 FROM tA ORDER BY;
	SELECT c8 FROM tA ORDER BY;
	SELECT c10 FROM tA ORDER BY;
	SELECT c11 FROM tA ORDER BY;

-- -----------------------------------------------

INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('Y', 'abcdsfghsdfgsdfgsdfgsdfgdsfga', 'abcd', '','');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('', '', 'abcdefg     h', 'abcdsfghsdfgsdfgsdfgsdfgdsfga', ' ');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES (' ', ' ', '             9', 'abcdefg     h', 'abcdefg     h');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('      ', '      ', '', '             9', 'abcdefg');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('abcdefg     h', 'abcdefg     h', '     ', '      ', '             9');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('             9', '             9', '     ', ' ', '');
	SELECT c6 FROM tA ORDER BY;
	SELECT c7 FROM tA ORDER BY;
	SELECT c8 FROM tA ORDER BY;
	SELECT c10 FROM tA ORDER BY;
	SELECT c11 FROM tA ORDER BY;

-- -------------------------------------------------
DELETE FROM tA;

INSERT INTO tA (c6, c11) VALUES ('00:00 AM', '02.29.1999');
INSERT INTO tA (c7, c10) VALUES ('00:00 PM', '31.08.1939');
INSERT INTO tA (c8, c9) VALUES ('12:00 AM', '02/31/3001');
INSERT INTO tA (c9, c7) VALUES ('12:00 PM', '02.29.2000');
INSERT INTO tA (c10, c6) VALUES ('06:59 PM', '02/29/2000');
INSERT INTO tA (c11, c6) VALUES ('00:01 AM', '01/01/0100');
INSERT INTO tA (c11, c7) VALUES ('24:00:00', '4000.08.31');
INSERT INTO tA (c10, c8) VALUES ('00:00:00', '02.31.3000');
INSERT INTO tA (c9, c9) VALUES ('10:34:45', '31/08/1938');
INSERT INTO tA (c8, c8) VALUES ('23:59:59', '1984.02.29');
INSERT INTO tA (c7, c10) VALUES ('00:00:01', '1999.11.31');
INSERT INTO tA (c6, c11) VALUES ('12:00:00', '01.01.0100');
INSERT INTO tA (c11, c7) VALUES ('24.00.00', '02.29.1999');
INSERT INTO tA (c6, c9) VALUES ('23.59.59', '02/29/1999');
INSERT INTO tA (c8, c6) VALUES ('15.59.23', '0100-01-01');
INSERT INTO tA (c9, c8) VALUES ('00.00.01', '2000.01.01');
INSERT INTO tA (c7, c11) VALUES ('12.45.32', '12/31/1255');
INSERT INTO tA (c11, c10) VALUES ('06.06.06', '12.31.1245'); 
	SELECT c6 FROM tA ORDER BY;
	SELECT c7 FROM tA ORDER BY;
	SELECT c8 FROM tA ORDER BY;
	SELECT c10 FROM tA ORDER BY;
	SELECT c11 FROM tA ORDER BY;

DELETE FROM tA;


--------------------------------------------------------------------------------
-- TEST CASES FOR TIMESTAMP
--------------------------------------------------------------------------------

-- Special Register: CURRENT TIMESTAMP
-- Create with timestamp
-- Create with Index on timestamp.
-- Insert
--	* default values.
--	* check constraint.
--	* Foreign Key/Primary Key/Not null column.
--	* Duplicate values in primary key.
--	* CURRENT TIMESTAMP register

-- Update
--	* CHECK constraint
--	* Block update on primary key

-- Select
--	* WHERE predicates (<, >, =, <>, >=, =< )
--	* Join using Timestamp columns with/without indices.
--	* Select distinct on timestamp column.
--	* Order by timestamp column.
--	* Group by timestamp column.
--	* Aggregate functions: max, count, min.

--------------------------------------------------------------------------------

-- testing different formats of timestamp
CREATE TABLE y(b TIMESTAMP);
insert into y values ('2001-01-01-01.01.01.111111');
insert into y values ('2001-1-01-01.01.01.111111');
insert into y values ('2001-1-1-01.01.01.111111');
insert into y values ('2001-01-1-01.01.01.111111');
insert into y values ('2001-1-1-01.01.01');
insert into y values ('1900-1-2-01.01.01');
insert into y values ('2400-1-2-01.01.01');
insert into y values (null);

select * from y;
select count(*) from y;

-- syntax error
-- SQLSTATE=22007
insert into y values ('2001-1-1');
insert into y values ('2001-01-01');
insert into y values ('2001-1-1-01.01');
insert into y values ('2001-01-01-01.01.01.111111111');
insert into y values ('2001-1-32-01.01.01');
insert into y values ('2001-13-2-01.01.01');
insert into y values ('001-1-2-01.01.01');
insert into y values ('1-1-2-01.01.01');

select count(*) from y;

-- distinct on timestamp column
select distinct * from y;

-- distinct and orderby on timestamp column using index
create index idxy on y(b);
select distinct * from y;
select distinct * from y order by b;
select distinct * from y order by b desc;
select * from y order by b asc;
select * from y order by b desc;

-- testing insert w/ subselect
create table yy (b timestamp);
insert into yy select * from y;
select * from yy;
delete from yy;

-- join on timestamp column
insert into yy select distinct b from y;
select * from y, yy where y.b=yy.b;

create index idxyy on yy(b);
select * from y, yy where y.b=yy.b;

select * from yy, y where y.b=yy.b;

-- where involving different timestamp format
select * from y where b = '2001-01-01-01.01.01.111111';
select * from y where b = '2001-1-1-01.01.01';

select * from y where b is null;
select * from y where b is not null;

-- expects error
select * from y where b = '2001-1-1';
select * from y where b = '2001-01-01';

drop table y;
drop table yy;

--------------------------------------------------------------------
-- testing default values in timestamp columns

CREATE TABLE y(a int, b TIMESTAMP default '2001-01-01-01.01.01.000000');

insert into y (a) values (1);
insert into y (a) values (null);

insert into y (b) values (null);

select * from y;

insert into y (a, b) values(1, '2001-01-10-01.01.01.111111');
insert into y (b) values('2001-01-10-01.01.01.111111');

select * from y;

drop table y;

--------------------------------------------------------------------
-- testing check constraints in timestamp columns

CREATE TABLE y(a int, b TIMESTAMP check(b > '2001-01-01-01.01.01.000000'));

insert into y (a) values (1);
insert into y (a) values (null);

insert into y (b) values (null);

select * from y;

-- insert should be okay
insert into y (a, b) values(2, '2001-01-10-01.01.01.111111');
insert into y (b)    values(   '2001-01-10-01.01.01.111111');

select * from y;

-- insert should fail
insert into y (a, b) values(3, '2000-12-31-23.23.23.111111');
insert into y (b)    values(   '2000-12-31-23.23.23.111111');
insert into y (b)    values(   '2001-01-01-01.01.01.000000');

select * from y;

-- update should be okay
update y set b = '2001-01-01-01.01.01.000001' where a is null;

select * from y;

update y set b = '2111-11-11-11.11.11.111111' where b = '2001-01-01-01.01.01.000001';

select * from y;

-- update should fail
update y set b = '2001-01-01-01.01.01.000000' where b = '2111-11-11-11.11.11.111111';

select * from y;

drop table y;


--------------------------------------------------------------------
-- testing a timestamp column as the primary key column

CREATE TABLE y(a int, b TIMESTAMP not null primary key);

-- insert should be okay
insert into y (a, b) values(2, '2001-01-10-01.01.01.111110');
insert into y (b)    values(   '2001-01-10-01.01.01.111111');

select * from y;

-- duplicates: should fail 
insert into y (b)    values(   '2001-01-10-01.01.01.111111');

select * from y;

drop table y;

--------------------------------------------------------------------
-- testing a timestamp column as one of the primary key columns

CREATE TABLE y(a int not null, b TIMESTAMP not null, primary key(a, b));

-- insert should be okay
insert into y (a, b) values(2, '2001-01-10-01.01.01.111110');
insert into y (a, b) values(1, '2001-01-10-01.01.01.111110');
insert into y (a, b) values(1, '2001-01-10-01.01.01.111111');
insert into y (a, b) values(2, '2001-01-10-01.01.01.111111');

select * from y;

-- duplicates: should fail 
insert into y (a, b) values(2, '2001-01-10-01.01.01.111111');

select * from y;

drop table y;

--------------------------------------------------------------------

CREATE TABLE x(a INT, b TIMESTAMP DEFAULT CURRENT TIMESTAMP);

INSERT INTO x VALUES(1, '2001-01-01-01.01.01.111111');
INSERT INTO x VALUES(2, '2001-01-01-01.01.01.111112');
INSERT INTO x VALUES(3, '2001-01-01-01.01.02.111111');
INSERT INTO x VALUES(4, '2001-01-01-01.02.01.111111');
INSERT INTO x VALUES(5, '2001-01-01-02.01.01.111111');
INSERT INTO x VALUES(6, '2001-01-01-02.01.01.111111');
INSERT INTO x VALUES(7, '2001-01-02-01.01.01.111111');
INSERT INTO x VALUES(8, '2001-02-01-01.01.01.111111');
INSERT INTO x VALUES(9, '2002-01-01-01.01.01.111111');
INSERT INTO x VALUES(0, '2001-01-01-13.35.30.955001');
INSERT INTO x VALUES(0, '2001-01-02-13.35.30.955001');
INSERT INTO x VALUES(0, '2001-01-03-13.35.30.955001');
INSERT INTO x VALUES(0, '2001-01-04-13.35.30.955001');
INSERT INTO x VALUES(1, '2001-02-22-13.35.30.955001');
INSERT INTO x VALUES(1, '2001-02-22-13.35.30.965000');
INSERT INTO x VALUES(1, '2001-02-22-13.35.30.975000');
INSERT INTO x VALUES(1, '2001-02-22-13.35.30.975001');
INSERT INTO x VALUES(1, '2001-02-22-13.35.30.985000');
INSERT INTO x VALUES(1, '2001-02-22-13.35.30.000000');
INSERT INTO x VALUES(1, '2001-02-22-13.35.30.000000');
INSERT INTO x VALUES(1, '2001-02-22-13.35.30.000000');
INSERT INTO x VALUES(1, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(2, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(2, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(2, '2001-02-22-13.35.31.035000');
INSERT INTO x VALUES(2, '2001-02-22-13.35.31.045000');
INSERT INTO x VALUES(2, '2001-02-22-13.35.31.045001');
INSERT INTO x VALUES(2, '2001-02-22-13.35.31.055000');
INSERT INTO x VALUES(2, '2001-02-22-13.35.31.055001');
INSERT INTO x VALUES(2, '2001-02-22-13.35.31.065000');
INSERT INTO x VALUES(2, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(3, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(3, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(3, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(3, '2001-02-22-13.35.31.105000');
INSERT INTO x VALUES(3, '2001-02-22-13.35.31.115000');
INSERT INTO x VALUES(3, '2001-02-22-13.35.31.115001');
INSERT INTO x VALUES(3, '2001-02-22-13.35.31.125000');
INSERT INTO x VALUES(3, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(3, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(4, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(4, '2001-02-22-13.35.31.145000');
INSERT INTO x VALUES(4, '2001-02-22-13.35.31.145001');
INSERT INTO x VALUES(4, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(4, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(4, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(4, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(4, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(4, '2001-02-22-13.35.31.195000');
INSERT INTO x VALUES(5, '2001-02-22-13.35.31.205000');
INSERT INTO x VALUES(5, '2001-02-22-13.35.31.205001');
INSERT INTO x VALUES(5, '2001-02-22-13.35.31.225000');
INSERT INTO x VALUES(5, '2001-02-22-13.35.31.225001');
INSERT INTO x VALUES(5, '2001-02-22-13.35.31.235000');
INSERT INTO x VALUES(5, '2001-02-22-13.35.31.245000');
INSERT INTO x VALUES(5, '2001-02-22-13.35.31.245001');
INSERT INTO x VALUES(5, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(5, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(6, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(6, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(6, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(6, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(6, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(6, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(6, '2001-02-22-13.35.31.000000');
INSERT INTO x VALUES(6, '2001-02-22-13.35.31.315000');
INSERT INTO x VALUES(6, '2001-02-22-13.35.31.315001');
INSERT INTO x VALUES(7, null);
INSERT INTO x VALUES(7, null);
INSERT INTO x VALUES(7, null);

--

SELECT * FROM x;
SELECT count(*) from x;
SELECT max(b) from x;
SELECT min(b) from x;
SELECT count(b) from x;

--

SELECT * FROM x WHERE b <  '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b <= '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b =  '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b >= '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b <> '2001-1-2-1.01.01.111111';

--

SELECT * FROM x WHERE b < '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b > '2001-1-2-1.01.01.111111';

--

SELECT * FROM x ORDER BY b;
SELECT * FROM x ORDER BY b desc;

SELECT b, count(*) FROM x GROUP BY b;

SELECT count(*) from x group by a;
SELECT max(a) from x group by a;
SELECT count(b) from x group by a;
SELECT max(b) from x group by a;
SELECT min(b) from x group by a;

-- distinct on timestamp column
select distinct b from x;
select distinct a, b from x;

------------------------------------------------------------
-- use index on timestamp
CREATE INDEX IDX1 ON x(b ASC);
CREATE INDEX IDX2 ON x(b DESC);

--

SELECT * FROM x;
SELECT count(*) from x;
SELECT max(b) from x;
SELECT min(b) from x;
SELECT count(b) from x;

--

SELECT * FROM x WHERE b <  '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b <= '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b =  '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b >= '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b <> '2001-1-2-1.01.01.111111';

--

SELECT * FROM x WHERE b < '2001-1-2-1.01.01.111111';
SELECT * FROM x WHERE b > '2001-1-2-1.01.01.111111';

--

SELECT * FROM x ORDER BY b;
SELECT * FROM x ORDER BY b desc;

SELECT b, count(*) FROM x GROUP BY b;

SELECT count(*) from x group by a;
SELECT max(a) from x group by a;
SELECT count(b) from x group by a;
SELECT max(b) from x group by a;
SELECT min(b) from x group by a;

-- distinct on timestamp column
select distinct b from x;
select distinct a, b from x;

drop table x;

------------------------------------------------------------
-- testing optional timestamp part

create table zpp(a int, b timestamp);
insert into zpp values(1, '2001-01-01-01.01.01');
insert into zpp values(2, '2001-01-01-01.01.01.');
insert into zpp values(3, '2001-01-01-01.01.01.1');
insert into zpp values(4, '2001-01-01-01.01.01.11');
insert into zpp values(5, '2001-01-01-01.01.01.111');
insert into zpp values(6, '2001-01-01-01.01.01.1111');
insert into zpp values(7, '2001-01-01-01.01.01.11111');
insert into zpp values(8, '2001-01-01-01.01.01.111111');
--
insert into zpp values(9, '2001-1-1-01.01.01');
insert into zpp values(10, '2001-1-1-01.01.01.');
insert into zpp values(11, '2001-1-1-01.01.01.0');
insert into zpp values(12, '2001-1-1-01.01.01.01');
insert into zpp values(9, '2001-1-1-01.01.01.001');
insert into zpp values(9, '2001-1-1-01.01.01.0001');
insert into zpp values(9, '2001-1-1-01.01.01.00001');
insert into zpp values(9, '2001-1-1-01.01.01.000001');
--
select * from zpp;
--
select count(*) from zpp;
drop table zpp;

------------------------------------------------------------
-- testing blanks in microsecond part

create table datetime (c1 date,c2 time,c3 timestamp);
insert into datetime values('2001-06-04','11.39.11','2001-06-04-11.39.11.1');
select * from datetime where c3 in ('2001-06-04-11.39.11.100000');
insert into datetime(c3) values('2001-1-1-02.02.02.1234567');
insert into datetime(c3) values('2001-01-01-02.02.03.123345        abcd');
insert into datetime(c3) values('2001-01-01-02.02.05.12 4');
drop table datetime;

------------------------------------------------------------

drop table xtime;
create table xtime(c1 timestamp);
insert into xtime values('111-1-1-1.21.21');
select * from xtime where c1 = '111-1-1-1.21.21';
select * from xtime where c1 in ('111-01-1-01.21.21');
insert into xtime values('2001-06-15-01.01.01.12');
select * from xtime where c1 = '2001-06-15-01.01.01.1200';
insert into xtime values('2111-01-01-12.12.12');
select * from xtime where c1 > '2111-01-01-12.12.11';

insert into xtime values('2001-01-01-02.12.12.1234567');
insert into xtime values('2122-1-4-3.12.12.1234567');
insert into xtime values('2001-1-2-3.12.34.123 345');
insert into xtime values('2201-12-12-12.12.12.123a34');		
drop table xtime;


--
-- Extra test case for timestamp 1
--
CREATE TABLE T (A TIMESTAMP);
CREATE INDEX I ON T (A);

INSERT INTO T VALUES ('2001-02-03-04.05.06.111111');
SELECT * FROM T;

UPDATE T SET A = '2001-02-03-04.05.06.111112';
SELECT * FROM T;

DROP TABLE T;


--
-- Extra test case for timestamp 2
--
CREATE TABLE T (A TIMESTAMP);
CREATE INDEX I ON T (A);

INSERT INTO T VALUES ('2001-02-03-04.05.06.111111');
INSERT INTO T VALUES ('2001-02-03-04.05.06.111112');
INSERT INTO T VALUES ('2001-02-03-04.05.06.111113');
SELECT * FROM T;

UPDATE T SET A = '1999-12-20-17.18.19.654321' WHERE A = '2001-02-03-04.05.06.111111';
SELECT * FROM T;

DELETE FROM T WHERE A = '2001-02-03-04.05.06.111112'; 
SELECT * FROM T;

UPDATE T SET A = '2046-01-02-10.11.22.123456';
SELECT * FROM T;

DROP TABLE T;


--
-- Extra test case for timestamp 3
--
CREATE TABLE T (A TIMESTAMP, B INT);
CREATE INDEX I ON T(B);

INSERT INTO T VALUES ('2001-12-31-23.24.25.123456', 0);
INSERT INTO T VALUES (null, 1);
SELECT * FROM T;

UPDATE T SET B = 2 WHERE B = 0;
SELECT * FROM T;

UPDATE T SET B = 3 WHERE A IS null;
SELECT * FROM T;

UPDATE T SET A = null WHERE A IS not null;
SELECT * FROM T;

DELETE FROM T WHERE A IS null;
SELECT * FROM T;

DROP TABLE T;


--
-- Extra test case for timestamp 4
--
CREATE TABLE T (A TIMESTAMP, B INT);
CREATE INDEX I ON T(A);

INSERT INTO T VALUES ('2001-12-31-23.24.25.123456', 0);
INSERT INTO T VALUES (null, 1);
SELECT * FROM T;

UPDATE T SET B = 2 WHERE B = 0;
SELECT * FROM T;

UPDATE T SET B = 3 WHERE A IS null;
SELECT * FROM T;

UPDATE T SET A = null WHERE A IS not null;
SELECT * FROM T;

DELETE FROM T WHERE A IS null;
SELECT * FROM T;

DROP TABLE T;



--
-- Extra test case for timestamp 5
--
CREATE TABLE T (A TIMESTAMP, B INT);
CREATE INDEX I ON T(A,B);
CREATE INDEX J ON T(B,A);

INSERT INTO T VALUES ('2001-12-31-23.24.25.123456', 0);
INSERT INTO T VALUES (null, 1);
SELECT * FROM T;

UPDATE T SET B = 2 WHERE B = 0;
SELECT * FROM T;

UPDATE T SET B = 3 WHERE A IS null;
SELECT * FROM T;

UPDATE T SET A = null WHERE A IS not null;
SELECT * FROM T;

DELETE FROM T WHERE A IS null;
SELECT * FROM T;

DROP TABLE T;



--
-- Extra test case for timestamp 6
--
CREATE TABLE T (A TIMESTAMP, B TIMESTAMP, C TIMESTAMP, D INT);

CREATE INDEX I ON T (B,A);
CREATE INDEX J ON T (A,B);
CREATE INDEX K ON T (C,A);

INSERT INTO T VALUES ('1985-04-05-12.30.45.456789', '1985-04-05-12.30.45.456789', '1985-04-05-12.30.45.456789', 0);
INSERT INTO T VALUES ('2010-11-12-10.09.08.654321', '2010-11-12-10.09.08.654321', '2010-11-12-10.09.08.654321', 1);

SELECT * FROM T;
SELECT * FROM T ORDER BY A;

UPDATE T SET A = '2001-02-03-04.05.06.123456', B = '2001-02-03-04.05.06.123456', C = '2001-02-03-04.05.06.123456' WHERE D = 0;
SELECT * FROM T;
SELECT * FROM T ORDER BY A;

DELETE FROM T WHERE A = '2001-02-03-04.05.06.123456';
SELECT * FROM T;
SELECT * FROM T ORDER BY A;

DELETE FROM T WHERE D = 1;
SELECT * FROM T;
SELECT * FROM T ORDER BY A;

DROP TABLE T;

DROP TABLE tA;

--
-- Insert-Select
--
create table t (a int, b smallint, c char(10), d varchar(10), e decimal(5,2), f date, g time);
insert into t values ( 32767,  32767, 'a', 'b',  999.99, '01/01/2001', '01:01:01');
insert into t values ( 32767,  32767, 'c', 'd',  999.99, '01/01/2001', '01:01:01');
insert into t values (-32768, -32768, 'a', 'b', -999.99, '01/01/2001', '01:01:01');
insert into t values (-32768, -32768, 'c', 'd', -999.99, '01/01/2001', '01:01:01');
insert into t values ( null,   null,  null, null, null, null, null);
insert into t values ( 0,      0,     'a', 'd',    0.0,  '01/01/2001', '01:01:02');
insert into t values ( 1,      0,     'e', 'f',    1.0,  '01/02/2001', '01:01:02');

select * from t order by a;

create table r (a int, b smallint);
insert into r values ( null, null);
insert into r values ( 32767,  32767);
insert into r values ( 32767,  32767);
insert into r values (-32768, -32768);
insert into r values (-32768, -32768);
insert into r values ( 0,      0);
insert into r values ( 1,      0);

select * from r order by a;

create table s (a int, b smallint, c char(10), d varchar(10), e decimal(5,2), f date, g time);

-----------------------------------------------------------------

-- a simple test using "*"
insert into s select * from t;
select * from s;
delete from s;

-- a select list is specified but no column list in the insert
insert into s select a, b, c, d, e, f, g from t;
select * from s;
delete from s;

-- a select list is specified but no column list in the insert
insert into s select t.a, t.b, t.c, t.d, t.e, t.f, t.g from t;
select * from s;
delete from s;

-- a complete column list is specified
insert into s (a, b, c, d, e, f, g) select a, b, c, d, e, f, g from t;
select * from s;
delete from s;

-- a partial column list is specified
-- should see nulls on the g column
insert into s (a, b, c, d, e, f) select a, b, c, d, e, f from t;
select * from s;
delete from s;

-- column list is specified
-- A bug was found by this query: wrong data on column s(a)
-- The problem is the we need to promote a smallint (B) to integer (A).
insert into s (a, b, c, d, e, f, g) select b, a, d, c, e, f, g from t;
select * from s;
delete from s;

-- inserting no rows; should return SQLSTATE=02000
insert into s select * from t where 1=0;
select * from s;
delete from s;

-- subselect has a predicate; a single table access: expects 3 rows
insert into s select * from t where a>0;
select * from s;
delete from s;

-- subselect has a select list involving arithmetics
insert into s select a+1, b-1, c, d, e-1.99, f, g from t where a>0;
select * from s;
delete from s;

insert into s select a, b, c, d, e+1.0, f, g from t where e<999.99;
select * from s;
delete from s;

-- subselect has a predicate; a single table access; use index
create index idxa on t(a);
insert into s select a+1, b, c, d, e-1.0, f, g from t where a>0;
select * from s;
delete from s;
drop index idxa;

-- the target has an index
create index idxb on s(a);
insert into s select a+1, b, c, d, e-1.0, f, g from t where a>0;
select * from s;
delete from s;
drop index idxb;

----------------------------------------

-- subselect has a join
insert into s select t.a, t.b, t.c, t.d, t.e, t.f, t.g from t, r where t.a=r.a;
select * from s;
delete from s;

insert into s select t.a, t.b, t.c, t.d, t.e, t.f, t.g from t, r;
select * from s;
delete from s;

-- a bug was found in insertselectsemantics(); tmp is fine, but tmp2 fails
create table tmp (a int, b smallint, c char(10), d varchar(10), e decimal(5,2), f date);
insert into tmp select t.a, t.b, t.c, t.d, t.e, t.f from t, r where t.a=r.a;
select * from tmp;
drop table tmp;

-- This query found a bug -- too many columns.
-- Apparently we call initColReferenced() but we never use this array.
create table tmp2 (a int, b smallint, c char(10), d varchar(10), e decimal(5,2), f date, g time);
insert into tmp2 select t.a, t.b, t.c, t.d, t.e, t.f, t.g from t, r where t.a=r.a;
select * from tmp2;
drop table tmp2;

create table tmp (g time);
insert into tmp select t.g from t, r where t.a=r.a;
select * from tmp;
drop table tmp;

--------------------------------------------------------

-- groupby w/ groupby items in the subselect
select 1, max(t.b), max(t.c), max(t.d), max(t.e), max(t.f), max(t.g) from t group by t.a;
insert into s select 1, max(t.b), max(t.c), max(t.d), max(t.e), max(t.f), max(t.g) from t
              group by t.a;
select * from s;
delete from s;

select min(t.a), min(t.b), min(t.c), min(t.d), min(t.e), min(t.f), min(t.g) from t group by a;
insert into s select min(t.a), min(t.b), min(t.c), min(t.d), min(t.e), min(t.f), min(t.g) from t
              group by a;
select * from s;
delete from s;

-- grouping on t.c
select max(t.a), max(t.b), max(t.c), max(t.d), max(t.e), max(t.f), max(t.g) from t group by t.c;
insert into s select max(t.a), max(t.b), max(t.c), max(t.d), max(t.e), max(t.f), max(t.g) from t
              group by t.c;
select * from s;
delete from s;

-- grouping on t.g
select max(t.a), max(t.b), max(t.c), max(t.d), max(t.e), max(t.f), max(t.g) from t group by t.g;
insert into s select max(t.a), max(t.b), max(t.c), max(t.d), max(t.e), max(t.f), max(t.g) from t
              group by t.g;
select * from s;
delete from s;

-- COUNT
create table tmp (c char(10), cnt int);

select t.c, count(t.b) from t group by t.c;
insert into tmp select t.c, count(t.b) from t group by t.c;
select * from tmp;
delete from tmp;

select t.c, count(t.c) from t group by t.c;
insert into tmp select t.c, count(t.c) from t group by t.c;
select * from tmp;
delete from tmp;

select t.c, count(t.d) from t group by t.c;
insert into tmp select t.c, count(t.d) from t group by t.c;
select * from tmp;
delete from tmp;

select t.c, count(t.e) from t group by t.c;
insert into tmp select t.c, count(t.e) from t group by t.c;
select * from tmp;
delete from tmp;

select t.c, count(t.f) from t group by t.c;
insert into tmp select t.c, count(t.f) from t group by t.c;
select * from tmp;
delete from tmp;

select t.c, count(t.g) from t group by t.c;
insert into tmp select t.c, count(t.g) from t group by t.c;
select * from tmp;
delete from tmp;

select t.c, count(t.h) from t group by t.c;
insert into tmp select t.c, count(t.h) from t group by t.c;
select * from tmp;
delete from tmp;

select t.c, count(*) from t group by t.c;
insert into tmp select t.c, count(*) from t group by t.c;
select * from tmp;
delete from tmp;

drop table tmp;

--------------------------------------------------------

-- groupby w/o groupby items in the subselect; bug in char/varchar columns???
-- MAX
select max(t.a), max(t.b), max(t.c), max(t.d), max(t.e), max(t.f), max(t.g) from t;
insert into s select max(t.a), max(t.b), max(t.c), max(t.d), max(t.e), max(t.f), max(t.g) from t;
select * from s;
delete from s;

-- MIN
select min(t.a), min(t.b), min(t.c), min(t.d), min(t.e), min(t.f), min(t.g) from t;
insert into s select min(t.a), min(t.b), min(t.c), min(t.d), min(t.e), min(t.f), min(t.g) from t;
select * from s;
delete from s;

-- SUM/MAX
select sum(t.a), sum(t.b), max(t.c), max(t.d), sum(t.e), max(t.f), max(t.g) from t;
insert into s select sum(t.a), sum(t.b), max(t.c), max(t.d), sum(t.e), max(t.f), max(t.g) from t;
select * from s;
delete from s;

-- AVG/MAX
select avg(t.a), avg(t.b), max(t.c), max(t.d), avg(t.e), max(t.f), max(t.g) from t;
insert into s select avg(t.a), avg(t.b), max(t.c), max(t.d), avg(t.e), max(t.f), max(t.g) from t;
select * from s;
delete from s;

-- COUNT
create table tmp (a int);
insert into tmp select count(t.a) from t;
select * from tmp;
delete from tmp;

insert into tmp select count(t.b) from t;
select * from tmp;
delete from tmp;

insert into tmp select count(t.c) from t;
select * from tmp;
delete from tmp;

insert into tmp select count(t.d) from t;
select * from tmp;
delete from tmp;

insert into tmp select count(t.e) from t;
select * from tmp;
delete from tmp;

insert into tmp select count(t.f) from t;
select * from tmp;
delete from tmp;

insert into tmp select count(t.g) from t;
select * from tmp;
delete from tmp;

insert into tmp select count(*) from t;
select * from tmp;
delete from tmp;

drop table tmp;

----------------------------------------------------------------------

-- distinct in the subselect
insert into s select distinct * from t;
select * from s;
delete from s;

insert into s select 22222,  22222, 'x', 'y',  99.99, '11/11/2000', '11:11:11' from t;
select * from s;
delete from s;

-- only 1 row will be inserted!
insert into s select distinct 22222,  22222, 'x', 'y',  99.99, '11/11/2000', '11:11:11' from t;
select * from s;
delete from s;

-- distinct on a date column
create table tmp (a date);
insert into tmp select distinct f from t;
select * from tmp;
drop table tmp;

-- distinct on a time column
create table tmp (a time);
insert into tmp select distinct g from t;
select * from tmp;
drop table tmp;

-- distinct on a decimal column
create table tmp (a decimal(5,2));
insert into tmp select distinct e from t;
select * from tmp;
drop table tmp;

-- distinct on a varchar column
create table tmp (a varchar(10));
insert into tmp select distinct d from t;
select * from tmp;
drop table tmp;

-- distinct on a char column
create table tmp (a char(10));
insert into tmp select distinct c from t;
select * from tmp;
drop table tmp;

-- distinct on a smallint column
create table tmp (a smallint);
insert into tmp select distinct b from t;
select * from tmp;
drop table tmp;

-- insert from varchar to char
insert into s (a, b, c, d, e, f, g) select a, b, d, d, e, f, g from t;
select * from s;
delete from s;

-- insert from char to varchar
insert into s (a, b, c, d, e, f, g) select a, b, c, c, e, f, g from t;
select * from s;
delete from s;

-----------------

-- Error cases

-- insert strings into shorter char columns: truncation
create table t1 (a char(5));
insert into t1 values ('aaaaa');
insert into t1 values ('aaaab');
insert into t1 values ('aaaac');

create table t2 (a char(3));

-- expects SQLSTATE=22001
insert into t2 select * from t1;

-- expects no rows
select * from t2;

drop table t1;
drop table t2;

-- target table being referenced in the subselect
insert into s select * from s;

-- column list mis-match
insert into s (b, a, c, d, e, f, g) select b, a, c, d, e, f, g from t;

-- some column are missing
insert into s                    select b, c, d, e, f, g from t;
insert into s (b, c, d, e, f, g) select b, c, d, e, f, g from t;

-- data types mis-match
insert into s (a, b, c, d, e, f, g) select a, e, c, d, b, f, g from t;
insert into s (a, b, c, d, e, f, g) select a, b, d, c, e, f, g from t;

-- insert null values into non-nullable columns
create table nt (a int not null, b smallint not null, c char(10) not null, d varchar(10) not null,
                 e decimal(5,2) not null, f date not null, g time not null);

-- should get an error: SQLSTATE=23502
insert into nt (a, b, c, d, e, f, g) select a, b, c, d, e, f, g from t;

-- should see 4 rows
select * from nt;

drop table nt;

-- arithmetic exception in the subselect
create table tmp (a int);
-- expects SQLSTATE=22012
insert into tmp select 1/a from t;
-- expects a row of null value
select * from tmp;
drop table tmp;

---------
-- date error??? bug??
insert into t values (22222,  22222, 'x', 'y',  99.99, '13/11/2000', '11:11:11');

-- bug???  '13/11/2000' is considered as string -- need to promote it into a date.
insert into s select 22222,  22222, 'x', 'y',  99.99, '13/11/2000', '11:11:11' from t where a=0;
select * from s;
delete from s;

-- orderby in the subselect
insert into s select * from t order by a desc limit 3;
select * from s;
delete from s;

-- limit clause in the subselect
insert into s select * from t limit 3;
select * from s;
delete from s;


-- insert into small decimal into big decimal
create table tmp (a decimal(20,3));
insert into tmp select e from t;
select * from tmp;
drop table tmp;

-- insert into smaller decimal columns: truncation
create table tmp (a decimal(5,1));
insert into tmp select e from t;
select * from tmp;
drop table tmp;

-- insert into smaller decimal columns: overflows
create table tmp (a decimal(5,3));
insert into tmp select e from t;
select * from tmp;
drop table tmp;



---------

-- bug
-- b-0 is integer??? need to support this and report running error
insert into s select a+1, b-0, c, d, e+1.0, f, g from t;
select * from s;
delete from s;

insert into s select a+1, b-0, c, d, e+0.0, f, g from t;
select * from s;
delete from s;

---------

-- timestamp datatype??

-- default values in the target table
create table u (a int default 999, b smallint default 99,
                c char(10) default '1234567890', d varchar(10) default '1234567890',
                e decimal(5,2) default 999.99, f date default '01/01/2001', g time default '12:12:12');

insert into u (a) select a from t;
select * from u;
delete from u;

insert into u (b) select b from t;
select * from u;
delete from u;

insert into u (c) select c from t;
select * from u;
delete from u;

insert into u (d) select d from t;
select * from u;
delete from u;

insert into u (e) select e from t;
select * from u;
delete from u;

insert into u (f) select f from t;
select * from u;
delete from u;

insert into u (g) select g from t;
select * from u;
delete from u;

-----------------------------------------------------------------
-- constraints in the target table
create table ta (a int check(a>0));
create table tb (b smallint check(b>0));
create table tc (c char(10) check(c='a         '));
create table td (d varchar(10) check(d='b'));
create table te (e decimal(5,2) check(e>=0.0));
create table tf (f date check(f='01/01/2001'));
create table tg (g time check(g='01:01:02'));

-- integer
-- should see a null value
insert into ta select a from t where a>0 or a is null;
select * from ta;
delete from ta;

-- should fail
insert into ta select a from t where a=0;
select * from ta;
delete from ta;

-- smallint
-- should see a null value
insert into tb select b from t where b>0 or b is null;
select * from tb;
delete from tb;

-- should fail
insert into tb select b from t where b=0;
select * from tb;
delete from tb;

-- char(10)
-- should see a null value
insert into tc select c from t where c='a         ' or c is null;
select * from tc;
delete from tc;

-- should fail
insert into tc select c from t where c<>'a         ';
select * from tc;
delete from tc;

-- varchar(10)
-- should see a null value
insert into td select d from t where d='b' or d is null;
select * from td;
delete from td;

-- should fail
insert into td select d from t where d<>'b';
select * from td;
delete from td;

-- decimal
-- should see a null value
insert into te select e from t where e>=0.0 or e is null;
select * from te;
delete from te;

-- should fail
insert into te select e from t where e<0.0;
select * from te;
delete from te;

-- date
-- should see a null value
insert into tf select f from t where f='01/01/2001' or f is null;
select * from tf;
delete from tf;

-- should fail
insert into tf select f from t where f!='01/01/2001';
select * from tf;
delete from tf;

-- time
-- should see a null value
insert into tg select g from t where g='01:01:02' or g is null;
select * from tg;
delete from tg;

-- should fail
insert into tg select g from t where g!='01:01:02';
select * from tg;
delete from tg;

drop table ta;
drop table tb;
drop table tc;
drop table td;
drop table te;
drop table tf;
drop table tg;

---------------------------------------

-- type promotions

create table ta (a int);
create table tb (b smallint);
create table tc (c char(10));
create table td (d varchar(10));
create table te (e decimal(7,2));

-- SMALLINT to INTEGER
-- create a temp table for distinct and insert into INTEGER column
insert into ta select distinct b from t;
select * from ta;
delete from ta;

-- create an index for distinct
create index idxtb on t(b);
insert into ta select distinct b from t;
select * from ta;
delete from ta;
drop index idxtb;

-- SMALLINT to DECIMAL
-- create a temp table for distinct and insert into DECIMAL column
insert into te select distinct b from t;
select * from te;
delete from te;

-- create an index for distinct
create index idxtb on t(b);
insert into te select distinct b from t;
select * from te;
delete from te;
drop index idxtb;

-- INTEGER to DECIMAL
-- create a temp table for distinct and insert into DECIMAL column
insert into te select distinct a from t;
select * from te;
delete from te;

-- create an index for distinct
create index idxta on t(a);
insert into te select distinct a from t;
select * from te;
delete from te;
drop index idxta;

-- VARCHAR to CHAR
-- create a temp table for distinct
insert into tc select distinct d from t;
select * from tc;
delete from tc;

-- create an index for distinct
create index idxtd on t(d);
insert into tc select distinct d from t;
select * from tc;
delete from tc;
drop index idxtd;

-- CHAR to VARCHAR
-- create a temp table for distinct
insert into td select distinct c from t;
select * from td;
delete from td;

-- create an index for distinct
create index idxtc on t(c);
insert into td select distinct c from t;
select * from td;
delete from td;
drop index idxtc;

drop table ta;
drop table tb;
drop table tc;
drop table td;
drop table te;

------------------------------------------- 

drop table t;
drop table s;
drop table r;
drop table u;
drop table v;

drop table testx;
-- should return error
create table testx (c1 int not null default 'a' not null, primary key(c1));
drop table testx;
