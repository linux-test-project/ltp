-- ----------------- FILE: SMALLINT1.SQL  -----------------
-- -                                                      - 
-- -     CHECK ALL ERROR IN "CREATE TABLE" STATEMENT      -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE STAFF;
DROP TABLE PROJ;
DROP TABLE WORKS;

-- ------------------  PERFORMANCE TEST  ------------------
-- --------------------------------------------------------
-- 
-- --------------------------------------------------------
-- -----------------------  1PT001  -----------------------
-- --------------------------------------------------------
-- CREATE "STAFF" TABLE WITH [PRIMARY KEY NOT NULL] OPTION 
-- UDB2 RESULT = 42831

CREATE TABLE STAFF
 (EmpNum   VARCHAR(3) PRIMARY KEY NOT NULL,
  EmpName  VARCHAR(20),
  Grade    SMALLINT,
  City     VARCHAR(15));


-- --------------------------------------------------------
-- -----------------------  1PT002  -----------------------
-- --------------------------------------------------------
-- CREATE "PROJ" TABLE WITH [PRIMARY KEY NOT NULL] OPTION 
-- UDB2 RESULT = 42831

CREATE TABLE PROJ
 (PNum     VARCHAR(3) PRIMARY KEY NOT NULL,
  PName    VARCHAR(20),
  PType    VARCHAR(6),
  Budge    SMALLINT,
  City     VARCHAR(15));


-- --------------------------------------------------------
-- -----------------------  1PT003  -----------------------
-- --------------------------------------------------------
-- Create "WORKS" TABLE WITH [NOT NULL] OPTION
-- UDB2 RESULT = SUCC

CREATE TABLE WORKS
 (EmpNum   VARCHAR(3) NOT NULL,
  PNum     VARCHAR(3) NOT NULL,
  Hours    SMALLINT);


-- --------------------------------------------------------
-- -----------------------  1PT004  -----------------------
-- --------------------------------------------------------
-- CREATE "TMP1" TABLE WITH NO OPTION 
-- UDB2 RESULT = SUCC

CREATE TABLE TMP1
 (InsId           SMALLINT,
  OwnerLastName   VARCHAR(15),
  OwnerFirstName  VARCHAR(15),
  Address         VARCHAR(30),
  City            VARCHAR(15),
  State           VARCHAR(2),
  Zip             SMALLINT, 
  Phone           SMALLINT,
  StartDate       VARCHAR(15),
  EndDate         VARCHAR(15));


-- --------------------------------------------------------
-- -----------------------  1PT005  -----------------------
-- --------------------------------------------------------
-- CREATE "TMP2" TABLE WITH [NOT NULL][PRIMARY KEY] OPTION 
-- UDB2 RESULT = SUCC

CREATE TABLE TMP2
 (InsID         SMALLINT NOT NULL PRIMARY KEY,
  CaseID        SMALLINT,
  EstLastName   VARCHAR(15), 
  EstFirstName  VARCHAR(15),
  Maker         VARCHAR(10),
  Model         VARCHAR(10), 
  Color         VARCHAR(10),
  LIC           VARCHAR(10),
  EstPrice      SMALLINT,
  Comment       VARCHAR(50));


-- -----------------------  1PT006  -----------------------
-- --------------------------------------------------------
-- CREATE "TMP3" TABLE WITH [PRIMARY KEY][NOT NULL] OPTION 
-- UDB2 RESULT = SUCC

CREATE TABLE TMP3
 (InsID         SMALLINT PRIMARY KEY NOT NULL,
  CaseID        SMALLINT,
  EstLastName   VARCHAR(15), 
  EstFirstName  VARCHAR(15),
  Maker         VARCHAR(10),
  Model         VARCHAR(10), 
  Color         VARCHAR(10),
  LIC           VARCHAR(10),
  EstPrice      SMALLINT,
  Comment       VARCHAR(50));


-- --------------------------------------------------------
-- -----------------------  1PT007  -----------------------
-- --------------------------------------------------------
-- CREATE "TMP4" TABLE WITH SMALLINTEGER DATA TYPE
-- UDB2 RESULT = SUCC

CREATE TABLE TMP4
 (Percentage   SMALLINT,
  Description  VARCHAR(25));





-- --------------------------------------------------------
-- ---  SYNTAX ERROR TEST (VALID TABLE OR COLUMN NAME)  ---
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1VN001  -----------------------
-- --------------------------------------------------------
-- TABLE NAME BEGIN WITH SMALLINT AND CONTAIN ONLY SMALLINT
-- UDB2 RESULT = 42601

CREATE TABLE 1234
 (Percentage   SMALLINT,
  Description  VARCHAR(25));
 

-- --------------------------------------------------------
-- -----------------------  1VN002  -----------------------
-- --------------------------------------------------------
-- TABLE NAME BEGIN WITH SMALLINT AND CONTAIN CHAR
-- UDB2 RESULT = 42604

CREATE TABLE 2VNTMP
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN003  -----------------------
-- --------------------------------------------------------
-- TABLE NAME BEGIN WITH SMALLINT AND CONTAIN SYMBOLS
-- UDB2 RESULT = 42601

CREATE TABLE 2?!@
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN004  -----------------------
-- --------------------------------------------------------
-- TABLE NAME BEGIN WITH CHAR AND CONTAIN CHAR
-- UDB2 RESULT = SUCC

CREATE TABLE VNTMP
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN005  -----------------------
-- --------------------------------------------------------
-- TABLE NAME BEGIN WITH CHAR AND CONTAIN SMALLINT
-- UDB2 RESULT = SUCC

CREATE TABLE VN005
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN006  -----------------------
-- --------------------------------------------------------
-- TABLE NAME BEGIN WITH CHAR AND CONTAIN SYMBOLS
-- UDB2 RESULT = 42601

CREATE TABLE VN?!@
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN007  -----------------------
-- --------------------------------------------------------
-- TABLE NAME BEGIN WITH SYMBOLS CONTAIN ONLY SYMBOL 
-- UDB2 RESULT = 42601

CREATE TABLE ?!@
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN008  -----------------------
-- --------------------------------------------------------
-- TABLE NAME BEGIN WITH SYMBOLS AND CONTAIN SMALLINT
-- UDB2 RESULT = 42601

CREATE TABLE ?!@007
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN009  -----------------------
-- --------------------------------------------------------
-- TABLE NAME BEGIN WITH SYMBOLS AND CONTAIN CHAR 
-- UDB2 RESULT = 42601

CREATE TABLE ?!@VNTMP
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN010  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME BEGIN WITH SMALLINT AND CONTAIN ONLY SMALLINT 
-- UDB2 RESULT = 42601

CREATE TABLE VN010
 (1999         SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN011  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME BEGIN WITH SMALLINT AND CONTAIN CHAR 
-- UDB2 RESULT = 42604

CREATE TABLE VN011
 (1999Balance  SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN012  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME BEGIN WITH SMALLINT AND CONTAIN ONLY SYMBOLS 
-- UDB2 RESULT = 42601

CREATE TABLE VN012
 (1999?@!  SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN013  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME BEGIN WITH CHAR AND CONTAIN ONLY CHAR 
-- UDB2 RESULT = SUCC

CREATE TABLE VN013
 (Balance      SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN014  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME BEGIN WITH CHAR AND CONTAIN SMALLINT 
-- UDB2 RESULT = SUCC

CREATE TABLE VN014
 (Balance1999  SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN015  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME BEGIN WITH CHAR AND CONTAIN SYMBOLS 
-- UDB2 RESULT = 42601

CREATE TABLE VN015
 (Balance?@#!  SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN016  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME BEGIN WITH SYMBOLS AND CONTAIN ONLY SYMBOLS 
-- UDB2 RESULT = 42601

CREATE TABLE VN016
 (?@#!         SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN017  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME BEGIN WITH SYMBOLS AND CONTAIN SMALLINT 
-- UDB2 RESULT = 42601

CREATE TABLE VN017
 (?@#!1999     SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1VN018  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME BEGIN WITH SYMBOLS AND CONTAIN CHAR 
-- UDB2 RESULT = 42601

CREATE TABLE VN018
 (?@!$Balance  SMALLINT,
  Description  VARCHAR(25));




-- --------------------------------------------------------
-- ------------  SYNTAX ERROR TEST (SPELLING)  ------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1SP001  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "CREATE"
-- UDB2 RESULT = 42601

CREAT TABLE SP001
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1SP002  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "TABLE"
-- UDB2 RESULT = 42601

CREATE ABLE SP002
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1SP003  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "SMALLINT"
-- UDB2 RESULT = 42704

CREATE TABLE SP003
 (Percentage   IN,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1SP004  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "VARCHAR(N)"
-- UDB2 RESULT = 42601

CREATE TABLE SP004
 (Percentage   SMALLINT,
  Description  ARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1SP005  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR INSIDE BRACKET OF "VARCHAR(N)"
-- UDB2 RESULT = 42601

CREATE TABLE SP005
 (Percentage   SMALLINT,
  Description  VARCHAR(FAILED));


-- --------------------------------------------------------
-- -----------------------  1SP006  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "PRIMARY"
-- UDB2 RESULT = 42601

CREATE TABLE SP006
 (Percentage   SMALLINT PRIMERY KEY,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1SP007  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "PRIMARY KEY NOT NULL"
-- UDB2 RESULT = 42601

CREATE TABLE SP007
 (Percentage   SMALLINT PRIMARYKEY,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1SP008  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "NULL"
-- UDB2 RESULT = 42601

CREATE TABLE SP008
 (Percentage   SMALLINT NOT NOLL,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1SP009  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "NOT NULL"
-- UDB2 RESULT = 42601

CREATE TABLE SP009
 (Percentage   SMALLINT NOTNULL,
  Description  VARCHAR(25));



-- --------------------------------------------------------
-- -----  SYNTAX ERROR TEST (EXTRA OR MISSING WORD)  ------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1EW001  -----------------------
-- --------------------------------------------------------
-- WORD "CREATE" IS MISSING
-- UDB2 RESULT = 42601

TABLE EW001
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW002  -----------------------
-- --------------------------------------------------------
-- WORD "TABLE" IS MISSING
-- UDB2 RESULT = 42601

CREATE EW002
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW003  -----------------------
-- --------------------------------------------------------
-- TABLE NAME IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE 
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW004  -----------------------
-- --------------------------------------------------------
-- COLUMN NAME IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE EW004
 (Percentage   SMALLINT,
               VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW005  -----------------------
-- --------------------------------------------------------
-- DATA TYPE "SMALLINT" IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE EW005
 (Percentage   ,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW006  -----------------------
-- --------------------------------------------------------
-- DATA TYPE "VARCHAR(N)" IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE EW006
 (Percentage   SMALLINT,
  Description  );


-- --------------------------------------------------------
-- -----------------------  1EW007  -----------------------
-- --------------------------------------------------------
-- (N) IN DATA TYPE "VARCHAR" IS MISSING
-- UDB2 RESULT = 42611

CREATE TABLE EW007
 (Percentage   SMALLINT,
  Description  VARCHAR);


-- --------------------------------------------------------
-- -----------------------  1EW008  -----------------------
-- --------------------------------------------------------
-- WORD "PRIMARY" IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE EW008
 (Percentage   SMALLINT KEY,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW009  -----------------------
-- --------------------------------------------------------
-- WORD "PRIMARY KEY NOT NULL" IS MISSING
-- UDB2 RESULT = SUCC

CREATE TABLE EW009
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW010  -----------------------
-- --------------------------------------------------------
-- WORD "NOT" IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE EW010
 (Percentage   SMALLINT NULL,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW011  -----------------------
-- --------------------------------------------------------
-- WORD "NOT NULL" IS MISSING
-- UDB2 RESULT = SUCC

CREATE TABLE EW011
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW012  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "CREATE"
-- UDB2 RESULT = 42601

FAILED CREATE TABLE EW012
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW013  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "TABLE"
-- UDB2 RESULT = 42601

CREATE FAILED TABLE EW013
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW014  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF TABLE NAME
-- UDB2 RESULT = 42601

CREATE TABLE FAILED EW014
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW015  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF FIRST BRACKET
-- UDB2 RESULT = 42601

CREATE TABLE EW015 FAILED
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW016  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF COLUMN NAME
-- UDB2 RESULT = 42601

CREATE TABLE EW016
 (FAILED Percentage   SMALLINT,
  Description         VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW017  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF DATA TYPE
-- UDB2 RESULT = 42601

CREATE TABLE EW017
 (Percentage   FAILED SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW018  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF OPTION
-- UDB2 RESULT = 42601

CREATE TABLE EW018
 (Percentage   SMALLINT FAILED NOT NULL,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1EW019  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF SECOND BRACKET
-- UDB2 RESULT = 42601

CREATE TABLE EW019
 (Percentage   SMALLINT,
  Description  VARCHAR(25) FAILED);


-- --------------------------------------------------------
-- -----------------------  1EW020  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" AFTER SECOND BRACKET
-- UDB2 RESULT = 42601

CREATE TABLE EW020
 (Percentage   SMALLINT,
  Description  VARCHAR(25)) FAILED;




-- --------------------------------------------------------
-- --------  SYNTAX ERROR TEST (BRACKET MISSING)  ---------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1BM001  -----------------------
-- --------------------------------------------------------
-- FIRST BRACKET IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE BM001
  Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1BM002  -----------------------
-- --------------------------------------------------------
-- LAST BRACKET IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE BM002
 (Percentage   SMALLINT,
  Description  VARCHAR(25);


-- --------------------------------------------------------
-- -----------------------  1BM003  -----------------------
-- --------------------------------------------------------
-- NO BRACKET "CREATE TABLE" STATEMENT
-- UDB2 RESULT = 42601

CREATE TABLE BM003
  Percentage   SMALLINT,
  Description  VARCHAR(25);


-- --------------------------------------------------------
-- -----------------------  1BM004  -----------------------
-- --------------------------------------------------------
-- FIRST BRACKET IN "VARCHAR(N)" IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE BM004
 (Percentage   SMALLINT,
  Description  VARCHAR25));


-- --------------------------------------------------------
-- -----------------------  1BM005  -----------------------
-- --------------------------------------------------------
-- NO BRACKET IN "VARCHAR(N)"
-- UDB2 RESULT = 42704

CREATE TABLE BM005
 (Percentage   SMALLINT,
  Description  VARCHAR25);


-- --------------------------------------------------------
-- -----------------------  1BM006  -----------------------
-- --------------------------------------------------------
-- EXTRA BRACKET IN FRONT OF FIRST BRACKET
-- UDB2 RESULT = 42601

CREATE TABLE BM006
((Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1BM007  -----------------------
-- --------------------------------------------------------
-- TWO EXTRA BRACKET AT THE END OF STATEMENT
-- UDB2 RESULT = 42601

CREATE TABLE BM007
 (Percentage   SMALLINT,
  Description  VARCHAR(25)))));


-- --------------------------------------------------------
-- -----------------------  1BM008  -----------------------
-- --------------------------------------------------------
-- SPACES BETWEEN BRACKET AND TABLE NAME
-- UDB2 RESULT = SUCC

CREATE TABLE BM008
            
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1BM009  -----------------------
-- --------------------------------------------------------
-- SPACES BETWEEN BRACKET AND FIRST COLUMN NAME
-- UDB2 RESULT = SUCC

CREATE TABLE BM009
 (           Percentage   SMALLINT,
             Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1BM010  -----------------------
-- --------------------------------------------------------
-- SPACES BETWEEN LAST DATA TYPE AND LAST BRACKET
-- UDB2 RESULT = SUCC

CREATE TABLE BM010
 (Percentage   SMALLINT,
  Description  VARCHAR(25)                      );


-- --------------------------------------------------------
-- -----------------------  1BM011  -----------------------
-- --------------------------------------------------------
-- SPACES BETWEEN VARCHAR AND BRACKET AFTER VARCHAR
-- UDB2 RESULT = SUCC

CREATE TABLE BM011
 (Percentage   SMALLINT,
  Description  VARCHAR                     (25));


-- --------------------------------------------------------
-- -----------------------  1BM012  -----------------------
-- --------------------------------------------------------
-- SPACES BETWEEN BRACKET AFTER VARCHAR AND NUMBER
-- UDB2 RESULT = SUCC

CREATE TABLE BM012
 (Percentage   SMALLINT,
  Description  VARCHAR(                     25));




-- --------------------------------------------------------
-- ---------  SYNTAX ERROR TEST (CASE SENSITIVE)  ---------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1CS001  -----------------------
-- --------------------------------------------------------
-- CHECK IF "CREATE" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

CrEaTe TABLE CS001
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1CS002  -----------------------
-- --------------------------------------------------------
-- CHECK IF "TABLE" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

CREATE TaBlE CS002
 (Percentage   SMALLINT,
  Description  VARCHAR(25));



-- --------------------------------------------------------
-- -----------------------  1CS003  -----------------------
-- --------------------------------------------------------
-- CHECK IF "SMALLINT" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

CREATE TABLE CS003
 (Percentage   SMALLINT,
  Description  VARCHAR(25));



-- --------------------------------------------------------
-- -----------------------  1CS004  -----------------------
-- --------------------------------------------------------
-- CHECK IF "VARCHAR(N)" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

CREATE TABLE CS004
 (Percentage   SMALLINT,
  Description  VaRcHaR(25));



-- --------------------------------------------------------
-- -----------------------  1CS005  -----------------------
-- --------------------------------------------------------
-- CHECK IF "CREATE" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

CREATE TABLE CS005
 (Percentage   SMALLINT NOT NULL PRIMARY KEY,
  Description  VARCHAR(25));



-- --------------------------------------------------------
-- -----------------------  1CS006  -----------------------
-- --------------------------------------------------------
-- CHECK IF "CREATE" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

CREATE TABLE CS006
 (Percentage   SMALLINT NoT NuLL,
  Description  VARCHAR(25));




-- --------------------------------------------------------
-- ---------  SYNTAX ERROR TEST (WRONG COMMAND)  ----------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1WC001  -----------------------
-- --------------------------------------------------------
-- REPLACE "CREATE TABLE' WITH "INSERT"
-- UDB2 RESULT = 42601

INSERT INTO WC001
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1WC002  -----------------------
-- --------------------------------------------------------
-- REPLACE "CREATE TABLE' WITH "SELECT"
-- UDB2 RESULT = 42601

SELECT WC002
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1WC003  -----------------------
-- --------------------------------------------------------
-- REPLACE "CREATE TABLE' WITH "DELETE"
-- UDB2 RESULT = 42601

DELETE TABLE WC003
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1WC004  -----------------------
-- --------------------------------------------------------
-- REPLACE "CREATE TABLE' WITH "UPDATE"
-- UDB2 RESULT = 42601

UPDATE TABLE WC004
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1WC005  -----------------------
-- --------------------------------------------------------
-- REPLACE "CREATE TABLE' WITH "DROP"
-- UDB2 RESULT = 42601

DROP TABLE WC005
 (Percentage   SMALLINT,
  Description  VARCHAR(25));





-- --------------------------------------------------------
-- -----------------  SEMATIC ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1ST001  -----------------------
-- --------------------------------------------------------
-- CREATE A TABLE WITH FEWER COLUMNS
-- UDB2 RESULT = 42710

CREATE TABLE ST001
 (Percentage   SMALLINT,
  Description  VARCHAR(25));

CREATE TABLE ST001
 (Percentage   SMALLINT);


-- --------------------------------------------------------
-- -----------------------  1ST002  -----------------------
-- --------------------------------------------------------
-- CREATE A SAME TABLE WITH TWO PRIMARY KEY NOT NULL
-- UDB2 RESULT = 42614

CREATE TABLE ST002
 (Percentage   SMALLINT PRIMARY KEY NOT NULL,
  Description  VARCHAR(25) PRIMARY KEY NOT NULL);


-- --------------------------------------------------------
-- -----------------------  1ST003  -----------------------
-- --------------------------------------------------------
-- CREATE A SAME TABLE WITH TWO NOT NULL
-- UDB2 RESULT = SUCC

CREATE TABLE ST003
 (Percentage   SMALLINT NOT NULL,
  Description  VARCHAR(25) NOT NULL);


-- --------------------------------------------------------
-- -----------------------  1ST004  -----------------------
-- --------------------------------------------------------
-- CREATE A SAME TABLE WITH TWO NOT NULL
-- UDB2 RESULT = SUCC

CREATE TABLE ST004
 (Percentage   SMALLINT NOT NULL PRIMARY KEY NOT NULL,
  Description  VARCHAR(25) NOT NULL);




-- ----------------  RUN-TIME ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1RT001  -----------------------
--- --------------------------------------------------------
-- DECLARE VARCHAR DATA TYPE, SUCH AS "VARCHAR(-1)"
-- UDB2 RESULT = 42611

CREATE TABLE RT001
 (Percentage   SMALLINT,
  Description  VARCHAR(0));


-- --------------------------------------------------------
-- -----------------------  1RT002  -----------------------
-- --------------------------------------------------------
-- DECLARE VARCHAR DATA TYPE, SUCH AS "VARCHAR(-1)"
-- UDB2 RESULT = 42601

CREATE TABLE RT002
 (Percentage   SMALLINT,
  Description  VARCHAR(-1));





-- --------------------------------------------------------
-- ------------------  LIMITATION TEST  -------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1LT001  -----------------------
-- -----------------------  1LT002  -----------------------
-- -----------------------  1LT003  -----------------------
-- --------------------------------------------------------
-- ---------------  REFER TO LT001.SQL FILE  --------------
-- --------------------------------------------------------
--

-- --------------------------------------------------------
-- -----------------------  1LT004  -----------------------
-- -----------------------  1LT005  -----------------------
-- -----------------------  1LT006  -----------------------
-- --------------------------------------------------------
-- ---------------  REFER TO LT002.SQL FILE  --------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1LT007  -----------------------
-- --------------------------------------------------------
-- WITHIN NUMBER OF CHARACTER ALLOWED IN A TABLE NAME
-- UDB2 RESULT = SUCC

CREATE TABLE TableNameHas18CHAR
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1LT009  -----------------------
-- --------------------------------------------------------
-- EXCEED NUMBER OF CHARACTER ALLOWED IN A TABLE NAME
-- UDB2 RESULT = 42622

CREATE TABLE TableNameHas19CHARS
 (Percentage   SMALLINT,
  Description  VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1LT010  -----------------------
-- --------------------------------------------------------
-- WITHIN NUMBER OF CHARACTER ALLOWED IN A COLUMN NAME
-- UDB2 RESULT = SUCC

CREATE TABLE LT010
 (ColumnNameIs18CHAR  SMALLINT,
  Description         VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1LT011  -----------------------
-- --------------------------------------------------------
-- EXACT NUMBER OF CHARACTER ALLOWED IN A COLUMN NAME
-- UDB2 RESULT = SUCC

CREATE TABLE LT011
 (ColumnNameIs18CHAR  SMALLINT,
  Description         VARCHAR(25));


-- --------------------------------------------------------
-- -----------------------  1LT012  -----------------------
-- --------------------------------------------------------
-- EXCEED NUMBER OF CHARACTER ALLOWED IN A COLUMN NAME
-- UDB2 RESULT = 42622

CREATE TABLE LT012
 (ColumnNameIs19CHARS   SMALLINT,
  Description           VARCHAR(25));




-- ----------- DROP ALL PREVIOUSLY CREATED TABLE ----------
-- --------------------------------------------------------

DROP TABLE TMP3;

DROP TABLE BM008;
DROP TABLE BM009;
DROP TABLE BM010;
DROP TABLE BM011;
DROP TABLE BM012;

DROP TABLE CS001;
DROP TABLE CS002;
DROP TABLE CS003;
DROP TABLE CS004;
DROP TABLE CS005;
DROP TABLE CS006;

DROP TABLE EW009;
DROP TABLE EW011;

DROP TABLE LT010;
DROP TABLE LT011;

DROP TABLE ST001;
DROP TABLE ST003;
DROP TABLE ST004;

DROP TABLE VNTMP;
DROP TABLE VN005;
DROP TABLE VN013;
DROP TABLE VN014;

DROP TABLE TableNameHas17CHS;
DROP TABLE TableNameHas18CHAR;

