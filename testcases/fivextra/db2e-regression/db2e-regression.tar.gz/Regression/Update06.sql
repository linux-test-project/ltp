-- ----------------- FILE: UPDATE06.SQL -------------------
-- -                                                      - 
-- -        CHECK ALL ERROR IN "UPDATE" STATEMENT         -
-- -                                                      -
-- --------------------------------------------------------
--
drop table tx;
create table tx (c1 int, c2 varchar(100));
insert into tx values(1,'1');
update tx set c1=c1+1, c2='1111111111';
select c1 from tx;
drop table tx;
