-- ----------------- FILE: UPDATE07.SQL -------------------
-- -                                                      - 
-- -        CHECK ALL ERROR IN "UPDATE" STATEMENT         -
-- -                                                      -
-- --------------------------------------------------------
--
-- This is a test case that caused an index corruption on Palm
-- only.
drop table Orders;
create table Orders (ORDERID INTEGER  PRIMARY KEY NOT NULL,COMPLETED INTEGER,COMPANY CHARACTER(2),CUSTOMERNUM VARCHAR(20), EMAIL VARCHAR(80),BILLCITY VARCHAR(40),BILLSTATE CHARACTER(2),BILLZIP VARCHAR(10),CCNUMBER VARCHAR(32),CCNAME VARCHAR(40),CCEXPDATE VARCHAR(19),PLACEDDATE VARCHAR(19),DATESHIPPED VARCHAR(19), CREATEDATE VARCHAR(19),COMMENTS VARCHAR(256),SALESPERSON	CHARACTER(3),REFNUM VARCHAR(40));
create index OR_REF on Orders(REFNUM);
insert into Orders (ORDERID) values (1);
update Orders set REFNUM='' where orderid=1;
insert into Orders (ORDERID) values (2);
select refnum from orders order by refnum;
select refnum from orders group by refnum;
select refnum from orders where refnum is NULL;
select refnum from orders where refnum = '';
drop table Orders;