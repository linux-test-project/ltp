--
-----------------------------------------------------------------------------------
-- This bucket is for testing DB2e encryption and SampleCLP "connect to" command --
-----------------------------------------------------------------------------------
--
-- change to directory enctest2\for testing of encryption
--
connect to enctest2\ user user using passwd;
--
-- assume current connection is of user "user" with password "passwd"
-- following query should return 0 rows for now
--
select username,grantorname from "DB2eSYSUSERS";
--
-- following stmt will fail as the user need to register himself first
--
create table t(a int) with encryption;
--
--1)Test group1: syntax of the "grant" command 
-- try to create a user with empty id, should fail
--
grant encrypt on database to "" using "pwd" new "pwd";
--
-- try to create a user with empty password, should fail
--
grant encrypt on database to "test" using "" new "";
--
-- try to create a user with empty new password, should fail
--
grant encrypt on database to "test" using "test" new "";
--
-- try to authorize current connected user himself,but using a differnet password
-- from the one used at connection time
--
grant encrypt on database to "user" using "pwd" new "pwd";
--
select username,grantorname from "DB2eSYSUSERS";
--
connect to enctest2\ user tester using tester;
--
-- non-registered user can not grant others
--
grant encrypt on database to "worker" using "passwd" new "work";
--
connect to enctest2\ user user using pwd;
--
-- try to add user "worker"/"work" to sysusers table
-- yet with a different password "passwd" (grantor is "user"/"pwd") so should fail 
--
grant encrypt on database to "worker" using "passwd" new "work";
--
-- try to add user "worker"/"work" yet without using double quote so should fail
--
grant encrypt on database to worker using "pwd" new "work";
--
grant encrypt on database to "worker" using pwd new "work";
--
grant encrypt on database to "worker" using "pwd" new work;
--
-- finally giving the correct parameter
--
grant encrypt on database to "worker" using "pwd" new "work";
--
-- following return 2 rows;
--
select username,grantorname from "DB2eSYSUSERS";
--
create table t(a int) with encryption;
-- 
-- changin current connected user's password in sysusers table
--
grant encrypt on database to "user" using "pwd" new "passwd";
--
-- change current connected user to "worker" with password "work", should succeed
--
connect to enctest2\ user worker using work;
--
-- try to access the encrypted data, should succeed
--
select * from t;
--
-- try add another user "user1\user1"
-- fail as didn't give correct password the first try
--
grant encrypt on database to "user1" using "user1" new "user1";
--
-- succeed for the second try
--
grant encrypt on database to "user1" using "work" new "user1";
-- 
connect to enctest2\ user user1 using user1;
--
-- change current connected user to "user" with password "pwd" should fail
--
connect to enctest2\ user user using pwd;
--
connect to enctest2\ user user using passwd;
--
-- Here we create some users that have really long passwords, up to 254 characters.
-- All of those statements should succeed.
--
connect to enctest2\ user worker using work;
--
grant encrypt on database to "user_longpw" using "work" new "ThisIsALongPasswordWith42CharactersOverall";
connect to enctest2\ user user_longpw using ThisIsALongPasswordWith42CharactersOverall;
--
grant encrypt on database to "user_verylongpw" using "ThisIsALongPasswordWith42CharactersOverall" new "YouBetterBelieveIt_ThisPasswordStringHasInfactOneHundredAndTwentyEightCharactersOverallAndIsIntendedToTestTheUpperLimitOfOurCode";
connect to enctest2\ user user_verylongpw using YouBetterBelieveIt_ThisPasswordStringHasInfactOneHundredAndTwentyEightCharactersOverallAndIsIntendedToTestTheUpperLimitOfOurCode;
--
grant encrypt on database to "user_maxpw" using "YouBetterBelieveIt_ThisPasswordStringHasInfactOneHundredAndTwentyEightCharactersOverallAndIsIntendedToTestTheUpperLimitOfOurCode" new "ThisIsAVeryLongPassphraseWhichHasTwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_";
connect to enctest2\ user user_maxpw using ThisIsAVeryLongPassphraseWhichHasTwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_;
--
-- Okay, now we provoke some errors.  All of the following statements should fail.
--
-- password is too long
--
connect to enctest2\ user user using passwd;
grant encrypt on database to "user_pwtoolong" using "passwd" new "ThisIsAVeryLongPassphraseWhichHas_SOME_MORE_THAN_TwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_";
connect to enctest2\ user_pwtoolong using ThisIsAVeryLongPassphraseWhichHas_SOME_MORE_THAN_TwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_;
--
-- password is too long and not enclosed in double quotes;
-- 
connect to enctest2\ user user using passwd;
grant encrypt on database to "user_pwtoolong" using "passwd" new 'ThisIsAVeryLongPassphraseWhichHas_SOME_MORE_THAN_TwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_';
connect to enctest2\ user_pwtoolong using ThisIsAVeryLongPassphraseWhichHas_SOME_MORE_THAN_TwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_;
connect to enctest2\ user user using passwd;
grant encrypt on database to "user_pwtoolong" using "passwd" new ThisIsAVeryLongPassphraseWhichHas_SOME_MORE_THAN_TwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_;
connect to enctest2\ user_pwtoolong using ThisIsAVeryLongPassphraseWhichHas_SOME_MORE_THAN_TwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_;
--
-- Password has the right size, but is not enclosed in double quotes.
--
connect to enctest2\ user user using passwd;
grant encrypt on database to "user_maxpw_wrong" using 'YouBetterBelieveIt_ThisPasswordStringHasInfactOneHundredAndTwentyEightCharactersOverallAndIsIntendedToTestTheUpperLimitOfOurCode" new "ThisIsAVeryLongPassphraseWhichHasTwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_';
connect to enctest2\ user user_maxpw_wrong using ThisIsAVeryLongPassphraseWhichHasTwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_;
connect to enctest2\ user user using passwd;
grant encrypt on database to "user_maxpw_wrong" using YouBetterBelieveIt_ThisPasswordStringHasInfactOneHundredAndTwentyEightCharactersOverallAndIsIntendedToTestTheUpperLimitOfOurCode" new "ThisIsAVeryLongPassphraseWhichHasTwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_;
connect to enctest2\ user user_maxpw_wrong using ThisIsAVeryLongPassphraseWhichHasTwoHundredAndFiftyFourCharactersOverall_NobodyWillTypeSuchALongStringAnyway_HoweverWeBetterMakeSureThatItWorksSinceMartinMightTryToTestOurLimitsSomedayAndWeDontWannaFailOnThat_NowIAmTotallyTiredOfTypingThat_SoIJustStopIt_;
--
-- End of long password tests.
--
connect to enctest2\ user user using passwd;
--
--
--blastdb;
--
list tables;
--
--2)Test group2:not allow changing other's password, etc.
-- current connected user is registered
-- so following query should return 1 row
--
select username,grantorname from "DB2eSYSUSERS";
--
-- following stmt should work now
--
create table tt(a int) with encryption;
--
-- following stmt tries to add "worker"/"pwd" to sysusers table but fails 
-- for incorrect password of current user
-- 
grant encrypt on database to "worker" using "pwd" new "pwd";
--
-- following stmt will create user "WORKER" with password "WORK"
--
grant encrypt on database to "WORKER" using "passwd" new "WORK";
--
-- following returns 2 rows
--
select username,grantorname from "DB2eSYSUSERS";
--
-- following stmt will fails as one can only change his own password
--
grant encrypt on database to "WORKER" using "passwd" new "JOB";
--
-- change current connected user to "WORKER"/"WORK"
--
connect to enctest2\ user WORKER using WORK;
--
-- assume user "WORKER" with password "WORK" is current connected one
--
grant encrypt on database to "WORKER" using "PWD" new "PWD";
--
grant encrypt on database to "WORKER" using "WORK" new "JOB";
--
select * from t;
--
-- 3)test table join between encrypted table and unencrypted table
--
connect to enctest2\ user user using passwd;
--
create table t1(a int) with encryption;
--
create table t2(a int, b char(10));
-- 
insert into t1 values(5);
--
insert into t1 values(15);
--
insert into t1 values(25);
--
insert into t2 values(10, 'abc');
--
insert into t2 values(20, 'def');
--
select t1.a from t1, t2 where t1.a < t2.a;
--
-- 4)following is test for "REVOKE"
-- should use double quote for the following
--
connect to enctest2\ user user using passwd;
--
select username,grantorname from "DB2eSYSUSERS";
--
revoke encrypt on database from user;
--
-- assume user "user" exists(not "USER") so following fails
--
revoke encrypt on database from "USER";
--
connect to enctest2\ user db2e using db2e;
--
revoke encrypt on database from "WORKER";
--
connect to enctest2\ user WORKER using JOB;
--
select username,grantorname from "DB2eSYSUSERS";
--
-- "WORKER"/"JOB" is the correct password
--
grant encrypt on database to "tester" using "WORK" new "db2e";
--
grant encrypt on database to "tester" using "JOB" new "db2e";
--
select username,grantorname from "DB2eSYSUSERS";
--
-- 5)Once the DB2eSYSUSERS table become empty, no one can access the encrypted data
--   anymore; if the connected user "revoke" himself, he should not access enrypted
--   data or registere himself back again(this has to be done by another registered 
--   user)
--
connect to enctest2\ user tester using db2e;
--
-- assume current connected user is "tester" with password "db2e"
--
select * from t;
--
select username,grantorname from "DB2eSYSUSERS";
--
-- revoke the connected user
--
revoke encrypt on database from "tester";
--
-- following should fail
--
grant encrypt on database to "tester" using "tester" new "tester";
--
-- following should fail
--
select * from t;
--
select username,grantorname from "DB2eSYSUSERS";
--
connect to enctest2\ user user using passwd;
--
select * from t;
--
--blastdb;
--
list tables;
--
select username,grantorname from "DB2eSYSUSERS";
--
-- revoke continuously until the sysusers table becomes empty
--
revoke encrypt on database from "WORKER";
--
revoke encrypt on database from "user";
--
select username,grantorname from "DB2eSYSUSERS";
--
-- following should fail as the sysusers table is empty now
--
grant encrypt on database to "db2e" using "passwd" new "db2e";
--
revoke encrypt on database from all;
--
---------------------------------------------------------------
-- following is to test blastdbplus for encrypted tables
---------------------------------------------------------------
--
--blastdb;
connect to enctest2\ user abc using def;
grant encrypt on database to "abc" using "def" new "def";
select username from "DB2eSYSUSERS";
create table enc(a int, b decimal(10,4)) with encryption;
create table ttt(a int);
blastdb;

select tname from "DB2eSYSTABLES";
select cname from "DB2eSYSCOLUMNS";
select username from "DB2eSYSUSERS";

connect to .\ user abc using def;
create table ttt(a int);
grant encrypt on database to "abc" using "def" new "def";
select username from "DB2eSYSUSERS";
select tname from "DB2eSYSTABLES";
drop table ttt;
create table enc(a int, b decimal(10,4)) with encryption;
create table ttt(a int);
blastdb;
autocommit off;
select tname from "DB2eSYSTABLES";
select cname from "DB2eSYSCOLUMNS";
select username from "DB2eSYSUSERS";
commit work;
autocommit on;
-------------------------------------------------------------
--- test encryption of temp files(using scrollable cursor) --
-------------------------------------------------------------
connect to enctest2\ user db2e using db2e;
grant encrypt on database to "db2e" using "db2e" new "db2e";

create table enc(a int, b char(10)) with encryption;
insert into enc values(10, 'aaa');
insert into enc values(20, 'bbb');
insert into enc values(15, 'ccc');
select * from enc;

create stmt handle :1;
enable scrollable cursor :1;
prepare :1 select a, b from enc;
execute :1; 
fetch :1;
fetch :1;
fetch :1;

disable scrollable cursor :1;
prepare :1 select * from enc order by a;
execute :1;
fetch :1;
fetch :1;
fetch :1;

drop stmt handle :1;

blastdb;
