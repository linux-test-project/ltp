drop table t;
create table t(i int primary key, c char(50), v varchar(50));
create index tc on t(c);

-- Index updates with transaction (similar to file trbasic.sql)

insert into t values(1, 'one', 'ett');

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- empty transactions
transaction begin;
transaction commit;
transaction begin;
transaction rollback;

-- select inside a transaction
transaction begin;
select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;
transaction commit;
transaction begin;
select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;
transaction rollback;

-- insert one row inside a transaction
transaction begin;
insert into t values(2, 'two', 'tva');

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

transaction commit;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- insert one row inside a transaction, but rollback
transaction begin;
 insert into t values(3, 'three', 'tre');

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;
transaction rollback;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- insert a row at the same place as the previous transaction
transaction begin;
 insert into t values(4, 'four', 'fyra');

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

transaction commit;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- delete the last row, rollback
transaction begin;
 delete from t where i=4;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;
transaction rollback;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- delete it for real, commit
transaction begin;
 delete from t where i=4;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

transaction commit;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- insert,delete inside a transacation, rollback, space will be reused
transaction begin;
insert into t values(5, 'five', 'fem');

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

 delete from t where i=5;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;
transaction rollback;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- will reuse the space
 insert into t values(6, 'six', 'sex');

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- insert,delete inside a transacation, commit, space will not be reused
transaction begin;
 insert into t values(7, 'seven', 'sju');

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

 delete from t where i=7;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

transaction commit;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- will not reuse the space
 insert into t values(8, 'eigth', 'atta');

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- insert something to change...
 insert into t values(9, 'ninee', 'nio');

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- do an update and regret it since it's wrong!
transaction begin;
  update t set c='nino' where i=9;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;
transaction rollback;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- do an update to fix it
transaction begin;
  update t set c='nine' where i=9;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

transaction commit;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- delete all, undo
transaction begin;
 delete from t;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;
transaction rollback;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- delete all with predicate, undo
transaction begin;
 delete from t where i>=0;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;
transaction rollback;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- delete all for sure
transaction begin;
 delete from t;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

transaction commit;

select $rid,i,c,v from t order by i;
select $rid,i,c,v from t order by c;
select $rid,i,c,v from t order by v;
select  $rid,i,c,v from t;

-- cleanup

drop table t;

