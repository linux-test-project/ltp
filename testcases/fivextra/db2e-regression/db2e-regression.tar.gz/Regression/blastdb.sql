blastdb;
create table " abc " (c1 int, c2 smallint);
create table xx ("c 1" int not null primary key, c2 char(4));
create table  yy (c1 int, c2 int, foreign key (c1) references xx); 
create table " blank " (c1 int, c2 char(55));
create table "INT" ("INT" int);
create table zz (abc int, def decimal(12,3), z123 varchar(100) not null, y123 int, 
mm11mm integer, mno65tre smallint, a int, b int, a4 int, x54 int, fgt int, hsg int);
create table parent (c1 char(4) not null, c2 char(4) not null, c3 int, primary key(c1,c2));
create table child (c1 char(4) not null, c2 char(4) not null, c3 int, c4 int, foreign key (c1,c2) references parent);
select tname from "DB2eSYSTABLES";
select cname, tname from "DB2eSYSCOLUMNS";
select rmd_id from "DB2eSYSRELS";


blastdb;
select tname from "DB2eSYSTABLES";
select cname, tname from "DB2eSYSCOLUMNS";
select rmd_id from "DB2eSYSRELS";

