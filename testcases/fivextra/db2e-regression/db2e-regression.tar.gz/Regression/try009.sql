-- ------------------ FILE: TRYOO9.SQL  -------------------
-- -                                                      - 
-- -   CHECK COMBINATIONS OF CREATE TABLE                 -
-- -                                                      -
-- --------------------------------------------------------
--
create table testa (c1 int);
create table testb (c1 int not null primary key);

create table testx (c1 int not null default 'a' not null);
create table testx (c1 integer char(4));
create table testx (c1 int not null primary key, c2 int not null, primary key(c1,c2));
create table testx (c1 int not null, c2 int not null,primary key (c1), primary key (c1));
create table testx (c1 int not null, c2 int not null,primary key (c1), primary key (c2));
create table testz (c1 int not null primary key references testa);

-- following should be errors?
create table testm (c1 int primary key not null primary key);
create table testn (c1 int not null default 1 not null);

-- following are okay
create table testu (c1 date default current date primary key not null);
create table testv (c1 time default current time not null, c2 date);
create table testw (c1 int primary key not null);
create table testx (c1 int default 1 not null);
create table testy (c1 int not null primary key check (c1 > 0));
create table testz (c1 int not null primary key references testb );
insert into testu values('10/10/1992');
insert into testv values('01:01:01', '10/10/1992');
insert into testw values(11);
insert into testx values(12);
insert into testy values(1);
insert into testz values(14);

-- this one should be error
insert into testy values(0);

select * from testu;
select * from testv;
select * from testw;
select * from testx;
select * from testy;
select * from testz;

drop table testa;
drop table testm;
drop table testn;
drop table testu;
drop table testv;
drop table testw;
drop table testx;
drop table testy;
drop table testz;
