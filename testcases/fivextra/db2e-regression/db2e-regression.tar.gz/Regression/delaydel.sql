--------------------------------------------------------------------
-- test delay-delete, which is to address index performance issue --
--------------------------------------------------------------------
-- Delayed delete only happens when following conditions are satisfied
-- 1)Table has at least one index and there is an index used in fetching records
-- 2)Physical delete or deleting a record just inserted($dirty=2)
-- 3)We are not deleting from a table with primary key and for each key column
-- there is an equal prediacate in the where clause, which means only 1 row need 
-- to be deleted

-- Note1: there is no way to tell whether or not delayed delete is happenning ouside
-- the engine,because no temp file can be seen created on disk. The way to testify 
-- it is setting up a debugger and stepping through 

-------------------------------
-- group I test normal table --
-------------------------------
-- Note2: when testing the effectiveness of condtion 1 and condtion 3, we make
-- condtion 2 always true. In order to do this, we need to set physical delete
-- explicitly as the system is doing logical delete by default. Also a record
-- just inserted has $dirty=2, need to set it to 0.This is the purpose of following
-- two lines

ENABLE APPLICATION SET DIRTY;
ENABLE PHYSICAL DELETE;

-- case1 table doesn't have index(physical delete, $dirty = 0): no delay delete
drop table tb;
create table tb(a int, b int, c varchar(50));
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 13;
select $dirty, a, b, c from tb;

-- case2.0 table has index but index is not used(physical delete, $dirty = 0):no delay delete 
drop table tb;
create table tb(a int, b int, c varchar(50));
create index idx on tb(b);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 15;
select $dirty, a, b, c from tb;

-- case2.1 table has index but index is not used(physical delete, $dirty = 0):no delay delete 
drop table tb;
create table tb(a int, b int, c varchar(50));
create index i1 on tb(a, c);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where b < 18;
select $dirty, a, b, c from tb;

-- case2.2 table has index but index is not used(physical delete, $dirty = 0):no delay delete 
drop table tb;
create table tb(a int, b int, c varchar(50));
create index idx on tb(a, b);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where b < 18 or a > 10;
select $dirty, a, b, c from tb;

-- case3.0 table has index and index is used(physical delete, $dirty = 0, not single row 
-- delete):do delay delete
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50));
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 15;
select $dirty, a, b, c from tb;

-- case3.1 table has index and index is used(physical delete, $dirty = 0):do delay delete
drop table tb;
create table tb(a int, b int, c varchar(50));
create index idx on tb(a, b);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 17;
select $dirty, a, b, c from tb;

-- case3.2 table has index and index is used(physical delete, $dirty = 0):do delay delete
drop table tb;
create table tb(a int, b int, c varchar(50));
create index idx on tb(a);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 15, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 17 and b = 15;
select $dirty, a, b, c from tb;

-- case3.3 table has index and index is used(physical delete, $dirty = 0):do delay delete
drop table tb;
create table tb(a int, b int, c varchar(50));
create index idx on tb(a, b);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 15, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 17 and b < 15;
select $dirty, a, b, c from tb;

-- case4.0 single row delete from table with primary key and for each key column 
-- there is an equal prediacate in the where clause(physical delete, $dirty = 0
-- index is used): no delay delete
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50));
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a = 12;
select $dirty, a, b, c from tb;

-- case4.1 single row delete from table with primary key but not for each key column 
-- there is an equal prediacate in the where clause(physical delete, $dirty = 0
-- index is used): delay delete
drop table tb;
create table tb(a int not null, b int not null, c varchar(20), primary key(a,b));
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(12, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a = 12 and b < 15;
select $dirty, a, b, c from tb;

-- case4.2 single row delete from table with primary key and for each key column 
-- there is an equal prediacate in the where clause(physical delete, $dirty = 0
-- index is used): no delay delete
drop table tb;
create table tb(a int not null, b int not null, c varchar(20), primary key(a,b));
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(12, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a = 12 and b = 20;
select $dirty, a, b, c from tb;

-- case5 logical delete($dirty = 0, index is used): no delay delete
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50));
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
DISABLE PHYSICAL DELETE;
delete from tb where a < 15;
ENABLE PHYSICAL DELETE;
select $dirty, a, b, c from tb;
ENABLE READ DELETED;
select $dirty, a, b, c from tb;
DISABLE READ DELETED;

-- case6 delete rows just inserted(physical delete, index used):do delay delete
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50));
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
select $dirty, a, b, c from tb;
delete from tb where a < 15;
select $dirty, a, b, c from tb;


-- case7 delete a row which is just inserted(logical delete, index used):do delay delete
DISABLE PHYSICAL DELETE;
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50));
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
select $dirty, a, b, c from tb;
delete from tb where a < 15;
select $dirty, a, b, c from tb;
ENABLE READ DELETED;
select $dirty, a, b from tb;
DISABLE READ DELETED;
ENABLE PHYSICAL DELETE;

--clean up
blastdb;

--restore system default behavior
DISABLE PHYSICAL DELETE;
DISABLE APPLICATION SET DIRTY;

-------------------------------------------------------------
-- group II test encrypted table, repeat above 8 scenarios --
-------------------------------------------------------------
connect to enctest2\ user db2e using db2e;
grant encrypt on database to "db2e" using "db2e" new "db2e";

ENABLE APPLICATION SET DIRTY;
ENABLE PHYSICAL DELETE;

-- case1 table doesn't have index(physical delete, $dirty = 0): no delay delete
drop table tb;
create table tb(a int, b int, c varchar(50)) with encryption;
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 13;
select $dirty, a, b, c from tb;

-- case2.0 table has index but index is not used(physical delete, $dirty = 0):no delay delete 
drop table tb;
create table tb(a int, b int, c varchar(50)) with encryption;
create index idx on tb(b);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 15;
select $dirty, a, b, c from tb;

-- case2.1 table has index but index is not used(physical delete, $dirty = 0):no delay delete 
drop table tb;
create table tb(a int, b int, c varchar(50)) with encryption;
create index i1 on tb(a, c);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where b < 18;
select $dirty, a, b, c from tb;

-- case2.2 table has index but index is not used(physical delete, $dirty = 0):no delay delete 
drop table tb;
create table tb(a int, b int, c varchar(50)) with encryption;
create index idx on tb(a, b);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where b < 18 or a > 10;
select $dirty, a, b, c from tb;

-- case3.0 table has index and index is used(physical delete, $dirty = 0, not single row 
-- delete):do delay delete
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50)) with encryption;
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 15;
select $dirty, a, b, c from tb;

-- case3.1 table has index and index is used(physical delete, $dirty = 0):do delay delete
drop table tb;
create table tb(a int, b int, c varchar(50)) with encryption;
create index idx on tb(a, b);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 17;
select $dirty, a, b, c from tb;

-- case3.2 table has index and index is used(physical delete, $dirty = 0):do delay delete
drop table tb;
create table tb(a int, b int, c varchar(50)) with encryption;
create index idx on tb(a);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 15, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 17 and b = 15;
select $dirty, a, b, c from tb;

-- case3.3 table has index and index is used(physical delete, $dirty = 0):do delay delete
drop table tb;
create table tb(a int, b int, c varchar(50)) with encryption;
create index idx on tb(a, b);
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 15, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a < 17 and b < 15;
select $dirty, a, b, c from tb;

-- case4.0 single row delete from table with primary key and for each key column 
-- there is an equal prediacate in the where clause(physical delete, $dirty = 0
-- index is used): no delay delete
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50)) with encryption;
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a = 12;
select $dirty, a, b, c from tb;

-- case4.1 single row delete from table with primary key but not for each key column 
-- there is an equal prediacate in the where clause(physical delete, $dirty = 0
-- index is used): delay delete
drop table tb;
create table tb(a int not null, b int not null, c varchar(20), primary key(a,b)) with encryption;
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(12, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a = 12 and b < 15;
select $dirty, a, b, c from tb;

-- case4.2 single row delete from table with primary key and for each key column 
-- there is an equal prediacate in the where clause(physical delete, $dirty = 0
-- index is used): no delay delete
drop table tb;
create table tb(a int not null, b int not null, c varchar(20), primary key(a,b)) with encryption;
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(12, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
delete from tb where a = 12 and b = 20;
select $dirty, a, b, c from tb;

-- case5 logical delete($dirty = 0, index is used): no delay delete
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50)) with encryption;
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
update tb set $dirty = 0;
select $dirty, a, b, c from tb;
DISABLE PHYSICAL DELETE;
delete from tb where a < 15;
ENABLE PHYSICAL DELETE;
select $dirty, a, b, c from tb;
ENABLE READ DELETED;
select $dirty, a, b, c from tb;
DISABLE READ DELETED;

-- case6 delete rows just inserted(physical delete, index used):do delay delete
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50)) with encryption;
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
select $dirty, a, b, c from tb;
delete from tb where a < 15;
select $dirty, a, b, c from tb;


-- case7 delete a row which is just inserted(logical delete, index used):do delay delete
DISABLE PHYSICAL DELETE;
drop table tb;
create table tb(a int not null primary key, b int, c varchar(50)) with encryption;
insert into tb values(10, 15, 'delay-delete-record1');
insert into tb values(12, 13, 'delay-delete-record2');
insert into tb values(15, 20, 'delay-delete-record3');
insert into tb values(18, 25, 'delay-delete-record4');
select $dirty, a, b, c from tb;
delete from tb where a < 15;
select $dirty, a, b, c from tb;
ENABLE READ DELETED;
select $dirty, a, b from tb;
DISABLE READ DELETED;
ENABLE PHYSICAL DELETE;

--clean up
blastdb;

--restore system default behavior
DISABLE PHYSICAL DELETE;
DISABLE APPLICATION SET DIRTY;
