--------------------------------------------------------------------------------
-- TEST FOR like optimization
--------------------------------------------------------------------------------

drop table likeopt1;

create table likeopt1
(
	name	varchar(20)
);

insert into likeopt1 values('Cliff');
insert into likeopt1 values('Cliff Leung');

select * from likeopt1 where name like 'C%';
select * from likeopt1 where name like 'Cliff%';
select * from likeopt1 where name like 'Cliff%ung';

create index iLO1 on likeopt1(name);

select * from likeopt1 where name like 'C%';
select * from likeopt1 where name like 'Cliff%';
select * from likeopt1 where name like 'Cliff%ung';

drop table likeopt1;

drop table t1;

create table t1 (c1 char(10), c2 varchar(10));
create index ix1 on t1 (c1);
select * from t1 where c1 like 'abcdefghijklmnopq%';

drop table t1;
