reorg table table3;
select c1 from table3 where c1 > 'abc';
select c1 from table3 where c1 < 'abc';
drop table table3;

-- test case for d6581
drop table x;
create table x (c1 int,c2 varchar(1000));
create index ixxx on x (c1);
insert into x values(1,'1');
insert into x values(10, '10');
insert into x values(2,'1111111111111111111111111');
insert into x values(3,'3');
insert into x values(4,'4');
insert into x values(20,'20');
delete from x where c1 = 2;
update x set c2 = '20202020202020' where c1=20;
delete from x where c1=1;
delete from x where c1=4;
reorg table x 0 0;
select * from x where c1=20;
drop table x;

-- test cases for d10730

CREATE TABLE T1 (A INT PRIMARY KEY, B VARCHAR(20));

AUTOCOMMIT OFF;

INSERT INTO T1 VALUES(1, 'eins');
INSERT INTO T1 VALUES(2, 'zwei');
INSERT INTO T1 VALUES(3, 'drei');
INSERT INTO T1 VALUES(4, 'vier');
INSERT INTO T1 VALUES(5, 'fuenf');
SELECT A FROM T1;

COMMIT;

DELETE FROM T1 WHERE A <= 3;

SELECT A FROM T1;
REORG TABLE T1 0 0;
ROLLBACK;
SELECT A FROM T1;
DROP TABLE T1;
COMMIT;
AUTOCOMMIT ON;
