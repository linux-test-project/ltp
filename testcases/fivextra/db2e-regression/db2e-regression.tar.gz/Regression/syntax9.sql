-- ----------------- FILE: SYNTAX9.SQL  -------------------
-- -                                                      - 
-- -          CHECK ALL STANDARD SQL SYNTAX ERROR         -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE PROJ;
DROP TABLE STAFF;
DROP TABLE TEST1;
DROP TABLE TEST2;
DROP TABLE TEST3;
DROP TABLE TEST4;
DROP TABLE TEST5;
DROP TABLE TEST6;
DROP TABLE TESTING;
DROP TABLE TESTING1;
DROP TABLE WORKS;
DROP TABLE BEANIE;