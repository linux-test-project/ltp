-- ------------------- FILE: CHAR2.SQL  -------------------
-- -                                                      - 
-- -      CHECK ALL ERROR IN "INSERT INTO" STATEMENT      -
-- -                                                      -
-- --------------------------------------------------------
--

-- ------------------  PERFORMANCE TEST  ------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2PT001  -----------------------
-- --------------------------------------------------------
-- INSERT INTO VALUE INTO "STAFF" TABLE  
-- UDB2 RESULT = SUCC

INSERT INTO STAFF VALUES ('E1','Alice',12,'Deale');
INSERT INTO STAFF VALUES ('E2','Betty',10,'Vienna');
INSERT INTO STAFF VALUES ('E3','Carmen',13,'Vienna');
INSERT INTO STAFF VALUES ('E4','Don',12,'Deale');
INSERT INTO STAFF VALUES ('E5','Ed',13,'Akron');

     
-- --------------------------------------------------------
-- -----------------------  2PT002  -----------------------
-- --------------------------------------------------------
-- INSERT INTO VALUE INTO "PROJ" TABLE  
-- UDB2 RESULT = SUCC

INSERT INTO PROJ VALUES  ('P1','MXSS','Design',10000,'Deale');
INSERT INTO PROJ VALUES  ('P2','CALM','Code',30000,'Vienna');
INSERT INTO PROJ VALUES  ('P3','SDP','Test',30000,'Tampa');
INSERT INTO PROJ VALUES  ('P4','SDP','Design',20000,'Deale');
INSERT INTO PROJ VALUES  ('P5','IRM','Test',10000,'Vienna');
INSERT INTO PROJ VALUES  ('P6','PAYR','Design',50000,'Deale');


-- --------------------------------------------------------
-- -----------------------  2PT003  -----------------------
-- --------------------------------------------------------
-- INSERT INTO VALUE INTO "WORKS" TABLE 
-- UDB2 RESULT = SUCC

INSERT INTO WORKS VALUES  ('E1','P1',40);
INSERT INTO WORKS VALUES  ('E1','P2',20);
INSERT INTO WORKS VALUES  ('E1','P3',80);
INSERT INTO WORKS VALUES  ('E1','P4',20);
INSERT INTO WORKS VALUES  ('E1','P5',12);
INSERT INTO WORKS VALUES  ('E1','P6',12);
INSERT INTO WORKS VALUES  ('E2','P1',40);
INSERT INTO WORKS VALUES  ('E2','P2',80);
INSERT INTO WORKS VALUES  ('E3','P2',20);
INSERT INTO WORKS VALUES  ('E4','P2',20);
INSERT INTO WORKS VALUES  ('E4','P4',40);
INSERT INTO WORKS VALUES  ('E4','P5',80);


-- --------------------------------------------------------
-- -----------------------  2PT004  -----------------------
-- --------------------------------------------------------
-- INSERT INTO VALUE INTO "TMP1" TABLE 
-- UDB2 RESULT = SUCC

INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(1, 'Pham006', 'Rony010', '100 Santa Teresa Blvd.     ', 'SJ010', 'AQ', 10017, 100000015, 
            '01/16/1975', '01/09/1990');
INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(2, 'Pham006', 'Jack004', '400 D-153 OFFICE AT STL IBM', 'LA011', 'AT', 10012, 100000000, 
            '01/13/1985', '01/02/1980');
INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(3, 'Sung003', 'Andy007', '400 Anza Ave. Room 207     ', 'LA001', 'AK', 10005, 100000014, 
            '01/10/1995', '01/13/1985');
INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(4, 'Pham011', 'Jack019', '400 Cottle Rd. Apt#207     ', 'LA001', 'AL', 10015, 100000013, 
            '01/15/1995', '01/11/1975');
INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(5, 'Wang019', 'Rony015', '100 Cottle Rd. Apt#207     ', 'SF012', 'AJ', 10008, 100000006, 
            '01/05/1995', '01/13/1985');
INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(6, 'Sung003', 'Jonh006', '100 Anza Ave. Room 207     ', 'SD019', 'AL', 10007, 100000000, 
            '01/16/1975', '01/13/1985');
INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(7, 'Sung008', 'Jonh006', '200 Santa Teresa Blvd.     ', 'SF002', 'AO', 10009, 100000009, 
            '01/04/1990', '01/07/1980');
INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(8, 'Pham001', 'Rony010', '400 D-153 OFFICE AT STL IBM', 'SJ005', 'AT', 10010, 100000013, 
            '01/14/1990', '01/10/1995');
INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(9, 'Leee005', 'Andy002', '300 D-153 OFFICE AT STL IBM', 'SF017', 'AQ', 10008, 100000000, 
            '01/19/1990', '01/17/1980');
INSERT INTO TMP1(InsID, OwnerLastName, OwnerFirstName, Address, City, State, Zip, Phone, StartDate, EndDate)
            VALUES(10, 'Leee000', 'Andy002', '100 Santa Teresa Blvd.     ', 'SF007', 'AP', 10016, 100000018, 
            '01/17/1980', '01/20/1995');


-- --------------------------------------------------------
-- -----------------------  2PT005  -----------------------
-- --------------------------------------------------------
-- CREATE "TMP2" TABLE WITH [PRIMARY KEY][NOT NULL] OPTION 
-- UDB2 RESULT = SUCC

INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(988, 1988, 'Wang009', 'Andy002', 'VW012', 'SE013', 'White013', 'LIC003', 10014, 'DUMM');
INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(989, 1989, 'Leee000', 'Than008', 'VW017', 'M5001', 'Red001', 'LIC019', 10018, 'DUMM');
INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(990, 1990, 'Pham001', 'Rony005', 'BMW015', 'EX009', 'White018', 'LIC004', 10003, 'FOOL');
INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(991, 1991, 'Pham001', 'Than008', 'VW012', 'M5006', 'Pink019', 'LIC016', 10013, 'STUPID');
INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(992, 1992, 'Wang019', 'Jonh006', 'BENZ013', 'SE013', 'Blue012', 'LIC014', 10009, 'FOOL');
INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(993, 1993, 'Wang014', 'Andy007', 'BMW000', 'EX004', 'Black015', 'LIC004', 10005, 'STUPID');
INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(994, 1994, 'Leee010', 'Jonh001', 'VW012', 'SC012', 'Red011', 'LIC008', 10010, 'DUMM');
INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(995, 1995, 'Pham011', 'Andy002', 'LX006', 'M5001', 'Red006', 'LIC017', 10000, 'STUPID');
INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(996, 1996, 'Sung003', 'Jonh016', 'LX001', 'SC007', 'Black000', 'LIC017', 10010, 'STUPID');
INSERT INTO TMP2(InsID, CaseID, EstLastName, EstFirstName, Maker, Model, Color, LIC, EstPrice, Comment)
           VALUES(997, 1997, 'Sung003', 'Rony010', 'BMW005', 'M5006', 'Pink004', 'LIC019', 10012, 'FOOL');


-- --------------------------------------------------------
-- -----------------------  2PT006  -----------------------
-- --------------------------------------------------------
-- CREATE "TMP4" TABLE WITH INTEGER DATA TYPE
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VALUES(1,'A');
INSERT INTO TMP4 VALUES(2,'B');
INSERT INTO TMP4 VALUES(3,'C');
INSERT INTO TMP4 VALUES(4,'D');
INSERT INTO TMP4 VALUES(5,'E');
INSERT INTO TMP4 VALUES(6,'F');



-- --------------------------------------------------------
-- ------------  SYNTAX ERROR TEST (SPELLING)  ------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2SP001  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "INSERT INTO"
-- UDB2 RESULT = 42601

INSET INTO TMP4 VALUES(101,'2SP001');


-- --------------------------------------------------------
-- -----------------------  2SP002  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "INTO"
-- UDB2 RESULT = 42601

INSERT IN TMP4 VALUES(101,'2SP002');


-- --------------------------------------------------------
-- -----------------------  2SP003  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "VALUES"
-- UDB2 RESULT = 42601

INSERT INTO TMP4 VALUE(101,'2SP003');



-- --------------------------------------------------------
-- -----  SYNTAX ERROR TEST (EXTRA OR MISSING WORD)  ------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2EW001  -----------------------
-- --------------------------------------------------------
-- WORD "INSERT INTO" IS MISSING
-- UDB2 RESULT = 42601

INTO TMP4 VALUES(102,'2EW001');


-- --------------------------------------------------------
-- -----------------------  2EW002  -----------------------
-- --------------------------------------------------------
-- WORD "INTO" IS MISSING
-- UDB2 RESULT = 42601

INSERT TMP4 VALUES(102,'2EW002');


-- --------------------------------------------------------
-- -----------------------  2EW003  -----------------------
-- --------------------------------------------------------
-- WORD "VALUES" IS MISSING
-- UDB2 RESULT = 42601

INSERT INTO TMP4(102,'2EW003');


-- --------------------------------------------------------
-- -----------------------  2EW004  -----------------------
-- --------------------------------------------------------
-- TABLE NAME IS MISSING
-- UDB2 RESULT = 42601

INSERT INTO VALUES(102,'2EW004');


-- --------------------------------------------------------
-- -----------------------  2EW005  -----------------------
-- --------------------------------------------------------
-- ONE COLUMN NAME IS MISSING
-- UDB2 RESULT = 42802

INSERT INTO TMP4(Description) VALUES(102,'2EW005');


-- --------------------------------------------------------
-- -----------------------  2EW006  -----------------------
-- --------------------------------------------------------
-- ONE VALUE EXPRESSION IS MISSING
-- UDB2 RESULT = 42802

INSERT INTO TMP4 VALUES('2EW006');


-- --------------------------------------------------------
-- -----------------------  2EW007  -----------------------
-- --------------------------------------------------------
-- BOTH COLUMN NAME AND VALUE EXPRESSION ARE MISSING
-- UDB2 RESULT = SUCC

INSERT INTO TMP4(Description) VALUES('2EW007');


-- --------------------------------------------------------
-- -----------------------  2EW008  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "INSERT INTO"
-- UDB2 RESULT = 42601

FAILED INSERT INTO TMP4 VALUES(102,'2EW008');


-- --------------------------------------------------------
-- -----------------------  2EW009  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "INTO"
-- UDB2 RESULT = 42601

INSERT FAILED INTO TMP4 VALUES(102,'2EW009');


-- --------------------------------------------------------
-- -----------------------  2EW010  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF TABLE NAME
-- UDB2 RESULT = 42601

INSERT INTO FAILED TMP4 VALUES(102,'2EW010');


-- --------------------------------------------------------
-- -----------------------  2EW011  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF FIRST BRACKET
-- UDB2 RESULT = 42601

INSERT INTO TMP4 FAILED(Percentage, Description) VALUES(102,'2EW011');


-- --------------------------------------------------------
-- -----------------------  2EW012  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN COLUMN NAME
-- UDB2 RESULT = 42703

INSERT INTO TMP4(Percentage, Description, FAILED)  VALUES(102,'2EW012');


-- --------------------------------------------------------
-- -----------------------  2EW013  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "VALUES"
-- UDB2 RESULT = 42601

INSERT INTO TMP4 FAILED VALUES(102,'2EW013');


-- --------------------------------------------------------
-- -----------------------  2EW014  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" INSIDE "VALUES"
-- UDB2 RESULT = 42802

INSERT INTO TMP4 VALUES(102,'2EW014', 'FAILED');


-- --------------------------------------------------------
-- -----------------------  2EW015  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" AFTER SECOND BRACKET
-- UDB2 RESULT = 42601

INSERT INTO TMP4 VALUES(102,'2EW015') FAILED;



-- --------------------------------------------------------
-- --------  SYNTAX ERROR TEST (BRACKET MISSING)  ---------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2BM001  -----------------------
-- --------------------------------------------------------
-- FIRST BRACKET IS MISSING
-- UDB2 RESULT = 42601

INSERT INTO TMP4Percentage, Description) VALUES(103,'2BM001');


-- --------------------------------------------------------
-- -----------------------  2BM002  -----------------------
-- --------------------------------------------------------
-- LAST BRACKET IS MISSING
-- UDB2 RESULT = 42601

INSERT INTO TMP4(Percentage, Description) VALUES(103,'2BM002';


-- --------------------------------------------------------
-- -----------------------  2BM003  -----------------------
-- --------------------------------------------------------
-- FIRST SET OF BRACKET IS MISSING
-- UDB2 RESULT = 42601

INSERT INTO TMP4Percentage, Description VALUES(103,'2BM003');


-- --------------------------------------------------------
-- -----------------------  2BM004  -----------------------
-- --------------------------------------------------------
-- SECOND SET OF BRACKET IS MISSING
-- UDB2 RESULT = 42601

INSERT INTO TMP4(Percentage, Description) VALUES103,'2BM004';


-- --------------------------------------------------------
-- -----------------------  2BM005  -----------------------
-- --------------------------------------------------------
-- NO BRACKET IN "INSERT INTO" STATEMENT
-- UDB2 RESULT = 42601

INSERT INTO TMP4Percentage, Description VALUES103,'2BM005';


-- --------------------------------------------------------
-- -----------------------  2BM006  -----------------------
-- --------------------------------------------------------
-- EXTRA BRACKET IN FRONT OF FIRST BRACKET
-- UDB2 RESULT = 42601

INSERT INTO TMP4((Percentage, Description) VALUES(103,'2BM006');


-- --------------------------------------------------------
-- -----------------------  2BM007  -----------------------
-- --------------------------------------------------------
-- TWO EXTRA BRACKET AT THE END OF STATEMENT
-- UDB2 RESULT = 42601

INSERT INTO TMP4(Percentage, Description) VALUES(103,'2BM007')));


-- --------------------------------------------------------
-- -----------------------  2BM008  -----------------------
-- --------------------------------------------------------
-- SPACES BETWEEN BRACKET AND TABLE NAME
-- UDB2 RESULT = SUCC

INSERT INTO TMP4    (Percentage, Description) VALUES(103,'2BM008');


-- --------------------------------------------------------
-- -----------------------  2BM009  -----------------------
-- --------------------------------------------------------
-- SPACES BETWEEN BRACKET AND FIRST COLUMN NAME
-- UDB2 RESULT = SUCC

INSERT INTO TMP4(    Percentage, Description) VALUES(103,'2BM009');


-- --------------------------------------------------------
-- -----------------------  2BM010  -----------------------
-- --------------------------------------------------------
-- SPACES BETWEEN "VALUES" AND BRACKET
-- UDB2 RESULT = SUCC

INSERT INTO TMP4(Percentage, Description) VALUES    (103,'2BM010');


-- --------------------------------------------------------
-- -----------------------  2BM011  -----------------------
-- --------------------------------------------------------
-- SPACES BETWEEN BRACKET AND BRACKET AFTER VALUES
-- UDB2 RESULT = SUCC

INSERT INTO TMP4(Percentage, Description) VALUES(    103,'2BM011');



-- --------------------------------------------------------
-- ---------  SYNTAX ERROR TEST (CASE SENSITIVE)  ---------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2CS001  -----------------------
-- --------------------------------------------------------
-- CHECK IF "INSERT INTO" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VALUES(104,'2CS001');


-- --------------------------------------------------------
-- -----------------------  2CS002  -----------------------
-- --------------------------------------------------------
-- CHECK IF "INTO" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VALUES(104,'2CS002');


-- --------------------------------------------------------
-- -----------------------  2CS003  -----------------------
-- --------------------------------------------------------
-- CHECK IF "VALUES" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VaLuEs(104,'2CS003');


-- --------------------------------------------------------
-- -----------------------  2CS004  -----------------------
-- --------------------------------------------------------
-- CHECK IF TABLE NAME IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

INSERT INTO TmP4 VALUES(104,'2CS004');


-- --------------------------------------------------------
-- -----------------------  2CS005  -----------------------
-- --------------------------------------------------------
-- CHECK IF COLUMN NAME IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

INSERT INTO TMP4(pERCENTAGE, dESCRIPTION) VALUES(104,'2CS005');


-- --------------------------------------------------------
-- -----------------------  2CS006  -----------------------
-- --------------------------------------------------------
-- CHECK IF VALUE EXPRESSION IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VALUES(104,'2CS006');
INSERT INTO TMP4 VALUES(104,'2cs006');



-- --------------------------------------------------------
-- ---------  SYNTAX ERROR TEST (WRONG COMMAND)  ----------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2WC001  -----------------------
-- --------------------------------------------------------
-- REPLACE "INSERT INTO" WITH "CREATE TABLE"
-- UDB2 RESULT = 42601

CREATE TABLE TMP4 VALUES(105,'2WC001');


-- --------------------------------------------------------
-- -----------------------  2WC002  -----------------------
-- --------------------------------------------------------
-- REPLACE "INSERT INTO" WITH "SELECT"
-- UDB2 RESULT = 42601

SELECT TMP4 VALUES(105,'2WC002');


-- --------------------------------------------------------
-- -----------------------  2WC003  -----------------------
-- --------------------------------------------------------
-- REPLACE "INSERT INTO" WITH "DELETE"
-- UDB2 RESULT = 42601

DELETE TMP4 VALUES(105,'2WC003');


-- --------------------------------------------------------
-- -----------------------  2WC004  -----------------------
-- --------------------------------------------------------
-- REPLACE "INSERT INTO" WITH "UPDATE"
-- UDB2 RESULT = 42601

UPDATE TMP4 VALUES(105,'2WC004');


-- --------------------------------------------------------
-- -----------------------  2WC005  -----------------------
-- --------------------------------------------------------
-- REPLACE "INSERT INTO" WITH "DROP"
-- UDB2 RESULT = 42601

DROP TMP4 VALUES(105,'2WC005');




-- --------------------------------------------------------
-- -----------------  SEMATIC ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2ST001  -----------------------
-- --------------------------------------------------------
-- INSERT UNKNOWN TABLE NAME
-- UDB2 RESULT = 42704

INSERT INTO TMP5 VALUES(106,'2ST001');


-- --------------------------------------------------------
-- -----------------------  2ST002  -----------------------
-- --------------------------------------------------------
-- INSERT UNKNOWN COLUMN NAME
-- UDB2 RESULT = 42703

INSERT INTO TMP4(FAILED, Description) VALUES(106,'2ST002');


-- --------------------------------------------------------
-- -----------------------  2ST003  -----------------------
-- --------------------------------------------------------
-- PASS CHAR WHEN INT IS THE INTENDED PARAMETER
-- UDB2 RESULT = 42821

INSERT INTO TMP4 VALUES('106','2ST003');


-- --------------------------------------------------------
-- -----------------------  2ST004  -----------------------
-- --------------------------------------------------------
-- PASS INT WHEN CHAR IS THE INTENDED PARAMETER
-- UDB2 RESULT = 42821

INSERT INTO TMP4 VALUES(106, 4);


-- --------------------------------------------------------
-- -----------------------  2ST005  -----------------------
-- --------------------------------------------------------
-- PASS CHAR WITHOUT QUOTATION MARK
-- UDB2 RESULT = 42604

INSERT INTO TMP4 VALUES(106, 2ST005);


-- --------------------------------------------------------
-- -----------------------  2ST006  -----------------------
-- --------------------------------------------------------
-- PASS 3 MORE VALUE THAN COLUMN NAME
-- UDB2 RESULT = 42802

INSERT INTO TMP4 VALUES(106,'2ST006', 6, 'FAILED', 4);


-- --------------------------------------------------------
-- -----------------------  2ST007  -----------------------
-- --------------------------------------------------------
-- PASS MORE CHAR THAN CHAR CONSTRAINTED
-- REFER TO 2LT004


-- --------------------------------------------------------
-- -----------------------  2ST008  -----------------------
-- --------------------------------------------------------
-- INSERT ONE LESS COLUMN THAN ORIGINAL TABLE.
-- REFER TO 2EW007

-- --------------------------------------------------------
-- -----------------------  2ST009  -----------------------
-- --------------------------------------------------------
-- INSERT NULL IN PRIMARY KEY 
-- UDB2 RESULT = 23502

CREATE TABLE TMP5
 (ID     INT NOT NULL PRIMARY KEY,
  CAL2   INT NOT NULL, 
  TITLE  CHAR(25));

INSERT INTO TMP5 VALUES(1, 101, '2ST009');
INSERT INTO TMP5 VALUES(NULL, 101, '2ST009');

SELECT * FROM TMP5;


-- --------------------------------------------------------
-- -----------------------  2ST010  -----------------------
-- --------------------------------------------------------
-- INSERT NOTHING IN PRIMARY KEY
-- UDB2 RESULT = SUCC

CREATE TABLE TMP6
 (ID     CHAR(5) PRIMARY KEY NOT NULL,
  CAL2   CHAR(5) NOT NULL, 
  TITLE  CHAR(25));

INSERT INTO TMP6 VALUES('1', '101', '2ST010');
INSERT INTO TMP6 VALUES('', '101', '2ST010');

SELECT * FROM TMP6;


-- --------------------------------------------------------
-- -----------------------  2ST011  -----------------------
-- --------------------------------------------------------
-- INSERT NOTHING IN PRIMARY KEY
-- UDB2 RESULT = 42601

INSERT INTO TMP5 VALUES(, 101, '2ST011');
INSERT INTO TMP6 VALUES(, '101', '2ST011');

SELECT * FROM TMP5;
SELECT * FROM TMP6;

-- --------------------------------------------------------
-- -----------------------  2ST012  -----------------------
-- --------------------------------------------------------
-- INSERT IDENTICAL "PRIMARY KEY"
-- UDB2 RESULT = 23505

INSERT INTO TMP6 VALUES('1', '101', '2ST012');

SELECT * FROM TMP6;


-- --------------------------------------------------------
-- -----------------------  2ST013  -----------------------
-- --------------------------------------------------------
-- INSERT IDENTICAL "NOT NULL PRIMARY KEY"
-- UDB2 RESULT = 23505

INSERT INTO TMP5 VALUES(1, 101, '2ST013');

SELECT * FROM TMP5;

-- --------------------------------------------------------
-- -----------------------  2ST014  -----------------------
-- --------------------------------------------------------
-- INSERT NULL IN NOT NULL COLUMN 
-- UDB2 RESULT = 23502

INSERT INTO TMP5 VALUES(2, NULL, '2ST014');
INSERT INTO TMP6 VALUES('2', NULL, '2ST014');

SELECT * FROM TMP5;
SELECT * FROM TMP6;


-- --------------------------------------------------------
-- -----------------------  2ST015  -----------------------
-- --------------------------------------------------------
-- INSERT '' IN NULL COLUMN
-- UDB2 RESULT = SUCC

INSERT INTO TMP6 VALUES('3', '', '2ST015');

SELECT * FROM TMP6;

-- --------------------------------------------------------
-- -----------------------  2ST016  -----------------------
-- --------------------------------------------------------
-- INSERT NOTHING IN NOT NULL COLUMN
-- UDB2 RESULT = 42601

INSERT INTO TMP5 VALUES(4, , '2ST016');
INSERT INTO TMP6 VALUES('4', , '2ST016');

SELECT * FROM TMP5;
SELECT * FROM TMP6;

-- --------------------------------------------------------
-- -----------------------  2ST017  -----------------------
-- --------------------------------------------------------
-- INSERT IDENTICAL VALUE IN NOT NULL COLUMN 
-- UDB2 RESULT = SUCC

INSERT INTO TMP5 VALUES(5, 105, '2ST017');
INSERT INTO TMP5 VALUES(6, 105, '2ST017');

INSERT INTO TMP6 VALUES('5', '105', '2ST017');
INSERT INTO TMP6 VALUES('6', '105', '2ST017');

SELECT * FROM TMP5;
SELECT * FROM TMP6;


-- --------------------------------------------------------
-- -----------------------  2ST018  -----------------------
-- --------------------------------------------------------
-- INSERT TWO IDENTICAL RECORDS 
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VALUES(106, '2ST018');
INSERT INTO TMP4 VALUES(106, '2ST018');

SELECT * FROM TMP4;



-- ----------------  RUN-TIME ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2RT001  -----------------------
-- --------------------------------------------------------
-- TO BE DETERMINED



-- --------------------------------------------------------
-- ------------------  LIMITATION TEST  -------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2LT001  -----------------------
-- --------------------------------------------------------
-- WITHIN NUMBER OF CHARACTER ALLOWED IN "INT"
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VALUES(2147483646,'2LT001');
INSERT INTO TMP4 VALUES(-2147483646,'2LT001');


-- --------------------------------------------------------
-- -----------------------  2LT002  -----------------------
-- --------------------------------------------------------
-- EXACT NUMBER OF CHARACTER ALLOWED IN "INT"
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VALUES(2147483647,'2LT001');
INSERT INTO TMP4 VALUES(-2147483647,'2LT001');

-- --------------------------------------------------------
-- -----------------------  2LT003  -----------------------
-- --------------------------------------------------------
-- EXCEED NUMBER OF CHARACTER ALLOWED IN "INT"
-- UDB2 RESULT = 22003

INSERT INTO TMP4 VALUES(2147483648,'2LT001');
INSERT INTO TMP4 VALUES(-2147483649,'2LT001');

-- --------------------------------------------------------
-- -----------------------  2LT004  -----------------------
-- --------------------------------------------------------
-- WITHIN NUMBER OF CHARACTER ALLOWED IN "CHAR(N)"
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VALUES(107,'2LT004WithinVarchar(25)');


-- --------------------------------------------------------
-- -----------------------  2LT005  -----------------------
-- --------------------------------------------------------
-- EXACT NUMBER OF CHARACTER ALLOWED IN "CHAR(N)"
-- UDB2 RESULT = SUCC

INSERT INTO TMP4 VALUES(107,'2LT005ExactHasVarchar(25)');


-- --------------------------------------------------------
-- -----------------------  2LT006  -----------------------
-- --------------------------------------------------------
-- EXCEED NUMBER OF CHARACTER ALLOWED IN "CHAR(N)"
-- UDB2 RESULT = 22001

INSERT INTO TMP4 VALUES(107,'2LT007ExceedHasVarchar(25)');


-- --------------------------------------------------------
-- -----------------------  2LT007  -----------------------
-- -----------------------  2LT008  -----------------------
-- -----------------------  2LT009  -----------------------
-- --------------------------------------------------------
-- ---------------  REFER TO 2LT001.SQL FILE  -------------
-- --------------------------------------------------------
--

-- --------------------------------------------------------
-- CHECKING RESULT


SELECT * FROM STAFF;
SELECT * FROM PROJ;
SELECT * FROM WORKS;

SELECT * FROM TMP4;
DELETE FROM TMP4 WHERE Description LIKE '2%';
SELECT * FROM TMP4;

SELECT * FROM TMP5;
DROP TABLE TMP5;
SELECT * FROM TMP6;
DROP TABLE TMP6;
