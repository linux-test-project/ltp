-- ---------------- FILE: DECIMAL3.SQL  -------------------
-- -                                                      - 
-- -        CHECK ALL ERROR IN "SELECT" STATEMENT         -
-- -                                                      -
-- --------------------------------------------------------
--

-- ------------------  PERFROMMANCE TEST  ------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3PT001  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM "STAFF" TABLE  
-- UDB2 RESULT = SUCC

SELECT * FROM STAFF;
     
-- --------------------------------------------------------
-- -----------------------  3PT002  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM "PROJ" TABLE  
-- UDB2 RESULT = SUCC

SELECT * FROM PROJ;


-- --------------------------------------------------------
-- -----------------------  3PT003  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM "WORKS" TABLE 
-- UDB2 RESULT = SUCC

SELECT * FROM WORKS;


-- --------------------------------------------------------
-- -----------------------  3PT004  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM "TMP1" TABLE 
-- UDB2 RESULT = SUCC

SELECT * FROM TMP1;


-- --------------------------------------------------------
-- -----------------------  3PT005  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM FROM "TMP2" TABLE
-- UDB2 RESULT = SUCC

SELECT * FROM TMP2;


-- --------------------------------------------------------
-- -----------------------  3PT006  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM FROM "TMP4" TABLE
-- UDB2 RESULT = SUCC

SELECT * FROM TMP4;


-- --------------------------------------------------------
-- ------------  SYNTAX ERROR TEST (SPELLING)  ------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3SP001  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "SELECT"
-- UDB2 RESULT = SUCC, 42601


SELECT * FROM STAFF;
SELECE * FROM STAFF;


-- --------------------------------------------------------
-- -----------------------  3SP002  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "FROM"
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF;
SELECT * FOR STAFF;


-- --------------------------------------------------------
-- -----------------------  3SP003  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "AND"
-- UDB2 RESULT = SUCC, 42601 (E4)

SELECT * FROM STAFF WHERE Grade = 12 AND EmpNum = 'E4';
SELECT * FROM STAFF WHERE Grade = 12 AN EmpNum = 'E4';


-- --------------------------------------------------------
-- -----------------------  3SP004  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "AND NOT"
-- UDB2 RESULT = SUCC, 42601 (E1)

SELECT * FROM STAFF WHERE Grade = 12 AND NOT EmpNum = 'E4';
SELECT * FROM STAFF WHERE Grade = 12 AND NO EmpNum = 'E4';


-- --------------------------------------------------------
-- -----------------------  3SP005  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "OR"
-- UDB2 RESULT = SUCC, 42601 (E1, E2, E4)

SELECT * FROM STAFF WHERE Grade = 12 OR EmpNum = 'E2';
SELECT * FROM STAFF WHERE Grade = 12 OP EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3SP006  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "OR NOT"
-- UDB2 RESULT = SUCC, 42601 (E1, E3, E4, E5)

SELECT * FROM STAFF WHERE Grade = 12 OR NOT EmpNum = 'E2';
SELECT * FROM STAFF WHERE Grade = 12 OR NO EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3SP007  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "IS NULL"
-- UDB2 RESULT = SUCC, 42601 (0 SELECTED)

SELECT * FROM STAFF WHERE Grade IS NULL;
SELECT * FROM STAFF WHERE Grade IS NOLL;


-- --------------------------------------------------------
-- -----------------------  3SP008  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "IS NOT NULL"
-- UDB2 RESULT = SUCC, 42601 (5 SELECTED)

SELECT * FROM STAFF WHERE Grade IS NOT NULL;
SELECT * FROM STAFF WHERE Grade IS NO NULL;


-- --------------------------------------------------------
-- -----------------------  3SP009  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "LIKE"
-- UDB2 RESULT = SUCC, 42601 (E2)

SELECT * FROM STAFF WHERE EmpNum LIKE 'E2';
SELECT * FROM STAFF WHERE EmpNum LOVE 'E2';


-- --------------------------------------------------------
-- -----------------------  3SP010  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "NOT LIKE"
-- UDB2 RESULT = SUCC, 42601 (E1, E3, E4, E5)

SELECT * FROM STAFF WHERE EmpNum NOT LIKE 'E2';
SELECT * FROM STAFF WHERE EmpNum NO LIKE 'E2';


-- --------------------------------------------------------
-- -----------------------  3SP011  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "AS"
-- UDB2 RESULT = SUCC, 42601 (E2)

SELECT * FROM STAFF AS LABOR WHERE EmpNum = 'E2';
SELECT * FROM STAFF A LABOR WHERE EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3SP012  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "DISTINCT"
-- UDB2 RESULT = 42703 (E1, E2, E4)

SELECT DISTINCT Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2';
SELECT DISTNCT Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2';



-- --------------------------------------------------------
-- -----------------------  3SP013  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "WHERE"
-- UDB2 RESULT = SUCC, 42601 (E1, E4)

SELECT * FROM STAFF WHERE Grade = 12;
SELECT * FROM STAFF WERE Grade = 12;


-- --------------------------------------------------------
-- -----------------------  3SP014  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "ORDER"
-- UDB2 RESULT = SUCC, 42601 (5 SELECTED)

SELECT * FROM STAFF ORDER BY Grade;
SELECT * FROM STAFF ODER BY Grade;


-- --------------------------------------------------------
-- -----------------------  3SP015  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "ORDER BY"
-- UDB2 RESULT = SUCC, 42601 (5 SELECTED)

SELECT * FROM STAFF ORDER BY Grade;
SELECT * FROM STAFF ORDER Grade;





-- --------------------------------------------------------
-- -----  SYNTAX ERROR TEST (EXTRA OR MISSING WORD)  ------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3EW001  -----------------------
-- --------------------------------------------------------
-- WORD "SELECT" IS MISSING
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF;
* FROM STAFF;


-- --------------------------------------------------------
-- -----------------------  3EW002  -----------------------
-- --------------------------------------------------------
-- WORD "FROM" IS MISSING
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF;
SELECT * STAFF;


-- --------------------------------------------------------
-- -----------------------  3EW003  -----------------------
-- --------------------------------------------------------
-- ONE TABLE NAME IS MISSING
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade = 12 AND EmpNum = 'E4';
SELECT * FROM WHERE Grade = 12 AND EmpNum = 'E4';


-- --------------------------------------------------------
-- -----------------------  3EW004  -----------------------
-- --------------------------------------------------------
-- ONE TABLE NAME IS MISSING (WITH AS OPTION)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF AS LABOR WHERE EmpNum = 'E2';
SELECT * FROM STAFF AS WHERE EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3EW005  -----------------------
-- --------------------------------------------------------
-- ONE COLUMN NAME IS MISSING (SELECT COLUMN)
-- UDB2 RESULT = SUCC, 42601


SELECT * FROM STAFF AS LABOR WHERE EmpNum = 'E2';
SELECT FROM STAFF AS LABOR WHERE EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3EW006  -----------------------
-- --------------------------------------------------------
-- ONE COLUMN NAME IS MISSING (SEARCH STATEMENT 1)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF AS LABOR WHERE EmpNum = 'E2';
SELECT * FROM STAFF AS LABOR WHERE = 'E2';


-- --------------------------------------------------------
-- -----------------------  3EW007  -----------------------
-- --------------------------------------------------------
-- ONE COLUMN NAME IS MISSING (SEARCH STATEMENT 2)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade IS NOT NULL;
SELECT * FROM STAFF WHERE IS NOT NULL;


-- --------------------------------------------------------
-- -----------------------  3EW008  -----------------------
-- --------------------------------------------------------
-- ONE COLUMN NAME IS MISSING (SEARCH STATEMENT 3)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade = 12 AND EmpNum = 'E4';
SELECT * FROM STAFF WHERE Grade = 12 AND  = 'E4';

-- --------------------------------------------------------
-- -----------------------  3EW009  -----------------------
-- --------------------------------------------------------
-- EXTRA "," AFTER LAST COLUMN NAME SELECTED
-- UDB2 RESULT = SUCC, 42601

SELECT EmpNum, Grade FROM STAFF WHERE Grade = 12 AND EmpNum = 'E4';
SELECT EmpNum, Grade, FROM STAFF WHERE Grade = 12 AND EmpNum = 'E4';



-- --------------------------------------------------------
-- -----------------------  3EW010  -----------------------
-- --------------------------------------------------------
-- WORD "AND" IS MISSING (SEARCHCOND1)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade = 12 AND EmpNum = 'E4';
SELECT * FROM STAFF WHERE Grade = 12 EmpNum = 'E4';


-- --------------------------------------------------------
-- -----------------------  3EW011  -----------------------
-- --------------------------------------------------------
-- WORD "IS NULL" IS MISSING (SEARCHCOND2)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade IS NOT NULL;
SELECT * FROM STAFF WHERE Grade;


-- --------------------------------------------------------
-- -----------------------  3EW012  -----------------------
-- --------------------------------------------------------
-- WORD "LIKE" IS MISSING (SEARCHOP)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE EmpNum LIKE 'E2';
SELECT * FROM STAFF WHERE EmpNum 'E2';


-- --------------------------------------------------------
-- -----------------------  3EW013  -----------------------
-- --------------------------------------------------------
-- SEARCH OPERATOR IS MISSING (COMPARISON PREDICATE)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade < 12;
SELECT * FROM STAFF WHERE Grade 12;


-- --------------------------------------------------------
-- -----------------------  3EW014  -----------------------
-- --------------------------------------------------------
-- ONE SEARCH VALUE EXPRESSION IS MISSING (SS1)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE EmpNum LIKE 'E2';
SELECT * FROM STAFF WHERE EmpNum LIKE;


-- --------------------------------------------------------
-- -----------------------  3EW015  -----------------------
-- --------------------------------------------------------
-- ONE SEARCH VALUE EXPRESSION IS MISSING (SS2)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade IS NOT NULL;
SELECT * FROM STAFF WHERE IS NOT NULL;


-- --------------------------------------------------------
-- -----------------------  3EW016  -----------------------
-- --------------------------------------------------------
-- ONE SEARCH VALUE EXPRESSION IS MISSING (SS3)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade = 12 AND EmpNum = 'E4';
SELECT * FROM STAFF WHERE Grade = 12 AND EmpNum =;


-- --------------------------------------------------------
-- -----------------------  3EW017  -----------------------
-- --------------------------------------------------------
-- WORD "AS" IS MISSING
-- UDB2 RESULT = SUCC

SELECT * FROM STAFF AS LABOR WHERE EmpNum = 'E2';
SELECT * FROM STAFF LABOR WHERE EmpNum = 'E2';

-- --------------------------------------------------------
-- -----------------------  3EW018  -----------------------
-- --------------------------------------------------------
-- WORD "DISTINCT" IS MISSING
-- UDB2 RESULT = SUCC

SELECT DISTINCT Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2';
SELECT Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2';



-- --------------------------------------------------------
-- -----------------------  3EW019  -----------------------
-- --------------------------------------------------------
-- WORD "WHERE" IS MISSING
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade < 12;
SELECT * FROM STAFF Grade < 12;


-- --------------------------------------------------------
-- -----------------------  3EW020  -----------------------
-- --------------------------------------------------------
-- WORD "ORDER" IS MISSING
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF ORDER BY Grade;
SELECT * FROM STAFF BY Grade;


-- --------------------------------------------------------
-- -----------------------  3EW021  -----------------------
-- --------------------------------------------------------
-- WORD "ORDER BY" IS MISSING
-- UDB2 RESULT = SUCC, 42601

SELECT Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2' ORDER BY Grade;
SELECT Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2' Grade;


-- --------------------------------------------------------
-- -----------------------  3EW022  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "SELECT"
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF;
FAILED SELECT * FROM STAFF;


-- --------------------------------------------------------
-- -----------------------  3EW023  -----------------------
-- --------------------------------------------------------
--EXTRA WORD "FAILED" IN FRONT OF "DISTINCT"
-- UDB2 RESULT = SUCC, 42601

SELECT DISTINCT Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2';
SELECT FAILED DISTINCT Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2';


-- --------------------------------------------------------
-- -----------------------  3EW024  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF SELECT COLUMN
-- UDB2 RESULT = 42601, 42703

SELECT FAILED * FROM STAFF;
SELECT FAILED GRADE FROM STAFF;


-- --------------------------------------------------------
-- -----------------------  3EW025  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "FROM"
-- UDB2 RESULT = 42601, SUCC
-- DB2E RESULT = 42601, 42601

SELECT * FAILED FROM STAFF;
SELECT GRADE FAILED FROM STAFF;

-- --------------------------------------------------------
-- -----------------------  3EW026  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF TABLE NAME
-- UDB2 RESULT = SUCC, 42704

SELECT * FROM STAFF WHERE Grade IS NOT NULL;
SELECT * FROM FAILED STAFF WHERE Grade IS NOT NULL;


-- --------------------------------------------------------
-- -----------------------  3EW027  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "AS"
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF AS LABOR WHERE EmpNum = 'E2';
SELECT * FROM STAFF FAILED AS LABOR WHERE EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3EW028  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF TABLE NAME
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF AS LABOR WHERE EmpNum = 'E2';
SELECT * FROM STAFF AS FAILED LABOR WHERE EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3EW029  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "WHERE"
-- UDB2 RESULT = 42601, 42601

SELECT * FROM STAFF AS LABOR FAILED WHERE EmpNum = 'E2';
SELECT * FROM STAFF FAILED WHERE IS NOT NULL;


-- --------------------------------------------------------
-- -----------------------  3EW030  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "ORDER BY"
-- UDB2 RESULT = 42601, SUCC

SELECT Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2' FAILED ORDER BY Grade;
SELECT Grade FROM STAFF FAILED ORDER BY Grade;


-- --------------------------------------------------------
-- -----------------------  3EW031  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "ORDER BY"
-- NO TEST


-- --------------------------------------------------------
-- -----------------------  3EW032  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF COLUMN NAME
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade IS NOT NULL;
SELECT * FROM STAFF WHERE FAILED Grade IS NOT NULL;


-- --------------------------------------------------------
-- -----------------------  3EW033  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "LIKE"
-- UDB2 RESULT = SUCC, 42601

SELECT DISTINCT Grade FROM STAFF WHERE EmpNum LIKE 'E2';
SELECT DISTINCT Grade FROM STAFF WHERE EmpNum FAILED LIKE 'E2';


-- --------------------------------------------------------
-- -----------------------  3EW034  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF Comparison Predicator
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade < 12;
SELECT * FROM STAFF WHERE Grade FAILED < 12;


-- --------------------------------------------------------
-- -----------------------  3EW035  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF Search Values
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade < 12;
SELECT * FROM STAFF WHERE Grade < FAILED 12;


-- --------------------------------------------------------
-- -----------------------  3EW036  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF Column Name (SS2)
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade IS NOT NULL;
SELECT * FROM STAFF WHERE Grade FAILED IS NOT NULL;


-- --------------------------------------------------------
-- -----------------------  3EW037  -----------------------
-- --------------------------------------------------------
-- EXTRA WORD "FAILED" IN FRONT OF "AND"
-- UDB2 RESULT = SUCC, 42601

SELECT * FROM STAFF WHERE Grade = 12 AND EmpNum = 'E4';
SELECT * FROM STAFF WHERE Grade = 12 FAILED AND EmpNum = 'E4';




-- --------------------------------------------------------
-- ------  SYNTAX ERROR TEST (SEARCHING CONDITION) --------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3SC001  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (=) (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (2 SELECTED)

SELECT * FROM STAFF WHERE Grade = 12;


-- --------------------------------------------------------
-- -----------------------  3SC002  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (<) (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (1 SELECTED)

SELECT * FROM STAFF WHERE Grade < 12;


-- --------------------------------------------------------
-- -----------------------  3SC003  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (<=) (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (3 SELECTED)

SELECT * FROM STAFF WHERE Grade <= 12;


-- --------------------------------------------------------
-- -----------------------  3SC004  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (>) (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (2 SELECTED)

SELECT * FROM STAFF WHERE Grade > 12;


-- --------------------------------------------------------
-- -----------------------  3SC005  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (>=) (DATA TYPE DECIMAL)
-- UDB2 RESULT =  SUCC (4 SELECTED)

SELECT * FROM STAFF WHERE Grade >= 12;


-- --------------------------------------------------------
-- -----------------------  3SC006  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (<>) (DATA TYPE DECIMAL)
-- UDB2 RESULT =  SUCC (3 SELECTED)

SELECT * FROM STAFF WHERE Grade <> 12;


-- --------------------------------------------------------
-- -----------------------  3SC007  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (=) (DATA TYPE VARCHAR(N))
-- UDB2 RESULT =  SUCC (1 SELECTED)

SELECT * FROM STAFF WHERE EmpNum = 'E3';


-- --------------------------------------------------------
-- -----------------------  3SC008  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (<) (DATA TYPE VARCHAR(N))
-- UDB2 RESULT =  SUCC (2 SELECTED)

SELECT * FROM STAFF WHERE EmpNum < 'E3';


-- --------------------------------------------------------
-- -----------------------  3SC009  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (<=) (DATA TYPE VARCHAR(N))
-- UDB2 RESULT =  SUCC (3 SELECTED)

SELECT * FROM STAFF WHERE EmpNum <= 'E3';


-- --------------------------------------------------------
-- -----------------------  3SC010  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (>) (DATA TYPE VARCHAR(N))
-- UDB2 RESULT =  SUCC (2 SELECTED)

SELECT * FROM STAFF WHERE EmpNum > 'E3';


-- --------------------------------------------------------
-- -----------------------  3SC011  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (>=) (DATA TYPE VARCHAR(N))
-- UDB2 RESULT =  SUCC (2 SELECTED)

SELECT * FROM STAFF WHERE EmpNum > 'E3';


-- --------------------------------------------------------
-- -----------------------  3SC012  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (<>) (DATA TYPE VARCHAR(N))
-- UDB2 RESULT =  SUCC (4 SELECTED)

SELECT * FROM STAFF WHERE EmpNum <> 'E3';


-- --------------------------------------------------------
-- -----------------------  3SC013  -----------------------
-- --------------------------------------------------------
-- SELECT UNKNOWN COMPARISON PREDICATOR (==) 
-- UDB2 RESULT = 42601

SELECT * FROM STAFF WHERE Grade == 12;


-- --------------------------------------------------------
-- -----------------------  3SC014  -----------------------
-- --------------------------------------------------------
-- SELECT UNKNOWN COMPARISON PREDICATOR (<<) 
-- UDB2 RESULT = 42601

SELECT * FROM STAFF WHERE Grade << 12;


-- --------------------------------------------------------
-- -----------------------  3SC015  -----------------------
-- --------------------------------------------------------
-- SELECT "OR" COMPARISON PREDICATOR (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (3 SELECTED)

SELECT * FROM STAFF WHERE Grade < 12 OR Grade = 13;


-- --------------------------------------------------------
-- -----------------------  3SC016  -----------------------
-- --------------------------------------------------------
-- SELECT "OR NOT" COMPARISON PREDICATOR (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (5 SELECTED)

SELECT * FROM STAFF WHERE Grade < 13 OR NOT Grade = 12;

-- --------------------------------------------------------
-- -----------------------  3SC017  -----------------------
-- --------------------------------------------------------
-- SELECT "NOT" COMPARISON PREDICATOR (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (4 SELECTED)

SELECT * FROM STAFF WHERE NOT Grade < 12;

-- --------------------------------------------------------
-- -----------------------  3SC018  -----------------------
-- --------------------------------------------------------
-- SELECT "OR" COMPARISON PREDICATOR (DATA TYPE VARCHAR(N))
-- UDB2 RESULT = SUCC (4 SELECTED)

SELECT * FROM STAFF WHERE EmpNum = 'E3' OR City <> 'Akron';


-- --------------------------------------------------------
-- -----------------------  3SC019  -----------------------
-- --------------------------------------------------------
-- SELECT "OR NOT" COMPARISON PREDICATOR (DATA TYPE VARCHAR(N))
-- UDB2 RESULT = SUCC (2 SELECTED)

SELECT * FROM STAFF WHERE EmpNum = 'E3' OR NOT City <> 'Akron';



-- --------------------------------------------------------
-- -----------------------  3SC020  -----------------------
-- --------------------------------------------------------
-- SELECT "NOT" COMPARISON PREDICATOR (DATA TYPE VARCHAR(N))
-- UDB2 RESULT = SUCC (4 SELECTED)

SELECT * FROM STAFF WHERE NOT EmpNum = 'E3';



-- --------------------------------------------------------
-- -----------------------  3SC021  -----------------------
-- --------------------------------------------------------
-- SELECT UNKNOWN PREDICATOR (SS1)
-- UDB2 RESULT = 42601

SELECT * FROM STAFF WHERE EmpNum HAS 'E3';


-- --------------------------------------------------------
-- -----------------------  3SC022  -----------------------
-- --------------------------------------------------------
-- SELECT UNKNOWN PREDICATOR (SS2)
-- UDB2 RESULT = 42601

SELECT * FROM STAFF WHERE EmpNum FAILED;




-- --------------------------------------------------------
-- ---------  SYNTAX ERROR TEST (CASE SENSITIVE)  ---------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3CS001  -----------------------
-- --------------------------------------------------------
-- CHECK IF "SELECT" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

SeLeCt * FROM STAFF;


-- --------------------------------------------------------
-- -----------------------  3CS002  -----------------------
-- --------------------------------------------------------
-- CHECK IF "FROM" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

SELECT * FrOm STAFF;


-- --------------------------------------------------------
-- -----------------------  3CS003  -----------------------
-- --------------------------------------------------------
-- CHECK IF "AND" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (E4)

SELECT * FROM STAFF WHERE Grade = 12 AnD EmpNum = 'E4';

-- --------------------------------------------------------
-- -----------------------  3CS004  -----------------------
-- --------------------------------------------------------
-- CHECK IF "AND NOT" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (E1)

SELECT * FROM STAFF WHERE Grade = 12 AND NoT EmpNum = 'E4';

-- --------------------------------------------------------
-- -----------------------  3CS005  -----------------------
-- --------------------------------------------------------
-- CHECK IF "OR" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (E1, E2, E4)

SELECT * FROM STAFF WHERE Grade = 12 oR EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3CS006  -----------------------
-- --------------------------------------------------------
-- CHECK IF "OR NOT" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (E1, E3, E4, E5)

SELECT * FROM STAFF WHERE Grade = 12 OR NoT EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3CS007  -----------------------
-- --------------------------------------------------------
-- CHECK IF "LIKE" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (E2)

SELECT * FROM STAFF WHERE EmpNum LiKe 'E2';


-- --------------------------------------------------------
-- -----------------------  3CS008  -----------------------
-- --------------------------------------------------------
-- CHECK IF "NOT LIKE" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (E1, E3, E4, E5)

SELECT * FROM STAFF WHERE EmpNum NoT LIKE 'E2';


-- --------------------------------------------------------
-- -----------------------  3CS009  -----------------------
-- --------------------------------------------------------
-- CHECK IF "AS" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (E2)

SELECT * FROM STAFF aS LABOR WHERE EmpNum = 'E2';


-- --------------------------------------------------------
-- -----------------------  3CS010  -----------------------
-- --------------------------------------------------------
-- CHECK IF "DISTINCT" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (E1, E2, E4)

SELECT DiStInCt Grade FROM STAFF WHERE EmpNum NOT LIKE 'E2';


-- --------------------------------------------------------
-- -----------------------  3CS011  -----------------------
-- --------------------------------------------------------
-- CHECK IF "WHERE" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (E1, E4)

SELECT * FROM STAFF WhErE Grade = 12;


-- --------------------------------------------------------
-- -----------------------  3CS012  -----------------------
-- --------------------------------------------------------
-- CHECK IF "ORDER" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (5 SELECTED)

SELECT * FROM STAFF OrDeR BY Grade;


-- --------------------------------------------------------
-- -----------------------  3CS013  -----------------------
-- --------------------------------------------------------
-- CHECK IF "ORDER BY" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC (5 SELECTED)

SELECT * FROM STAFF ORDER bY Grade;


-- --------------------------------------------------------
-- -----------------------  3CS014  -----------------------
-- --------------------------------------------------------
-- CHECK IF SEARCH VALUE IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

INSERT INTO STAFF VALUES('E6','ALICE',11,'Gaithersburg');

SELECT EmpName FROM STAFF WHERE EmpName LIKE 'Ali%';
-- PASS:0208 If EmpName = 'Alice'?

SELECT EmpName FROM STAFF WHERE EmpName LIKE 'ALI%';
-- PASS:0208 If EmpName = 'ALICE'?

DELETE FROM STAFF WHERE EmpName = 'ALICE';


-- --------------------------------------------------------
-- -----------------------  3CS015  -----------------------
-- --------------------------------------------------------
-- CHECK IF SEARCH VALUE IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

INSERT INTO STAFF VALUES('E7', 'yanping',26,'China');
-- PASS:0208 If 1 row is inserted?

INSERT INTO STAFF VALUES('E8','YANPING',30,'NIST');
-- PASS:0208 If 1 row is inserted?

SELECT CITY FROM STAFF WHERE EMPNAME LIKE 'yan____%';
-- PASS:0208 If CITY = 'China'?

SELECT CITY FROM STAFF WHERE EMPNAME LIKE 'YAN____%';
-- PASS:0208 If CITY = 'NIST'?

DELETE FROM STAFF WHERE EmpName = 'yanping';
DELETE FROM STAFF WHERE EmpName = 'YANPING';


-- --------------------------------------------------------
-- ---------  SYNTAX ERROR TEST (WRONG COMMAND)  ----------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3WC001  -----------------------
-- --------------------------------------------------------
-- REPLACE "SELECT" WITH "CREATE TABLE"
-- UDB2 RESULT = 42601

CREATE TABLE * FROM TMP4;


-- --------------------------------------------------------
-- -----------------------  3WC002  -----------------------
-- --------------------------------------------------------
-- REPLACE "SELECT" WITH "INSERT INTO"
-- UDB2 RESULT = 42601

INSERT INTO * FROM TMP4;

-- --------------------------------------------------------
-- -----------------------  3WC003  -----------------------
-- --------------------------------------------------------
-- REPLACE "SELECT" WITH "DELETE"
-- UDB2 RESULT = 42601

DELETE * FROM TMP4;


-- --------------------------------------------------------
-- -----------------------  3WC004  -----------------------
-- --------------------------------------------------------
-- REPLACE "SELECT" WITH "UPDATE"
-- UDB2 RESULT = 42601

UPDATE * FROM TMP4;


-- --------------------------------------------------------
-- -----------------------  3WC005  -----------------------
-- --------------------------------------------------------
-- REPLACE "SELECT" WITH "DROP"
-- UDB2 RESULT = 42601

DROP * FROM TMP4;



-- --------------------------------------------------------
-- -----------------  SEMATIC ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3ST001  -----------------------
-- --------------------------------------------------------
-- SELECT UNKNOWN TABLE NAME
-- UDB2 RESULT = 42704

SELECT * FROM FAILED;


-- --------------------------------------------------------
-- -----------------------  3ST002  -----------------------
-- --------------------------------------------------------
-- INSERT UNKNOWN COLUMN NAME
-- UDB2 RESULT = 42703

SELECT Ron FROM STAFF;


-- --------------------------------------------------------
-- -----------------------  3ST003  -----------------------
-- --------------------------------------------------------
-- SELECT UNKNOWN SELECT VALUE
-- UDB2 RESULT = SUCC

SELECT * FROM STAFF WHERE EmpName = 'Ron';


-- --------------------------------------------------------
-- -----------------------  3ST004  -----------------------
-- --------------------------------------------------------
-- PASS VARCHAR WHEN DECIMAL IS THE INTENDED PARAMETER
-- UDB2 RESULT = 42818

SELECT * FROM STAFF WHERE Grade = '10';


-- --------------------------------------------------------
-- -----------------------  3ST005  -----------------------
-- --------------------------------------------------------
-- PASS INT WHEN VARCHAR IS THE INTENDED PARAMETER
-- UDB2 RESULT = 42818

SELECT * FROM STAFF WHERE EmpName = 10;


-- --------------------------------------------------------
-- -----------------------  3ST006  -----------------------
-- --------------------------------------------------------
-- PASS VARCHAR WITHOUT QUOTATION MARK
-- UDB2 RESULT = 42703

SELECT * FROM STAFF WHERE EmpName = Alice;


-- --------------------------------------------------------
-- -----------------------  3ST007  -----------------------
-- --------------------------------------------------------
-- SELECT WITH ORDER BY "DESC" (0001)
-- UDB2 RESULT = SUCC

SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM='P2' ORDER BY EMPNUM;
SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM='P2' ORDER BY EMPNUM DESC;

-- PASS:0001 If 4 rows selected and last EMPNUM = 'E1'?


-- --------------------------------------------------------
-- -----------------------  3ST008  -----------------------
-- --------------------------------------------------------
-- SELECT WITH ORDER BY INTEGER (0002)
-- UDB2 RESULT = SUCC

SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM='P2' ORDER BY 2;
SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM='P2' ORDER BY 2 ASC;

-- PASS:0002 If 4 rows selected and last HOURS = 80?


-- --------------------------------------------------------
-- -----------------------  3ST009  -----------------------
-- --------------------------------------------------------
-- SELECT WITH ORDER BY "DESC" INTEGER (0003)
-- UDB2 RESULT = SUCC

SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM = 'P2' ORDER BY 2, EMPNUM;
SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM = 'P2' ORDER BY 2 DESC,EMPNUM DESC;

-- PASS:0003 If 4 rows selected and last EMPNUM = 'E1'?


-- --------------------------------------------------------
-- -----------------------  3ST010  -----------------------
-- --------------------------------------------------------
-- FETCH ON EMPTY TABLE (0008)
-- UDB2 RESULT = SUCC

SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM = 'P8' ORDER BY EMPNUM;
SELECT EMPNUM,HOURS FROM WORKS WHERE PNUM = 'P8' ORDER BY EMPNUM DESC;
-- PASS:0008 If 0 rows selected, SQLCODE = 100, end of data?


-- --------------------------------------------------------
-- -----------------------  3ST011  -----------------------
-- --------------------------------------------------------
-- FETCH ON NULL VALUE (0009)
-- UDB2 RESULT = SUCC

INSERT INTO WORKS VALUES('E9','P9',NULL);
-- PASS:0009 If 1 row is inserted?

SELECT EMPNUM FROM WORKS WHERE HOURS IS NULL;
-- PASS:0009 If EMPNUM = 'E9'?

SELECT EMPNUM, HOURS FROM WORKS WHERE PNUM = 'P9' ORDER BY EMPNUM DESC;
-- PASS:0009 If EMPNUM = 'E9' and HOURS is NULL?

DELETE FROM WORKS WHERE EmpNum = 'E9';


-- --------------------------------------------------------
-- -----------------------  3ST012  -----------------------
-- --------------------------------------------------------
-- SELECT ALL SYNTAX (0016)
-- UDB2 RESULT = SUCC

SELECT ALL EMPNUM FROM WORKS WHERE HOURS = 12;
-- PASS:0016 If 2 rows are selected and both EMPNUMs are 'E1'?


-- --------------------------------------------------------
-- -----------------------  3ST013  -----------------------
-- --------------------------------------------------------
-- SELECT DISTINCT SYNTAX (0017)
-- UDB2 RESULT = SUCC

SELECT EMPNUM FROM WORKS WHERE HOURS = 12;
-- PASS:0164 If 2 rows are selected and both EMPNUMs are 'E1'?

SELECT DISTINCT EMPNUM FROM WORKS WHERE HOURS = 12;
-- PASS:0017 If 1 row is selected and EMPNUM = 'E1'?


-- --------------------------------------------------------
-- -----------------------  3ST014  -----------------------
-- --------------------------------------------------------
-- SELECT WITH ON DATA (0018)
-- UDB2 RESULT = SUCC

SELECT EMPNUM,PNUM FROM WORKS WHERE EMPNUM = 'E16';
-- PASS:0018 If 0 rows selected, SQLCODE = 100, end of data?


-- --------------------------------------------------------
-- -----------------------  3ST015  -----------------------
-- --------------------------------------------------------
-- SELECT WITH DATA (0019)
-- UDB2 RESULT = SUCC

SELECT EMPNUM,HOURS FROM WORKS WHERE EMPNUM = 'E1' AND PNUM = 'P4';
-- PASS:0019 If HOURS = 20 ?



-- --------------------------------------------------------
-- -----------------------  3ST016  -----------------------
-- --------------------------------------------------------
-- SELECT NULL VALUE (0020)
-- UDB2 RESULT = SUCC

INSERT INTO WORKS VALUES('E18','P18',NULL);
-- PASS:0020 If 1 row is inserted?

SELECT EMPNUM,HOURS FROM WORKS WHERE  EMPNUM='E18' AND PNUM='P18';
-- PASS:0020 If EMPNUM = 'E18' and HOURS is NULL?

DELETE FROM WORKS WHERE EmpNum = 'E18';


-- --------------------------------------------------------
-- -----------------------  3ST017  -----------------------
-- --------------------------------------------------------
-- TWO SEARCH STATEMENT CONNECT WITH "AND" (0045)
-- UDB2 RESULT = SUCC

SELECT PNUM FROM PROJ WHERE Budge >= 40000 AND Budge <= 60000;
-- PASS:0045 If PNUM = 'P6'?


-- --------------------------------------------------------
-- -----------------------  3ST018  -----------------------
-- --------------------------------------------------------
-- TWO SEARCH STATEMENT CONNECT WITH "AND NOT" (0046)
-- UDB2 RESULT = SUCC, SUCC, SUCC, SUCC

SELECT CITY FROM STAFF WHERE NOT GRADE >= 12 AND NOT GRADE <= 13;

--SELECT CITY FROM STAFF WHERE GRADE NOT BETWEEN 12 AND 13;
-- PASS:0046 If CITY = 'Vienna'?
-- ayc20000519  dbes does not support between

SELECT CITY FROM STAFF WHERE NOT(GRADE >= 12 AND GRADE <= 13);

--SELECT CITY FROM STAFF WHERE NOT(GRADE BETWEEN 12 AND 13);
-- PASS:0046 If CITY = 'Vienna'?
-- ayc20000519  dbes does not support between

-- --------------------------------------------------------
-- -----------------------  3ST019  -----------------------
-- --------------------------------------------------------
-- "NOT" SEARCH STATEMENT 1 "AND" SEARCH STATEMENT 2
-- UDB2 RESULT = SUCC

SELECT * FROM STAFF WHERE NOT GRADE < 12 AND EmpName = 'Ed';
-- PASS:3ST019 If EmpName = 'E5'


-- --------------------------------------------------------
-- -----------------------  3ST020  -----------------------
-- --------------------------------------------------------
-- "LIKE" PREDICATOR WITH % (0050)
-- UDB2 RESULT = SUCC

SELECT EMPNAME FROM STAFF WHERE EMPNAME LIKE 'Al%';
-- PASS:0050 If EMPNAME = 'Alice'?


-- --------------------------------------------------------
-- -----------------------  3ST021  -----------------------
-- --------------------------------------------------------
-- "LIKE" PREDICATOR WITH _ (0051)
-- UDB2 RESULT = SUCC

SELECT CITY FROM STAFF WHERE EMPNAME LIKE 'B__t%';
-- PASS:0051 If CITY = 'Vienna'?


-- --------------------------------------------------------
-- -----------------------  3ST022  -----------------------
-- --------------------------------------------------------
-- "NOT LIKE" PREDICATOR (0053)
-- UDB2 RESULT = SUCC

INSERT INTO STAFF VALUES('E36','Huyan',36,'Xi_an%');
-- PASS:0053 If 1 row is inserted?

SELECT * FROM STAFF WHERE EMPNUM NOT LIKE '_36';
-- PASS:0053 If SELECT = 5?

SELECT * FROM STAFF WHERE NOT(EMPNUM  LIKE '_36');
-- PASS:0053 If count = 5?

DELETE FROM STAFF WHERE Grade = 36;


-- --------------------------------------------------------
-- -----------------------  3ST023  -----------------------
-- --------------------------------------------------------
-- "IS NULL" PREDICATOR (0054)
-- UDB2 RESULT = SUCC

INSERT INTO STAFF VALUES('E36','Huyan',36,NULL);
-- PASS:0054 If 1 row is inserted?

SELECT EMPNAME FROM STAFF WHERE CITY IS NULL;
-- PASS:0054 If EMPNAME = 'Huyan'?

DELETE FROM STAFF WHERE Grade = 36;



-- --------------------------------------------------------
-- -----------------------  3ST024  -----------------------
-- --------------------------------------------------------
-- "IS NOT NULL" PREDICATOR (0055)
-- UDB2 RESULT = SUCC

INSERT INTO STAFF VALUES('E36','Huyan',36,NULL);
-- PASS:0055 If 1 row is inserted?

SELECT * FROM STAFF;
-- PASS:0055 If count = 6?

SELECT * FROM STAFF WHERE CITY IS NOT NULL;
-- PASS:0055 If count = 5?

SELECT * FROM STAFF WHERE NOT (CITY IS NULL);
-- PASS:0055 If count = 5?

DELETE FROM STAFF WHERE Grade = 36;



-- --------------------------------------------------------
-- -----------------------  3ST025  -----------------------
-- --------------------------------------------------------
-- SELECT NUMBERICAL LITERAL (0066)
-- UDB2 RESULT = SUCC
     
SELECT EMPNUM,10 FROM STAFF WHERE GRADE = 10;
-- PASS:0066 If 1 row with values 'E2' and 10?

SELECT EMPNUM, 10 FROM STAFF;
-- PASS:0066 If 5 rows are selected with second value always = 10?
-- PASS:0066 and EMPNUMs are 'E1', 'E2', 'E3', 'E4', 'E5'?


-- --------------------------------------------------------
-- -----------------------  3ST026  -----------------------
-- --------------------------------------------------------
-- TWO TABLE JOIN (0080)
-- UDB2 RESULT = SUCC

SELECT EMPNUM, EMPNAME,GRADE, STAFF.CITY, PNAME, PROJ.CITY 
     FROM STAFF, PROJ
     WHERE STAFF.CITY = PROJ.CITY;
-- PASS:0080 If 10 rows are selected with EMPNAMEs:'Alice', 'Betty', ?
-- PASS:0080 'Carmen', and 'Don' but not 'Ed'?



-- --------------------------------------------------------
-- -----------------------  3ST027  -----------------------
-- --------------------------------------------------------
-- TWO TABLE JOIN WITH 1 TABLE PREDICATE (0081)
-- UDB2 RESULT = SUCC

SELECT EMPNUM, EMPNAME, GRADE, STAFF.CITY, PNUM,PNAME, PTYPE, BUDGE, PROJ.CITY                        
     FROM STAFF, PROJ
     WHERE STAFF.CITY = PROJ.CITY AND GRADE <> 12;
-- PASS:0081 If 4 rows selected with EMPNAMEs 'Betty' and 'Carmen' ?



-- --------------------------------------------------------
-- -----------------------  3ST028  -----------------------
-- --------------------------------------------------------
-- THREE TABLE JOIN (0082)
-- UDB2 RESULT = SUCC

SELECT DISTINCT STAFF.CITY, PROJ.CITY
     FROM STAFF, WORKS, PROJ
     WHERE STAFF.EMPNUM = WORKS.EMPNUM AND WORKS.PNUM = PROJ.PNUM;
-- PASS:0082 If 5 distinct rows are selected ?


-- --------------------------------------------------------
-- -----------------------  3ST029  -----------------------
-- --------------------------------------------------------
-- JOIN A TABLE WITH ITSEL (0083)
-- UDB2 RESULT = SUCC

SELECT FIRST1.EMPNUM, SECOND2.EMPNUM
     FROM STAFF FIRST1, STAFF SECOND2
     WHERE FIRST1.CITY = SECOND2.CITY AND FIRST1.EMPNUM < SECOND2.EMPNUM;
-- PASS:0083 If 2 rows are selected and ?
-- PASS:0083 If EMPNUM pairs are 'E1'/'E4' and 'E2'/'E3'?


-- --------------------------------------------------------
-- -----------------------  3ST030  -----------------------
-- --------------------------------------------------------
-- JOIN TWO TABLES FROM DIFFERENT SCHEMA (209)
-- NO TEST



-- --------------------------------------------------------
-- -----------------------  3ST031  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATE (<>) (0106)
-- UDB2 RESULT = SUCC

SELECT PNUM FROM PROJ WHERE CITY <> 'Deale';
-- PASS:0106 If 3 rows are selected with PNUMs:'P2','P3','P5'?


-- --------------------------------------------------------
-- -----------------------  3ST032  -----------------------
-- --------------------------------------------------------
-- SHORT STRING LOGICALLY BLANK PADDED IN = PREDICATE (0107) 
-- UDB2 RESULT = SUCC

SELECT * FROM WORKS WHERE EMPNUM = 'E1';
-- PASS:0107 If count = 6 ?

SELECT * FROM WORKS WHERE EMPNUM = 'E1' AND EMPNUM = 'E1 ';
-- PASS:0107 If count = 6?


-- --------------------------------------------------------
-- -----------------------  3ST033  -----------------------
-- --------------------------------------------------------
-- SEARCH CONDITION TRUE "OR NOT" TRUE (0108)
-- UDB2 RESULT = SUCC

UPDATE STAFF SET GRADE = NULL WHERE EMPNUM = 'E1' OR EMPNUM = 'E3' OR EMPNUM = 'E5';
-- PASS:0180 If 3 rows are updated?
                                                                     
SELECT EMPNUM, GRADE FROM STAFF ORDER BY GRADE,EMPNUM;
-- PASS:0180 If 5 rows are selected with NULLs together ?
-- PASS:0180 If first EMPNUM is either 'E1' or 'E2'?
-- PASS:0180 If last EMPNUM is either 'E4' or 'E5?

UPDATE STAFF SET GRADE = 12 WHERE EMPNUM = 'E1';
UPDATE STAFF SET GRADE = 13 WHERE EMPNUM = 'E3';
UPDATE STAFF SET GRADE = 13 WHERE EMPNUM = 'E5';


-- --------------------------------------------------------
-- -----------------------  3ST034  -----------------------
-- --------------------------------------------------------
-- SEARCH CONDITION TRUE "AND NOT" TRUE (0109)
-- UDB2 RESULT = SUCC
    
SELECT EMPNUM, CITY FROM STAFF WHERE EMPNUM='E1' AND NOT(EMPNUM='E1');
-- PASS:0109 If 0 rows are selected ?


-- --------------------------------------------------------
-- -----------------------  3ST035  -----------------------
-- --------------------------------------------------------
-- SEARCH CONDITION UNKNOWN "OR NOT" TRUE (0110)
-- UDB2 RESULT = SUCC

INSERT INTO WORKS VALUES('E8','P8',NULL);
-- PASS:0110 If 1 row is inserted?


SELECT EMPNUM,PNUM 
     FROM WORKS 
    WHERE HOURS < NULL
   OR NOT HOURS < NULL;
                                                   
--SELECT EMPNUM,PNUM 
--     FROM WORKS 
--    WHERE HOURS < (SELECT HOURS FROM WORKS WHERE EMPNUM = 'E8')
--   OR NOT(HOURS < (SELECT HOURS FROM WORKS WHERE EMPNUM = 'E8'));
-- PASS:0110 If 0 rows are selected ?
-- previous stmt was supported on udb but not on db2e
-- ayc20000519

DELETE FROM WORKS WHERE EMPNUM = 'E8';


-- --------------------------------------------------------
-- -----------------------  3ST036  -----------------------
-- --------------------------------------------------------
-- SEARCH CONDITION UNKNOWN "AND NOT" UNKNOWN (0111)
-- UDB2 RESULT = SUCC


-- --------------------------------------------------------
-- -----------------------  3ST037  -----------------------
-- --------------------------------------------------------
-- SEARCH CONDITION UNKNOWN "OR" TRUE (0113)
-- UDB2 RESULT = SUCC




-- --------------------------------------------------------
-- -----------------------  3ST038  -----------------------
-- --------------------------------------------------------
-- SEARCH CONDITION UNKNOWN "AND" TRUE (0112)
-- UDB2 RESULT = SUCC




-- --------------------------------------------------------
-- -----------------------  3ST039  -----------------------
-- --------------------------------------------------------
-- ORDER BY "NULL" VALUES (0180)
-- UDB2 RESULT = SUCC

UPDATE STAFF SET GRADE = NULL WHERE EMPNUM = 'E1' OR EMPNUM = 'E3' OR EMPNUM = 'E5';
-- PASS:0180 If 3 rows are updated?
                                                                     
SELECT EMPNUM,GRADE FROM STAFF ORDER  BY GRADE,EMPNUM;
-- PASS:0180 If 5 rows are selected with NULLs together ?
-- PASS:0180 If first EMPNUM is either 'E1' or 'E2'?
-- PASS:0180 If last EMPNUM is either 'E4' or 'E5?

UPDATE STAFF SET GRADE = 12 WHERE EMPNUM = 'E1';
UPDATE STAFF SET GRADE = 13 WHERE EMPNUM = 'E3';
UPDATE STAFF SET GRADE = 13 WHERE EMPNUM = 'E5';


-- --------------------------------------------------------
-- -----------------------  3ST040  -----------------------
-- --------------------------------------------------------
-- DISTINCT WITH EQUAL "NULL" VALUE (0181)
-- UDB2 RESULT = SUCC

UPDATE STAFF SET GRADE = NULL WHERE EMPNUM = 'E1' OR EMPNUM = 'E3' OR EMPNUM = 'E5';
-- PASS:0181 If 3 rows are updated?
                                                                     
SELECT DISTINCT GRADE FROM STAFF ORDER  BY GRADE;
-- PASS:0181 If 3 rows are selected with GRADEs:10, 12, NULL ?
-- PASS:0181 GRADE 10 precedes GRADE 12?

UPDATE STAFF SET GRADE = 12 WHERE EMPNUM = 'E1';
UPDATE STAFF SET GRADE = 13 WHERE EMPNUM = 'E3';
UPDATE STAFF SET GRADE = 13 WHERE EMPNUM = 'E5';



-- --------------------------------------------------------
-- -----------------------  3ST041  -----------------------
-- --------------------------------------------------------
-- DISTINCT WITH UPPER AND LOWER CASES (0135)
-- UDB2 RESULT = SUCC

INSERT INTO WORKS VALUES('UPP','low',100);
-- PASS:0135 If 1 row is inserted?

SELECT EMPNUM,PNUM FROM WORKS WHERE EMPNUM='UPP' AND PNUM='low';
-- PASS:0135 If EMPNUM = 'UPP' and PNUM = 'low'?

SELECT EMPNUM,PNUM FROM WORKS WHERE EMPNUM='upp' OR PNUM='LOW';
-- PASS:0135 If 0 rows are selected - out of data?

DELETE FROM WORKS WHERE PNUM = 'low';


-- --------------------------------------------------------
-- -----------------------  3ST042  -----------------------
-- --------------------------------------------------------
-- SELECT STATEMENT WITHOUT "WHERE" CLAUSE (0205)
-- UDB2 RESULT = SUCC

SELECT GRADE, HOURS, BUDGE FROM STAFF, WORKS, PROJ;
-- PASS:0205 If 360 rows are selected ?


-- --------------------------------------------------------
-- -----------------------  3ST043  -----------------------
-- --------------------------------------------------------
-- SELECT FROM COMPUTATION COLUMN
-- NO TEST YET


-- --------------------------------------------------------
-- -----------------------  3ST044  -----------------------
-- --------------------------------------------------------
-- SQL COMMENTS WITHIN SQL STATEMENT (0234)
-- UDB2 RESULT = 42601

DELETE  -- WE EMPTY THE TABLE FROM TMP4;

INSERT INTO TMP4  -- THIS IS THE TEST FOR THE RULES VALUES
-- FOR THE REPLACEMENT ('SQL-STYLE COMMENTS') -- OF -- SQL-STYLE COMMENT;
-- PASS:0234 If 1 row is inserted?

SELECT * FROM TMP4;
-- PASS:0234 If TEXXT = 'SQL-STYLE COMMENTS'?





-- ----------------  RUN-TIME ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3RT001  -----------------------
-- --------------------------------------------------------
-- TO BE DETERMINED



-- --------------------------------------------------------
-- ------------------  LIMITATION TEST  -------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3LT001  -----------------------
-- -----------------------  3LT002  -----------------------
-- -----------------------  3LT003  -----------------------
-- --------------------------------------------------------
-- ---------------  REFER TO 3LT001.SQL FILE  -------------
-- --------------------------------------------------------
--

-- --------------------------------------------------------
-- CHECKING RESULT


SELECT * FROM STAFF;
SELECT * FROM PROJ;
SELECT * FROM WORKS;

