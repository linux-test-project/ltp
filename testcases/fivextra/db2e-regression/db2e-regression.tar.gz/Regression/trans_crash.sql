--  TRANSACTION CRASH/FAILURE/RECOVERY TEST
-- 
-- 	* uShadowCommit
-- 	  * ERROR_SHADOW_WRITE
-- 	  * ERROR_SHADOW_FLUSH
-- 	  * ERROR_SHADOW_WRITE_COMMIT_MARK
-- 	  * ERROR_SHADOW_FLUSH2
-- 	* uCommit
-- 	  * ERROR_COMMIT_COMMITTED
-- 	  * ERROR_COMMIT_INCONSISTENT
-- 	  * ERROR_COMMIT_COPIED
-- 	  * ERROR_COMMIT_INVALIDATE
-- 	* Recovery:
-- 	  * ERROR_READ_NUM_PAGES
--        * ERROR_READ_COMMIT_MARK  
--        * ERROR_READ_MAPPING      
--        * ERROR_COPY_SHADOW_PAGE  

-- start with a clean db
BLASTDB;

--  make the tables record bigger than one page
CREATE TABLE tr_crash(a int, b char(10), c char(512));

-- create a few indexes for the fun of it
CREATE INDEX tr_crasha  ON tr_crash(a);
CREATE INDEX tr_crashb  ON tr_crash(b);
CREATE INDEX tr_crashab ON tr_crash(a,b);

--  just insert some starter data
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

-- the start db looks like this
SELECT * FROM tr_crash;

--   uShadowCommit: (COMMIT)
--   REJECT TRANS TEST 
--   inject error to fail during write of shadow file, 
--   transaction will fail, nothing to recover

--  ERROR_SHADOW_WRITE

TRANSACTION BEGIN;

INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
UPDATE tr_crash SET b = 'zwei' WHERE a=2;
SELECT * FROM tr_crash;

--  will get fatal
SETCONNECTATTR 242 1;
TRANSACTION COMMIT;

--  attempt recovery (connect again to same directory)
CONNECT TO foo;

--  we should now have the updates
SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--  ERROR_SHADOW_FLUSH

TRANSACTION BEGIN;

INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
UPDATE tr_crash SET b = 'zwei' WHERE a=2;
SELECT * FROM tr_crash;

--  will get fatal
SETCONNECTATTR 242 2;
TRANSACTION COMMIT;

--  attempt recovery (connect again to same directory)
CONNECT TO foo;

--  we should now have the updates
SELECT * FROM tr_crash;
-- Now we will set the db back to its initial state

-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--  ERROR_SHADOW_WRITE_COMMIT_MARK

TRANSACTION BEGIN;

INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
UPDATE tr_crash SET b = 'zwei' WHERE a=2;
SELECT * FROM tr_crash;

--  will get fatal
SETCONNECTATTR 242 3;
TRANSACTION COMMIT;

--  attempt recovery (connect again to same directory)
CONNECT TO foo;

--  we should now have the updates
SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--  ERROR_SHADOW_FLUSH2

TRANSACTION BEGIN;

INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
UPDATE tr_crash SET b = 'zwei' WHERE a=2;
SELECT * FROM tr_crash;

--  will get fatal
SETCONNECTATTR 242 4;
TRANSACTION COMMIT;

--  attempt recovery (connect again to same directory)
CONNECT TO foo;

--  we should now have the updates
SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--   uCommit: (COMMIT)
--   RECOVER TRANS TEST 
--   inject error to get valid shadowfile, but inconsistent database (not updated)
--   then it will do recovery because the shadowfile is there and in the
--   end the transaction IS THERE.

--  ERROR_COMMIT_COMMITTED

TRANSACTION BEGIN;

INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
UPDATE tr_crash SET b = 'zwei' WHERE a=2;
SELECT * FROM tr_crash;

--  will get fatal
SETCONNECTATTR 242 5; 
TRANSACTION COMMIT;

--  attempt recovery (connect again to same directory)
CONNECT TO foo;

--  we should now have the updates
SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--  ERROR_COMMIT_INCONSISTENT

TRANSACTION BEGIN;

INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
UPDATE tr_crash SET b = 'zwei' WHERE a=2;
SELECT * FROM tr_crash;

--  will get fatal
SETCONNECTATTR 242 6;
TRANSACTION COMMIT;

--  attempt recovery (connect again to same directory)
CONNECT TO foo;

--  we should now have the updates
SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--  ERROR_COMMIT_COPIED

TRANSACTION BEGIN;

INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
UPDATE tr_crash SET b = 'zwei' WHERE a=2;
SELECT * FROM tr_crash;

--  will get fatal
SETCONNECTATTR 242 7;
TRANSACTION COMMIT;

--  attempt recovery (connect again to same directory)
CONNECT TO foo;

--  we should now have the updates
SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--  ERROR_COMMIT_INVALIDATE

TRANSACTION BEGIN;

INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
UPDATE tr_crash SET b = 'zwei' WHERE a=2;
SELECT * FROM tr_crash;

--  will get fatal
SETCONNECTATTR 242 8;
TRANSACTION COMMIT;

--  attempt recovery (connect again to same directory)
CONNECT TO foo;

--  we should now have the updates
SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--   Now we try to get a valid shadow file and an untouched database.
--   Then we will inject an error so that recovery fails too. After
--   that we will connect again which should recover fine.

--  ERROR_READ_NUM_PAGES
--  This file generates a valid shadow file. It does not
--  alter the database.

transaction begin;
INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
INSERT INTO tr_crash VALUES(5, 'five', 'and this right after it');
UPDATE tr_crash SET b = 'zwei' WHERE a=2 OR a=4;
SELECT * FROM tr_crash;

--  Let's commit the changes. Will generate the shadow file.
SETCONNECTATTR 242 5;
transaction commit;

--  Let's clean up.
SETCONNECTATTR 242 0;
-- AUTOCOMMIT ON;

SETCONNECTATTR 242 9;
--   This file will recover twice. Assuming that the first fails
--   because of an injected error, it will then set the injected
--   error to NO_ERROR and recover again. The recovered db will
--   then be displayed.

--  attempt recovery - this will fail
CONNECT TO foo;

--  Now we attempt recovery again - without failing.
SETCONNECTATTR 242 0;
CONNECT TO foo;

SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--  ERROR_READ_COMMIT_MARK
--  This file generates a valid shadow file. It does not
--  alter the database.

transaction begin;
INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
INSERT INTO tr_crash VALUES(5, 'five', 'and this right after it');
UPDATE tr_crash SET b = 'zwei' WHERE a=2 OR a=4;
SELECT * FROM tr_crash;

--  Let's commit the changes. Will generate the shadow file.
SETCONNECTATTR 242 5;
transaction commit;

--  Let's clean up.
SETCONNECTATTR 242 0;
-- AUTOCOMMIT ON;

SETCONNECTATTR 242 10;
--   This file will recover twice. Assuming that the first fails
--   because of an injected error, it will then set the injected
--   error to NO_ERROR and recover again. The recovered db will
--   then be displayed.

--  attempt recovery - this will fail
CONNECT TO foo;

--  Now we attempt recovery again - without failing.
SETCONNECTATTR 242 0;
CONNECT TO foo;

SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--  ERROR_READ_MAPPING
--  This file generates a valid shadow file. It does not
--  alter the database.

transaction begin;
INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
INSERT INTO tr_crash VALUES(5, 'five', 'and this right after it');
UPDATE tr_crash SET b = 'zwei' WHERE a=2 OR a=4;
SELECT * FROM tr_crash;

--  Let's commit the changes. Will generate the shadow file.
SETCONNECTATTR 242 5;
transaction commit;

--  Let's clean up.
SETCONNECTATTR 242 0;
-- AUTOCOMMIT ON;

SETCONNECTATTR 242 11;
--   This file will recover twice. Assuming that the first fails
--   because of an injected error, it will then set the injected
--   error to NO_ERROR and recover again. The recovered db will
--   then be displayed.

--  attempt recovery - this will fail
CONNECT TO foo;

--  Now we attempt recovery again - without failing.
SETCONNECTATTR 242 0;
CONNECT TO foo;

SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

--  ERROR_WRITE_SHADOW_COPY
--  This file generates a valid shadow file. It does not
--  alter the database.

transaction begin;
INSERT INTO tr_crash VALUES(4, 'four', 'we put this in the shadowfile');
INSERT INTO tr_crash VALUES(5, 'five', 'and this right after it');
UPDATE tr_crash SET b = 'zwei' WHERE a=2 OR a=4;
SELECT * FROM tr_crash;

--  Let's commit the changes. Will generate the shadow file.
SETCONNECTATTR 242 5;
transaction commit;

--  Let's clean up.
SETCONNECTATTR 242 0;
-- AUTOCOMMIT ON;

SETCONNECTATTR 242 12;
--   This file will recover twice. Assuming that the first fails
--   because of an injected error, it will then set the injected
--   error to NO_ERROR and recover again. The recovered db will
--   then be displayed.

--  attempt recovery - this will fail
CONNECT TO foo;

--  Now we attempt recovery again - without failing.
SETCONNECTATTR 242 0;
CONNECT TO foo;

SELECT * FROM tr_crash;

-- Now we will set the db back to its initial state
-- Set back to no error state
SETCONNECTATTR 242 0;

DELETE FROM tr_crash;
INSERT INTO tr_crash VALUES(1, 'one', 'this is some data');
INSERT INTO tr_crash VALUES(2, 'two', 'which for sure is in the database');
INSERT INTO tr_crash VALUES(3, 'three', 'the three of that that is');

--  Prove that we're clean
SELECT * from tr_crash;

-- Now let's remove the stuff we generated.
BLASTDB;