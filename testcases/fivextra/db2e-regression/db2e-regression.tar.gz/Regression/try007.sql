-- ------------------ FILE: TRYOO7.SQL  -------------------
-- -                                                      - 
-- -   CHECK INDEX
-- -                                                      -
-- --------------------------------------------------------
--
---------------------------------
-- Test for Indexing - idx01.sql
---------------------------------

DROP INDEX I;

DROP TABLE T;

-- -------------------------------------------
-- 1PT001
-- Test PK 1
-- -------------------------------------------
--
CREATE TABLE T ( a INT PRIMARY KEY NOT NULL, b INT NOT NULL, PRIMARY KEY(b) );

DROP TABLE T;

-- -------------------------------------------
-- 1PT002
-- Test PK 2
-- -------------------------------------------
--
CREATE TABLE T ( a INT NOT NULL, b INT, PRIMARY KEY(a,b) );

DROP TABLE T;

-- -------------------------------------------
-- 1PT003
-- Create index name = 18 characters long
-- -------------------------------------------
--
CREATE TABLE T ( a INT PRIMARY KEY NOT NULL, b INT );

CREATE INDEX I12345678912345678 on T(a);

CREATE INDEX I1234567891234567b on T(b);

DROP INDEX I12345678912345678;

DROP INDEX I1234567891234567b;

DROP TABLE T;

-- -------------------------------------------
-- 1PT004
-- Create index name > 18 characters long
-- -------------------------------------------
--
CREATE TABLE T ( a INT PRIMARY KEY NOT NULL, b INT);

CREATE INDEX I1234567891234567890 on T(a);

CREATE INDEX I1234567891234567890b on T(b);

DROP INDEX I1234567891234567890;

DROP INDEX I1234567891234567890b;

DROP TABLE T;

-- -------------------------------------------
-- 1PT005
-- Drop Primary Key index (should fail)
-- -------------------------------------------
--
CREATE TABLE T ( a INT PRIMARY KEY NOT NULL);

DROP INDEX iT;

DROP INDEX T_z;

CREATE INDEX Ia ON T(a);

CREATE INDEX Iad ON T(a DESC);

SELECT COUNT(*) FROM T;

SELECT * FROM T;

DROP TABLE T;

-- -------------------------------------------
-- 1PT006
-- Create and drop index on an empty table
-- -------------------------------------------
--
CREATE TABLE T ( C integer );

CREATE INDEX I on T ( C );

DROP INDEX I;

SELECT COUNT(*) FROM T;

DROP TABLE T;

-- ------------------------------------------------
-- 1PT007
-- Create 10 indexes with different data types
-- ------------------------------------------------
-- 
CREATE TABLE T (a INT NOT NULL , b VARCHAR(10), c CHAR(10), d DECIMAL(5,2), e SMALLINT, f DATE, g TIME, h BLOB(60), i INT, j INT, PRIMARY KEY(a));

CREATE INDEX a on T(a);

CREATE INDEX b on T(b ASC);

CREATE INDEX c on T(c DESC);

CREATE INDEX d on T(d DESC);

CREATE INDEX e on T(e ASC);

CREATE INDEX f on T(f ASC);

CREATE INDEX g on T(g ASC);

CREATE INDEX h on T(h);

CREATE INDEX i on T(i DESC);

CREATE INDEX j on T(j);

SELECT COUNT(*) FROM T;

DROP INDEX j;

DROP INDEX i;

DROP INDEX h;

DROP INDEX g;

DROP INDEX f;

DROP INDEX e;

DROP INDEX d;

DROP INDEX c;

DROP INDEX b;

DROP INDEX a;

DROP TABLE T;

-- ---------------------------------------------------------
-- 1PT008
-- Create indexes on same column with ASC and DESC order
-- ---------------------------------------------------------
--
CREATE TABLE T (a INT);

CREATE INDEX a on T(a ASC);

CREATE INDEX b on T(a DESC);

SELECT COUNT(*) FROM T;

DROP TABLE T;

-- --------------------------------------------- 
-- 1PT009
-- Create indexes on the same column
-- ---------------------------------------------
--
CREATE TABLE T (a INT);

CREATE INDEX a1 on T(a);

CREATE INDEX a1 on T(a);

CREATE INDEX a2 on T(a);

CREATE INDEX d1 on T(a DESC);

CREATE INDEX d2 on T(a DESC);

SELECT COUNT(*) FROM T;

DROP TABLE T;

-- ----------------------------------------------------
-- 1PT010
-- Create composite index (Column repeat)
-- ----------------------------------------------------
--
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b CHAR(100), c VARCHAR(100), d CHAR(100), e CHAR(100));

CREATE INDEX I0 on T(a DESC, a);

CREATE INDEX I1 on T(b, b);

CREATE INDEX I2 on T(b ASC, b DESC);

CREATE INDEX I3 on T(b DESC, b DESC);

CREATE INDEX I4 on T(a, c, a);

CREATE INDEX I5 on T(c, a, a);

CREATE INDEX I6 on T(a, a, e);

CREATE INDEX I6 on T(a, a DESC);
 
CREATE INDEX I7 on T(d, b, b, d);

CREATE INDEX I8 on T(d DESC, b, b DESC, d ASC);
 
DROP TABLE T;

-- ----------------------------------------------------
-- 1PT011
-- Create composite index (#columns > 8)
-- ----------------------------------------------------
--
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b CHAR(100), c VARCHAR(100), d CHAR(100), e CHAR(100), f INT, g INT, h INT, i INT, j INT);

CREATE INDEX I ON T(a,b,c,d,e,f,g,h,i,j);

SELECT COUNT(*) FROM T;

SELECT * FROM T;

DROP TABLE T;

-- ----------------------------------------------------
-- 1PT012
-- Create composite index (Length of key > 1024 bytes)
-- UDB CHAR limit is 254, VARCHAR is 4000
-- ----------------------------------------------------
--
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b VARCHAR(500), c VARCHAR(500), d VARCHAR(500), e VARCHAR(500));

CREATE INDEX I ON T(a,b,c,d,e);

SELECT COUNT(*) FROM T;

SELECT * FROM T;

DROP TABLE T;

-- -------------------------------------
-- 1PT013
-- Create composite index
-- -------------------------------------
-- 
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b CHAR(50), c VARCHAR(100) );

CREATE INDEX BandC1 on T(b, c DESC);

CREATE INDEX BandC2 on T(b DESC, c);

CREATE INDEX AandBandC on T(a, b, c ASC);

CREATE INDEX CandBandA on T(c, b, a);

CREATE INDEX BandAandC on T(b, a DESC, c);

CREATE INDEX CandAandB on T(c DESC, a DESC, b DESC);

CREATE INDEX CandA1 on T(c DESC, a DESC);

CREATE INDEX CandA2 on T(c DESC, a ASC);

CREATE INDEX CandA3 on T(c ASC, a ASC);

SELECT COUNT(*) FROM T;

DROP INDEX BandAandC;

DROP INDEX CandAandB;

DROP INDEX AandBandC;

DROP INDEX CandA1;

DROP INDEX CandA3;

DROP INDEX CandA2;

DROP INDEX BandC1;

DROP INDEX CandBandA;

DROP INDEX BandC2;

SELECT COUNT(*) FROM T;

DROP TABLE T;

-- -------------------------------------------
-- 1PT014
-- Create more than 15 indexes on a table
-- -------------------------------------------
--
CREATE TABLE T ( a INT NOT NULL, b INT, c INT NOT NULL, d INT, e INT, f INT, g INT, h INT,
                    i INT, j INT, k INT, l INT, m INT, n INT, o INT, p INT, q INT,
                    r INT, s INT, t INT, PRIMARY KEY(a) );

CREATE INDEX a on T(a);

CREATE INDEX b on T(b);

CREATE INDEX c on T(c);

CREATE INDEX d on T(d);

CREATE INDEX e on T(e);

CREATE INDEX f on T(f);

CREATE INDEX g on T(g);

CREATE INDEX h on T(h);

CREATE INDEX i on T(i);

CREATE INDEX j on T(j);

CREATE INDEX k on T(k);

CREATE INDEX l on T(l);

CREATE INDEX m on T(m);

CREATE INDEX n on T(n);

CREATE INDEX o on T(o);

CREATE INDEX p on T(p);

CREATE INDEX q on T(q);

CREATE INDEX r on T(r);

CREATE INDEX s on T(s);

CREATE INDEX t on T(t);

DROP INDEX s;

DROP INDEX d;

DROP INDEX e;

DROP INDEX g;

DROP INDEX h;

DROP INDEX j;

DROP INDEX f;

DROP INDEX i;

DROP INDEX k;

DROP INDEX l;

DROP INDEX p;

DROP INDEX m;

DROP INDEX r;

DROP INDEX n;

DROP INDEX b;

DROP INDEX t;

DROP INDEX o;

DROP INDEX q;

DROP INDEX a;

DROP INDEX c;

SELECT COUNT(*) FROM T;

DROP TABLE T;

---------------------------------
-- 1PT015
-- Limit Test 8 columns
---------------------------------
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b INT, c INT, d INT, e INT, f INT, g INT, h INT );

CREATE INDEX I1 ON T(a, b, c, d, e, f, g, h);

CREATE INDEX I2 ON T(b, a, c, d, e, f, g, h);

CREATE INDEX I3 ON T(c, b, a, d, e, f, g, h);

CREATE INDEX I4 ON T(d, c, b, a, e, f, g, h);

CREATE INDEX I5 ON T(e, d, c, b, a, f, g, h);

CREATE INDEX I6 ON T(f, e, d, c, b, a, g, h);

CREATE INDEX I7 ON T(g, f, e, d, c, b, a, h);

CREATE INDEX I8 ON T(h, g, f, e, d, c, b, a);

CREATE INDEX I9 ON T(a DESC, b DESC, c DESC, d DESC, e DESC, f DESC, g DESC, h DESC);

CREATE INDEX I10 ON T(b DESC, a DESC, c DESC, d DESC, e DESC, f DESC, g DESC, h DESC);

CREATE INDEX I11 ON T(c DESC, b DESC, a DESC, d DESC, e DESC, f DESC, g DESC, h DESC);

CREATE INDEX I12 ON T(d DESC, c DESC, b DESC, a DESC, e DESC, f DESC, g DESC, h DESC);

CREATE INDEX I13 ON T(e DESC, d DESC, c DESC, b DESC, a DESC, f DESC, g DESC, h DESC);

CREATE INDEX I14 ON T(f DESC, e DESC, d DESC, c DESC, b DESC, a DESC, g DESC, h DESC);

CREATE INDEX I15 ON T(g DESC, f DESC, e DESC, d DESC, c DESC, b DESC, a DESC, h DESC);

CREATE INDEX I16 ON T(h DESC, g DESC, f DESC, e DESC, d DESC, c DESC, b DESC, a DESC);

CREATE INDEX I17 ON T(g ASC, f DESC, e ASC, d DESC, c ASC, b DESC, a ASC, h DESC);

CREATE INDEX I18 ON T(h DESC, g ASC, f DESC, e ASC, d DESC, c ASC, b DESC, a ASC);

DROP TABLE T;

--------------------------------------------
-- 1PT016
-- Cross-Product empty tables with indexes
--------------------------------------------

CREATE TABLE T1 (a INT PRIMARY KEY NOT NULL, b CHAR(10));
CREATE TABLE T2 (c INT PRIMARY KEY NOT NULL, d CHAR(10));

CREATE INDEX IT1ad     ON T1(a DESC);
CREATE INDEX IT1b      ON T1(b);
CREATE INDEX IT1bd     ON T1(b DESC);
CREATE INDEX IT1AandB  ON T1(a,b);
CREATE INDEX IT1AandBd ON T1(a DESC, b DESC);

CREATE INDEX IT2cd     ON T2(c DESC);
CREATE INDEX IT2d      ON T2(d);
CREATE INDEX IT2dd     ON T2(d DESC);
CREATE INDEX IT2CandD  ON T2(c,d);
CREATE INDEX IT2CandDd ON T2(c DESC, d DESC);

SELECT COUNT(*) FROM T1, T2;
SELECT COUNT(*) FROM T2, T1;

SELECT * FROM T1, T2;
SELECT * FROM T2, T1;

SELECT * FROM T1, T2 ORDER BY a;
SELECT * FROM T2, T1 ORDER BY a;
SELECT * FROM T1, T2 ORDER BY a DESC;
SELECT * FROM T2, T1 ORDER BY a DESC;

SELECT * FROM T1, T2 ORDER BY b;
SELECT * FROM T2, T1 ORDER BY b;
SELECT * FROM T1, T2 ORDER BY b DESC;
SELECT * FROM T2, T1 ORDER BY b DESC;

SELECT * FROM T1, T2 ORDER BY c;
SELECT * FROM T2, T1 ORDER BY c;
SELECT * FROM T1, T2 ORDER BY c DESC;
SELECT * FROM T2, T1 ORDER BY c DESC;

SELECT * FROM T1, T2 ORDER BY d;
SELECT * FROM T2, T1 ORDER BY d;
SELECT * FROM T1, T2 ORDER BY d DESC;
SELECT * FROM T2, T1 ORDER BY d DESC;

SELECT * FROM T1, T2 ORDER BY a,b;
SELECT * FROM T2, T1 ORDER BY a,b;
SELECT * FROM T1, T2 ORDER BY a,b;
SELECT * FROM T2, T1 ORDER BY a,b;

SELECT * FROM T1, T2 ORDER BY a DESC, b DESC;
SELECT * FROM T2, T1 ORDER BY a DESC, b DESC;
SELECT * FROM T1, T2 ORDER BY a DESC, b DESC;
SELECT * FROM T2, T1 ORDER BY a DESC, b DESC;

SELECT * FROM T1, T2 ORDER BY c,d;
SELECT * FROM T2, T1 ORDER BY c,d;
SELECT * FROM T1, T2 ORDER BY c,d;
SELECT * FROM T2, T1 ORDER BY c,d;

SELECT * FROM T1, T2 ORDER BY c DESC, d DESC;
SELECT * FROM T2, T1 ORDER BY c DESC, d DESC;
SELECT * FROM T1, T2 ORDER BY c DESC, d DESC;
SELECT * FROM T2, T1 ORDER BY c DESC, d DESC;

DELETE FROM T1;
DELETE FROM T2;

DROP TABLE T1;
DROP TABLE T2;

--------------------------------------------
-- 1PT017
-- Inner Joins empty tables with indexes
--------------------------------------------
CREATE TABLE T1 (a INT PRIMARY KEY NOT NULL, b CHAR(10));
CREATE TABLE T2 (c INT PRIMARY KEY NOT NULL, d CHAR(10));

CREATE INDEX IT1ad     ON T1(a DESC);
CREATE INDEX IT1b      ON T1(b);
CREATE INDEX IT1bd     ON T1(b DESC);
CREATE INDEX IT1AandB  ON T1(a,b);
CREATE INDEX IT1AandBd ON T1(a DESC, b DESC);

CREATE INDEX IT2cd     ON T2(c DESC);
CREATE INDEX IT2d      ON T2(d);
CREATE INDEX IT2dd     ON T2(d DESC);
CREATE INDEX IT2CandD  ON T2(c,d);
CREATE INDEX IT2CandDd ON T2(c DESC, d DESC);

SELECT COUNT(*) FROM T1, T2;
SELECT COUNT(*) FROM T2, T1;

SELECT * FROM T1, T2 WHERE T1.a = T2.c;
SELECT * FROM T2, T1 WHERE T1.a = T2.c;
SELECT * FROM T1, T2 WHERE T2.c = T1.a;
SELECT * FROM T2, T1 WHERE T2.c = T1.a;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T1.a;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T1.a;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T1.a;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T1.a;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T1.a DESC;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T1.a DESC;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T1.a DESC;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T1.a DESC;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T1.b;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T1.b;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T1.b;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T1.b;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T1.b DESC;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T1.b DESC;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T1.b DESC;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T1.b DESC;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T2.c;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T2.c;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T2.c;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T2.c;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T2.c DESC;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T2.c DESC;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T2.c DESC;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T2.c DESC;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T2.d;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T2.d;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T2.d;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T2.d;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T2.d DESC;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T2.d DESC;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T2.d DESC;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T2.d DESC;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T1.a, T1.b;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T1.a, T1.b;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T1.a, T1.b;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T1.a, T1.b;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T1.a DESC, T1.b DESC;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T1.a DESC, T1.b DESC;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T1.a DESC, T1.b DESC;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T1.a DESC, T1.b DESC;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T2.c, T2.d;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T2.c, T2.d;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T2.c, T2.d;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T2.c, T2.d;

SELECT * FROM T1, T2 WHERE T1.a = T2.c ORDER BY T2.c DESC, T2.d DESC;
SELECT * FROM T2, T1 WHERE T1.a = T2.c ORDER BY T2.c DESC, T2.d DESC;
SELECT * FROM T1, T2 WHERE T2.c = T1.a ORDER BY T2.c DESC, T2.d DESC;
SELECT * FROM T2, T1 WHERE T2.c = T1.a ORDER BY T2.c DESC, T2.d DESC;

DELETE FROM T1;
DELETE FROM T2;

DROP TABLE T1;
DROP TABLE T2;

--------------------------------
-- End of idx01.sql
---------------------------------

---------------------------------
-- Test for Indexing - idx02.sql
---------------------------------

DROP INDEX I;

DROP TABLE T;

-- -------------------------------------------
-- 2PT001
-- Drop Primary Key index (should fail)
-- -------------------------------------------
--
CREATE TABLE T ( a INT PRIMARY KEY NOT NULL);

DROP INDEX iT;

DROP INDEX T_z;

INSERT INTO T VALUES ( 10 );

CREATE INDEX Ia ON T(a);

CREATE INDEX Iad ON T(a DESC);

INSERT INTO T VALUES ( 20 );

SELECT COUNT(*) FROM T;

SELECT * FROM T;

DROP TABLE T;

-- -----------------------------------------------------------------
-- 2PT002
-- Create and drop index on a table and populate it with some data
-- -----------------------------------------------------------------
--
CREATE TABLE T ( a INTEGER );

CREATE INDEX I on T ( a );

CREATE INDEX Id on T ( a DESC );

INSERT INTO T VALUES ( 0 );

INSERT INTO T VALUES ( 1 );

INSERT INTO T VALUES ( -1 );

INSERT INTO T VALUES ( 2 );

INSERT INTO T VALUES ( -2 );

INSERT INTO T VALUES ( 3 );

INSERT INTO T VALUES ( -3 );

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT a FROM T WHERE a > 0;

SELECT a FROM T WHERE a < 0;

SELECT a FROM T WHERE a = 0;

SELECT a FROM T WHERE a <> 0;

SELECT a FROM T ORDER BY a;

SELECT a FROM T ORDER BY a DESC;

SELECT a FROM T WHERE a >= -2 AND a <= 2;

SELECT a FROM T WHERE a >= -2 AND a <= 2 ORDER BY a;

SELECT a FROM T WHERE a >= -2 AND a <= 2 ORDER BY a DESC;

SELECT a FROM T WHERE a >= 0 ORDER BY a DESC;

SELECT a FROM T WHERE a <= 0 ORDER BY a ASC;
 
DROP INDEX I;

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT a FROM T WHERE a > 0;

SELECT a FROM T WHERE a < 0;

DROP INDEX Id;

SELECT a FROM T WHERE a = 0;

SELECT a FROM T WHERE a <> 0;

SELECT a FROM T ORDER BY a;

SELECT a FROM T ORDER BY a DESC;

SELECT a FROM T WHERE a >= -2 AND a <= 2;

SELECT a FROM T WHERE a >= -2 AND a <= 2 ORDER BY a;

SELECT a FROM T WHERE a >= -2 AND a <= 2 ORDER BY a DESC;

SELECT a FROM T WHERE a >= 0 ORDER BY a DESC;

SELECT a FROM T WHERE a <= 0 ORDER BY a ASC;

DELETE FROM T;

SELECT * FROM T;

DROP TABLE T;

-- -----------------------------------------------------------
-- 2PT003
-- Create and drop index on a populated table for decimal PK  
-- -----------------------------------------------------------
--
CREATE TABLE T ( d DECIMAL(5,2) PRIMARY KEY NOT NULL );

CREATE INDEX I on T ( d );

CREATE INDEX Id on T ( d DESC );

INSERT INTO T VALUES ( 0.0 );

INSERT INTO T VALUES ( 1.0 );

INSERT INTO T VALUES ( -1.0 );

INSERT INTO T VALUES ( 2.0 );

INSERT INTO T VALUES ( -2.0 );

INSERT INTO T VALUES ( 3.0 );

INSERT INTO T VALUES ( -3.0 );

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT d FROM T WHERE d > 0.0;

SELECT d FROM T WHERE d < 0.0;

SELECT d FROM T WHERE d = 0.0;

SELECT d FROM T WHERE d = 1.0;

SELECT d FROM T WHERE d = -1.0;

SELECT d FROM T WHERE d <> 0.0;

SELECT d FROM T ORDER BY d;

SELECT d FROM T ORDER BY d DESC;

SELECT d FROM T WHERE d >= -2.0 AND d <= 2.0;
 
DROP INDEX I;

DROP INDEX Id;

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT d FROM T WHERE d > 0.0;

SELECT d FROM T WHERE d < 0.0;

SELECT d FROM T WHERE d = 0.0;

SELECT d FROM T WHERE d = 1.0;

SELECT d FROM T WHERE d = -1.0;

SELECT d FROM T WHERE d <> 0.0;

SELECT d FROM T ORDER BY d;

SELECT d FROM T ORDER BY d DESC;

SELECT d FROM T WHERE d >= -2.0 AND d <= 2.0;

DELETE FROM T;

SELECT * FROM T;

DROP TABLE T;

-- ---------------------------------------------------------------
-- 2PT004
-- Create and drop index on a populated table for decimal column  
-- ---------------------------------------------------------------
--
CREATE TABLE T ( d DECIMAL(5,2) );

CREATE INDEX I on T ( d );

CREATE INDEX Id on T ( d DESC );

INSERT INTO T VALUES ( 0.0 );

INSERT INTO T VALUES ( 1.0 );

INSERT INTO T VALUES ( -1.0 );

INSERT INTO T VALUES ( 2.0 );

INSERT INTO T VALUES ( -2.0 );

INSERT INTO T VALUES ( 3.0 );

INSERT INTO T VALUES ( -3.0 );

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT d FROM T WHERE d > 0.0;

SELECT d FROM T WHERE d < 0.0;

SELECT d FROM T WHERE d = 0.0;

SELECT d FROM T WHERE d = 1.0;

SELECT d FROM T WHERE d = -1.0;

SELECT d FROM T ORDER BY d;

SELECT d FROM T ORDER BY d DESC;

SELECT d FROM T WHERE d >= -2.0 AND d <= 2.0;
 
DROP INDEX I;

DROP INDEX Id;

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT d FROM T WHERE d > 0.0;

SELECT d FROM T WHERE d < 0.0;

SELECT d FROM T WHERE d = 0.0;

SELECT d FROM T WHERE d = 1.0;

SELECT d FROM T WHERE d = -1.0;

SELECT d FROM T ORDER BY d;

SELECT d FROM T ORDER BY d DESC;

SELECT d FROM T WHERE d >= -2.0 AND d <= 2.0;

DELETE FROM T;

SELECT * FROM T;

DROP TABLE T;

-- -----------------------------------------------------------------
-- 2PT005
-- Create 10 indexes with different data types
-- Populate them with values including NULL and duplicates
-- Drop indexes in different order
-- -----------------------------------------------------------------
--
CREATE TABLE T (a INT NOT NULL , b VARCHAR(10), c CHAR(10), d DECIMAL(5,2), e SMALLINT, f DATE, g TIME, h BLOB(60), i INT, j INT, PRIMARY KEY(a));

CREATE INDEX a on T(a);

CREATE INDEX ad on T(a DESC);

CREATE INDEX b on T(b ASC);

CREATE INDEX c on T(c DESC);

CREATE INDEX d on T(d DESC);

CREATE INDEX e on T(e ASC);

CREATE INDEX f on T(f ASC);

CREATE INDEX g on T(g ASC);

CREATE INDEX h on T(h);

CREATE INDEX i on T(i DESC);

CREATE INDEX j on T(j);

INSERT INTO T VALUES (1, 'John', 'Chan', 1.11, -1, '06/12/2000','12:00:00', NULL, 10, 100);

INSERT INTO T VALUES (2, 'Wil', 'Ng', 2.22, -2, '06/14/2000','14:56:00', NULL, 20, 200);

INSERT INTO T VALUES (3, 'Mary', 'Ponet', 3.33, -3, '08/20/1999', '07:07:10', NULL, 30, 300);

INSERT INTO T VALUES (4, 'Susan', 'Chan', 4.44, -4, '07/14/2000', '05:05:05', NULL, 40, 400);

INSERT INTO T VALUES (5, 'Howard', 'Peterson', 5.55, -5, '09/16/2000', '08:08:08', NULL, 50, 500);

INSERT INTO T VALUES (6, 'Jane', 'Chen', 6.66, -6, '06/12/2000','01:00:00', NULL, 60, 600);

INSERT INTO T (a,b,c,d,e,f,g,h,j) VALUES (7, 'Steven', 'Zheng', 7.77, -7, '06/15/2000','02:00:00', NULL, 700);

INSERT INTO T (a,b,c,d,e,f,g,h,j) VALUES (8, 'Jason', 'Yuen', 8.88, -8, '10/15/2000','03:00:00', NULL, 800);

INSERT INTO T VALUES (9, 'Howard', 'Watts', 9.99, -9, '03/03/2000', '04:00:00', NULL, 90, 900);

INSERT INTO T VALUES (10, 'Jimmy', 'Watts', 10.0, -10, '05/05/2000', '05:00:00', NULL, 100, 1000);

SELECT COUNT(*) FROM T;

SELECT a, b, c, d, e, f, g, h, i, j FROM T;

SELECT a, b, c FROM T where a > 2;

SELECT c, b, a FROM T where a <= 2;

SELECT a, b, c, j FROM T where a > 1 AND j > 100;

SELECT a, b, c, f, g, i FROM T where f > '08/20/1999' AND i IS NOT NULL;

SELECT a, b, c, f, g, i FROM T where f > '08/20/1999' AND i IS NULL;

SELECT a, b, c FROM T WHERE b LIKE 'J%' ORDER BY b;

SELECT a, b, c FROM T WHERE c = 'Watts';

SELECT a, b, c, d, e  FROM T WHERE e < -1 AND e > -5;

SELECT b, c, d FROM T WHERE d = 1.11 OR d = 2.22 OR d = 3.33;

SELECT MAX(j) FROM T;

SELECT MIN(j) FROM T;

SELECT SUM(j) FROM T;

SELECT AVG(j) FROM T;

DROP INDEX j;

DROP INDEX i;

DROP INDEX h;

DROP INDEX g;

SELECT COUNT(*) FROM T;

SELECT a, b, c, d, e, f, g, h, i, j FROM T;

SELECT a, b, c FROM T where a > 2;

SELECT c, b, a FROM T where a <= 2;

SELECT a, b, c, j FROM T where a > 1 AND j > 100;

SELECT a, b, c, f, g, i FROM T where f > '08/20/1999' AND i IS NOT NULL;

SELECT a, b, c, f, g, i FROM T where f > '08/20/1999' AND i IS NULL;

SELECT a, b, c FROM T WHERE b LIKE 'J%' ORDER BY b;

SELECT a, b, c FROM T WHERE c = 'Watts';

SELECT a, b, c, d, e  FROM T WHERE e < -1 AND e > -5;

SELECT b, c, d FROM T WHERE d = 1.11 OR d = 2.22 OR d = 3.33;

SELECT MAX(j) FROM T;

SELECT MIN(j) FROM T;

SELECT SUM(j) FROM T;

SELECT AVG(j) FROM T;

DROP INDEX f;

DROP INDEX e;

DROP INDEX d;

DROP INDEX c;

DROP INDEX b;

DROP INDEX a;

SELECT COUNT(*) FROM T;

SELECT a, b, c, d, e, f, g, h, i, j FROM T;

SELECT a, b, c FROM T where a > 2;

SELECT c, b, a FROM T where a <= 2;

SELECT a, b, c, j FROM T where a > 1 AND j > 100;

SELECT a, b, c, f, g, i FROM T where f > '08/20/1999' AND i IS NOT NULL;

SELECT a, b, c, f, g, i FROM T where f > '08/20/1999' AND i IS NULL;

SELECT a, b, c FROM T WHERE b LIKE 'J%' ORDER BY b;

SELECT a, b, c FROM T WHERE c = 'Watts';

SELECT a, b, c, d, e  FROM T WHERE e < -1 AND e > -5;

SELECT b, c, d FROM T WHERE d = 1.11 OR d = 2.22 OR d = 3.33;

SELECT MAX(j) FROM T;

SELECT MIN(j) FROM T;

SELECT SUM(j) FROM T;

SELECT AVG(j) FROM T;

DELETE FROM T;

SELECT * FROM T;

DROP TABLE T;

-- -----------------------------------------------------------------
-- 2PT006
-- Create indexes on same column with ASC and DESC order
-- Create index on a table that has been populated with some tuples
-- -----------------------------------------------------------------
--
CREATE TABLE T ( a CHAR(10), b INT );

INSERT INTO T VALUES ('John', 1);

INSERT INTO T VALUES ('Mary', 2);

INSERT INTO T VALUES ('Jane', 0);

CREATE INDEX a on T(a ASC);

INSERT INTO T VALUES ('Charlie', -1);

CREATE INDEX d on T(a DESC);

SELECT COUNT(*) FROM T;

SELECT * FROM T;

INSERT INTO T VALUES ('Peter', -2);

INSERT INTO T VALUES ('Susan', 2);

INSERT INTO T VALUES ('Susan', 100);

INSERT INTO T VALUES ('Steven', 3);

INSERT INTO T VALUES ('Allison', 0);

INSERT INTO T (a) VALUES ('Wil');

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT a, b FROM T where a > 'Allison';

SELECT a, b FROM T where a < 'Wil'; 

SELECT a, b  FROM T where a = 'Susan';

SELECT a, b FROM T ORDER BY a;

SELECT a, b FROM T ORDER BY a, b;

SELECT a, b FROM T ORDER BY a DESC;

SELECT a, b FROM T ORDER BY a DESC, b DESC;

UPDATE T SET b=-100 WHERE a='Susan';

UPDATE T SET a='Allison' WHERE b=3;

DELETE FROM T WHERE a = 'Peter';

DROP INDEX I;

UPDATE T SET a='Henry' WHERE a='Charlie';

DELETE FROM T WHERE a='Jane';

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT a, b FROM T where a > 'Allison';

SELECT a, b FROM T where a < 'Wil'; 

SELECT a, b  FROM T where a = 'Susan';

SELECT a, b FROM T ORDER BY a;

SELECT a, b FROM T ORDER BY a, b;

SELECT a, b FROM T ORDER BY a DESC;

SELECT a, b FROM T ORDER BY a DESC, b DESC;

CREATE INDEX I ON T(a);

INSERT INTO T VALUES ('Gaven', -10);

SELECT COUNT(*) FROM T;

SELECT * FROM T;

DROP TABLE T;

-- -------------------------------------------------------------- 
-- 2PT007
-- Create indexes on the same column 
-- --------------------------------------------------------------
--
CREATE TABLE T (a VARCHAR(10), b INT);

INSERT INTO T VALUES ('John', 1);

CREATE INDEX b2 ON T(b);

INSERT INTO T VALUES ('Mary', 2);

INSERT INTO T VALUES ('Jane', 0);

CREATE INDEX a1 on T(a);

CREATE INDEX a1 on T(a);

CREATE INDEX a2 on T(a);

CREATE INDEX d1 on T(a DESC);

CREATE INDEX d2 on T(a DESC);

INSERT INTO T VALUES ('Peter', -2);

INSERT INTO T VALUES ('Susan', 2);

INSERT INTO T VALUES ('Susan', 100);

INSERT INTO T VALUES ('Steven', 3);

INSERT INTO T VALUES ('Allison', 0);

INSERT INTO T (a) VALUES ('Wil');

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT a, b FROM T where a > 'Allison';

SELECT a, b FROM T where a < 'Wil'; 

SELECT a, b  FROM T where a = 'Susan';

SELECT a, b FROM T ORDER BY a;

SELECT a, b FROM T ORDER BY a, b;

SELECT a, b FROM T ORDER BY a DESC;

SELECT a, b FROM T ORDER BY a DESC, b DESC;

DROP TABLE T;

-- ----------------------------------------------------
-- 2PT008
-- Create composite index (Column repeat)
-- ----------------------------------------------------
--
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b CHAR(100), c VARCHAR(100), d CHAR(100), e CHAR(100));

CREATE INDEX I0 on T(a DESC, a);

CREATE INDEX I1 on T(b, b);

CREATE INDEX I2 on T(b ASC, b DESC);

CREATE INDEX I3 on T(b DESC, b DESC);

CREATE INDEX I4 on T(a, c, a);

CREATE INDEX I5 on T(c, a, a);

CREATE INDEX I6 on T(a, a, e);

CREATE INDEX I6 on T(a, a DESC);
 
CREATE INDEX I7 on T(d, b, b, d);

CREATE INDEX I8 on T(d DESC, b, b DESC, d ASC);
  
DROP TABLE T;

-- ----------------------------------------------------
-- 2PT009
-- Create composite index (#columns > 8)
-- ----------------------------------------------------
--
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b CHAR(100), c VARCHAR(100), d CHAR(100), e CHAR(100), f INT, g INT, h INT, i INT, j INT);

CREATE INDEX I ON T(a,b,c,d,e,f,g,h,i,j);

INSERT INTO T (a, b) VALUES (1, 'A');

INSERT INTO T (a, b) VALUES (2, 'B');

INSERT INTO T (a, b) VALUES (3, 'C');

SELECT COUNT(*) FROM T;

SELECT * FROM T;

DROP TABLE T;

-- ----------------------------------------------------
-- 2PT010
-- Create composite index (Length of key > 1024 bytes)
-- ----------------------------------------------------
-- 
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b VARCHAR(200), c VARCHAR(200), d VARCHAR(200), e VARCHAR(200), 
 f VARCHAR(200), g VARCHAR(200), h VARCHAR(200));

INSERT INTO T VALUES (1, 'z1', 'z2', 'z3', 'z4', 'z5', 'z6', 'z7');

CREATE INDEX I ON T(a,b,c,d,e,f,g,h);

SELECT COUNT(*) FROM T;

INSERT INTO T VALUES (2, 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7');

INSERT INTO T VALUES (3, 'y1', 'y2', 'y3', 'y4', 'y5', 'y6', 'y7');

CREATE INDEX Id ON T(a DESC, b DESC, c DESC, e DESC, f DESC, g DESC, h DESC);
 
INSERT INTO T VALUES (4, 's1', 's2', 's3', 's4', 's5', 's6', 's7');

INSERT INTO T VALUES (5, 't1', 't2', 't3', 't4', 't5', 't6', 't7');

UPDATE T SET h=NULL WHERE a=1;

UPDATE T SET h=NULL WHERE a=4;

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT * FROM T ORDER BY a, b, c, d, e, f, g, h;

SELECT * FROM T ORDER BY a, b DESC, c, d DESC, e, f DESC, g, h DESC;

SELECT * FROM T ORDER BY a DESC, b DESC, c DESC, d DESC, e DESC, f DESC, g DESC, h DESC;

SELECT * FROM T WHERE b >  'y1';

SELECT * FROM T WHERE b <  'y1';

SELECT * FROM T WHERE b =  'y1';

SELECT * FROM T WHERE b <> 'y1';

SELECT * FROM T WHERE b > 'x1' AND b < 'z1';

SELECT * FROM T WHERE b < 'z1' AND b > 'x1';

SELECT * FROM T WHERE b > 'y1' AND c > 'y2' AND d > 'y3' AND e > 'y4' AND f > 'y5' AND f > 'y6' AND h > 'y7';

SELECT * FROM T WHERE b < 'y1' AND c < 'y2' AND d < 'y3' AND e < 'y4' AND f < 'y5' AND f < 'y6' AND h < 'y7';

SELECT * FROM T WHERE b > 'y1' ORDER BY h;

SELECT * FROM T WHERE b < 'y1' ORDER BY h;

SELECT * FROM T WHERE b = 'y1' ORDER BY h;

SELECT * FROM T WHERE b <> 'y1' ORDER BY h;

SELECT * FROM T WHERE b > 'x1' AND b < 'z1' ORDER BY h;

SELECT * FROM T WHERE b < 'z1' AND b > 'x1' ORDER BY h;

SELECT * FROM T WHERE b > 'y1' AND c > 'y2' AND d > 'y3' AND e > 'y4' AND f > 'y5' AND f > 'y6' AND h > 'y7' ORDER BY a DESC;

SELECT * FROM T WHERE b < 'y1' AND c < 'y2' AND d < 'y3' AND e < 'y4' AND f < 'y5' AND f < 'y6' AND h < 'y7' ORDER BY a DESC;

DROP TABLE T;

-- ----------------------------------------------------
-- 2PT010b
-- Create composite index (Length of key < 1024 bytes)
-- ----------------------------------------------------
-- 
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b VARCHAR(10), c VARCHAR(10), d VARCHAR(10), e VARCHAR(10), 
 f VARCHAR(10), g VARCHAR(10), h VARCHAR(10));

INSERT INTO T VALUES (1, 'z1', 'z2', 'z3', 'z4', 'z5', 'z6', 'z7');

CREATE INDEX I ON T(a,b,c,d,e,f,g,h);

SELECT COUNT(*) FROM T;

INSERT INTO T VALUES (2, 'x1', 'x2', 'x3', 'x4', 'x5', 'x6', 'x7');

INSERT INTO T VALUES (3, 'y1', 'y2', 'y3', 'y4', 'y5', 'y6', 'y7');

CREATE INDEX Id ON T(a DESC, b DESC, c DESC, e DESC, f DESC, g DESC, h DESC);

INSERT INTO T VALUES (4, 's1', 's2', 's3', 's4', 's5', 's6', 's7');

INSERT INTO T VALUES (5, 't1', 't2', 't3', 't4', 't5', 't6', 't7');

UPDATE T SET h=NULL WHERE a=1;

UPDATE T SET h=NULL WHERE a=4;
 
SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT * FROM T ORDER BY a, b, c, d, e, f, g, h;

SELECT * FROM T ORDER BY a, b DESC, c, d DESC, e, f DESC, g, h DESC;

SELECT * FROM T ORDER BY a DESC, b DESC, c DESC, d DESC, e DESC, f DESC, g DESC, h DESC;

SELECT * FROM T WHERE b >  'y1';

SELECT * FROM T WHERE b <  'y1';

SELECT * FROM T WHERE b =  'y1';

SELECT * FROM T WHERE b <> 'y1';

SELECT * FROM T WHERE b > 'x1' AND b < 'z1';

SELECT * FROM T WHERE b < 'z1' AND b > 'x1';

SELECT * FROM T WHERE b > 'y1' AND c > 'y2' AND d > 'y3' AND e > 'y4' AND f > 'y5' AND f > 'y6' AND h > 'y7';

SELECT * FROM T WHERE b < 'y1' AND c < 'y2' AND d < 'y3' AND e < 'y4' AND f < 'y5' AND f < 'y6' AND h < 'y7';

SELECT * FROM T WHERE b > 'y1' ORDER BY h;

SELECT * FROM T WHERE b < 'y1' ORDER BY h;

SELECT * FROM T WHERE b = 'y1' ORDER BY h;

SELECT * FROM T WHERE b <> 'y1' ORDER BY h;

SELECT * FROM T WHERE b > 'x1' AND b < 'z1' ORDER BY h;

SELECT * FROM T WHERE b < 'z1' AND b > 'x1' ORDER BY h;

SELECT * FROM T WHERE b > 'y1' AND c > 'y2' AND d > 'y3' AND e > 'y4' AND f > 'y5' AND f > 'y6' AND h > 'y7' ORDER BY a DESC;

SELECT * FROM T WHERE b < 'y1' AND c < 'y2' AND d < 'y3' AND e < 'y4' AND f < 'y5' AND f < 'y6' AND h < 'y7' ORDER BY a DESC;

DROP TABLE T;

-- ----------------------------- 
-- 2PT011
-- Create composite index
-- -----------------------------
-- 
CREATE TABLE T (a INT PRIMARY KEY NOT NULL, b CHAR(50), c VARCHAR(100) );

CREATE INDEX BandC1 on T(b, c DESC);

CREATE INDEX BandC2 on T(b DESC, c);

CREATE INDEX AandBandC on T(a, b, c ASC);

CREATE INDEX CandBandA on T(c, b, a);

CREATE INDEX BandAandC on T(b, a DESC, c);

CREATE INDEX CandAandB on T(c DESC, a DESC, b DESC);

CREATE INDEX CandA1 on T(c DESC, a DESC);

CREATE INDEX CandA2 on T(c DESC, a ASC);

CREATE INDEX CandA3 on T(c ASC, a ASC);

INSERT INTO T VALUES (1, 'John', 'Lawson');

INSERT INTO T VALUES (2, 'John', 'Beck');

INSERT INTO T VALUES (3, 'Tom', 'Arnold');

INSERT INTO T VALUES (4, 'Sally', 'Tanaka');

INSERT INTO T VALUES (5, 'Wil', 'Ng');

INSERT INTO T VALUES (6, 'Susan', 'Lawson');

INSERT INTO T VALUES (7, 'Peter', 'Kenson');

INSERT INTO T VALUES (8, 'Jane', 'Nomi');

INSERT INTO T VALUES (9, 'Monica', 'Thanks');

INSERT INTO T VALUES (10, 'Steven', 'Hong');

INSERT INTO T VALUES (0, 'Christina', 'Jones');

INSERT INTO T VALUES (-1, 'Jamie', 'Lee');

INSERT INTO T VALUES (-2, 'Ben', 'Wong');

INSERT INTO T VALUES (-4, 'Christina');

INSERT INTO T VALUES (-3, 'Howard', 'Chan');

INSERT INTO T VALUES (-5, 'Frank', 'Yuen');

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT a, b, c FROM T ORDER BY b, c DESC;

SELECT a, b, c FROM T ORDER BY b DESC, c;

SELECT a, b, c FROM T ORDER BY a, b, c;

SELECT a, b, c FROM T ORDER BY c, b, a;

SELECT a, b, c FROM T ORDER BY b, a DESC, c;

SELECT a, b, c FROM T ORDER BY c DESC, a DESC, b DESC;

SELECT a, b, c FROM T WHERE a > 3 AND b >= 'John' AND c > 'Arnold' ORDER BY c, a, b;

DROP INDEX BandAandC;

DROP INDEX CandAandB;

DROP INDEX AandBandC;

DROP INDEX CandA1;

DROP INDEX CandA3;

DROP INDEX CandA2;

DROP INDEX BandC1;

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT a, b, c FROM T ORDER BY b, c DESC;

SELECT a, b, c FROM T ORDER BY b DESC, c;

SELECT a, b, c FROM T ORDER BY a, b, c;

SELECT a, b, c FROM T ORDER BY c, b, a;

SELECT a, b, c FROM T ORDER BY b, a DESC, c;

SELECT a, b, c FROM T ORDER BY c DESC, a DESC, b DESC;

SELECT a, b, c FROM T WHERE a > 3 AND b >= 'John' AND c > 'Arnold' ORDER BY c, a, b;

DROP INDEX CandBandA;

DROP INDEX BandC2;

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT a, b, c FROM T ORDER BY b, c DESC;

SELECT a, b, c FROM T ORDER BY b DESC, c;

SELECT a, b, c FROM T ORDER BY a, b, c;

SELECT a, b, c FROM T ORDER BY c, b, a;

SELECT a, b, c FROM T ORDER BY b, a DESC, c;

SELECT a, b, c FROM T ORDER BY c DESC, a DESC, b DESC;

SELECT a, b, c FROM T WHERE a > 3 AND b >= 'John' AND c > 'Arnold' ORDER BY c, a, b;

DROP TABLE T;

-- -----------------------
-- 2PT012
-- Composite primary key 
-- -----------------------
-- 
CREATE TABLE PK (a INT NOT NULL, b INT NOT NULL, C INT, PRIMARY KEY(a, b));

INSERT INTO PK VALUES (1, 2, 3);

INSERT INTO PK VALUES (1, 1, 2);

INSERT INTO PK VALUES (1, 3, 2);

INSERT INTO PK VALUES (2, 2, 3);

INSERT INTO PK VALUES (2, 2, 0);

INSERT INTO PK VALUES (3, 1, 0);

SELECT COUNT(*) FROM PK;

SELECT * FROM PK;

SELECT PK.a, PK.b, PK.c FROM PK ORDER BY a, b;

SELECT c, b, a FROM PK ORDER BY a, b, c;

SELECT * FROM PK WHERE a = 1 AND b = 1;

SELECT * FROM PK WHERE b = 2 ORDER BY a DESC;

SELECT * FROM PK WHERE a > 1 AND b > 1;

SELECT * FROM PK WHERE c > 0 ORDER BY a, b;

SELECT * FROM PK WHERE c <= 0 ORDER BY b, a DESC;

SELECT COUNT(a) FROM PK GROUP BY a;

SELECT a FROM PK GROUP BY a;

DELETE FROM PK;

DROP TABLE PK;

-- -------------------------------------------
-- 2PT013
-- Create more than 15 indexes on a table
-- -------------------------------------------
--
CREATE TABLE T ( a INT NOT NULL, b INT, c INT NOT NULL, d INT, e INT, f INT, g INT, h INT,
                    i INT, j INT, k INT, l INT, m INT, n INT, o INT, p INT, q INT,
                    r INT, s INT, t INT, PRIMARY KEY(a) );

INSERT INTO T VALUES (1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);

CREATE INDEX a on T(a);

CREATE INDEX b on T(b);

CREATE INDEX c on T(c);

INSERT INTO T VALUES (2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2);

CREATE INDEX d on T(d);

CREATE INDEX e on T(e);

CREATE INDEX f on T(f);

CREATE INDEX g on T(g);

CREATE INDEX h on T(h);

CREATE INDEX i on T(i);

CREATE INDEX j on T(j);

CREATE INDEX k on T(k);

CREATE INDEX l on T(l);

CREATE INDEX m on T(m);

CREATE INDEX n on T(n);

CREATE INDEX o on T(o);

CREATE INDEX p on T(p);

CREATE INDEX q on T(q);

CREATE INDEX r on T(r);

CREATE INDEX s on T(s);

CREATE INDEX t on T(t);

INSERT INTO T VALUES (3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3);

SELECT COUNT(*) FROM T;

SELECT * FROM T;

DROP INDEX s;

DROP INDEX d;

INSERT INTO T VALUES (4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4);

DROP INDEX e;

DROP INDEX g;

DROP INDEX h;

DROP INDEX j;

DROP INDEX f;

DROP INDEX i;

INSERT INTO T VALUES (-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1);

DROP INDEX k;

DROP INDEX l;

DROP INDEX p;

DROP INDEX m;

DROP INDEX r;

DROP INDEX n;

DROP INDEX b;

DROP INDEX t;

DROP INDEX o;

DROP INDEX q;

DROP INDEX a;

DROP INDEX c;

SELECT COUNT(*) FROM T;

SELECT * FROM T;

SELECT * FROM T ORDER BY a;

SELECT * FROM T ORDER BY c;

SELECT * FROM T ORDER BY q;

DROP TABLE T;

-----------------------------------------------------------
-- 2PT014
-- Test for iscan with indexing
-----------------------------------------------------------
--
CREATE TABLE x ( a INT, b INT, c CHAR(2), d DATE);
CREATE TABLE y ( a DATE, b INT, c INT);

-- create index xidxa on x(a asc);
CREATE INDEX xidxd ON x(a DESC);
-- create index yidxa on x(b asc);
CREATE INDEX yidxd ON y(b DESC);

INSERT INTO x VALUES(1,1,'ab','02/21/1990');
INSERT INTO x VALUES(2,1,'bc','03/23/1991');
INSERT INTO x VALUES(3,9,'ce','09/12/1999');
INSERT INTO x VALUES(9,1,'df','10/12/2000');
INSERT INTO x VALUES(1,1,'cd','11/12/1992');
INSERT INTO x VALUES(1,1,'cd','11/12/1992');
INSERT INTO x VALUES(2,3,'xd','12/10/1991');

INSERT INTO y VALUES('02/21/1999',1,3);
INSERT INTO y VALUES('01/21/2000',2,3);
INSERT INTO y VALUES('09/12/1991',5,4);
INSERT INTO y VALUES('08/12/2000',2,3);
INSERT INTO y VALUES('01/11/1999',1,1);
INSERT INTO y VALUES('01/10/1996',2,1);

SELECT DISTINCT x.a FROM x ORDER BY x.a;
SELECT DISTINCT y.c FROM y ORDER BY y.c;
SELECT DISTINCT x.a FROM x ORDER BY x.a DESC;
SELECT DISTINCT y.c FROM y ORDER BY y.c DESC;

SELECT x.a, y.a FROM x,y WHERE y.c = x.a;
SELECT x.a, y.a FROM x,y WHERE x.a = y.c;
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d =  '02/21/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d =  '02/21/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d >  '03/01/1990' AND x.d < '01/01/2000';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d >  '03/01/1990' AND x.d < '01/01/2000';

SELECT x.a, y.a FROM y,x WHERE y.c = x.a;
SELECT x.a, y.a FROM y,x WHERE x.a = y.c;
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d =  '02/21/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d =  '02/21/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d >  '03/01/1990' AND x.d < '01/01/2000';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d >  '03/01/1990' AND x.d < '01/01/2000';

CREATE INDEX Ixdd ON x(d);

SELECT DISTINCT x.a FROM x ORDER BY x.a;
SELECT DISTINCT y.c FROM y ORDER BY y.c;
SELECT DISTINCT x.a FROM x ORDER BY x.a DESC;
SELECT DISTINCT y.c FROM y ORDER BY y.c DESC;

SELECT x.a, y.a FROM x,y WHERE y.c = x.a;
SELECT x.a, y.a FROM x,y WHERE x.a = y.c;
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d >  '03/01/1990' AND x.d < '01/01/2000';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d >  '03/01/1990' AND x.d < '01/01/2000';

SELECT x.a, y.a FROM y,x WHERE y.c = x.a;
SELECT x.a, y.a FROM y,x WHERE x.a = y.c;
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d >  '03/01/1990' AND x.d < '01/01/2000';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d >  '03/01/1990' AND x.d < '01/01/2000';

DROP INDEX Ixdd;

SELECT DISTINCT x.a FROM x ORDER BY x.a;
SELECT DISTINCT y.c FROM y ORDER BY y.c;
SELECT DISTINCT x.a FROM x ORDER BY x.a DESC;
SELECT DISTINCT y.c FROM y ORDER BY y.c DESC;

SELECT x.a, y.a FROM x,y WHERE y.c = x.a;
SELECT x.a, y.a FROM x,y WHERE x.a = y.c;
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM x,y WHERE y.c = x.a AND x.d >  '03/01/1990' AND x.d < '01/01/2000';
SELECT x.a, y.a FROM x,y WHERE x.a = y.c AND x.d >  '03/01/1990' AND x.d < '01/01/2000';

SELECT x.a, y.a FROM y,x WHERE y.c = x.a;
SELECT x.a, y.a FROM y,x WHERE x.a = y.c;
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d =  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d <> '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d >  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d <  '03/01/1990';
SELECT x.a, y.a FROM y,x WHERE y.c = x.a AND x.d >  '03/01/1990' AND x.d < '01/01/2000';
SELECT x.a, y.a FROM y,x WHERE x.a = y.c AND x.d >  '03/01/1990' AND x.d < '01/01/2000';

DROP TABLE x;
DROP TABLE y;

---------------------------------------------------
-- 2PT015
-- Composite index iscan test with table ordering
---------------------------------------------------
--
CREATE TABLE X (a INT, b INT CHECK(b <= 0), c CHAR(5), d VARCHAR(5));
CREATE TABLE Y (a INT, b INT CHECK(b <= 0), c CHAR(5), d VARCHAR(5));

CREATE INDEX Ibc  ON y(a,b);
CREATE INDEX Ibcd ON y(a DESC, b DESC);

INSERT INTO x VALUES ( 0,  0, 'a', 'abc');
INSERT INTO x VALUES (-1, -1, 'b', 'def');
INSERT INTO x VALUES (-2, -2, 'c', 'ghi');
INSERT INTO x VALUES (-3, -3, 'd', 'jkl');
INSERT INTO x VALUES (-4, -4, 'e', 'mno');
INSERT INTO x VALUES (-5, -5, 'f', 'pqr');

INSERT INTO y VALUES (0,  0, 'a', 'pqr');
INSERT INTO y VALUES (1, -1, 'b', 'mno');
INSERT INTO y VALUES (2, -2, 'c', 'jkl');
INSERT INTO y VALUES (3, -3, 'd', 'ghi');
INSERT INTO y VALUES (4, -4, 'e', 'def');
INSERT INTO y VALUES (5, -5, 'f', 'abc');

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b; 
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a; 
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b; 
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a; 

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a = 1;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a = 1;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a = 1;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a = 1;

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a <> 1;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a <> 1;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a <> 1;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a <> 1;

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a > 3;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a > 3;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a > 3;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a > 3;

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a < 3;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a < 3;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a < 3;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a < 3;

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5;

-- Returns 42822 if order by list is not in the select list in DB2e, UDB is okay.
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5 ORDER BY y.a, y.b;

SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5 ORDER BY y.a DESC, y.b DESC;

SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.b >= -5 AND y.b <= -2 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.b >= -5 AND y.b <= -2 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.b >= -5 AND y.b <= -2 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.b >= -5 AND y.b <= -2 ORDER BY y.a, y.b;

SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.b >= -5 AND y.b <= -2 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.b >= -5 AND y.b <= -2 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.b >= -5 AND y.b <= -2 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.b >= -5 AND y.b <= -2 ORDER BY y.a DESC, y.b DESC;

UPDATE x SET x.b = x.b + 1;
UPDATE y SET y.b = y.b + 1;

SELECT * FROM x;
SELECT * FROM y;

UPDATE x SET x.b = x.b - 1;
UPDATE y SET y.b = y.b - 1;

SELECT * FROM x;
SELECT * FROM y;

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b; 
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a; 
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b; 
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a; 

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a = 1;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a = 1;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a = 1;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a = 1;

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a <> 1;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a <> 1;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a <> 1;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a <> 1;

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a > 3;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a > 3;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a > 3;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a > 3;

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a < 3;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a < 3;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a < 3;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a < 3;

SELECT x.a, x.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5;
SELECT x.a, x.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5;
SELECT x.a, x.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5;

SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5 ORDER BY y.a, y.b;

SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.a >= 2 AND y.a <= 5 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.a >= 2 AND y.a <= 5 ORDER BY y.a DESC, y.b DESC;

SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.b >= -5 AND y.b <= -2 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.b >= -5 AND y.b <= -2 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.b >= -5 AND y.b <= -2 ORDER BY y.a, y.b;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.b >= -5 AND y.b <= -2 ORDER BY y.a, y.b;

SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE x.a = y.b AND y.b >= -5 AND y.b <= -2 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM x,y WHERE y.b = x.a AND y.b >= -5 AND y.b <= -2 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE x.a = y.b AND y.b >= -5 AND y.b <= -2 ORDER BY y.a DESC, y.b DESC;
SELECT x.a, x.b, y.a, y.b, x.d, y.d FROM y,x WHERE y.b = x.a AND y.b >= -5 AND y.b <= -2 ORDER BY y.a DESC, y.b DESC;

DROP TABLE x;
DROP TABLE y;

-- -------------------------------------
-- 2PT016
-- Self-join index test with PK
-- -------------------------------------
--
DROP TABLE EMPLOYEE;

-- DB2e does not support self-referencing for FOREIGN KEY
CREATE TABLE EMPLOYEE (
   empno INT PRIMARY KEY NOT NULL, 
   name CHAR(20), 
   yrsemployed INT, 
   managerno INT 
);

CREATE INDEX Imgr  ON employee(managerno);
CREATE INDEX Iname ON employee(name);

-- Should return 23503
INSERT INTO employee VALUES (1, 'John', 1, 200);

INSERT INTO employee VALUES (100, 'Don', 25, NULL);
INSERT INTO employee VALUES (200, 'Josephine', 22, NULL);
INSERT INTO employee VALUES (300, 'Cliff', 8, NULL);
INSERT INTO employee VALUES (400, 'Thanh', 15, NULL);
INSERT INTO employee VALUES (410, 'Yip-Hing', 3, NULL);
INSERT INTO employee VALUES (420, 'Michael', 5, NULL);
INSERT INTO employee VALUES (430, 'Jonas', 1, NULL);
INSERT INTO employee VALUES (440, 'Amrish', 1, NULL);
INSERT INTO employee VALUES (450, 'Torsten', 1, NULL);
INSERT INTO employee VALUES (460, 'Ulrich', 1, NULL);
INSERT INTO employee VALUES (470, 'Craig', 1, NULL);
INSERT INTO employee VALUES (480, 'Anthony', 1, NULL);

CREATE INDEX Imgrd ON employee(managerno DESC);

UPDATE employee SET managerno=300 WHERE empno=400;
UPDATE employee SET managerno=300 WHERE empno=410;
UPDATE employee SET managerno=300 WHERE empno=420;
UPDATE employee SET managerno=300 WHERE empno=430;
UPDATE employee SET managerno=300 WHERE empno=440;
UPDATE employee SET managerno=300 WHERE empno=450;
UPDATE employee SET managerno=300 WHERE empno=460;
UPDATE employee SET managerno=300 WHERE empno=470;
UPDATE employee SET managerno=300 WHERE empno=480;
UPDATE employee SET managerno=200 WHERE empno=300;
UPDATE employee SET managerno=100 WHERE empno=200;

INSERT INTO employee VALUES (481, 'Jing', 0, NULL);
INSERT INTO employee VALUES (482, 'Xin', 0, NULL);

UPDATE employee SET managerno=300 WHERE empno=482;
UPDATE employee SET managerno=300 WHERE empno=481;

CREATE INDEX InameAndyrs  ON employee(name, yrsemployed);
CREATE INDEX InameAndyrsD ON employee(name DESC, yrsemployed DESC);

INSERT INTO employee (empno, name, managerno) VALUES (483, 'Unknown', NULL);
INSERT INTO employee (empno, name, managerno) VALUES (484, 'Unknown', NULL);
INSERT INTO employee (empno, name, managerno) VALUES (485, 'Unknown1', NULL);
INSERT INTO employee (empno, name, managerno) VALUES (486, 'Unknown2', NULL);
INSERT INTO employee (empno, name, managerno) VALUES (487, 'Unknown3', NULL);

UPDATE employee SET managerno=300 WHERE empno=483;
UPDATE employee SET managerno=300 WHERE empno=484;
UPDATE employee SET managerno=300 WHERE empno=485;
UPDATE employee SET managerno=300 WHERE empno=486;
UPDATE employee SET managerno=300 WHERE empno=487;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, mgr.name  
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno; 

SELECT emp.name, mgr.name  
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno 
ORDER BY emp.name; 

DELETE FROM employee WHERE empno=485;
DELETE FROM employee WHERE empno=483;
DELETE FROM employee WHERE empno=487;
DELETE FROM employee WHERE empno=484;
DELETE FROM employee WHERE empno=486;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, mgr.name 
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno;

SELECT emp.name, mgr.name 
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno 
ORDER BY emp.name;

DROP INDEX InameAndyrs;
DROP INDEX Imgr;
DROP INDEX Iname;
DROP INDEX Imgrd;
DROP INDEX InameAndyrsD;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, mgr.name 
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno;

SELECT emp.name, mgr.name 
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno 
ORDER BY emp.name;

DELETE FROM EMPLOYEE;

SELECT COUNT(*) FROM EMPLOYEE;

SELECT * FROM EMPLOYEE;

DROP TABLE EMPLOYEE;

-- -------------------------------------
-- 2PT017
-- Self-join index test without PK
-- -------------------------------------
--
DROP TABLE EMPLOYEE;

CREATE TABLE EMPLOYEE (
   empno INT, 
   name CHAR(20), 
   yrsemployed INT, 
   managerno INT
);

CREATE INDEX Imgr  ON employee(managerno);
CREATE INDEX Iname ON employee(name);

INSERT INTO employee VALUES (1, 'John', 1, 200);

INSERT INTO employee VALUES (100, 'Don', 25, NULL);
INSERT INTO employee VALUES (200, 'Josephine', 22, NULL);
INSERT INTO employee VALUES (300, 'Cliff', 8, NULL);
INSERT INTO employee VALUES (400, 'Thanh', 15, NULL);
INSERT INTO employee VALUES (410, 'Yip-Hing', 3, NULL);
INSERT INTO employee VALUES (420, 'Michael', 5, NULL);
INSERT INTO employee VALUES (430, 'Jonas', 1, NULL);
INSERT INTO employee VALUES (440, 'Amrish', 1, NULL);
INSERT INTO employee VALUES (450, 'Torsten', 1, NULL);
INSERT INTO employee VALUES (460, 'Ulrich', 1, NULL);
INSERT INTO employee VALUES (470, 'Craig', 1, NULL);
INSERT INTO employee VALUES (480, 'Anthony', 1, NULL);

CREATE INDEX Imgrd ON employee(managerno DESC);

UPDATE employee SET managerno=300 WHERE empno=400;
UPDATE employee SET managerno=300 WHERE empno=410;
UPDATE employee SET managerno=300 WHERE empno=420;
UPDATE employee SET managerno=300 WHERE empno=430;
UPDATE employee SET managerno=300 WHERE empno=440;
UPDATE employee SET managerno=300 WHERE empno=450;
UPDATE employee SET managerno=300 WHERE empno=460;
UPDATE employee SET managerno=300 WHERE empno=470;
UPDATE employee SET managerno=300 WHERE empno=480;
UPDATE employee SET managerno=200 WHERE empno=300;
UPDATE employee SET managerno=100 WHERE empno=200;

INSERT INTO employee VALUES (481, 'Jing', 0, NULL);
INSERT INTO employee VALUES (482, 'Xin', 0, NULL);

UPDATE employee SET managerno=300 WHERE empno=482;
UPDATE employee SET managerno=300 WHERE empno=481;

CREATE INDEX InameAndyrs  ON employee(name, yrsemployed);
CREATE INDEX InameAndyrsD ON employee(name DESC, yrsemployed DESC);

INSERT INTO employee (empno, name, managerno) VALUES (483, 'Unknown', NULL);
INSERT INTO employee (empno, name, managerno) VALUES (484, 'Unknown', NULL);
INSERT INTO employee (empno, name, managerno) VALUES (485, 'Unknown1', NULL);
INSERT INTO employee (empno, name, managerno) VALUES (486, 'Unknown2', NULL);
INSERT INTO employee (empno, name, managerno) VALUES (487, 'Unknown3', NULL);

UPDATE employee SET managerno=300 WHERE empno=483;
UPDATE employee SET managerno=300 WHERE empno=484;
UPDATE employee SET managerno=300 WHERE empno=485;
UPDATE employee SET managerno=300 WHERE empno=486;
UPDATE employee SET managerno=300 WHERE empno=487;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, mgr.name  
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno; 

SELECT emp.name, mgr.name  
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno 
ORDER BY emp.name; 

DELETE FROM employee WHERE empno=485;
DELETE FROM employee WHERE empno=483;
DELETE FROM employee WHERE empno=487;
DELETE FROM employee WHERE empno=484;
DELETE FROM employee WHERE empno=486;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, mgr.name 
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno;

SELECT emp.name, mgr.name 
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno 
ORDER BY emp.name;

DROP INDEX InameAndyrs;
DROP INDEX Imgr;
DROP INDEX Iname;
DROP INDEX Imgrd;
DROP INDEX InameAndyrsD;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name, emp.yrsemployed;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed = 0 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, emp.yrsemployed  
FROM employee emp 
WHERE emp.yrsemployed > 2 AND emp.yrsemployed < 10 
ORDER BY emp.name DESC, emp.yrsemployed DESC;

SELECT emp.name, mgr.name 
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno;

SELECT emp.name, mgr.name 
FROM employee AS emp, employee AS mgr  
WHERE emp.managerno = mgr.empno 
ORDER BY emp.name;

DELETE FROM EMPLOYEE;

SELECT COUNT(*) FROM EMPLOYEE;

SELECT * FROM EMPLOYEE;

DROP TABLE EMPLOYEE;

-- -------------------------------------
-- 2PT018
-- Index join test
-- M:N STUDENT and CLASS relation
-- -------------------------------------
--
DROP INDEX IStdLastname;
DROP INDEX IStdAge;
DROP INDEX IStdAgeD;
DROP INDEX IStdSsnD;
DROP INDEX IStdMajor;
DROP INDEX IStdDoB;

DROP INDEX IClsCoursefee;
DROP INDEX IClsClassnameD;
DROP INDEX IClsClassname;

DROP INDEX IRstClsnoSsnD;
DROP INDEX IRstGrade;
DROP INDEX IRstGradeD;

DROP TABLE student;
DROP TABLE roster;
DROP TABLE class;

CREATE TABLE STUDENT
(
   ssn       CHAR(9) NOT NULL,
   firstname VARCHAR(20),
   lastname  VARCHAR(20),
   major     VARCHAR(25),
   gender    CHAR(1),
   age       SMALLINT CHECK(age > 10),
   DoB       DATE,
   PRIMARY KEY(ssn)
);

CREATE TABLE CLASS
(
   classno   CHAR(4) PRIMARY KEY NOT NULL,
   classname VARCHAR(30) NOT NULL,
   coursefee DECIMAL(5,2) CHECK(coursefee > 0.00),
   coursehrs INT CHECK(coursehrs > 0)  
);

CREATE TABLE ROSTER
(
   classno   CHAR(4) NOT NULL,
   sectionno CHAR(3),
   ssn       CHAR(9) NOT NULL,
   grade     CHAR(1),
   PRIMARY KEY(classno,ssn),
   FOREIGN KEY(classno) REFERENCES class,
   FOREIGN KEY(ssn) REFERENCES student
);

--
-- Populate tuples to Table STUDENT
--
CREATE INDEX IStdLastname ON student(lastname);
INSERT INTO student VALUES ('000000000', 'John', 'Olivera', 'History', 'M', 28, '07/04/1972' );
INSERT INTO student VALUES ('000000001', 'Mary', 'Jane', 'History', 'F', 27, '10/05/1973' );
INSERT INTO student VALUES ('000000002', 'Tom', 'Armstrong', 'Physics', 'M', 27, '08/02/1973' );
CREATE INDEX IStdAge ON student(age);
INSERT INTO student VALUES ('000000003', 'Frank', 'Peterson', 'Business', 'M', 25, '07/04/1975' );
INSERT INTO student VALUES ('000000004', 'Jane', 'Lee', 'Computer Science', 'F', 24, '07/04/1976' );
DROP INDEX IStdAge;
CREATE INDEX IStdDob ON student(DoB);
CREATE INDEX IStdSsnD ON student(ssn DESC);
INSERT INTO student VALUES ('000000005', 'John', 'Howson', 'Physics', 'M', 30, '12/05/1970' );
INSERT INTO student VALUES ('000000006', 'Wil', 'Armstrong', 'Computer Science', 'M', 28, '07/04/1972' );
INSERT INTO student VALUES ('000000007', 'Sandra', 'Terra', 'Math', 'F', 28, '07/04/1972' );
INSERT INTO student VALUES ('000000008', 'Albert', 'Willington', 'Math', 'M', 31, '02/02/1969' );
INSERT INTO student VALUES ('000000009', 'Ben', 'Wong', 'Architecture', 'M', 29, '11/12/1971' );
INSERT INTO student VALUES ('000000010', 'Steven', 'Lee', 'Chemistry', 'M', 28, '06/11/1972' );
CREATE INDEX IStdAge ON student(age);
CREATE INDEX IStdAgeD ON student(age DESC);
INSERT INTO student VALUES ('000000011', 'Shirley', 'Aguella', 'Undeclared', 'F', 22, '01/11/1978' );
INSERT INTO student VALUES ('000000012', 'Chris', 'Jonet', 'Business', 'M', 28, '05/26/1972' );
INSERT INTO student VALUES ('000000013', 'Claire', 'Gina', 'Business', 'F', 27, '03/10/1973' );
INSERT INTO student VALUES ('000000014', 'Howard', 'Redford', 'Architecture', 'M', 27, '03/10/1973' );
INSERT INTO student VALUES ('000000015', 'Karen', 'Chan', 'Business', 'F', 28, '07/21/1972' );
CREATE INDEX IStdMajor ON student(major);

-- 
-- Populate tuples to Table CLASS 
-- 
CREATE INDEX IClsCoursefee ON class(coursefee);
CREATE INDEX IClsClassnameD ON class(classname DESC);
CREATE INDEX IClsClassname ON class(classname ASC);

INSERT INTO class VALUES ('EC01', 'Economics 101', 200.00, 1);
INSERT INTO class VALUES ('EC02', 'Economics 201', 300.00, 2);
INSERT INTO class VALUES ('EC03', 'Economics 301', 400.00, 3);

INSERT INTO class VALUES ('PS01', 'Psychology 101', 50.00, 1);
INSERT INTO class VALUES ('PS02', 'Psychology 201', 200.00, 2);
INSERT INTO class VALUES ('PS03', 'Psychology 309', 200.50, 3);

INSERT INTO class VALUES ('CS01', 'Computer Arch 101', 200.00, 4);
INSERT INTO class VALUES ('CS02', 'Compiler 450', 300.00, 4);
INSERT INTO class VALUES ('CS03', 'Database 310', 300.00, 4);

INSERT INTO class VALUES ('PY01', 'Physics 101', 200.00, 4);
INSERT INTO class VALUES ('PY02', 'Thermodynamics 300', 200.00, 4);
INSERT INTO class VALUES ('PY03', 'AstroPhysics 400', 400.00, 4);

INSERT INTO class VALUES ('MA01', 'Calculas 101', 200.00, 2);
INSERT INTO class VALUES ('MA02', 'Differential Equations 201', 200.00, 4);
INSERT INTO class VALUES ('MA03', 'Linear Algebra 301', 900.00, 4);

INSERT INTO class VALUES ('CH01', 'Chemistry 101', 400.00, 3);
INSERT INTO class VALUES ('CH02', 'Chemistry 201', 400.00, 3);
INSERT INTO class VALUES ('CH03', 'Chemistry 301', 400.00, 3);

INSERT INTO class VALUES ('AR01', 'Architecture 101', 400.00, 3);
INSERT INTO class VALUES ('AR02', 'Architecture 201', 400.00, 3);
INSERT INTO class VALUES ('AR03', 'Architecture 301', 400.00, 3);

INSERT INTO class VALUES ('HY01', 'History 101', 100.00, 1);
INSERT INTO class VALUES ('HY02', 'History 201', 100.00, 1);
INSERT INTO class VALUES ('HY03', 'History 301', 100.00, 1);

--
-- Populate tuples to Table ROSTER
--
CREATE INDEX IRstClsnoSsnD ON roster(classno DESC, ssn DESC);
INSERT INTO roster VALUES ('EC01', '001', '000000000', 'B');
INSERT INTO roster VALUES ('EC01', '001', '000000001', 'B');
INSERT INTO roster VALUES ('EC01', '001', '000000002', 'C');
INSERT INTO roster VALUES ('EC01', '001', '000000003', 'B');
INSERT INTO roster VALUES ('EC01', '001', '000000004', 'D');
INSERT INTO roster VALUES ('EC01', '001', '000000005', 'A');
INSERT INTO roster VALUES ('EC01', '001', '000000006', 'A');
INSERT INTO roster VALUES ('EC01', '001', '000000007', 'A');
INSERT INTO roster VALUES ('EC01', '001', '000000009', NULL);
INSERT INTO roster VALUES ('EC01', '001', '000000010', NULL);
INSERT INTO roster VALUES ('EC01', '001', '000000012', 'B');
INSERT INTO roster VALUES ('EC01', '001', '000000014', NULL);
INSERT INTO roster VALUES ('EC01', '001', '000000015', 'F');

CREATE INDEX IRstGrade ON roster(grade);

INSERT INTO roster VALUES ('EC01', '002', '000000008', 'B');
INSERT INTO roster VALUES ('EC01', '002', '000000011', 'B');
INSERT INTO roster VALUES ('EC01', '002', '000000013', 'D');

INSERT INTO roster VALUES ('EC02', '001', '000000003', 'B');
INSERT INTO roster VALUES ('EC02', '001', '000000006', 'A');

INSERT INTO roster VALUES ('EC03', '001', '000000000', 'B');
INSERT INTO roster VALUES ('EC03', '001', '000000004', 'A');
INSERT INTO roster VALUES ('EC03', '001', '000000005', 'B');
INSERT INTO roster VALUES ('EC03', '001', '000000010', 'B');

CREATE INDEX IRstGradeD ON roster(grade DESC);

INSERT INTO roster VALUES ('CS01', '001', '000000000', 'C');
INSERT INTO roster VALUES ('CS01', '001', '000000004', 'C');
INSERT INTO roster VALUES ('CS01', '001', '000000006', 'A');
INSERT INTO roster VALUES ('CS01', '001', '000000012', 'B');
INSERT INTO roster VALUES ('CS01', '001', '000000015', 'F');

INSERT INTO roster VALUES ('CS02', '001', '000000003', 'A');
INSERT INTO roster VALUES ('CS02', '001', '000000006', 'A');
INSERT INTO roster VALUES ('CS02', '001', '000000009', 'D');

INSERT INTO roster VALUES ('CS03', '001', '000000006', 'A');
INSERT INTO roster VALUES ('CS03', '001', '000000007', 'C');
INSERT INTO roster VALUES ('CS03', '001', '000000008', 'B');

INSERT INTO roster VALUES ('MA01', '001', '000000000', 'A');
INSERT INTO roster VALUES ('MA01', '001', '000000001', NULL);
INSERT INTO roster VALUES ('MA01', '001', '000000002', 'A');
INSERT INTO roster VALUES ('MA01', '001', '000000003', 'B');
INSERT INTO roster VALUES ('MA01', '001', '000000004', 'C');
INSERT INTO roster VALUES ('MA01', '001', '000000005', 'C');
INSERT INTO roster VALUES ('MA01', '001', '000000006', 'A');
INSERT INTO roster VALUES ('MA01', '001', '000000007', 'B');
INSERT INTO roster VALUES ('MA01', '001', '000000008', 'B');
INSERT INTO roster VALUES ('MA01', '001', '000000009', NULL);
INSERT INTO roster VALUES ('MA01', '001', '000000010', 'B');
INSERT INTO roster VALUES ('MA01', '001', '000000011', 'B');
INSERT INTO roster VALUES ('MA01', '001', '000000012', NULL);
INSERT INTO roster VALUES ('MA01', '001', '000000013', 'D');
INSERT INTO roster VALUES ('MA01', '001', '000000014', 'B');
INSERT INTO roster VALUES ('MA01', '001', '000000015', 'F');

INSERT INTO roster VALUES ('MA03', '001', '000000006', 'A');
INSERT INTO roster VALUES ('MA03', '001', '000000007', 'B');
INSERT INTO roster VALUES ('MA03', '001', '000000008', 'D');
INSERT INTO roster VALUES ('MA03', '001', '000000009', 'B');
INSERT INTO roster VALUES ('MA03', '001', '000000015', 'F');

INSERT INTO roster VALUES ('HY02', '001', '000000000', 'A');
INSERT INTO roster VALUES ('HY02', '001', '000000001', 'A');
INSERT INTO roster VALUES ('HY02', '001', '000000002', 'A');
INSERT INTO roster VALUES ('HY02', '001', '000000003', 'B');
INSERT INTO roster VALUES ('HY02', '001', '000000004', 'C');
INSERT INTO roster VALUES ('HY02', '001', '000000005', 'C');
INSERT INTO roster VALUES ('HY02', '001', '000000006', 'A');
INSERT INTO roster VALUES ('HY02', '001', '000000007', 'B');
INSERT INTO roster VALUES ('HY02', '001', '000000008', 'B');

INSERT INTO roster VALUES ('HY03', '001', '000000009', 'B');
INSERT INTO roster VALUES ('HY03', '001', '000000010', 'B');
INSERT INTO roster VALUES ('HY03', '001', '000000011', 'B');
INSERT INTO roster VALUES ('HY03', '001', '000000012', 'B');
INSERT INTO roster VALUES ('HY03', '001', '000000013', 'D');
INSERT INTO roster VALUES ('HY03', '001', '000000014', 'B');
INSERT INTO roster VALUES ('HY03', '001', '000000015', 'F');

INSERT INTO roster VALUES ('PY01', '001', '000000000', 'C');
INSERT INTO roster VALUES ('PY01', '001', '000000001', 'C');
INSERT INTO roster VALUES ('PY01', '001', '000000002', 'C');
INSERT INTO roster VALUES ('PY01', '001', '000000003', 'C');
INSERT INTO roster VALUES ('PY01', '001', '000000004', 'D');
INSERT INTO roster VALUES ('PY01', '001', '000000005', 'A');
INSERT INTO roster VALUES ('PY01', '001', '000000006', 'A');
INSERT INTO roster VALUES ('PY01', '001', '000000007', 'F');
INSERT INTO roster VALUES ('PY01', '001', '000000008', 'B');
INSERT INTO roster VALUES ('PY01', '001', '000000009', 'B');
INSERT INTO roster VALUES ('PY01', '001', '000000010', 'B');
INSERT INTO roster VALUES ('PY01', '001', '000000011', 'B');
INSERT INTO roster VALUES ('PY01', '001', '000000012', 'A');
INSERT INTO roster VALUES ('PY01', '001', '000000013', 'D');
INSERT INTO roster VALUES ('PY01', '001', '000000014', 'A');
INSERT INTO roster VALUES ('PY01', '001', '000000015', 'F');

INSERT INTO roster VALUES ('AR01', '001', '000000010', 'D');
INSERT INTO roster VALUES ('AR01', '001', '000000011', 'F');
INSERT INTO roster VALUES ('AR01', '001', '000000014', 'A');

INSERT INTO roster VALUES ('AR02', '001', '000000003', 'C');
INSERT INTO roster VALUES ('AR02', '001', '000000009', 'C');
INSERT INTO roster VALUES ('AR02', '001', '000000014', 'A');

INSERT INTO roster VALUES ('AR03', '001', '000000002', 'B');
INSERT INTO roster VALUES ('AR03', '001', '000000008', 'C');
INSERT INTO roster VALUES ('AR03', '001', '000000014', 'A');

INSERT INTO roster VALUES ('PS01', '001', '000000000', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000001', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000002', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000003', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000004', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000005', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000006', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000007', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000008', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000009', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000010', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000011', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000012', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000013', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000014', 'A');
INSERT INTO roster VALUES ('PS01', '001', '000000015', 'F');
INSERT INTO roster VALUES ('PS03', '001', '000000015', 'F');

INSERT INTO roster VALUES ('CH01', '001', '000000000', 'A');
INSERT INTO roster VALUES ('CH01', '001', '000000001', 'B');
INSERT INTO roster VALUES ('CH01', '001', '000000002', 'C');
INSERT INTO roster VALUES ('CH01', '001', '000000003', 'D');
INSERT INTO roster VALUES ('CH01', '001', '000000004', 'F');
INSERT INTO roster VALUES ('CH01', '001', '000000005', 'F');
INSERT INTO roster VALUES ('CH01', '001', '000000006', 'A');
INSERT INTO roster VALUES ('CH01', '001', '000000007', 'B');
INSERT INTO roster VALUES ('CH01', '001', '000000008', 'B');
INSERT INTO roster VALUES ('CH01', '001', '000000009', 'B');
INSERT INTO roster VALUES ('CH01', '001', '000000010', 'A');
INSERT INTO roster VALUES ('CH01', '001', '000000011', 'A');
INSERT INTO roster VALUES ('CH01', '001', '000000012', 'C');
INSERT INTO roster VALUES ('CH01', '001', '000000013', 'A');
INSERT INTO roster VALUES ('CH01', '001', '000000014', 'B');
INSERT INTO roster VALUES ('CH01', '001', '000000015', 'F');

SELECT COUNT(*) FROM student;
SELECT COUNT(*) FROM class;
SELECT COUNT(*) FROM roster;

SELECT * FROM student;
SELECT * FROM class;
SELECT * FROM roster;

SELECT * FROM student ORDER BY ssn DESC;
SELECT * FROM class ORDER BY classno DESC ;
SELECT * FROM roster ORDER BY classno DESC, ssn DESC;

SELECT classname, sectionno, firstname, lastname 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) 
ORDER BY classname, sectionno, lastname;

SELECT classname, firstname, lastname, grade 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'CS01' 
ORDER BY firstname, lastname, grade;

SELECT classname, firstname, lastname, grade  
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND roster.grade = 'A' 
ORDER BY firstname, lastname, grade;

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND student.age > 28 
ORDER BY firstname, lastname, age;

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND student.age <= 28 
ORDER BY firstname, lastname, age;

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND (student.age < 24 OR 
student.age > 27)   
ORDER BY firstname, lastname, age;

SELECT classname, age, COUNT(*) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND (student.age > 25) AND (student.age < 31) 
GROUP BY classname, age  
ORDER BY classname, age; 

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND student.age <> 28 
ORDER BY firstname, lastname, age;

SELECT classname, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) 
GROUP BY classname 
ORDER BY classname;

SELECT classname, COUNT(*) 
FROM   class, roster 
WHERE  (class.classno = roster.classno) 
GROUP BY classname 
ORDER BY classname;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) 
GROUP BY classname, grade 
ORDER BY classname, grade;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) 
GROUP BY classname, grade 
ORDER BY classname DESC, grade DESC;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) AND (roster.grade = 'A') 
GROUP BY classname, grade 
ORDER BY classname, grade;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (roster.grade = 'A') AND (class.classno = roster.classno)  
GROUP BY classname, grade 
ORDER BY classname, grade;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (roster.grade = 'A') AND (class.classno = roster.classno)  
GROUP BY classname, grade 
ORDER BY classname DESC, grade DESC;

SELECT student.ssn, SUM(class.coursefee) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) 
GROUP BY student.ssn 
ORDER BY student.ssn; 

SELECT student.ssn, MIN(class.coursefee) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn)
GROUP BY student.ssn 
ORDER BY student.ssn; 

SELECT student.ssn, MAX(class.coursefee) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) 
GROUP BY student.ssn 
ORDER BY student.ssn; 

-- Foreign keys are not enforced in DB2e!  UDB returns 23504
-- Thus we delete the child table entries first before deleting parent
DELETE FROM roster WHERE classno = 'PY01';
DELETE FROM class WHERE classno  = 'PY01'; 

UPDATE class SET classname = 'Biochemistry 101', coursefee = 100.00 WHERE classno = 'CH01';
UPDATE class SET classname = 'Biochemistry 201', coursefee = 125.00 WHERE classno = 'CH02';
UPDATE class SET classname = 'Biochemistry 301', coursefee = 150.00 WHERE classno = 'CH03';

DELETE FROM roster WHERE classno = 'MA03';
DELETE FROM class WHERE classno  = 'MA03';

UPDATE class SET coursefee = coursefee + 100, coursehrs = 5 WHERE classno = 'CH01';
UPDATE class SET coursefee = coursefee - 55, coursehrs = 2 WHERE classno = 'AR03';
UPDATE roster SET grade = 'A' WHERE classno = 'CS01';

DELETE FROM roster WHERE classno = 'HY03' OR classno = 'AR01';

INSERT INTO roster VALUES ('PY02', '001', '000000000', 'A');
INSERT INTO roster VALUES ('PY02', '001', '000000001', 'B');
INSERT INTO roster VALUES ('PY02', '001', '000000002', 'C');
INSERT INTO roster VALUES ('PY02', '001', '000000003', 'D');
INSERT INTO roster VALUES ('PY02', '001', '000000004', 'F');

DELETE FROM roster WHERE classno = 'PY02' AND ssn = '000000002';

UPDATE student SET age = age + 1 WHERE DoB > '10/10/1972';
UPDATE student SET major = 'Biochemistry' WHERE ssn = '000000011';
UPDATE student SET firstname = 'Steven' WHERE   ssn = '000000012';

SELECT COUNT(*) FROM student;
SELECT COUNT(*) FROM class;
SELECT COUNT(*) FROM roster;

SELECT * FROM student;
SELECT * FROM class;
SELECT * FROM roster;

SELECT * FROM student ORDER BY ssn DESC;
SELECT * FROM class ORDER BY classno DESC ;
SELECT * FROM roster ORDER BY classno DESC, ssn DESC;

SELECT classname, sectionno, firstname, lastname 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) 
ORDER BY classname, sectionno, lastname;

SELECT classname, firstname, lastname, grade 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'CS01' 
ORDER BY firstname, lastname, grade;

SELECT classname, firstname, lastname, grade  
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND roster.grade = 'A' 
ORDER BY firstname, lastname, grade;

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND student.age > 28 
ORDER BY firstname, lastname, age;

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND student.age <= 28 
ORDER BY firstname, lastname, age;

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND (student.age < 24 OR  
student.age > 27)   
ORDER BY firstname, lastname, age;

SELECT classname, age, COUNT(*) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND (student.age > 25) AND (student.age < 31) 
GROUP BY classname, age  
ORDER BY classname, age; 

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND student.age <> 28 
ORDER BY firstname, lastname, age;

SELECT classname, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) 
GROUP BY classname 
ORDER BY classname;

SELECT classname, COUNT(*) 
FROM   class, roster 
WHERE  (class.classno = roster.classno) 
GROUP BY classname 
ORDER BY classname;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) 
GROUP BY classname, grade 
ORDER BY classname, grade;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) 
GROUP BY classname, grade 
ORDER BY classname DESC, grade DESC;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) AND (roster.grade = 'A') 
GROUP BY classname, grade 
ORDER BY classname, grade;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (roster.grade = 'A') AND (class.classno = roster.classno)  
GROUP BY classname, grade 
ORDER BY classname, grade;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (roster.grade = 'A') AND (class.classno = roster.classno)  
GROUP BY classname, grade 
ORDER BY classname DESC, grade DESC;

SELECT student.ssn, SUM(class.coursefee) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) 
GROUP BY student.ssn 
ORDER BY student.ssn; 

SELECT student.ssn, MIN(class.coursefee) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn)
GROUP BY student.ssn 
ORDER BY student.ssn; 

SELECT student.ssn, MAX(class.coursefee) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) 
GROUP BY student.ssn 
ORDER BY student.ssn; 

DROP INDEX IStdLastname;
DROP INDEX IStdAge;
DROP INDEX IStdAgeD;
DROP INDEX IStdSsnD;
DROP INDEX IStdMajor;
DROP INDEX IStdDoB;

UPDATE student SET age = age - 1 WHERE DoB < '10/10/1972';
UPDATE student SET major = 'Chemistry' WHERE ssn = '000000011';
UPDATE student SET firstname = 'Stephen' WHERE ssn = '000000012';

DROP INDEX IClsCoursefee;
DROP INDEX IClsClassnameD;
DROP INDEX IClsClassname;

DELETE FROM roster  WHERE ssn = '000000000';
DELETE FROM student WHERE ssn = '000000000';
DELETE FROM roster  WHERE ssn = '000000014';
DELETE FROM student WHERE ssn = '000000014';
DELETE FROM roster  WHERE ssn = '000000013';
DELETE FROM student WHERE ssn = '000000013';
DELETE FROM roster  WHERE grade >= 'D';

DROP INDEX IRstClsnoSsnD;
DROP INDEX IRstGrade;
DROP INDEX IRstGradeD;

INSERT INTO student VALUES ('000000016', 'Lisa', 'Mak', 'Business', 'F', 30, '07/21/1970' );
INSERT INTO student VALUES ('000000017', 'Sally', 'Namek', 'Business', 'F', 26, '07/21/1974' );
INSERT INTO roster  VALUES ('PS01', '001', '000000016', 'B');
INSERT INTO roster  VALUES ('PS01', '001', '000000017', 'A');

SELECT COUNT(*) FROM student;
SELECT COUNT(*) FROM class;
SELECT COUNT(*) FROM roster;

SELECT * FROM student;
SELECT * FROM class;
SELECT * FROM roster;

SELECT * FROM student ORDER BY ssn DESC;
SELECT * FROM class ORDER BY classno DESC ;
SELECT * FROM roster ORDER BY classno DESC, ssn DESC;

SELECT classname, sectionno, firstname, lastname 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) 
ORDER BY classname, sectionno, lastname;

SELECT classname, firstname, lastname, grade 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'CS01' 
ORDER BY firstname, lastname, grade;

SELECT classname, firstname, lastname, grade  
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND roster.grade = 'A' 
ORDER BY firstname, lastname, grade;

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND student.age > 28 
ORDER BY firstname, lastname, age;

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND student.age <= 28 
ORDER BY firstname, lastname, age;

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND (student.age < 24 OR  
student.age > 27) 
ORDER BY firstname, lastname, age;

SELECT classname, age, COUNT(*) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND (student.age > 25) AND (student.age < 31) 
GROUP BY classname, age  
ORDER BY classname, age; 

SELECT classname, firstname, lastname, age 
FROM   student, roster, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) AND class.classno = 'EC01' AND student.age <> 28 
ORDER BY firstname, lastname, age;

SELECT classname, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) 
GROUP BY classname 
ORDER BY classname;

SELECT classname, COUNT(*) 
FROM   class, roster 
WHERE  (class.classno = roster.classno) 
GROUP BY classname 
ORDER BY classname;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) 
GROUP BY classname, grade 
ORDER BY classname, grade;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) 
GROUP BY classname, grade 
ORDER BY classname DESC, grade DESC;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (class.classno = roster.classno) AND (roster.grade = 'A') 
GROUP BY classname, grade 
ORDER BY classname, grade;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (roster.grade = 'A') AND (class.classno = roster.classno)  
GROUP BY classname, grade 
ORDER BY classname, grade;

SELECT classname, grade, COUNT(*) 
FROM   roster, class 
WHERE  (roster.grade = 'A') AND (class.classno = roster.classno)  
GROUP BY classname, grade 
ORDER BY classname DESC, grade DESC;

SELECT student.ssn, SUM(class.coursefee) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) 
GROUP BY student.ssn 
ORDER BY student.ssn; 

SELECT student.ssn, MIN(class.coursefee) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn)
GROUP BY student.ssn 
ORDER BY student.ssn; 

SELECT student.ssn, MAX(class.coursefee) 
FROM   roster, student, class 
WHERE (class.classno = roster.classno) AND (student.ssn = roster.ssn) 
GROUP BY student.ssn 
ORDER BY student.ssn; 

DROP TABLE student;
DROP TABLE roster;
DROP TABLE class;

------------------------------------
-- End of idx02.sql
------------------------------------

---------------------------------
-- Test for Indexing - idx03.sql
---------------------------------

DROP TABLE T;
DROP TABLE S;

-- -------------------------------------------
-- 3PT001
-- Basic index support testing
-- INT Descending index
-- -------------------------------------------
--

CREATE TABLE T ( a INT );
CREATE INDEX  Id on T(a DESC);
INSERT INTO T VALUES (0);
INSERT INTO T VALUES (1);
INSERT INTO T VALUES (2);
INSERT INTO T VALUES (3);
INSERT INTO T VALUES (-1);
INSERT INTO T VALUES (-2);
INSERT INTO T VALUES (-3);

-- start key, no stop key
SELECT * FROM T WHERE a < 0;
SELECT * FROM T WHERE 0 > a;

SELECT * FROM T WHERE a < 1;
SELECT * FROM T WHERE a < -1;

-- start key, no stop key
SELECT * FROM T WHERE a <= 0;
SELECT * FROM T WHERE 0 >= a;

SELECT * FROM T WHERE a <= 1;
SELECT * FROM T WHERE a <= -1;

-- no start key, stop key
SELECT * FROM T WHERE a > 0;
SELECT * FROM T WHERE 0 < a;

SELECT * FROM T WHERE a > 1;
SELECT * FROM T WHERE a > -1;

-- no start key, stop key
SELECT * FROM T WHERE a >= 0;
SELECT * FROM T WHERE 0 <= a;

SELECT * FROM T WHERE a >= 1;
SELECT * FROM T WHERE a >= -1;

SELECT * FROM T WHERE a <= 2 AND a >= -2;
SELECT * FROM T WHERE a >= -2 AND a <= 2;

DROP INDEX Id;

SELECT * FROM T WHERE a < 0;
SELECT * FROM T WHERE 0 > a;

SELECT * FROM T WHERE a < 1;
SELECT * FROM T WHERE a < -1;

SELECT * FROM T WHERE a <= 0;
SELECT * FROM T WHERE 0 >= a;

SELECT * FROM T WHERE a <= 1;
SELECT * FROM T WHERE a <= -1;

SELECT * FROM T WHERE a > 0;
SELECT * FROM T WHERE 0 < a;

SELECT * FROM T WHERE a > 1;
SELECT * FROM T WHERE a > -1;

SELECT * FROM T WHERE a >= 0;
SELECT * FROM T WHERE 0 <= a;

SELECT * FROM T WHERE a >= 1;
SELECT * FROM T WHERE a >= -1;

SELECT * FROM T WHERE a <= 2 AND a >= -2;
SELECT * FROM T WHERE a >= -2 AND a <= 2;

DROP TABLE T;

-- -------------------------------------------
-- 3PT002
-- Basic index support testing
-- INT Ascending index
-- -------------------------------------------
--

CREATE TABLE S ( a INT );
CREATE INDEX  Ia on S(a ASC);
INSERT INTO S VALUES (0);
INSERT INTO S VALUES (1);
INSERT INTO S VALUES (2);
INSERT INTO S VALUES (3);
INSERT INTO S VALUES (-1);
INSERT INTO S VALUES (-2);
INSERT INTO S VALUES (-3);

-- no start key, stop key
SELECT * FROM S WHERE a < 0;
SELECT * FROM S WHERE 0 > a;

SELECT * FROM S WHERE a < 1;
SELECT * FROM S WHERE a < -1;

-- no start key, stop key
SELECT * FROM S WHERE a <= 0;
SELECT * FROM S WHERE 0 >= a;

SELECT * FROM S WHERE a <= 1;
SELECT * FROM S WHERE a <= -1;

-- start key, no stop key
SELECT * FROM S WHERE a > 0;
SELECT * FROM S WHERE 0 < a;

SELECT * FROM S WHERE a > 1;
SELECT * FROM S WHERE a > -1;

-- start key, no stop key
SELECT * FROM S WHERE a >= 0;
SELECT * FROM S WHERE 0 <= a;

SELECT * FROM S WHERE a >= 1;
SELECT * FROM S WHERE a >= -1;

SELECT * FROM S WHERE a <= 2 AND a >= -2;
SELECT * FROM S WHERE a >= -2 AND a <= 2;

DROP INDEX Ia;

-- forcing table scan
SELECT * FROM S WHERE a < 0;
SELECT * FROM S WHERE 0 > a;

SELECT * FROM S WHERE a < 1;
SELECT * FROM S WHERE a < -1;

SELECT * FROM S WHERE a <= 0;
SELECT * FROM S WHERE 0 >= a;

SELECT * FROM S WHERE a <= 1;
SELECT * FROM S WHERE a <= -1;

SELECT * FROM S WHERE a > 0;
SELECT * FROM S WHERE 0 < a;

SELECT * FROM S WHERE a > 1;
SELECT * FROM S WHERE a > -1;

SELECT * FROM S WHERE a >= 0;
SELECT * FROM S WHERE 0 <= a;

SELECT * FROM S WHERE a >= 1;
SELECT * FROM S WHERE a >= -1;

SELECT * FROM S WHERE a <= 2 AND a >= -2;
SELECT * FROM S WHERE a >= -2 AND a <= 2;

DROP TABLE S;

-- -------------------------------------------
-- 3PT003
-- Basic index support testing
-- SMALLINT Descending index
-- -------------------------------------------
--

CREATE TABLE T ( a SMALLINT );
CREATE INDEX  Id on T(a DESC);
INSERT INTO T VALUES (0);
INSERT INTO T VALUES (1);
INSERT INTO T VALUES (2);
INSERT INTO T VALUES (3);
INSERT INTO T VALUES (-1);
INSERT INTO T VALUES (-2);
INSERT INTO T VALUES (-3);

-- start key, no stop key
SELECT * FROM T WHERE a < 0;
SELECT * FROM T WHERE 0 > a;

SELECT * FROM T WHERE a < 1;
SELECT * FROM T WHERE a < -1;

-- start key, no stop key
SELECT * FROM T WHERE a <= 0;
SELECT * FROM T WHERE 0 >= a;

SELECT * FROM T WHERE a <= 1;
SELECT * FROM T WHERE a <= -1;

-- no start key, stop key
SELECT * FROM T WHERE a > 0;
SELECT * FROM T WHERE 0 < a;

SELECT * FROM T WHERE a > 1;
SELECT * FROM T WHERE a > -1;

-- no start key, stop key
SELECT * FROM T WHERE a >= 0;
SELECT * FROM T WHERE 0 <= a;

SELECT * FROM T WHERE a >= 1;
SELECT * FROM T WHERE a >= -1;

SELECT * FROM T WHERE a <= 2 AND a >= -2;
SELECT * FROM T WHERE a >= -2 AND a <= 2;

DROP INDEX Id;

SELECT * FROM T WHERE a < 0;
SELECT * FROM T WHERE 0 > a;

SELECT * FROM T WHERE a < 1;
SELECT * FROM T WHERE a < -1;

SELECT * FROM T WHERE a <= 0;
SELECT * FROM T WHERE 0 >= a;

SELECT * FROM T WHERE a <= 1;
SELECT * FROM T WHERE a <= -1;

SELECT * FROM T WHERE a > 0;
SELECT * FROM T WHERE 0 < a;

SELECT * FROM T WHERE a > 1;
SELECT * FROM T WHERE a > -1;

SELECT * FROM T WHERE a >= 0;
SELECT * FROM T WHERE 0 <= a;

SELECT * FROM T WHERE a >= 1;
SELECT * FROM T WHERE a >= -1;

SELECT * FROM T WHERE a <= 2 AND a >= -2;
SELECT * FROM T WHERE a >= -2 AND a <= 2;

DROP TABLE T;

-- -------------------------------------------
-- 3PT004
-- Basic index support testing
-- SMALLINT Ascending index
-- -------------------------------------------
--

CREATE TABLE S ( a SMALLINT );
CREATE INDEX  Ia on S(a ASC);
INSERT INTO S VALUES (0);
INSERT INTO S VALUES (1);
INSERT INTO S VALUES (2);
INSERT INTO S VALUES (3);
INSERT INTO S VALUES (-1);
INSERT INTO S VALUES (-2);
INSERT INTO S VALUES (-3);

-- no start key, stop key
SELECT * FROM S WHERE a < 0;
SELECT * FROM S WHERE 0 > a;

SELECT * FROM S WHERE a < 1;
SELECT * FROM S WHERE a < -1;

-- no start key, stop key
SELECT * FROM S WHERE a <= 0;
SELECT * FROM S WHERE 0 >= a;

SELECT * FROM S WHERE a <= 1;
SELECT * FROM S WHERE a <= -1;

-- start key, no stop key
SELECT * FROM S WHERE a > 0;
SELECT * FROM S WHERE 0 < a;

SELECT * FROM S WHERE a > 1;
SELECT * FROM S WHERE a > -1;

-- start key, no stop key
SELECT * FROM S WHERE a >= 0;
SELECT * FROM S WHERE 0 <= a;

SELECT * FROM S WHERE a >= 1;
SELECT * FROM S WHERE a >= -1;

SELECT * FROM S WHERE a <= 2 AND a >= -2;
SELECT * FROM S WHERE a >= -2 AND a <= 2;

DROP INDEX Ia;

-- forcing table scan
SELECT * FROM S WHERE a < 0;
SELECT * FROM S WHERE 0 > a;

SELECT * FROM S WHERE a < 1;
SELECT * FROM S WHERE a < -1;

SELECT * FROM S WHERE a <= 0;
SELECT * FROM S WHERE 0 >= a;

SELECT * FROM S WHERE a <= 1;
SELECT * FROM S WHERE a <= -1;

SELECT * FROM S WHERE a > 0;
SELECT * FROM S WHERE 0 < a;

SELECT * FROM S WHERE a > 1;
SELECT * FROM S WHERE a > -1;

SELECT * FROM S WHERE a >= 0;
SELECT * FROM S WHERE 0 <= a;

SELECT * FROM S WHERE a >= 1;
SELECT * FROM S WHERE a >= -1;

SELECT * FROM S WHERE a <= 2 AND a >= -2;
SELECT * FROM S WHERE a >= -2 AND a <= 2;

DROP TABLE S;

-- -------------------------------------------
-- 3PT005
-- Basic index support testing
-- DECIMAL Descending index
-- -------------------------------------------
--

CREATE TABLE T ( a DECIMAL(5,2) );
CREATE INDEX  Id on T(a DESC);
INSERT INTO T VALUES (0.00);
INSERT INTO T VALUES (1.11);
INSERT INTO T VALUES (2.22);
INSERT INTO T VALUES (3.33);
INSERT INTO T VALUES (-1.11);
INSERT INTO T VALUES (-2.22);
INSERT INTO T VALUES (-3.33);

-- start key, no stop key
SELECT * FROM T WHERE a < 0.00;
SELECT * FROM T WHERE 0.00 > a;

SELECT * FROM T WHERE a < 1.11;
SELECT * FROM T WHERE a < -1.11;

-- start key, no stop key
SELECT * FROM T WHERE a <= 0.00;
SELECT * FROM T WHERE 0.00 >= a;

SELECT * FROM T WHERE a <= 1.11;
SELECT * FROM T WHERE a <= -1.11;

-- no start key, stop key
SELECT * FROM T WHERE a > 0.00;
SELECT * FROM T WHERE 0.00 < a;

SELECT * FROM T WHERE a > 1.11;
SELECT * FROM T WHERE a > -1.11;

-- no start key, stop key
SELECT * FROM T WHERE a >= 0.00;
SELECT * FROM T WHERE 0.00 <= a;

SELECT * FROM T WHERE a >= 1.11;
SELECT * FROM T WHERE a >= -1.11;

SELECT * FROM T WHERE a <= 2.22 AND a >= -2.22;
SELECT * FROM T WHERE a >= -2.22 AND a <= 2.22;

DROP INDEX Id;

SELECT * FROM T WHERE a < 0.00;
SELECT * FROM T WHERE 0.00 > a;

SELECT * FROM T WHERE a < 1.11;
SELECT * FROM T WHERE a < -1.11;

SELECT * FROM T WHERE a <= 0.00;
SELECT * FROM T WHERE 0.00 >= a;

SELECT * FROM T WHERE a <= 1.11;
SELECT * FROM T WHERE a <= -1.11;

SELECT * FROM T WHERE a > 0.00;
SELECT * FROM T WHERE 0.00 < a;

SELECT * FROM T WHERE a > 1.11;
SELECT * FROM T WHERE a > -1.11;

SELECT * FROM T WHERE a >= 0.00;
SELECT * FROM T WHERE 0.00 <= a;

SELECT * FROM T WHERE a >= 1.11;
SELECT * FROM T WHERE a >= -1.11;

SELECT * FROM T WHERE a <= 2.22 AND a >= -2.22;
SELECT * FROM T WHERE a >= -2.22 AND a <= 2.22;

DROP TABLE T;

-- -------------------------------------------
-- 3PT006
-- Basic index support testing
-- DECIMAL Ascending index
-- -------------------------------------------
--

CREATE TABLE S ( a DECIMAL(5,2) );
CREATE INDEX  Ia on S(a ASC);
INSERT INTO S VALUES (0.00);
INSERT INTO S VALUES (1.11);
INSERT INTO S VALUES (2.22);
INSERT INTO S VALUES (3.33);
INSERT INTO S VALUES (-1.11);
INSERT INTO S VALUES (-2.22);
INSERT INTO S VALUES (-3.33);

-- no start key, stop key
SELECT * FROM S WHERE a < 0.00;
SELECT * FROM S WHERE 0.00 > a;

SELECT * FROM S WHERE a < 1.11;
SELECT * FROM S WHERE a < -1.11;

-- no start key, stop key
SELECT * FROM S WHERE a <= 0.00;
SELECT * FROM S WHERE 0.00 >= a;

SELECT * FROM S WHERE a <= 1.11;
SELECT * FROM S WHERE a <= -1.11;

-- start key, no stop key
SELECT * FROM S WHERE a > 0.00;
SELECT * FROM S WHERE 0.00 < a;

SELECT * FROM S WHERE a > 1.11;
SELECT * FROM S WHERE a > -1.11;

-- start key, no stop key
SELECT * FROM S WHERE a >= 0.00;
SELECT * FROM S WHERE 0.00 <= a;

SELECT * FROM S WHERE a >= 1.11;
SELECT * FROM S WHERE a >= -1.11;

SELECT * FROM S WHERE a <= 2.22 AND a >= -2.22;
SELECT * FROM S WHERE a >= -2.22 AND a <= 2.22;

DROP INDEX Ia;

-- forcing table scan
SELECT * FROM S WHERE a < 0.00;
SELECT * FROM S WHERE 0.00 > a;

SELECT * FROM S WHERE a < 1.11;
SELECT * FROM S WHERE a < -1.11;

SELECT * FROM S WHERE a <= 0.00;
SELECT * FROM S WHERE 0.00 >= a;

SELECT * FROM S WHERE a <= 1.11;
SELECT * FROM S WHERE a <= -1.11;

SELECT * FROM S WHERE a > 0.00;
SELECT * FROM S WHERE 0.00 < a;

SELECT * FROM S WHERE a > 1.11;
SELECT * FROM S WHERE a > -1.11;

SELECT * FROM S WHERE a >= 0.00;
SELECT * FROM S WHERE 0.00 <= a;

SELECT * FROM S WHERE a >= 1.11;
SELECT * FROM S WHERE a >= -1.11;

SELECT * FROM S WHERE a <= 2.22 AND a >= -2.22;
SELECT * FROM S WHERE a >= -2.22 AND a <= 2.22;

DROP TABLE S;

-- -------------------------------------------
-- 3PT007
-- Basic index support testing
-- CHAR Descending index
-- -------------------------------------------
--

CREATE TABLE T ( a CHAR(10) );
CREATE INDEX  Id on T(a DESC);
INSERT INTO T VALUES ('Thanh');    
INSERT INTO T VALUES ('Jonas');    
INSERT INTO T VALUES ('Cliff');    
INSERT INTO T VALUES ('Michael');   
INSERT INTO T VALUES ('Yip-Hing');  
INSERT INTO T VALUES ('Amrish');    
INSERT INTO T VALUES ('Josephine'); 

-- start key, no stop key
SELECT * FROM T WHERE a < 'Josephine';
SELECT * FROM T WHERE 'Josephine' > a;

SELECT * FROM T WHERE a < 'Michael';
SELECT * FROM T WHERE a < 'Jonas';

-- start key, no stop key
SELECT * FROM T WHERE a <= 'Josephine';
SELECT * FROM T WHERE 'Josephine' >= a;

SELECT * FROM T WHERE a <= 'Michael';
SELECT * FROM T WHERE a <= 'Jonas';

-- no start key, stop key
SELECT * FROM T WHERE a > 'Josephine';
SELECT * FROM T WHERE 'Josephine' < a;

SELECT * FROM T WHERE a > 'Michael';
SELECT * FROM T WHERE a > 'Jonas';

-- no start key, stop key
SELECT * FROM T WHERE a >= 'Josephine';
SELECT * FROM T WHERE 'Josephine' <= a;

SELECT * FROM T WHERE a >= 'Michael';
SELECT * FROM T WHERE a >= 'Jonas';

SELECT * FROM T WHERE a <= 'Thanh' AND a >= 'Cliff';
SELECT * FROM T WHERE a >= 'Cliff' AND a <= 'Thanh';

DROP INDEX Id;

SELECT * FROM T WHERE a < 'Josephine';
SELECT * FROM T WHERE 'Josephine' > a;

SELECT * FROM T WHERE a < 'Michael';
SELECT * FROM T WHERE a < 'Jonas';

SELECT * FROM T WHERE a <= 'Josephine';
SELECT * FROM T WHERE 'Josephine' >= a;

SELECT * FROM T WHERE a <= 'Michael';
SELECT * FROM T WHERE a <= 'Jonas';

SELECT * FROM T WHERE a > 'Josephine';
SELECT * FROM T WHERE 'Josephine' < a;

SELECT * FROM T WHERE a > 'Michael';
SELECT * FROM T WHERE a > 'Jonas';

SELECT * FROM T WHERE a >= 'Josephine';
SELECT * FROM T WHERE 'Josephine' <= a;

SELECT * FROM T WHERE a >= 'Michael';
SELECT * FROM T WHERE a >= 'Jonas';

SELECT * FROM T WHERE a <= 'Thanh' AND a >= 'Cliff';
SELECT * FROM T WHERE a >= 'Cliff' AND a <= 'Thanh';

DROP TABLE T;

-- -------------------------------------------
-- 3PT008
-- Basic index support testing
-- CHAR Ascending index
-- -------------------------------------------
--

CREATE TABLE S ( a CHAR(10) );
CREATE INDEX  Ia on S(a ASC);
INSERT INTO S VALUES ('Thanh');    
INSERT INTO S VALUES ('Jonas');    
INSERT INTO S VALUES ('Cliff');    
INSERT INTO S VALUES ('Michael');   
INSERT INTO S VALUES ('Yip-Hing');  
INSERT INTO S VALUES ('Amrish');    
INSERT INTO S VALUES ('Josephine'); 

-- start key, no stop key
SELECT * FROM S WHERE a < 'Josephine';
SELECT * FROM S WHERE 'Josephine' > a;

SELECT * FROM S WHERE a < 'Michael';
SELECT * FROM S WHERE a < 'Jonas';

-- start key, no stop key
SELECT * FROM S WHERE a <= 'Josephine';
SELECT * FROM S WHERE 'Josephine' >= a;

SELECT * FROM S WHERE a <= 'Michael';
SELECT * FROM S WHERE a <= 'Jonas';

-- no start key, stop key
SELECT * FROM S WHERE a > 'Josephine';
SELECT * FROM S WHERE 'Josephine' < a;

SELECT * FROM S WHERE a > 'Michael';
SELECT * FROM S WHERE a > 'Jonas';

-- no start key, stop key
SELECT * FROM S WHERE a >= 'Josephine';
SELECT * FROM S WHERE 'Josephine' <= a;

SELECT * FROM S WHERE a >= 'Michael';
SELECT * FROM S WHERE a >= 'Jonas';

SELECT * FROM S WHERE a <= 'Thanh' AND a >= 'Cliff';
SELECT * FROM S WHERE a >= 'Cliff' AND a <= 'Thanh';

DROP INDEX Ia;

SELECT * FROM S WHERE a < 'Josephine';
SELECT * FROM S WHERE 'Josephine' > a;

SELECT * FROM S WHERE a < 'Michael';
SELECT * FROM S WHERE a < 'Jonas';

SELECT * FROM S WHERE a <= 'Josephine';
SELECT * FROM S WHERE 'Josephine' >= a;

SELECT * FROM S WHERE a <= 'Michael';
SELECT * FROM S WHERE a <= 'Jonas';

SELECT * FROM S WHERE a > 'Josephine';
SELECT * FROM S WHERE 'Josephine' < a;

SELECT * FROM S WHERE a > 'Michael';
SELECT * FROM S WHERE a > 'Jonas';

SELECT * FROM S WHERE a >= 'Josephine';
SELECT * FROM S WHERE 'Josephine' <= a;

SELECT * FROM S WHERE a >= 'Michael';
SELECT * FROM S WHERE a >= 'Jonas';

SELECT * FROM S WHERE a <= 'Thanh' AND a >= 'Cliff';
SELECT * FROM S WHERE a >= 'Cliff' AND a <= 'Thanh';

DROP TABLE S;

-- -------------------------------------------
-- 3PT009
-- Basic index support testing
-- VARCHAR Descending index
-- -------------------------------------------
--

CREATE TABLE T ( a VARCHAR(10) );
CREATE INDEX  Id on T(a DESC);
INSERT INTO T VALUES ('Thanh');    
INSERT INTO T VALUES ('Jonas');    
INSERT INTO T VALUES ('Cliff');    
INSERT INTO T VALUES ('Michael');   
INSERT INTO T VALUES ('Yip-Hing');  
INSERT INTO T VALUES ('Amrish');    
INSERT INTO T VALUES ('Josephine'); 

-- start key, no stop key
SELECT * FROM T WHERE a < 'Josephine';
SELECT * FROM T WHERE 'Josephine' > a;

SELECT * FROM T WHERE a < 'Michael';
SELECT * FROM T WHERE a < 'Jonas';

-- start key, no stop key
SELECT * FROM T WHERE a <= 'Josephine';
SELECT * FROM T WHERE 'Josephine' >= a;

SELECT * FROM T WHERE a <= 'Michael';
SELECT * FROM T WHERE a <= 'Jonas';

-- no start key, stop key
SELECT * FROM T WHERE a > 'Josephine';
SELECT * FROM T WHERE 'Josephine' < a;

SELECT * FROM T WHERE a > 'Michael';
SELECT * FROM T WHERE a > 'Jonas';

-- no start key, stop key
SELECT * FROM T WHERE a >= 'Josephine';
SELECT * FROM T WHERE 'Josephine' <= a;

SELECT * FROM T WHERE a >= 'Michael';
SELECT * FROM T WHERE a >= 'Jonas';

SELECT * FROM T WHERE a <= 'Thanh' AND a >= 'Cliff';
SELECT * FROM T WHERE a >= 'Cliff' AND a <= 'Thanh';

DROP INDEX Id;

SELECT * FROM T WHERE a < 'Josephine';
SELECT * FROM T WHERE 'Josephine' > a;

SELECT * FROM T WHERE a < 'Michael';
SELECT * FROM T WHERE a < 'Jonas';

SELECT * FROM T WHERE a <= 'Josephine';
SELECT * FROM T WHERE 'Josephine' >= a;

SELECT * FROM T WHERE a <= 'Michael';
SELECT * FROM T WHERE a <= 'Jonas';

SELECT * FROM T WHERE a > 'Josephine';
SELECT * FROM T WHERE 'Josephine' < a;

SELECT * FROM T WHERE a > 'Michael';
SELECT * FROM T WHERE a > 'Jonas';

SELECT * FROM T WHERE a >= 'Josephine';
SELECT * FROM T WHERE 'Josephine' <= a;

SELECT * FROM T WHERE a >= 'Michael';
SELECT * FROM T WHERE a >= 'Jonas';

SELECT * FROM T WHERE a <= 'Thanh' AND a >= 'Cliff';
SELECT * FROM T WHERE a >= 'Cliff' AND a <= 'Thanh';

DROP TABLE T;

-- -------------------------------------------
-- 3PT010
-- Basic index support testing
-- VARCHAR Ascending index
-- -------------------------------------------
--

CREATE TABLE S ( a VARCHAR(10) );
CREATE INDEX  Ia on S(a ASC);
INSERT INTO S VALUES ('Thanh');    
INSERT INTO S VALUES ('Jonas');    
INSERT INTO S VALUES ('Cliff');    
INSERT INTO S VALUES ('Michael');   
INSERT INTO S VALUES ('Yip-Hing');  
INSERT INTO S VALUES ('Amrish');    
INSERT INTO S VALUES ('Josephine'); 

-- start key, no stop key
SELECT * FROM S WHERE a < 'Josephine';
SELECT * FROM S WHERE 'Josephine' > a;

SELECT * FROM S WHERE a < 'Michael';
SELECT * FROM S WHERE a < 'Jonas';

-- start key, no stop key
SELECT * FROM S WHERE a <= 'Josephine';
SELECT * FROM S WHERE 'Josephine' >= a;

SELECT * FROM S WHERE a <= 'Michael';
SELECT * FROM S WHERE a <= 'Jonas';

-- no start key, stop key
SELECT * FROM S WHERE a > 'Josephine';
SELECT * FROM S WHERE 'Josephine' < a;

SELECT * FROM S WHERE a > 'Michael';
SELECT * FROM S WHERE a > 'Jonas';

-- no start key, stop key
SELECT * FROM S WHERE a >= 'Josephine';
SELECT * FROM S WHERE 'Josephine' <= a;

SELECT * FROM S WHERE a >= 'Michael';
SELECT * FROM S WHERE a >= 'Jonas';

SELECT * FROM S WHERE a <= 'Thanh' AND a >= 'Cliff';
SELECT * FROM S WHERE a >= 'Cliff' AND a <= 'Thanh';

DROP INDEX Ia;

SELECT * FROM S WHERE a < 'Josephine';
SELECT * FROM S WHERE 'Josephine' > a;

SELECT * FROM S WHERE a < 'Michael';
SELECT * FROM S WHERE a < 'Jonas';

SELECT * FROM S WHERE a <= 'Josephine';
SELECT * FROM S WHERE 'Josephine' >= a;

SELECT * FROM S WHERE a <= 'Michael';
SELECT * FROM S WHERE a <= 'Jonas';

SELECT * FROM S WHERE a > 'Josephine';
SELECT * FROM S WHERE 'Josephine' < a;

SELECT * FROM S WHERE a > 'Michael';
SELECT * FROM S WHERE a > 'Jonas';

SELECT * FROM S WHERE a >= 'Josephine';
SELECT * FROM S WHERE 'Josephine' <= a;

SELECT * FROM S WHERE a >= 'Michael';
SELECT * FROM S WHERE a >= 'Jonas';

SELECT * FROM S WHERE a <= 'Thanh' AND a >= 'Cliff';
SELECT * FROM S WHERE a >= 'Cliff' AND a <= 'Thanh';

DROP TABLE S;

-- -------------------------------------------
-- 3PT011
-- Basic index support testing
-- DATE Descending index
-- -------------------------------------------
--

CREATE TABLE T ( a DATE );
CREATE INDEX  Id on T(a DESC);
INSERT INTO T VALUES ('02/29/2000');
INSERT INTO T VALUES ('05/20/2000');
INSERT INTO T VALUES ('06/14/2000');
INSERT INTO T VALUES ('09/16/2000');
INSERT INTO T VALUES ('01/01/2000');
INSERT INTO T VALUES ('12/12/1999');
INSERT INTO T VALUES ('07/14/1995');

-- start key, no stop key
SELECT * FROM T WHERE a < '02/29/2000';
SELECT * FROM T WHERE '02/29/2000' > a;

SELECT * FROM T WHERE a < '05/20/2000';
SELECT * FROM T WHERE a < '01/01/2000';

-- start key, no stop key
SELECT * FROM T WHERE a <= '02/29/2000';
SELECT * FROM T WHERE '02/29/2000' >= a;

SELECT * FROM T WHERE a <= '05/20/2000';
SELECT * FROM T WHERE a <= '01/01/2000';

-- no start key, stop key
SELECT * FROM T WHERE a > '02/29/2000';
SELECT * FROM T WHERE '02/29/2000' < a;

SELECT * FROM T WHERE a > '05/20/2000';
SELECT * FROM T WHERE a > '01/01/2000';

-- no start key, stop key
SELECT * FROM T WHERE a >= '02/29/2000';
SELECT * FROM T WHERE '02/29/2000' <= a;

SELECT * FROM T WHERE a >= '05/20/2000';
SELECT * FROM T WHERE a >= '01/01/2000';

SELECT * FROM T WHERE a <= '06/14/2000' AND a >= '12/12/1999';
SELECT * FROM T WHERE a >= '12/12/1999' AND a <= '06/14/2000';

DROP INDEX Id;

SELECT * FROM T WHERE a < '02/29/2000';
SELECT * FROM T WHERE '02/29/2000' > a;

SELECT * FROM T WHERE a < '05/20/2000';
SELECT * FROM T WHERE a < '01/01/2000';

SELECT * FROM T WHERE a <= '02/29/2000';
SELECT * FROM T WHERE '02/29/2000' >= a;

SELECT * FROM T WHERE a <= '05/20/2000';
SELECT * FROM T WHERE a <= '01/01/2000';

SELECT * FROM T WHERE a > '02/29/2000';
SELECT * FROM T WHERE '02/29/2000' < a;

SELECT * FROM T WHERE a > '05/20/2000';
SELECT * FROM T WHERE a > '01/01/2000';

SELECT * FROM T WHERE a >= '02/29/2000';
SELECT * FROM T WHERE '02/29/2000' <= a;

SELECT * FROM T WHERE a >= '05/20/2000';
SELECT * FROM T WHERE a >= '01/01/2000';

SELECT * FROM T WHERE a <= '06/14/2000' AND a >= '12/12/1999';
SELECT * FROM T WHERE a >= '12/12/1999' AND a <= '06/14/2000';

DROP TABLE T;

-- -------------------------------------------
-- 3PT012
-- Basic index support testing
-- DATE Ascending index
-- -------------------------------------------
--

CREATE TABLE S ( a DATE );
CREATE INDEX  Ia on S(a ASC);
INSERT INTO S VALUES ('02/29/2000');
INSERT INTO S VALUES ('05/20/2000');
INSERT INTO S VALUES ('06/14/2000');
INSERT INTO S VALUES ('09/16/2000');
INSERT INTO S VALUES ('01/01/2000');
INSERT INTO S VALUES ('12/12/1999');
INSERT INTO S VALUES ('07/14/1995');

-- start key, no stop key
SELECT * FROM S WHERE a < '02/29/2000';
SELECT * FROM S WHERE '02/29/2000' > a;

SELECT * FROM S WHERE a < '05/20/2000';
SELECT * FROM S WHERE a < '01/01/2000';

-- start key, no stop key
SELECT * FROM S WHERE a <= '02/29/2000';
SELECT * FROM S WHERE '02/29/2000' >= a;

SELECT * FROM S WHERE a <= '05/20/2000';
SELECT * FROM S WHERE a <= '01/01/2000';

-- no start key, stop key
SELECT * FROM S WHERE a > '02/29/2000';
SELECT * FROM S WHERE '02/29/2000' < a;

SELECT * FROM S WHERE a > '05/20/2000';
SELECT * FROM S WHERE a > '01/01/2000';

-- no start key, stop key
SELECT * FROM S WHERE a >= '02/29/2000';
SELECT * FROM S WHERE '02/29/2000' <= a;

SELECT * FROM S WHERE a >= '05/20/2000';
SELECT * FROM S WHERE a >= '01/01/2000';

SELECT * FROM S WHERE a <= '06/14/2000' AND a >= '12/12/1999';
SELECT * FROM S WHERE a >= '12/12/1999' AND a <= '06/14/2000';

DROP INDEX Ia;

SELECT * FROM S WHERE a < '02/29/2000';
SELECT * FROM S WHERE '02/29/2000' > a;

SELECT * FROM S WHERE a < '05/20/2000';
SELECT * FROM S WHERE a < '01/01/2000';

SELECT * FROM S WHERE a <= '02/29/2000';
SELECT * FROM S WHERE '02/29/2000' >= a;

SELECT * FROM S WHERE a <= '05/20/2000';
SELECT * FROM S WHERE a <= '01/01/2000';

SELECT * FROM S WHERE a > '02/29/2000';
SELECT * FROM S WHERE '02/29/2000' < a;

SELECT * FROM S WHERE a > '05/20/2000';
SELECT * FROM S WHERE a > '01/01/2000';

SELECT * FROM S WHERE a >= '02/29/2000';
SELECT * FROM S WHERE '02/29/2000' <= a;

SELECT * FROM S WHERE a >= '05/20/2000';
SELECT * FROM S WHERE a >= '01/01/2000';

SELECT * FROM S WHERE a <= '06/14/2000' AND a >= '12/12/1999';
SELECT * FROM S WHERE a >= '12/12/1999' AND a <= '06/14/2000';

DROP TABLE S;

-- -------------------------------------------
-- 3PT013
-- Basic index support testing
-- TIME Descending index
-- -------------------------------------------
--

CREATE TABLE T ( a TIME );
CREATE INDEX  Id on T(a DESC);
INSERT INTO T VALUES ('12:00:00');
INSERT INTO T VALUES ('13:15:10');
INSERT INTO T VALUES ('14:30:20');
INSERT INTO T VALUES ('15:45:30');
INSERT INTO T VALUES ('11:15:10');
INSERT INTO T VALUES ('10:30:20');
INSERT INTO T VALUES ('09:45:30');

-- start key, no stop key
SELECT * FROM T WHERE a < '12:00:00';
SELECT * FROM T WHERE '12:00:00'> a;

SELECT * FROM T WHERE a < '13:15:10';
SELECT * FROM T WHERE a < '11:15:10';

-- start key, no stop key
SELECT * FROM T WHERE a <= '12:00:00';
SELECT * FROM T WHERE '12:00:00'>= a;

SELECT * FROM T WHERE a <= '13:15:10';
SELECT * FROM T WHERE a <= '11:15:10';

-- no start key, stop key
SELECT * FROM T WHERE a > '12:00:00';
SELECT * FROM T WHERE '12:00:00' < a;

SELECT * FROM T WHERE a > '13:15:10';
SELECT * FROM T WHERE a > '11:15:10';

-- no start key, stop key
SELECT * FROM T WHERE a >= '12:00:00';
SELECT * FROM T WHERE '12:00:00' <= a;

SELECT * FROM T WHERE a >= '13:15:10';
SELECT * FROM T WHERE a >= '11:15:10';

SELECT * FROM T WHERE a <= '14:30:20' AND a >= '10:30:20';
SELECT * FROM T WHERE a >= '10:30:20' AND a <= '14:30:20';

DROP INDEX Id;

SELECT * FROM T WHERE a < '12:00:00';
SELECT * FROM T WHERE '12:00:00' > a;

SELECT * FROM T WHERE a < '13:15:10';
SELECT * FROM T WHERE a < '11:15:10';

SELECT * FROM T WHERE a <= '12:00:00';
SELECT * FROM T WHERE '12:00:00' >= a;

SELECT * FROM T WHERE a <= '13:15:10';
SELECT * FROM T WHERE a <= '11:15:10';

SELECT * FROM T WHERE a > '12:00:00';
SELECT * FROM T WHERE '12:00:00' < a;

SELECT * FROM T WHERE a > '13:15:10';
SELECT * FROM T WHERE a > '11:15:10';

SELECT * FROM T WHERE a >= '12:00:00';
SELECT * FROM T WHERE '12:00:00' <= a;

SELECT * FROM T WHERE a >= '13:15:10';
SELECT * FROM T WHERE a >= '11:15:10';

SELECT * FROM T WHERE a <= '14:30:20' AND a >= '10:30:20';
SELECT * FROM T WHERE a >= '10:30:20' AND a <= '14:30:20';

DROP TABLE T;

-- -------------------------------------------
-- 3PT014
-- Basic index support testing
-- TIME Ascending index
-- -------------------------------------------
--

CREATE TABLE S ( a TIME );
CREATE INDEX  Ia on S(a ASC);
INSERT INTO S VALUES ('12:00:00');
INSERT INTO S VALUES ('13:15:10');
INSERT INTO S VALUES ('14:30:20');
INSERT INTO S VALUES ('15:45:30');
INSERT INTO S VALUES ('11:15:10');
INSERT INTO S VALUES ('10:30:20');
INSERT INTO S VALUES ('09:45:30');

-- start key, no stop key
SELECT * FROM S WHERE a < '12:00:00';
SELECT * FROM S WHERE '12:00:00'> a;

SELECT * FROM S WHERE a < '13:15:10';
SELECT * FROM S WHERE a < '11:15:10';

-- start key, no stop key
SELECT * FROM S WHERE a <= '12:00:00';
SELECT * FROM S WHERE '12:00:00'>= a;

SELECT * FROM S WHERE a <= '13:15:10';
SELECT * FROM S WHERE a <= '11:15:10';

-- no start key, stop key
SELECT * FROM S WHERE a > '12:00:00';
SELECT * FROM S WHERE '12:00:00' < a;

SELECT * FROM S WHERE a > '13:15:10';
SELECT * FROM S WHERE a > '11:15:10';

-- no start key, stop key
SELECT * FROM S WHERE a >= '12:00:00';
SELECT * FROM S WHERE '12:00:00' <= a;

SELECT * FROM S WHERE a >= '13:15:10';
SELECT * FROM S WHERE a >= '11:15:10';

SELECT * FROM S WHERE a <= '14:30:20' AND a >= '10:30:20';
SELECT * FROM S WHERE a >= '10:30:20' AND a <= '14:30:20';

DROP INDEX Ia;

SELECT * FROM S WHERE a < '12:00:00';
SELECT * FROM S WHERE '12:00:00' > a;

SELECT * FROM S WHERE a < '13:15:10';
SELECT * FROM S WHERE a < '11:15:10';

SELECT * FROM S WHERE a <= '12:00:00';
SELECT * FROM S WHERE '12:00:00' >= a;

SELECT * FROM S WHERE a <= '13:15:10';
SELECT * FROM S WHERE a <= '11:15:10';

SELECT * FROM S WHERE a > '12:00:00';
SELECT * FROM S WHERE '12:00:00' < a;

SELECT * FROM S WHERE a > '13:15:10';
SELECT * FROM S WHERE a > '11:15:10';

SELECT * FROM S WHERE a >= '12:00:00';
SELECT * FROM S WHERE '12:00:00' <= a;

SELECT * FROM S WHERE a >= '13:15:10';
SELECT * FROM S WHERE a >= '11:15:10';

SELECT * FROM S WHERE a <= '14:30:20' AND a >= '10:30:20';
SELECT * FROM S WHERE a >= '10:30:20' AND a <= '14:30:20';

DROP TABLE S;

-- -------------------------------------------
-- 3PT015
-- Basic index support testing
-- BLOB Descending index (Error)
-- -------------------------------------------
--
CREATE TABLE T ( a BLOB(10) );
CREATE INDEX Id on T(a DESC);
INSERT INTO T VALUES (NULL);
SELECT COUNT(*) FROM T;
SELECT * FROM T;
DROP INDEX Id;
DROP TABLE T;

-- -------------------------------------------
-- 3PT016
-- Basic index support testing
-- BLOB Ascending index (Error)
-- -------------------------------------------
--
CREATE TABLE S ( a BLOB(10) );
CREATE INDEX Ia on S(a ASC);
INSERT INTO S VALUES (NULL);
SELECT COUNT(*) FROM S;
SELECT * FROM S;
DROP INDEX Ia;
DROP TABLE S;

-- -------------------------------------------
-- 3PT017
-- Joining 2 tables with NULLs
-- -------------------------------------------
--
DROP TABLE T1;
DROP TABLE T2;

CREATE TABLE T1 (x INT PRIMARY KEY NOT NULL, y CHAR(4));
CREATE TABLE T2 (x INT PRIMARY KEY NOT NULL, y CHAR(4));

CREATE INDEX IT1xD ON T1(x DESC);
CREATE INDEX IT2xD ON T2(x DESC);
CREATE INDEX IT1y  ON T1(y);
CREATE INDEX IT2y  ON T2(y);
CREATE INDEX IT2yD ON T2(y DESC);
CREATE INDEX IT1yD ON T1(y DESC);

SELECT * FROM T1 WHERE 2 > 1;

SELECT * FROM T1,T2;
SELECT * FROM T2,T1;

SELECT * FROM T1,T2 ORDER BY T1.x;
SELECT * FROM T2,T1 ORDER BY T1.x;
 
INSERT INTO T1 VALUES (-3, NULL);
INSERT INTO T1 VALUES (-2, 'a');
INSERT INTO T1 VALUES (-1, 'b');
INSERT INTO T1 VALUES (0,  'c');
INSERT INTO T1 VALUES (1,  'd');
INSERT INTO T1 VALUES (2,  NULL);
INSERT INTO T1 VALUES (3,  'd');

SELECT * FROM T1,T2;
SELECT * FROM T2,T1;

SELECT * FROM T1,T2 ORDER BY T1.x;
SELECT * FROM T2,T1 ORDER BY T1.x;

INSERT INTO T2 VALUES (-3, NULL);
INSERT INTO T2 VALUES (-2, 'a');
INSERT INTO T2 VALUES (-1, 'b');
INSERT INTO T2 VALUES (0,  'c');
INSERT INTO T2 VALUES (1,  'd');
INSERT INTO T2 VALUES (2,  NULL);
INSERT INTO T2 VALUES (3,  'd');

SELECT * FROM T1, T2 WHERE T1.x = T2.x;
SELECT * FROM T1, T2 WHERE T2.x = T1.x;
SELECT * FROM T2, T1 WHERE T1.x = T2.x;
SELECT * FROM T2, T1 WHERE T2.x = T1.x;

SELECT * FROM T1, T2 WHERE T1.x = T2.x ORDER BY T2.y DESC;
SELECT * FROM T1, T2 WHERE T2.x = T1.x ORDER BY T2.y DESC;
SELECT * FROM T2, T1 WHERE T1.x = T2.x ORDER BY T2.y DESC;
SELECT * FROM T2, T1 WHERE T2.x = T1.x ORDER BY T2.y DESC;

SELECT * FROM T1, T2 WHERE T1.y = T2.y;
SELECT * FROM T1, T2 WHERE T2.y = T1.y;
SELECT * FROM T2, T1 WHERE T1.y = T2.y;
SELECT * FROM T2, T1 WHERE T2.y = T1.y;

SELECT * FROM T1, T2 WHERE T1.y = T2.y ORDER BY T2.y DESC;
SELECT * FROM T1, T2 WHERE T2.y = T1.y ORDER BY T2.y DESC;
SELECT * FROM T2, T1 WHERE T1.y = T2.y ORDER BY T2.y DESC;
SELECT * FROM T2, T1 WHERE T2.y = T1.y ORDER BY T2.y DESC;

SELECT * FROM T1, T2;
SELECT * FROM T2, T1;

SELECT * FROM T1,T2 ORDER BY T1.x;
SELECT * FROM T2,T1 ORDER BY T1.x;

DROP INDEX IT2xD;
DROP INDEX IT2y;  
DROP INDEX IT1yD; 
DROP INDEX IT1y;  
DROP INDEX IT2yD; 
DROP INDEX IT1xD;

SELECT * FROM T1, T2 WHERE T1.x = T2.x;
SELECT * FROM T1, T2 WHERE T2.x = T1.x;
SELECT * FROM T2, T1 WHERE T1.x = T2.x;
SELECT * FROM T2, T1 WHERE T2.x = T1.x;

SELECT * FROM T1, T2 WHERE T1.x = T2.x ORDER BY T2.y DESC;
SELECT * FROM T1, T2 WHERE T2.x = T1.x ORDER BY T2.y DESC;
SELECT * FROM T2, T1 WHERE T1.x = T2.x ORDER BY T2.y DESC;
SELECT * FROM T2, T1 WHERE T2.x = T1.x ORDER BY T2.y DESC;

SELECT * FROM T1, T2 WHERE T1.y = T2.y;
SELECT * FROM T1, T2 WHERE T2.y = T1.y;
SELECT * FROM T2, T1 WHERE T1.y = T2.y;
SELECT * FROM T2, T1 WHERE T2.y = T1.y;

SELECT * FROM T1, T2 WHERE T1.y = T2.y ORDER BY T2.y DESC;
SELECT * FROM T1, T2 WHERE T2.y = T1.y ORDER BY T2.y DESC;
SELECT * FROM T2, T1 WHERE T1.y = T2.y ORDER BY T2.y DESC;
SELECT * FROM T2, T1 WHERE T2.y = T1.y ORDER BY T2.y DESC;

SELECT * FROM T1, T2;
SELECT * FROM T2, T1;

SELECT * FROM T1,T2 ORDER BY T1.x;
SELECT * FROM T2,T1 ORDER BY T1.x;

DROP TABLE T2;
DROP TABLE T1;

------------------------------------
-- End of idx03.sql
------------------------------------

DROP INDEX I;

DROP TABLE T;

-- -------------------------------------------
-- 7PT001
-- Test for non-existing search key.
-- -------------------------------------------
--
CREATE TABLE T (a INT);

INSERT INTO T VALUES (2);
INSERT INTO T VALUES (1);
INSERT INTO T VALUES (3);

CREATE INDEX I ON T (a DESC);

SELECT * FROM T WHERE a < 5;
SELECT * FROM T WHERE a > 5;
SELECT * FROM T WHERE a = 5;

SELECT * FROM T WHERE a < 1;
SELECT * FROM T WHERE a > 1;

SELECT * FROM T WHERE a < 3;
SELECT * FROM T WHERE a > 3;

DROP INDEX I;

CREATE INDEX I ON T (a ASC);

SELECT * FROM T WHERE a < 5;
SELECT * FROM T WHERE a > 5;
SELECT * FROM T WHERE a = 5;

SELECT * FROM T WHERE a < 1;
SELECT * FROM T WHERE a > 1;

SELECT * FROM T WHERE a < 3;
SELECT * FROM T WHERE a > 3;

DROP INDEX I;

DROP TABLE T;

-- -------------------------------------------
-- 7PT002
-- Test for extreme values in the index tree.
-- -------------------------------------------
--
CREATE TABLE T (a INT);

INSERT INTO T VALUES (-10);
INSERT INTO T VALUES (-5);
INSERT INTO T VALUES (0);
INSERT INTO T VALUES (12);
INSERT INTO T VALUES (35);
INSERT INTO T VALUES (25);
INSERT INTO T VALUES (-20);
INSERT INTO T VALUES (16);
INSERT INTO T VALUES (3);

CREATE INDEX I ON T (a ASC);

SELECT * FROM T WHERE a <= -20 ORDER BY a ASC;
SELECT * FROM T WHERE a <= -20 ORDER BY a DESC;
SELECT * FROM T WHERE a >= -20 ORDER BY a ASC;
SELECT * FROM T WHERE a >= -20 ORDER BY a DESC;

SELECT * FROM T WHERE a < -21 ORDER BY a ASC;
SELECT * FROM T WHERE a < -21 ORDER BY a DESC;

SELECT * FROM T WHERE a <= 35 ORDER BY a ASC;
SELECT * FROM T WHERE a <= 35 ORDER BY a DESC;
SELECT * FROM T WHERE a >= 35 ORDER BY a ASC;
SELECT * FROM T WHERE a >= 35 ORDER BY a DESC;

SELECT * FROM T WHERE a > 36 ORDER BY a ASC;
SELECT * FROM T WHERE a > 36 ORDER BY a DESC;

SELECT * FROM T WHERE a < 0 ORDER BY a ASC;
SELECT * FROM T WHERE a < 0 ORDER BY a DESC;
SELECT * FROM T WHERE a > 0 ORDER BY a ASC;
SELECT * FROM T WHERE a > 0 ORDER BY a DESC;

DROP INDEX I;

CREATE INDEX I ON T (a DESC);

SELECT * FROM T WHERE a <= -20 ORDER BY a ASC;
SELECT * FROM T WHERE a <= -20 ORDER BY a DESC;
SELECT * FROM T WHERE a >= -20 ORDER BY a ASC;
SELECT * FROM T WHERE a >= -20 ORDER BY a DESC;

SELECT * FROM T WHERE a < -21 ORDER BY a ASC;
SELECT * FROM T WHERE a < -21 ORDER BY a DESC;

SELECT * FROM T WHERE a <= 35 ORDER BY a ASC;
SELECT * FROM T WHERE a <= 35 ORDER BY a DESC;
SELECT * FROM T WHERE a >= 35 ORDER BY a ASC;
SELECT * FROM T WHERE a >= 35 ORDER BY a DESC;

SELECT * FROM T WHERE a > 36 ORDER BY a ASC;
SELECT * FROM T WHERE a > 36 ORDER BY a DESC;

SELECT * FROM T WHERE a < 0 ORDER BY a ASC;
SELECT * FROM T WHERE a < 0 ORDER BY a DESC;
SELECT * FROM T WHERE a > 0 ORDER BY a ASC;
SELECT * FROM T WHERE a > 0 ORDER BY a DESC;

DROP INDEX I;

DROP TABLE T;

-- -------------------------------------------
-- 7PT003
-- Test for NULL and zero.
-- -------------------------------------------
--
CREATE TABLE T (a INT);

INSERT INTO T VALUES (-6);
INSERT INTO T VALUES (-11);
INSERT INTO T VALUES (1); 
INSERT INTO T VALUES (0);
INSERT INTO T VALUES (NULL);
INSERT INTO T VALUES (-2);

CREATE INDEX I ON T (a ASC);

SELECT * FROM T ORDER BY a ASC;
SELECT * FROM T ORDER BY a DESC;

SELECT * FROM T WHERE a IS NOT NULL ORDER BY a DESC;
SELECT * FROM T WHERE a IS NOT NULL ORDER BY a ASC;
SELECT * FROM T WHERE a IS NULL ORDER BY a DESC;
SELECT * FROM T WHERE a IS NULL ORDER BY a ASC;

SELECT * FROM T WHERE a = 0;
SELECT * FROM T WHERE a < 0 ORDER BY a ASC;
SELECT * FROM T WHERE a < 0 ORDER BY a DESC;
SELECT * FROM T WHERE a > 0 ORDER BY a ASC;
SELECT * FROM T WHERE a > 0 ORDER BY a DESC;

DROP INDEX I;

CREATE INDEX I ON T (a DESC);

SELECT * FROM T ORDER BY a ASC;
SELECT * FROM T ORDER BY a DESC;

SELECT * FROM T WHERE a IS NOT NULL ORDER BY a DESC;
SELECT * FROM T WHERE a IS NOT NULL ORDER BY a ASC;
SELECT * FROM T WHERE a IS NULL ORDER BY a DESC;
SELECT * FROM T WHERE a IS NULL ORDER BY a ASC;

SELECT * FROM T WHERE a = 0;
SELECT * FROM T WHERE a < 0 ORDER BY a ASC;
SELECT * FROM T WHERE a < 0 ORDER BY a DESC;
SELECT * FROM T WHERE a > 0 ORDER BY a ASC;
SELECT * FROM T WHERE a > 0 ORDER BY a DESC;

DROP INDEX I;

DROP TABLE T;

-- -------------------------------------------
-- 7PT004
-- Test for multi-column.
-- -------------------------------------------
--
CREATE TABLE T (a INT, b VARCHAR(10), c DECIMAL(5,2));

INSERT INTO T VALUES (4, NULL, 4.20);
INSERT INTO T VALUES (-20, 'abc', -3.90);
INSERT INTO T VALUES (16, 'efg', 0.00);
INSERT INTO T VALUES (0, 'a', 4.21);
INSERT INTO T VALUES (2, 'z', 3.99);
INSERT INTO T VALUES (-45, 'ab', 3.97);
INSERT INTO T VALUES (-45, 'bc', 123.45);
INSERT INTO T VALUES (16, 'abc', -123.45);
INSERT INTO T VALUES (16, 'abd', -123.45);
INSERT INTO T VALUES (2, 'zz', NULL);
INSERT INTO T VALUES (NULL, 'ac', NULL);
INSERT INTO T VALUES (-45, 'ab', -23.56);
INSERT INTO T VALUES (-45, 'abc', 43.99);
INSERT INTO T VALUES (4, 'ac', -12.00);
INSERT INTO T VALUES (4, 'ab', -12.00);
INSERT INTO T VALUES (-45, '', 167.00);
INSERT INTO T VALUES (-45, 'b', 12.44);
INSERT INTO T VALUES (15, 'cdef', 36.66);
INSERT INTO T VALUES (-20, '', 810.10);
INSERT INTO T VALUES (2, 'zz', -999.99);
INSERT INTO T VALUES (4, 'abcd', 999.99);

CREATE INDEX I ON T (a ASC, b DESC, c DESC);

SELECT * FROM T ORDER BY a ASC, b DESC, c DESC;
SELECT * FROM T WHERE a IS NOT NULL AND c < 0 ORDER BY a ASC, b DESC, c DESC;
SELECT * FROM T WHERE a < 52 ORDER BY a ASC, b DESC, c DESC;
SELECT * FROM T WHERE a >= -6 ORDER BY a ASC, b DESC, c DESC;
SELECT * FROM T WHERE a IS NOT NULL AND b IS NOT NULL AND c IS NOT NULL ORDER BY a ASC, b DESC, c DESC;
SELECT * FROM T WHERE b > 'c' ORDER BY a ASC, b DESC, c DESC;
SELECT * FROM T WHERE b >= '' AND b < 'abcd' ORDER BY a ASC, b DESC, c DESC;
SELECT * FROM T WHERE a >= -5 AND a < 17 AND b IS NOT NULL AND c > 0 AND c < 177.78 ORDER BY a ASC, b DESC, c DESC;
SELECT * FROM T WHERE a >= -5 AND a < 17 AND b IS NOT NULL AND c IS NOT NULL ORDER BY a ASC, b DESC, c DESC;

CREATE INDEX J ON T (a DESC, b ASC, c DESC);

SELECT * FROM T ORDER BY a DESC, b ASC, c DESC;
SELECT * FROM T WHERE a IS NOT NULL AND c < 0 ORDER BY a DESC, b ASC, c DESC;
SELECT * FROM T WHERE a < 52 ORDER BY a DESC, b ASC, c DESC;
SELECT * FROM T WHERE a >= -6 ORDER BY a DESC, b ASC, c DESC;
SELECT * FROM T WHERE a IS NOT NULL AND b IS NOT NULL AND c IS NOT NULL ORDER BY a DESC, b ASC, c DESC;
SELECT * FROM T WHERE b > 'c' ORDER BY a DESC, b ASC, c DESC;
SELECT * FROM T WHERE b >= '' AND b < 'abcd' ORDER BY a DESC, b ASC, c DESC;
SELECT * FROM T WHERE a >= -5 AND a < 17 AND b IS NOT NULL AND c > 0 AND c < 177.78 ORDER BY a DESC, b ASC, c DESC;
SELECT * FROM T WHERE a >= -5 AND a < 17 AND b IS NOT NULL AND c IS NOT NULL ORDER BY a DESC, b ASC, c DESC;

DROP INDEX I;

DROP INDEX J;

DROP TABLE T;

-- defect 3693, enable index scan for key comparison with different data type
drop table t1;
drop table t2;
create table t1(c1 int, c2 int);
create table t2(c1 smallint, c2 smallint);
create index i21 on t2 (c1, c2);
insert into t1 values (32800, 32800);
insert into t1 values (-32800, -32800);
insert into t1 values (1000, 32800);
insert into t1 values (-32800, -1000);
insert into t2 values (1, 1);
insert into t2 values (1000, 1000);
insert into t2 values (30000, 30000);
insert into t2 values (-999, -999);
insert into t2 values (-30000, -30000);
select * from t1, t2 where t1.c1 > t2.c1 and t1.c2 >= t2.c2;
select * from t1, t2 where t1.c1 >= t2.c1 and t1.c2 < t2.c2;
select * from t1, t2 where t1.c1 <= t2.c1 and t1.c2 > t2.c2;
select * from t1, t2 where t1.c1 <= t2.c1 and t1.c2 < t2.c2;
select * from t1, t2 where t1.c1 = t2.c1 and t1.c2 = t2.c2;
select * from t1, t2 where t1.c1 = t2.c1 and t1.c2 > t2.c2;
select * from t1, t2 where t1.c1 = t2.c1 and t1.c2 <= t2.c2;
select * from t1, t2 where t1.c1 >= t2.c1 and t1.c2 = t2.c2;
select * from t1, t2 where t1.c1 < t2.c1 and t1.c2 = t2.c2;
select * from t1, t2 where t1.c1 < t2.c1;
select * from t1, t2 where t1.c1 >= t2.c1;
select * from t1, t2 where t1.c1 = t2.c1;
drop table t1;
create table t1(c1 decimal(8,2), c2 decimal(8,2));
insert into t1 values (32800.09, 32800.23);
insert into t1 values (-32800.9, -32800);
insert into t1 values (1000, 32800);
insert into t1 values (-32800, -1000.99);
insert into t1 values (1000.89, 999.4);
insert into t1 values (-999.2, -998.88);
insert into t1 values (1000.00, -999);
select * from t1, t2 where t1.c1 > t2.c1 and t1.c2 >= t2.c2;
select * from t1, t2 where t1.c1 >= t2.c1 and t1.c2 < t2.c2;
select * from t1, t2 where t1.c1 <= t2.c1 and t1.c2 > t2.c2;
select * from t1, t2 where t1.c1 <= t2.c1 and t1.c2 < t2.c2;
select * from t1, t2 where t1.c1 = t2.c1 and t1.c2 = t2.c2;
select * from t1, t2 where t1.c1 = t2.c1 and t1.c2 > t2.c2;
select * from t1, t2 where t1.c1 = t2.c1 and t1.c2 <= t2.c2;
select * from t1, t2 where t1.c1 >= t2.c1 and t1.c2 = t2.c2;
select * from t1, t2 where t1.c1 < t2.c1 and t1.c2 = t2.c2;
select * from t1, t2 where t1.c1 < t2.c1;
select * from t1, t2 where t1.c1 >= t2.c1;
select * from t1, t2 where t1.c1 = t2.c1;
drop table t1;
drop table t2;

------------------------------------------------------------
-- joining integer column w/ smallint column
------------

drop table t_int1;
drop table t_sint;
drop table t_dec;
drop table t_int2;

create table t_int1(c1 int);

create table t_sint(c1 smallint, c2 smallint);
create index t_sinti1 on t_sint (c1);

insert into t_int1 values (64000);
insert into t_int1 values (32800);
insert into t_int1 values (32767);
insert into t_int1 values (32768);
insert into t_int1 values (-32800);
insert into t_int1 values (0);
insert into t_int1 values (1000);
insert into t_int1 values (-1000);
insert into t_int1 values (-32767);
insert into t_int1 values (-32768);
insert into t_int1 values (-64000);
insert into t_int1 values (2147483647);
insert into t_int1 values (-2147483647);

insert into t_sint values (1, 1);
insert into t_sint values (0, 0);
insert into t_sint values (1000, 1000);
insert into t_sint values (-1000, -1000);
insert into t_sint values (30000, 30000);
insert into t_sint values (-999, -999);
insert into t_sint values (-30000, -30000);
insert into t_sint values (-32767, -32767);
insert into t_sint values (32767, 32767);
insert into t_sint values (-32768, -32768);
-- insert into t_sint values (32768, 32768);

select * from t_int1, t_sint where t_int1.c1 = t_sint.c1 order by 1, 2, 3;

select * from t_int1, t_sint where t_int1.c1 = t_sint.c2 order by 1, 2, 3;

---------

select * from t_int1, t_sint where t_int1.c1 > t_sint.c1 order by 1, 2, 3;

select * from t_int1, t_sint where t_int1.c1 > t_sint.c2 order by 1, 2, 3;

---------

select * from t_int1, t_sint where t_int1.c1 < t_sint.c1 order by 1, 2, 3;

select * from t_int1, t_sint where t_int1.c1 < t_sint.c2 order by 1, 2, 3;

---------

select * from t_int1, t_sint where t_int1.c1 >= t_sint.c1 order by 1, 2, 3;

select * from t_int1, t_sint where t_int1.c1 >= t_sint.c2 order by 1, 2, 3;

---------

select * from t_int1, t_sint where t_int1.c1 <= t_sint.c1 order by 1, 2, 3;

select * from t_int1, t_sint where t_int1.c1 <= t_sint.c2 order by 1, 2, 3;

------------------------------------------------------------
-- joining decimal column w/ smallint column
------------

create table t_dec(c1 decimal(30,2));

insert into t_dec values (64000);
insert into t_dec values (32800);
insert into t_dec values (32767);
insert into t_dec values (32768);
insert into t_dec values (-32800);
insert into t_dec values (0);
insert into t_dec values (1000);
insert into t_dec values (-1000);
insert into t_dec values (-32767);
insert into t_dec values (-32768);
insert into t_dec values (-64000);

insert into t_dec values (64000.1);
insert into t_dec values (32800.1);
insert into t_dec values (32767.1);
insert into t_dec values (32768.1);
insert into t_dec values (-32800.1);
insert into t_dec values (0.1);
insert into t_dec values (1000.1);
insert into t_dec values (-1000.1);
insert into t_dec values (-32767.1);
insert into t_dec values (-32768.1);
insert into t_dec values (-64000.1);

insert into t_dec values (2147483647);
insert into t_dec values (-2147483647);

insert into t_dec values (2147483648.0);
insert into t_dec values (-2147483649.0);

--------

select * from t_dec, t_sint where t_dec.c1 = t_sint.c1 order by 1, 2, 3;

select * from t_dec, t_sint where t_dec.c1 = t_sint.c2 order by 1, 2, 3;

---------

select * from t_dec, t_sint where t_dec.c1 > t_sint.c1 order by 1, 2, 3;

select * from t_dec, t_sint where t_dec.c1 > t_sint.c2 order by 1, 2, 3;

---------

select * from t_dec, t_sint where t_dec.c1 < t_sint.c1 order by 1, 2, 3;

select * from t_dec, t_sint where t_dec.c1 < t_sint.c2 order by 1, 2, 3;

---------

select * from t_dec, t_sint where t_dec.c1 >= t_sint.c1 order by 1, 2, 3;

select * from t_dec, t_sint where t_dec.c1 >= t_sint.c2 order by 1, 2, 3;

---------

select * from t_dec, t_sint where t_dec.c1 <= t_sint.c1 order by 1, 2, 3;

select * from t_dec, t_sint where t_dec.c1 <= t_sint.c2 order by 1, 2, 3;

------------------------------------------------------------
-- joining decimal column w/ integer column
------------

create table t_int2(c1 int, c2 int);
create index t_int2i1 on t_int2 (c1);

insert into t_int2 values (1, 1);
insert into t_int2 values (0, 0);
insert into t_int2 values (1000, 1000);
insert into t_int2 values (-1000, -1000);
insert into t_int2 values (30000, 30000);
insert into t_int2 values (-999, -999);
insert into t_int2 values (-30000, -30000);
insert into t_int2 values (-32767, -32767);
insert into t_int2 values (32767, 32767);
insert into t_int2 values (-32768, -32768);
insert into t_int2 values (2147483647,2147483647);
insert into t_int2 values (-2147483647,-2147483647);

--------

select * from t_dec, t_int2 where t_dec.c1 = t_int2.c1 order by 1, 2, 3;

select * from t_dec, t_int2 where t_dec.c1 = t_int2.c2 order by 1, 2, 3;

---------

select * from t_dec, t_int2 where t_dec.c1 > t_int2.c1 order by 1, 2, 3;

select * from t_dec, t_int2 where t_dec.c1 > t_int2.c2 order by 1, 2, 3;

---------

select * from t_dec, t_int2 where t_dec.c1 < t_int2.c1 order by 1, 2, 3;

select * from t_dec, t_int2 where t_dec.c1 < t_int2.c2 order by 1, 2, 3;

---------

select * from t_dec, t_int2 where t_dec.c1 >= t_int2.c1 order by 1, 2, 3;

select * from t_dec, t_int2 where t_dec.c1 >= t_int2.c2 order by 1, 2, 3;

---------

select * from t_dec, t_int2 where t_dec.c1 <= t_int2.c1 order by 1, 2, 3;

select * from t_dec, t_int2 where t_dec.c1 <= t_int2.c2 order by 1, 2, 3;

drop table t_int1;
drop table t_sint;
drop table t_dec;
drop table t_int2;
