drop table testlike;
drop stmt handle :1;
create stmt handle :1;
create table testlike (c1 varchar(20), c2 int);
create index itestlike on testlike(c1);
insert into testlike values('ABCD', 1);
prepare :1 select * from testlike where c1 like ?;
drop stmt handle :1;
drop table testlike;
