-- ----------------- FILE: SELECT06.SQL -------------------
-- -                                                      - 
-- -        CHECK ALL ERROR IN "SELECT" STATEMENT         -
-- -                                                      -
-- --------------------------------------------------------
--
-- test "fetchscroll" command of CLP
--
drop table t;
create table t (a int);
insert into t values (1);
insert into t values (2);
insert into t values (3);
insert into t values (4);
insert into t values (5);
insert into t values (6);
insert into t values (7);
insert into t values (8);
insert into t values (9);
insert into t values (10);
insert into t values (11);
insert into t values (12);

create stmt handle :1;

enable scrollable cursor :1;
prepare :1 select * from t;
execute :1;

fetchscroll :1 sql_fetch_first 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_next 1;
fetchscroll :1 sql_fetch_absolute 5;
fetchscroll :1 sql_fetch_relative 2;
fetchscroll :1 sql_fetch_relative -1;
fetchscroll :1 sql_fetch_last 1;
fetchscroll :1 sql_fetch_first 1;

drop stmt handle :1;
drop table t;


-----------
-- Cliff Leung. 11/2002
-- Scrollable cursor testing w/ multiple executions
DROP TABLE T;
CREATE TABLE T (ID VARCHAR(5), NAME VARCHAR(20));
CREATE INDEX IDX ON T (ID);
INSERT INTO T VALUES ('1', 'abcd');
INSERT INTO T VALUES ('1', 'ab');
INSERT INTO T VALUES ('2', 'cd');
INSERT INTO T VALUES ('2', 'cded');
INSERT INTO T VALUES ('3', 'edfg');

-- regular fetch
create stmt handle :1;
prepare :1 select * from t where id = ?;

-- 2
bind :1 1 2;
execute :1;
fetch :1;
fetch :1;
fetch :1;

-- 1
bind :1 1 1;
execute :1;
fetch :1;
fetch :1;
fetch :1;

drop stmt handle :1;

-- scrollable cursor fetch
create stmt handle :2;
enable scrollable cursor :2;
prepare :2 select * from t where id = ?;

-- 2
bind :2 1 2;
execute :2;
fetch :2;
fetch :2;
fetch :2;

-- 1
bind :2 1 1;
execute :2;
fetch :2;
fetch :2;
fetch :2;

drop stmt handle :2;

drop table t;

-- Parameter markers w/ %
DROP TABLE TT;
CREATE TABLE TT (A VARCHAR(10), B VARCHAR(10));
INSERT INTO TT VALUES ('abc', '123');
INSERT INTO TT VALUES ('abcde', '12345');
INSERT INTO TT VALUES ('ab', '12');
INSERT INTO TT VALUES ('stu', '123xxx');
INSERT INTO TT VALUES ('stuvw', '123yyy');
INSERT INTO TT VALUES ('st', '12y');

CREATE INDEX IDXTT ON TT(A);

create stmt handle :1;
prepare :1 select * from tt where a like ?;

bind :1 1 abc%;
execute :1;

fetch :1;
fetch :1;
fetch :1;

bind :1 1 stu%;
execute :1;

fetch :1;
fetch :1;
fetch :1;

-- execute it again
execute :1;

fetch :1;

drop stmt handle :1;

DROP TABLE TT;


