-- ----------------- FILE: SELECT09.SQL -------------------
-- -                                                      - 
-- -        CHECK ALL ERROR IN "SELECT" STATEMENT         -
-- -                                                      -
-- --------------------------------------------------------
--

-- new test case added as requested by Cliff (the second select stmt used to coredump)
create table s (a int);
create table t (b int);
select * from t, s;
select * from t, s;
DROP TABLE t;
DROP TABLE s;