-- ----------------- FILE: INSERT10.SQL -------------------
-- -                                                      - 
-- -        CHECK ALL ERROR IN "INSERT" STATEMENT         -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE TA;