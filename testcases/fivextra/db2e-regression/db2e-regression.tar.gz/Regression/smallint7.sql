-- ----------------- FILE: SMALLINT7.SQL  -----------------
-- -                                                      - 
-- -       CHECK ALL ERROR IN "SMALLINT" DATA TYPE        -
-- -                                                      -
-- --------------------------------------------------------
--  * d2443ctl  01/19/2001 cannot use index for "smallint_col = 99999"

--------  CREATE TABLES and INSERT ROWS ------------;
-- smallint, int, decimal(7,1);
-- future work: decimal(20,1);

-- SMALLINT;
create table s (a smallint);
insert into s values (32767);
insert into s values (-32768);
insert into s values (0);

-- these should fail;
insert into s values (32768);
insert into s values (-32769);

select * from s;

-- INTEGER;
create table b (a int);
insert into b values (0);
insert into b values (32767);
insert into b values (-32768);
insert into b values (99999);
insert into b values (-99999);
insert into b values (-2147483647);
insert into b values (2147483647);

-- these should fail;
insert into b values (2147483648);
insert into b values (-2147483648);

-- delete them: so that we can compare against UDB easily
delete from b where a = -2147483648;
delete from b where a = 2147483648;

select * from b;

-- DECIMAL;
create table dec (a decimal(7,1));
insert into dec values (0);
insert into dec values (32767);
insert into dec values (-32768);
insert into dec values (99999);
insert into dec values (-99999);

-- these should fail;
insert into dec values (-2147483647);
insert into dec values (2147483647);

select * from dec;

-------- TABLE SCAN ----------;

-- comparing a smallint w/ an integer number;
select * from s where a < 2147483647;
select * from s where a > -2147483647;
-- expect 0 rows;
select * from s where a = 32768;

-- comparing a smallint w/ a smallint number;
select * from s where a < 32767;
select * from s where a <= 32767;
select * from s where a = 32767;

select * from s where a > -32768;
select * from s where a >= -32768;
select * from s where a = -32768;

-- comparing a smallint w/ a decimal number;
select * from s where a < 2147483647.0;
select * from s where a > -2147483647.0;
select * from s where a = 32768.0;
select * from s where a < 32767.0;
select * from s where a <= 32767.0;
select * from s where a = 32767.0;
select * from s where a > -32768.0;
select * from s where a >= -32768.0;
select * from s where a = -32768.0;

-- comparing an integer w/ a decimal number;
select * from b where a < 2147483647.0;
select * from b where a > -2147483647.0;
select * from b where a = 32768.0;
select * from b where a < 32767.0;
select * from b where a <= 32767.0;
select * from b where a = 32767.0;
select * from b where a > -32768.0;
select * from b where a >= -32768.0;
select * from b where a = -32768.0;

-- comparing an integer w/ a smallint number;
select * from b where a < 32767;
select * from b where a <= 32767;
select * from b where a = 32767;

select * from b where a > -32768;
select * from b where a >= -32768;
select * from b where a = -32768;

-- comparing a decimal w/ an integer number;
select * from dec where a < 2147483647;
select * from dec where a > -2147483647;
select * from dec where a = 32768;
select * from dec where a < 32767;
select * from dec where a <= 32767;
select * from dec where a = 32767;
select * from dec where a = 99999;
select * from dec where a = -99999;
select * from dec where a < 99999;
select * from dec where a > 99999;


--------- JOIN w/o INDEX -----------;

-- integer w/ smallint;
select * from b, s where b.a=s.a;
select * from b, s where s.a=b.a;

select * from s, b where b.a=s.a;
select * from s, b where s.a=b.a;

-- integer w/ decimal;
select * from b, dec where b.a=dec.a;
select * from b, dec where dec.a=b.a;

select * from dec, b where b.a=dec.a;
select * from dec, b where dec.a=b.a;

-- decimal w/ smallint;
select * from dec, s where dec.a=s.a;
select * from dec, s where s.a=dec.a;

select * from s, dec where dec.a=s.a;
select * from s, dec where s.a=dec.a;


-------  CREATE AN INDEX  ------------;

create index idxs on s(a);

-------  INDEX SCAN ----------------;

-- comparing a smallint w/ an integer number;
select * from s where a < 2147483647;
select * from s where a > -2147483647;
-- expect 0 rows;
select * from s where a = 32768;

-- comparing a smallint w/ a smallint number;
select * from s where a < 32767;
select * from s where a <= 32767;
select * from s where a = 32767;

select * from s where a > -32768;
select * from s where a >= -32768;
select * from s where a = -32768;

-- comparing a smallint w/ a decimal number;
select * from s where a < 2147483647.0;
select * from s where a > -2147483647.0;
select * from s where a = 32768.0;
select * from s where a < 32767.0;
select * from s where a <= 32767.0;
select * from s where a = 32767.0;
select * from s where a > -32768.0;
select * from s where a >= -32768.0;
select * from s where a = -32768.0;

-- comparing an integer w/ a decimal number;
select * from b where a < 2147483647.0;
select * from b where a > -2147483647.0;
select * from b where a = 32768.0;
select * from b where a < 32767.0;
select * from b where a <= 32767.0;
select * from b where a = 32767.0;
select * from b where a > -32768.0;
select * from b where a >= -32768.0;
select * from b where a = -32768.0;

-- comparing an integer w/ a smallint number;
select * from b where a < 32767;
select * from b where a <= 32767;
select * from b where a = 32767;

select * from b where a > -32768;
select * from b where a >= -32768;
select * from b where a = -32768;

-- comparing a decimal w/ an integer number;
select * from dec where a < 2147483647;
select * from dec where a > -2147483647;
select * from dec where a = 32768;
select * from dec where a < 32767;
select * from dec where a <= 32767;
select * from dec where a = 32767;
select * from dec where a = 99999;
select * from dec where a = -99999;
select * from dec where a < 99999;
select * from dec where a > 99999;

--------- JOIN w/ INDEX -----------;

-- integer w/ smallint;
select * from b, s where b.a=s.a;
select * from b, s where s.a=b.a;

select * from s, b where b.a=s.a;
select * from s, b where s.a=b.a;

-- integer w/ decimal;
select * from b, dec where b.a=dec.a;
select * from b, dec where dec.a=b.a;

select * from dec, b where b.a=dec.a;
select * from dec, b where dec.a=b.a;

-- decimal w/ smallint;
select * from dec, s where dec.a=s.a;
select * from dec, s where s.a=dec.a;

select * from s, dec where dec.a=s.a;
select * from s, dec where s.a=dec.a;

--------- DROP INDEX AND TABLES ----------;

drop index idxs;
drop table s;
drop table b;
drop table dec;

-- The following tests defect 2424.
create table test (c1 decimal(15,14), c2 decimal(15,0), c3 decimal(15,8), c4 decimal(15,5));
INSERT INTO test VALUES (-.11111, +22222, 33333.55555, 123.45);                        
INSERT INTO test VALUES (-.0, +123456789., +.0, +1.00);
INSERT INTO test VALUES (+.0, +123456789., -.0, -1.00); 

select * from test;
select * from test where c3 >= .00001;
select * from test where c3 < .00001;

select * from test where c1 >= .00001;
select * from test where c1 < .00001;

drop table test;


