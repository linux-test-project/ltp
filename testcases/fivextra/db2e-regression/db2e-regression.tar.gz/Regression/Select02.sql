-- ----------------- FILE: SELECT02.SQL -------------------
-- -                                                      - 
-- -          Validates SELECT statement	          -
-- -                                                      -
-- --------------------------------------------------------
--

-- --------------------------------------------------------
-- This set of test cases validates OR predicates
-- --------------------------------------------------------
-- --------------------------------------------------------
-- Delete tables
-- --------------------------------------------------------
DROP TABLE tI;

-- --------------------------------------------------------
-- INITIALIZE THE TABLES
-- --------------------------------------------------------
CREATE TABLE tI (c1 INT);

INSERT INTO tI VALUES (1234);
INSERT INTO tI VALUES (1007);
INSERT INTO tI VALUES (999);

INSERT INTO tI VALUES (19);
INSERT INTO tI VALUES (19);
INSERT INTO tI VALUES (19);
INSERT INTO tI VALUES (19);

INSERT INTO tI VALUES (1234);
INSERT INTO tI VALUES (1007);
INSERT INTO tI VALUES (999);

INSERT INTO tI VALUES (19);
INSERT INTO tI VALUES (19);
INSERT INTO tI VALUES (19);

INSERT INTO tI VALUES (1234);
INSERT INTO tI VALUES (1007);
INSERT INTO tI VALUES (999);

INSERT INTO tI VALUES (19);
INSERT INTO tI VALUES (19);
INSERT INTO tI VALUES (19);
INSERT INTO tI VALUES (19);
INSERT INTO tI VALUES (19);



SELECT * FROM tI;
SELECT * FROM tI WHERE (c1 = 1);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11 OR c1 = 12);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11 OR c1 = 12 OR c1 = 13);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11 OR c1 = 12 OR c1 = 13 OR c1 = 14);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11 OR c1 = 12 OR c1 = 13 OR c1 = 14 OR c1 = 15);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11 OR c1 = 12 OR c1 = 13 OR c1 = 14 OR c1 = 15 OR c1 =16);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11 OR c1 = 12 OR c1 = 13 OR c1 = 14 OR c1 = 15 OR c1 =16 OR c1 = 17);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11 OR c1 = 12 OR c1 = 13 OR c1 = 14 OR c1 = 15 OR c1 =16 OR c1 = 17 OR c1 = 18);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11 OR c1 = 12 OR c1 = 13 OR c1 = 14 OR c1 = 15 OR c1 =16 OR c1 = 17 OR c1 = 18 OR c1 = 19);
SELECT * FROM tI WHERE (c1 = 1 OR c1 = 2 OR c1 = 3 OR c1 = 4 OR c1 = 5 OR c1 = 6 OR c1 = 7 OR c1 = 8 OR c1 = 9 OR c1 = 10 OR c1 = 11 OR c1 = 12 OR c1 = 13 OR c1 = 14 OR c1 = 15 OR c1 =16 OR c1 = 17 OR c1 = 18 OR c1 = 19 OR c1 = 20);






