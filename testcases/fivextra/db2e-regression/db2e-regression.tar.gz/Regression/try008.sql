-- ------------------ FILE: TRYOO8.SQL  -------------------
-- -                                                      - 
-- -   CHECK ALL ERROR IN "INT" AND "VARCHAR" DATA TYPE   -
-- -                                                      -
-- --------------------------------------------------------
--

--
-- Testing Bidirectional Indexing 1 (a2417kmt)
--
DROP TABLE t;

CREATE TABLE t (a INT, b VARCHAR(10), c DECIMAL(15,1));

CREATE INDEX i ON t (a ASC);

INSERT INTO t VALUES (10, 'a', 10.1);
INSERT INTO t VALUES (20, 'a', 10.2);
INSERT INTO t VALUES (10, 'ab', 10.1);
INSERT INTO t VALUES (20, 'ab', 10.2);
INSERT INTO t VALUES (-10, 'A', -10.1);
INSERT INTO t VALUES (-20, 'AB', -10.2);
INSERT INTO t VALUES (-10, 'A', -10.1);
INSERT INTO t VALUES (-20, 'AB', -10.2);
INSERT INTO t VALUES (null, null, null);

-- INDEX j has the same specification (i.e., only on column A)
-- Catalog will have two different entries but both indexes will be mapped into the same index tree.
CREATE INDEX j ON t (a DESC);

INSERT INTO t VALUES (10, 'a', 10.0);
INSERT INTO t VALUES (30, 'a', 10.0);
INSERT INTO t VALUES (20, 'b', 10.1);

-- the same index file will be used
SELECT * FROM t ORDER BY a ASC;
SELECT * FROM t ORDER BY a DESC;

-- create several indexes with more columns
-- the physical index tree of indexes i and j will be replaced by the new index tree (w/ both A and B)
-- the net is: we only have one index tree now despite we have 6 index entries in the catalog
CREATE INDEX k ON t (a ASC, b ASC);
CREATE INDEX l ON t (a DESC, b ASC);
CREATE INDEX m ON t (a DESC, b DESC);
CREATE INDEX n ON t (a ASC, b DESC);

INSERT INTO t VALUES (30, 'a', 10.1);
INSERT INTO t VALUES (10, 'a', 10.1);
INSERT INTO t VALUES (20, 'a', 10.1);
INSERT INTO t VALUES (10, 'a', 10.3);
INSERT INTO t VALUES (20, 'b', 10.0);

INSERT INTO t VALUES (-30, 'A', -10.1);
INSERT INTO t VALUES (-10, 'B', -10.1);
INSERT INTO t VALUES (-20, 'C', -10.1);

SELECT * FROM T ORDER BY a ASC, b ASC;
SELECT * FROM T ORDER BY a ASC, b DESC;
SELECT * FROM T ORDER BY a DESC, b ASC;
SELECT * FROM T ORDER BY a DESC, b DESC;

DROP INDEX n;
DROP INDEX k;
DROP INDEX i;
DROP INDEX j;
DROP INDEX m;
-- only index l is remaining;

SELECT * FROM T ORDER BY a ASC, b ASC;
SELECT * FROM T ORDER BY a ASC, b DESC;
SELECT * FROM T ORDER BY a DESC, b ASC;
SELECT * FROM T ORDER BY a DESC, b DESC;

-- the following indexes will create another index tree
CREATE INDEX o ON t (b DESC, c ASC);
CREATE INDEX p ON t (b ASC, c DESC);
CREATE INDEX q ON t (b DESC, c DESC);
CREATE INDEX r ON t (b ASC, c ASC);

INSERT INTO t VALUES (20, 'ab', 10.1);
INSERT INTO t VALUES (10, 'ab', 10.1);
INSERT INTO t VALUES (30, 'ab', 10.0);
INSERT INTO t VALUES (20, 'abc', 10.2);
INSERT INTO t VALUES (30, 'abc', 10.1);

SELECT * FROM T ORDER BY b ASC, c ASC;
SELECT * FROM T ORDER BY b ASC, c DESC;
SELECT * FROM T ORDER BY b DESC, c ASC;
SELECT * FROM T ORDER BY b DESC, c DESC;

DROP INDEX r;
DROP INDEX o;
DROP INDEX p;

SELECT * FROM T ORDER BY b ASC, c ASC;
SELECT DISTINCT * FROM T ORDER BY b ASC, c ASC;

SELECT * FROM T ORDER BY b ASC, c DESC;
SELECT DISTINCT * FROM T ORDER BY b ASC, c DESC;

SELECT * FROM T ORDER BY b DESC, c ASC;
SELECT DISTINCT * FROM T ORDER BY b DESC, c ASC;

SELECT * FROM T ORDER BY b DESC, c DESC;
SELECT DISTINCT * FROM T ORDER BY b DESC, c DESC;

DROP INDEX l;
DROP INDEX q;

DROP INDEX i;
DROP INDEX j;
DROP INDEX k;
DROP INDEX l;
DROP INDEX m;
DROP INDEX n;
DROP INDEX o;
DROP INDEX p;
DROP INDEX q;
DROP INDEX r;

DROP TABLE t;

--
-- Testing Bidirectional Indexing 2 (a2417kmt)
--
CREATE TABLE t (a CHAR(2) not null PRIMARY KEY, b INT NOT NULL DEFAULT -1);

INSERT INTO t VALUES ('aa', 1);
INSERT INTO t VALUES ('ab', 2);
INSERT INTO t VALUES ('ba', 3);
INSERT INTO t VALUES ('bb', 4);

CREATE INDEX i on t (a, b);

-- the following two INSERTs will fail
INSERT INTO t VALUES ('bb', 5);
INSERT INTO t(a) VALUES ('bb');

-- this INSERT will succeed
INSERT INTO t(a) VALUES ('bc');

SELECT * FROM t order by a, b;
SELECT * FROM t order by a asc, b desc;
SELECT * FROM t order by a desc, b asc;
SELECT * FROM t order by a desc, b desc;

DROP TABLE t;

--
-- Testing Bidirectional Indexing 3 (a2417kmt)
--
CREATE TABLE t (a INT NOT NULL, b VARCHAR(5) NOT NULL, c INT, PRIMARY KEY(a, b));

INSERT INTO t VALUES (0, 'a', NULL);
INSERT INTO t VALUES (0, 'a', 1);
INSERT INTO t VALUES (0, 'b', NULL);
INSERT INTO t VALUES (0, 'b', 0);
INSERT INTO t VALUES (NULL, NULL, 1);
INSERT INTO t VALUES (0, NULL, 1);

SELECT * FROM t ORDER BY a, b;

CREATE INDEX i ON t (b DESC, c ASC);

INSERT INTO t VALUES (1, 'a', NULL);
INSERT INTO t VALUES (0, 'c', 0);
INSERT INTO t VALUES (1, 'b', 0);
INSERT INTO t VALUES (2, 'a', 0);
INSERT INTO t VALUES (1, 'c', 1);

SELECT * FROM t ORDER BY a, b;
SELECT * FROM t ORDER BY b, c;
SELECT * FROM t ORDER BY b DESC, c ASC;
SELECT * FROM t ORDER BY b DESC, c DESC;
SELECT * FROM t ORDER BY b ASC, c DESC;

UPDATE t SET c=NULL WHERE a=2 AND b='a';
UPDATE t SET c=NULL WHERE a=1 AND b='b';
UPDATE t SET c=NULL WHERE a=0 AND b='c';
UPDATE t SET c=NULL WHERE a=1 AND b='c';

SELECT * FROM t ORDER BY b, c;
SELECT * FROM t ORDER BY a, b, c;

UPDATE t SET a=0 WHERE b='a';

CREATE INDEX j ON t (a ASC, b ASC, c ASC);

SELECT * FROM t ORDER BY a, b, c;

DROP INDEX j;

SELECT * FROM t ORDER BY a, b;
SELECT DISTINCT * FROM t ORDER BY a, b;

SELECT * FROM t ORDER BY b, c;
SELECT DISTINCT * FROM t ORDER BY b, c;

SELECT * FROM t ORDER BY b DESC, c ASC;
SELECT DISTINCT * FROM t ORDER BY b DESC, c ASC;

SELECT * FROM t ORDER BY b DESC, c DESC;
SELECT DISTINCT * FROM t ORDER BY b DESC, c DESC;

SELECT * FROM t ORDER BY b ASC, c DESC;
SELECT DISTINCT * FROM t ORDER BY b ASC, c DESC;

DELETE FROM t WHERE b NOT LIKE 'z';

SELECT * FROM t ORDER BY a, b;
SELECT * FROM t ORDER BY b, c;
SELECT * FROM t ORDER BY b DESC, c ASC;
SELECT * FROM t ORDER BY b DESC, c DESC;
SELECT * FROM t ORDER BY b ASC, c DESC;

-- the following should fail
create index m on (a, b);

DROP INDEX i;

DROP TABLE t;

--
-- Testing Bidirectional Indexing 4 (a2417kmt)
--
CREATE TABLE t1 (a INT not null PRIMARY KEY, b VARCHAR(6));
CREATE TABLE t2 (a INT, b VARCHAR(6));

INSERT INTO t1 VALUES (3, 'aab');
INSERT INTO t1 VALUES (0, 'aaa');
INSERT INTO t1 VALUES (1, 'aba');
INSERT INTO t1 VALUES (4, 'cab');
INSERT INTO t1 VALUES (2, 'aac');

INSERT INTO t2 VALUES (3, 'aab');
INSERT INTO t2 VALUES (0, 'aaa');
INSERT INTO t2 VALUES (1, 'aba');
INSERT INTO t2 VALUES (4, 'cab');
INSERT INTO t2 VALUES (2, 'aac');

CREATE INDEX i1 on t1 (a ASC, b DESC);
CREATE INDEX i2 on t2 (a ASC, b DESC);

SELECT X.a, X.b FROM t1 AS X, t1 AS Y WHERE X.a = Y.a ORDER BY a ASC, b DESC;

SELECT X.a, X.b FROM t1 AS X, t2 AS Y WHERE X.a = Y.a ORDER BY a ASC, b DESC;

DROP INDEX i2;
DROP INDEX i1;

DROP TABLE t1;
DROP TABLE t2;

---------------

CREATE TABLE t (a CHAR(2) not null PRIMARY KEY, b INT NOT NULL DEFAULT -1);

INSERT INTO t VALUES ('aa', 1);
INSERT INTO t VALUES ('ab', 2);
INSERT INTO t VALUES ('ba', 3);
INSERT INTO t VALUES ('bb', 4);

CREATE INDEX i on t (a, b);

INSERT INTO t VALUES ('bb', 5);
INSERT INTO t(a) VALUES ('bb');
INSERT INTO t(a) VALUES ('bc');

-- this should fail
CREATE INDEX j on t (a);

-- this should succeed
CREATE INDEX k on t (a desc);

SELECT * FROM t order by a, b;
SELECT * FROM t order by a asc, b desc;
SELECT * FROM t order by a desc, b asc;
SELECT * FROM t order by a desc, b desc;

DROP TABLE t;

-----------

CREATE TABLE t (a CHAR(2) not null, b int not null, c int not null, PRIMARY KEY(a,b));

INSERT INTO t VALUES ('aa', 1, 10);
INSERT INTO t VALUES ('aa', 2, 20);
INSERT INTO t VALUES ('ab', 2, 20);
INSERT INTO t VALUES ('ba', 3, 30);
INSERT INTO t VALUES ('bb', 4, 40);

CREATE INDEX i on t (a, b, c);

-- these two INSERTs should fail
INSERT INTO t VALUES ('ab', 2, 50);

-- these INSERTs should succeed
INSERT INTO t VALUES ('bb', 5, 50);
INSERT INTO t VALUES ('cc', 4, 40);

-- this should fail
CREATE INDEX j on t (a, b);

-- this should succeed
CREATE INDEX k on t (a desc);

SELECT * FROM t order by a, b;
SELECT * FROM t order by a asc, b desc;
SELECT * FROM t order by a desc, b asc;
SELECT * FROM t order by a desc, b desc;

DROP TABLE t;


--
-- Prefix Scan Test (d2580kmt)
--
CREATE TABLE t (a INT, b VARCHAR(18), c DECIMAL(30,0));

CREATE INDEX i ON t (a ASC, b DESC, c ASC);
CREATE INDEX j ON t (a DESC);
CREATE INDEX k ON t (c DESC, b ASC);

INSERT INTO t VALUES (2, 'b', 2.);
INSERT INTO t VALUES (NULL, 'b', 0.);
INSERT INTO t VALUES (2, 'a', -1.);
INSERT INTO t VALUES (0, NULL, -2.);
INSERT INTO t VALUES (0, 'a', 0.);
INSERT INTO t VALUES (NULL, 'b', 1.);
INSERT INTO t VALUES (-2, 'a', NULL);
INSERT INTO t VALUES (1, 'a', 1.);
INSERT INTO t VALUES (-1, NULL, -1.);
INSERT INTO t VALUES (-1, NULL, 2.);
INSERT INTO t VALUES (0, NULL, NULL);
INSERT INTO t VALUES (1, 'b', -2.);
INSERT INTO t VALUES (1, 'a', -2.);
INSERT INTO t VALUES (-2, 'b', NULL);
INSERT INTO t VALUES (2, 'a', 0.);

SELECT * FROM t ORDER BY a ASC, b ASC, c ASC;
SELECT * FROM t WHERE a>=0 AND a<=2 AND b IS NULL AND c IS NOT NULL;
SELECT * FROM t ORDER BY c DESC, b ASC;
SELECT * FROM t WHERE a>=0 AND a<=2 AND b IS NULL AND c IS NOT NULL ORDER BY c DESC, b ASC;

SELECT * FROM t WHERE a<=0;
SELECT * FROM t WHERE a<=0 ORDER BY c DESC, b ASC;

SELECT * FROM t WHERE a<=0 AND (b='a' OR b='b');
SELECT * FROM t WHERE a<=0 AND (b='a' OR b='b') ORDER BY c DESC, b ASC;
SELECT * FROM t WHERE a<=0 AND (b='a' OR b='b') ORDER BY a ASC, b ASC, c ASC;

SELECT * FROM t WHERE c > 0 AND c < 0;
SELECT * FROM t WHERE c = 0;
SELECT * FROM t WHERE c = 0.0;

DROP INDEX i;

DROP TABLE t;


--
-- Use index to find distinct records (d2523kmt)
--
CREATE TABLE T (A CHAR(10), B VARCHAR(10), C INT, D SMALLINT);
CREATE INDEX I ON T (A, B DESC, C, D DESC);
CREATE INDEX J ON T (D ASC, C DESC);
CREATE INDEX K ON T (C DESC, D DESC);
CREATE INDEX L ON T (C ASC, B DESC, A ASC);

INSERT INTO T VALUES ('ABC', 'XYZ', -1, 1);
INSERT INTO T VALUES ('ABC', 'XYZ', 10, 1);
INSERT INTO T VALUES ('ABC', 'XYZ', 5, 1);
INSERT INTO T VALUES ('ABC', 'XYZ', -18, 1);
INSERT INTO T VALUES ('ABC', 'XYZ', 0, -10);
INSERT INTO T VALUES ('ABC', 'XYZ', -20, -10);
INSERT INTO T VALUES ('ABC', 'XYZ', -20, -10);
INSERT INTO T VALUES ('ABC', 'XYZ', NULL, NULL);
INSERT INTO T VALUES ('ABC', 'XYZ', 0, 0);
INSERT INTO T VALUES ('ABC', 'XYZ', -1, 0);
INSERT INTO T VALUES ('ABC', 'XYZ', 3, 0);
INSERT INTO T VALUES ('ABC', 'XYZ', 3, 0);
INSERT INTO T VALUES ('ABC', 'XYZ', NULL, -10);
INSERT INTO T VALUES ('ABC', 'XYZ', NULL, NULL);
INSERT INTO T VALUES ('ABC', 'XYZ', -12, 0);
INSERT INTO T VALUES ('ABC', 'XYZ', 0, 1);
INSERT INTO T VALUES ('ABC', 'XYZ', 5, -10);
INSERT INTO T VALUES ('ABC', 'XYZ', 4, -10);
INSERT INTO T VALUES ('ABC', 'XYZ', 8, -10);

INSERT INTO T VALUES ('BC', 'XYZ', 10, 1);
INSERT INTO T VALUES ('BC', 'XYZ', 5, 1);
INSERT INTO T VALUES ('BC', 'XYZ', -18, 1);
INSERT INTO T VALUES ('BC', 'XYZ', 0, -10);
INSERT INTO T VALUES ('BC', 'XYZ', NULL, -10);
INSERT INTO T VALUES ('BC', 'XYZ', -12, 0);
INSERT INTO T VALUES ('BC', 'XYZ', 0, 1);
INSERT INTO T VALUES ('BC', 'XYZ', -1, 1);
INSERT INTO T VALUES ('BC', 'XYZ', -20, -10);
INSERT INTO T VALUES ('BC', 'XYZ', 4, -10);
INSERT INTO T VALUES ('BC', 'XYZ', NULL, NULL);
INSERT INTO T VALUES ('BC', 'XYZ', -20, -10);
INSERT INTO T VALUES ('BC', 'XYZ', 5, -10);
INSERT INTO T VALUES ('BC', 'XYZ', NULL, NULL);
INSERT INTO T VALUES ('BC', 'XYZ', 0, 0);
INSERT INTO T VALUES ('BC', 'XYZ', -1, 0);
INSERT INTO T VALUES ('BC', 'XYZ', 3, 0);
INSERT INTO T VALUES ('BC', 'XYZ', 3, 0);
INSERT INTO T VALUES ('BC', 'XYZ', 8, -10);

INSERT INTO T VALUES ('ABC', 'XY', NULL, NULL);
INSERT INTO T VALUES ('ABC', 'XY', 5, 1);
INSERT INTO T VALUES ('ABC', 'XY', -18, 1);
INSERT INTO T VALUES ('ABC', 'XY', NULL, NULL);
INSERT INTO T VALUES ('ABC', 'XY', -20, -10);
INSERT INTO T VALUES ('ABC', 'XY', 10, 1);
INSERT INTO T VALUES ('ABC', 'XY', 0, -10);
INSERT INTO T VALUES ('ABC', 'XY', NULL, -10);
INSERT INTO T VALUES ('ABC', 'XY', -1, 1);
INSERT INTO T VALUES ('ABC', 'XY', 5, -10);
INSERT INTO T VALUES ('ABC', 'XY', -20, -10);
INSERT INTO T VALUES ('ABC', 'XY', 0, 0);
INSERT INTO T VALUES ('ABC', 'XY', -1, 0);
INSERT INTO T VALUES ('ABC', 'XY', 3, 0);
INSERT INTO T VALUES ('ABC', 'XY', 3, 0);
INSERT INTO T VALUES ('ABC', 'XY', -12, 0);
INSERT INTO T VALUES ('ABC', 'XY', 0, 1);
INSERT INTO T VALUES ('ABC', 'XY', 4, -10);
INSERT INTO T VALUES ('ABC', 'XY', 8, -10);

SELECT * FROM T ORDER BY A ASC, B ASC, C ASC, D ASC;
SELECT * FROM T ORDER BY D ASC, C ASC;

SELECT DISTINCT * FROM T;
SELECT DISTINCT * FROM T ORDER BY A ASC, B ASC, C ASC, D ASC;

SELECT DISTINCT A,B FROM T ORDER BY A ASC, B ASC, C ASC, D ASC;
SELECT DISTINCT A,B FROM T ORDER BY C DESC, D DESC;
SELECT DISTINCT A,B FROM T;

SELECT DISTINCT D,C FROM T;
SELECT DISTINCT D,C FROM T ORDER BY C ASC;
SELECT DISTINCT D,C FROM T ORDER BY C DESC;

SELECT DISTINCT A,B,C FROM T;
SELECT DISTINCT A,B,C FROM T ORDER BY C DESC;
SELECT DISTINCT A,B,C FROM T ORDER BY C ASC;

SELECT DISTINCT D FROM T;
SELECT DISTINCT D FROM T ORDER BY D ASC;
SELECT DISTINCT D FROM T ORDER BY D DESC;

DROP TABLE T;


--
-- Use index to find max,min (d2523kmt)
-- Retrieve count(*) from DTable for simple queries
--
CREATE TABLE T (A INT, B INT);
CREATE INDEX I ON T (A DESC, B DESC);
CREATE INDEX J ON T (B DESC, A ASC);

INSERT INTO T VALUES (0, 0);
INSERT INTO T VALUES (-3, -23);
INSERT INTO T VALUES (NULL, 0);
INSERT INTO T VALUES (3, 6);
INSERT INTO T VALUES (0, NULL);
INSERT INTO T VALUES (5, 8);
INSERT INTO T VALUES (NULL, 2);
INSERT INTO T VALUES (1, 0);
INSERT INTO T VALUES (NULL, NULL);
INSERT INTO T VALUES (-12, 5);
INSERT INTO T VALUES (-1, 1);
INSERT INTO T VALUES (8, -18);

SELECT * FROM T ORDER BY A ASC, B ASC;
SELECT * FROM T ORDER BY B ASC, A ASC;

SELECT COUNT(*) FROM T;
SELECT COUNT(*) FROM T ORDER BY 1;

SELECT COUNT(A) FROM T;
SELECT COUNT(A) FROM T ORDER BY 1;

SELECT COUNT(B) FROM T;
SELECT COUNT(B) FROM T ORDER BY 1;

SELECT MAX(A) FROM T;
SELECT MAX(A) FROM T ORDER BY 1;

SELECT MAX(B) FROM T;
SELECT MAX(B) FROM T ORDER BY 1;

SELECT MIN(A) FROM T;
SELECT MIN(A) FROM T ORDER BY 1;

SELECT MIN(B) FROM T;
SELECT MIN(B) FROM T ORDER BY 1;

SELECT COUNT(A),COUNT(B),COUNT(*),MAX(A),MIN(A),MAX(B),MIN(B) FROM T;

DROP TABLE T;


--
-- Bug fix for positioning virtual node. (d2832kmt)
--
CREATE TABLE T (A INT, B INT);
CREATE INDEX I ON T (A ASC, B ASC);

INSERT INTO T VALUES(2, 64);
INSERT INTO T VALUES(2, 80);
INSERT INTO T VALUES(2, 96);
INSERT INTO T VALUES(2, 112);
INSERT INTO T VALUES(2, 128);
INSERT INTO T VALUES(2, 144);

SELECT A,B FROM T WHERE A = 2 AND B > 0;

DROP TABLE T;


--
-- Bug fix for uDeleteNode. (d2833kmt)
--
CREATE TABLE T (A VARCHAR(5), B DECIMAL(31,2) NOT NULL, C INT NOT NULL);
CREATE INDEX I ON T (A);

INSERT INTO T VALUES('ABC', -10.15, 18);
INSERT INTO T VALUES(NULL, 0.0, 0);
INSERT INTO T VALUES(NULL, 20.36, 78);
INSERT INTO T VALUES('ABC', 67.99, 56);

DELETE FROM T WHERE A = 'ABC' AND B = -10.15;
DELETE FROM T WHERE A IS NULL AND B = 0.0;
DELETE FROM T WHERE A IS NULL AND B = 20.36;
DELETE FROM T WHERE A = 'ABC' AND B = 67.99;

INSERT INTO T VALUES('ABC', -10.15, 18);
INSERT INTO T VALUES(NULL, 0.0, 0);
INSERT INTO T VALUES(NULL, 20.36, 78);
INSERT INTO T VALUES('ABC', 67.99, 56);

DELETE FROM T WHERE A IS NULL AND C <> 0;
DELETE FROM T WHERE A IS NULL AND C = 0;
INSERT INTO T VALUES(NULL, 20.36, 78);

DROP TABLE T;
DROP TABLE T;


--
-- Choose the appropriate indexes to update for UPDATE queries. (d2848kmt)
--
CREATE TABLE T (A INT, B INT, C INT, D INT);

DROP INDEX I;
DROP INDEX J;
DROP INDEX K;
DROP INDEX L;
DROP INDEX M;
DROP INDEX N;

CREATE INDEX I ON T (A DESC);
CREATE INDEX J ON T (A ASC, B DESC);
CREATE INDEX K ON T (C DESC, B ASC);
CREATE INDEX L ON T (C ASC);
CREATE INDEX M ON T (D ASC);
CREATE INDEX N ON T (D DESC);

INSERT INTO T VALUES (0, 0, 0, 0);
INSERT INTO T VALUES (0, 0, 0, 1);
INSERT INTO T VALUES (0, 0, 1, 0);
INSERT INTO T VALUES (0, 0, 1, 1);
INSERT INTO T VALUES (0, 1, 0, 0);
INSERT INTO T VALUES (0, 1, 0, 1);
INSERT INTO T VALUES (0, 1, 1, 0);
INSERT INTO T VALUES (0, 1, 1, 1);
INSERT INTO T VALUES (1, 0, 0, 0);
INSERT INTO T VALUES (1, 0, 0, 1);
INSERT INTO T VALUES (1, 0, 1, 0);
INSERT INTO T VALUES (1, 0, 1, 1);
INSERT INTO T VALUES (1, 1, 0, 0);
INSERT INTO T VALUES (1, 1, 0, 1);
INSERT INTO T VALUES (1, 1, 1, 0);
INSERT INTO T VALUES (1, 1, 1, 1);

SELECT A, B, C, D FROM T ORDER BY A ASC, B ASC;
SELECT C, B, A, D FROM T ORDER BY C ASC, B ASC;
SELECT D, A, B, C FROM T ORDER BY D ASC;

DELETE FROM T WHERE A = 0 AND B = 1 AND C = 1 AND D = 0;
DELETE FROM T WHERE A = 1 AND B = 0 AND C = 1 AND D = 0;

SELECT A, B, C, D FROM T ORDER BY A ASC, B ASC;
SELECT C, B, A, D FROM T ORDER BY C ASC, B ASC;
SELECT D, A, B, C FROM T ORDER BY D ASC;

INSERT INTO T VALUES (0, 1, 1, 0);
INSERT INTO T VALUES (1, 0, 1, 0);

SELECT A, B, C, D FROM T ORDER BY A ASC, B ASC;
SELECT C, B, A, D FROM T ORDER BY C ASC, B ASC;
SELECT D, A, B, C FROM T ORDER BY D ASC;

UPDATE T SET A = 2 WHERE A = 0;

SELECT A, B, C, D FROM T ORDER BY A ASC, B ASC;
SELECT C, B, A, D FROM T ORDER BY C ASC, B ASC;
SELECT D, A, B, C FROM T ORDER BY D ASC;

UPDATE T SET B = 3 WHERE A = 1;

SELECT A, B, C, D FROM T ORDER BY A ASC, B ASC;
SELECT C, B, A, D FROM T ORDER BY C ASC, B ASC;
SELECT D, A, B, C FROM T ORDER BY D ASC;

UPDATE T SET C = 4 WHERE A = 2;

SELECT A, B, C, D FROM T ORDER BY A ASC, B ASC;
SELECT C, B, A, D FROM T ORDER BY C ASC, B ASC;
SELECT D, A, B, C FROM T ORDER BY D ASC;

UPDATE T SET D = 5 WHERE B = 3;

SELECT A, B, C, D FROM T ORDER BY A ASC, B ASC;
SELECT C, B, A, D FROM T ORDER BY C ASC, B ASC;
SELECT D, A, B, C FROM T ORDER BY D ASC;

DROP INDEX I;
DROP INDEX J;
DROP INDEX K;
DROP INDEX L;
DROP INDEX M;
DROP INDEX N;

DROP TABLE T;


--
-- Test index scan (d3274kmt)
-- 
DROP TABLE XXX;

CREATE TABLE XXX (C1 INT, C2 INT);
CREATE INDEX XXXI ON XXX(C1,C2);

INSERT INTO XXX VALUES (1,1);
INSERT INTO XXX VALUES (10,10);

SELECT * FROM XXX WHERE C1 = 10 AND C2 > 2;

DROP TABLE XXX;


--
-- Test index scan (d3274kmt)
-- 
drop table tablex;

create table tablex (c1 char(10));
insert into tablex  values ('a11');
insert into tablex  values ('a13');
insert into tablex  values ('a14');
create index xsdfdf on tablex(c1);

select c1 from tablex where c1 > 'a10';
select c1 from tablex where c1 > 'a09';

drop table tablex;


--
-- Test index scan (d3274kmt)
-- 
CREATE TABLE Y (a INT, b INT);

CREATE INDEX Ibc  ON y(a,b);

INSERT INTO y VALUES (0,  0);
INSERT INTO y VALUES (1, -1);
INSERT INTO y VALUES (2, -2);
INSERT INTO y VALUES (3, -3);
INSERT INTO y VALUES (4, -4);
INSERT INTO y VALUES (5, -5);

SELECT * FROM y WHERE a >= 2 AND b = -5;
SELECT * FROM y WHERE a <= 2 AND b = -5;
SELECT * FROM y WHERE a < 2 AND b = -5;
SELECT * FROM y WHERE a > 2 AND b = -5;

DROP TABLE y;


--
-- Test index scan (d3421kmt)
--
DROP TABLE TABLEX;

CREATE TABLE TABLEX (C1 CHAR(10));

INSERT INTO TABLEX  VALUES ('a11');
INSERT INTO TABLEX  VALUES ('a13');
INSERT INTO TABLEX  VALUES ('a14');

CREATE INDEX XSDFDF ON TABLEX(C1);

SELECT C1 FROM TABLEX WHERE C1 > 'a10';
SELECT C1 FROM TABLEX WHERE C1 > 'a09';

DROP TABLE TABLEX;


--
-- Test index scan (d3681kmt)
--
DROP TABLE T2;
CREATE TABLE T2 (C1 VARCHAR(10));
CREATE INDEX YY ON T2(C1);
INSERT INTO T2 VALUES ('abcd');
SELECT * FROM T2 WHERE C1 = '0';
DROP TABLE T2;

DROP TABLE T3;
CREATE TABLE T3 (C1 DATE);
CREATE INDEX LKLK ON T3(C1);
INSERT INTO T3 VALUES('06/22/2001');
SELECT * FROM T3 WHERE C1 > '01/01/1999';
DROP TABLE T3;


--
-- Index scan on unbalanced tree (d3681kmt)
--
DROP TABLE T;
CREATE TABLE T (A INT PRIMARY KEY);
INSERT INTO T VALUES (1);
INSERT INTO T VALUES (2);
INSERT INTO T VALUES (4);
INSERT INTO T VALUES (8);
INSERT INTO T VALUES (16);
INSERT INTO T VALUES (32);
INSERT INTO T VALUES (64);
INSERT INTO T VALUES (128);
INSERT INTO T VALUES (256);
INSERT INTO T VALUES (512);
INSERT INTO T VALUES (1024);
INSERT INTO T VALUES (2048);
INSERT INTO T VALUES (4096);
INSERT INTO T VALUES (8192);
INSERT INTO T VALUES (16384);
INSERT INTO T VALUES (32768);
INSERT INTO T VALUES (65536);
INSERT INTO T VALUES (131072);
INSERT INTO T VALUES (262144);
INSERT INTO T VALUES (524288);
INSERT INTO T VALUES (1048576);
INSERT INTO T VALUES (2097152);
INSERT INTO T VALUES (4194304);
INSERT INTO T VALUES (8388608);
INSERT INTO T VALUES (16777216);
INSERT INTO T VALUES (33554432);
INSERT INTO T VALUES (67108864);
INSERT INTO T VALUES (134217728);
INSERT INTO T VALUES (268435456);
INSERT INTO T VALUES (536870912);
SELECT * FROM T ORDER BY A;
DROP TABLE T;


-------------------------------------
--  test index optimization (6010kmt)
-------------------------------------
DROP TABLE FOO;
CREATE TABLE FOO(CLE INT PRIMARY KEY, I2 INT, I3 INT);
INSERT INTO FOO values (6,6,6);
INSERT INTO FOO values (7,7,7);
INSERT INTO FOO values (8,8,8);
INSERT INTO FOO values (9,9,9);

SELECT COUNT (*) FROM FOO;
SELECT * FROM FOO WHERE CLE > 6;

DELETE FROM FOO WHERE CLE > 6;

SELECT * FROM FOO WHERE CLE > 6;
SELECT * FROM FOO;
SELECT COUNT (*) FROM FOO;

DELETE FROM FOO WHERE I2 > 6;
SELECT * FROM FOO;
SELECT COUNT (*) FROM FOO;

DROP TABLE FOO;


---------------------------------------------------------------
-- test dynamic stack during deleting node from index (6010kmt)
---------------------------------------------------------------
CREATE TABLE T (A INT, B INT, C INT);
CREATE INDEX I ON T (A, B, C);

INSERT INTO T VALUES (1073741824, 0, 0);
INSERT INTO T VALUES (1610612736, 0, 0);
INSERT INTO T VALUES (1879048192, 0, 0);
INSERT INTO T VALUES (2013265920, 0, 0);
INSERT INTO T VALUES (2080374784, 0, 0);
INSERT INTO T VALUES (2113929216, 0, 0);
INSERT INTO T VALUES (2130706432, 0, 0);
INSERT INTO T VALUES (2139095040, 0, 0);
INSERT INTO T VALUES (2143289344, 0, 0);
INSERT INTO T VALUES (2145386496, 0, 0);
INSERT INTO T VALUES (2146435072, 0, 0);
INSERT INTO T VALUES (2146959360, 0, 0);
INSERT INTO T VALUES (2147221504, 0, 0);
INSERT INTO T VALUES (2147352576, 0, 0);
INSERT INTO T VALUES (2147418112, 0, 0);
INSERT INTO T VALUES (2147450880, 0, 0);
INSERT INTO T VALUES (2147467264, 0, 0);
INSERT INTO T VALUES (2147475456, 0, 0);
INSERT INTO T VALUES (2147479552, 0, 0);
INSERT INTO T VALUES (2147481600, 0, 0);
INSERT INTO T VALUES (2147482624, 0, 0);
INSERT INTO T VALUES (2147483136, 0, 0);
INSERT INTO T VALUES (2147483392, 0, 0);
INSERT INTO T VALUES (2147483520, 0, 0);
INSERT INTO T VALUES (2147483584, 0, 0);
INSERT INTO T VALUES (2147483616, 0, 0);
INSERT INTO T VALUES (2147483632, 0, 0);
INSERT INTO T VALUES (2147483640, 0, 0);
INSERT INTO T VALUES (2147483644, 0, 0);
INSERT INTO T VALUES (2147483646, 0, 0);
INSERT INTO T VALUES (2147483647, 0, 0);
INSERT INTO T VALUES (2147483647, 1073741824, 0);
INSERT INTO T VALUES (2147483647, 1610612736, 0);
INSERT INTO T VALUES (2147483647, 1879048192, 0);
INSERT INTO T VALUES (2147483647, 2013265920, 0);
INSERT INTO T VALUES (2147483647, 2080374784, 0);
INSERT INTO T VALUES (2147483647, 2113929216, 0);
INSERT INTO T VALUES (2147483647, 2130706432, 0);
INSERT INTO T VALUES (2147483647, 2139095040, 0);
INSERT INTO T VALUES (2147483647, 2143289344, 0);
INSERT INTO T VALUES (2147483647, 2145386496, 0);
INSERT INTO T VALUES (2147483647, 2146435072, 0);
INSERT INTO T VALUES (2147483647, 2146959360, 0);
INSERT INTO T VALUES (2147483647, 2147221504, 0);
INSERT INTO T VALUES (2147483647, 2147352576, 0);
INSERT INTO T VALUES (2147483647, 2147418112, 0);
INSERT INTO T VALUES (2147483647, 2147450880, 0);
INSERT INTO T VALUES (2147483647, 2147467264, 0);
INSERT INTO T VALUES (2147483647, 2147475456, 0);
INSERT INTO T VALUES (2147483647, 2147479552, 0);
INSERT INTO T VALUES (2147483647, 2147481600, 0);
INSERT INTO T VALUES (2147483647, 2147482624, 0);
INSERT INTO T VALUES (2147483647, 2147483136, 0);
INSERT INTO T VALUES (2147483647, 2147483392, 0);
INSERT INTO T VALUES (2147483647, 2147483520, 0);
INSERT INTO T VALUES (2147483647, 2147483584, 0);
INSERT INTO T VALUES (2147483647, 2147483616, 0);
INSERT INTO T VALUES (2147483647, 2147483632, 0);
INSERT INTO T VALUES (2147483647, 2147483640, 0);
INSERT INTO T VALUES (2147483647, 2147483644, 0);
INSERT INTO T VALUES (2147483647, 2147483646, 0);
INSERT INTO T VALUES (2147483647, 2147483647, 0);
INSERT INTO T VALUES (2147483647, 2147483647, 1073741824);
INSERT INTO T VALUES (2147483647, 2147483647, 1610612736);
INSERT INTO T VALUES (2147483647, 2147483647, 1879048192);
INSERT INTO T VALUES (2147483647, 2147483647, 2013265920);
INSERT INTO T VALUES (2147483647, 2147483647, 2080374784);
INSERT INTO T VALUES (2147483647, 2147483647, 2113929216);
INSERT INTO T VALUES (2147483647, 2147483647, 2130706432);
INSERT INTO T VALUES (2147483647, 2147483647, 2139095040);
INSERT INTO T VALUES (2147483647, 2147483647, 2143289344);
INSERT INTO T VALUES (2147483647, 2147483647, 2145386496);
INSERT INTO T VALUES (2147483647, 2147483647, 2146435072);
INSERT INTO T VALUES (2147483647, 2147483647, 2146959360);
INSERT INTO T VALUES (2147483647, 2147483647, 2147221504);
INSERT INTO T VALUES (2147483647, 2147483647, 2147352576);
INSERT INTO T VALUES (2147483647, 2147483647, 2147418112);
INSERT INTO T VALUES (2147483647, 2147483647, 2147450880);
INSERT INTO T VALUES (2147483647, 2147483647, 2147467264);
INSERT INTO T VALUES (2147483647, 2147483647, 2147475456);
INSERT INTO T VALUES (2147483647, 2147483647, 2147479552);
INSERT INTO T VALUES (2147483647, 2147483647, 2147481600);
INSERT INTO T VALUES (2147483647, 2147483647, 2147482624);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483136);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483392);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483520);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483584);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483616);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483632);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483640);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483644);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483646);
INSERT INTO T VALUES (2147483647, 2147483647, 2147483647);

SELECT COUNT(*) FROM T;

DELETE FROM T WHERE A = 2147483647 AND B = 2147483647 AND C = 2147483647;

SELECT * FROM T WHERE A = 2147483647 AND B = 2147483647 AND C = 2147483647;
SELECT * FROM T;
SELECT COUNT(*) FROM T;

DROP TABLE T;


--
--  UPDATE record to its original value (6308kmt)
--
DROP TABLE X;

CREATE TABLE X(A INT, B INT, C INT, D INT, E INT, F INT, G CHAR(76));
CREATE INDEX IDX1 ON X(B);
CREATE INDEX IDX2 ON X(C);
CREATE INDEX IDX3 ON X(D);

INSERT INTO X VALUES (0,0,0,0,0,0,'blabla0');
INSERT INTO X VALUES (1,1,0,1,1,0,'blabla0');
INSERT INTO X VALUES (2,2,0,2,2,0,'blabla0');
INSERT INTO X VALUES (3,3,0,3,3,0,'blabla0');
INSERT INTO X VALUES (4,4,0,4,4,0,'blabla0');

UPDATE X set B=0, C=0, D=0, E=0, F=0, G='UPDATE0' WHERE A=0;
UPDATE X set B=1, C=0, D=1, E=1, F=0, G='UPDATE0' WHERE A=1;
UPDATE X set B=2, C=0, D=2, E=2, F=0, G='UPDATE0' WHERE A=2;
UPDATE X set B=3, C=0, D=3, E=3, F=0, G='UPDATE0' WHERE A=3;
UPDATE X set B=4, C=0, D=4, E=4, F=0, G='UPDATE0' WHERE A=4;

SELECT * from x;
SELECT * FROM X ORDER BY B;
SELECT * FROM X ORDER BY C;
SELECT * FROM X ORDER BY D;

DELETE FROM X;

SELECT * from x;
SELECT * FROM X ORDER BY B;
SELECT * FROM X ORDER BY C;
SELECT * FROM X ORDER BY D;

INSERT INTO X VALUES (0,0,0,0,0,0,'blabla0');
INSERT INTO X VALUES (1,1,0,1,1,0,'blabla0');
INSERT INTO X VALUES (2,2,0,2,2,0,'blabla0');
INSERT INTO X VALUES (3,3,0,3,3,0,'blabla0');
INSERT INTO X VALUES (4,4,0,4,4,0,'blabla0');

UPDATE X set B=0, C=0, D=0, E=0, F=0, G='UPDATE0' WHERE A=0;
UPDATE X set B=1, C=0, D=1, E=1, F=0, G='UPDATE0' WHERE A=1;
UPDATE X set B=2, C=0, D=2, E=2, F=0, G='UPDATE0' WHERE A=2;
UPDATE X set B=0, C=1, D=1, E=-1, F=0, G='UPDATE1' WHERE A=3;
UPDATE X set B=1, C=1, D=2, E=0, F=1, G='UPDATE1' WHERE A=4;

SELECT * from x;
SELECT * FROM X ORDER BY B;
SELECT * FROM X ORDER BY C;
SELECT * FROM X ORDER BY D;

DROP TABLE X;


--
--  UPDATE with CHECK CONSTRAINTS IN TABLE SCHEMA
--
CREATE TABLE EVENT (LUID INTEGER NOT NULL,
                    EVENTTYPE SMALLINT NOT NULL CHECK(EVENTTYPE IN (0,1,2,3)),
                    SUMMARY VARCHAR(128),
                    PRIMARY KEY(LUID));

CREATE INDEX XEVENTTYPE ON EVENT (EVENTTYPE);

INSERT INTO EVENT (LUID,EVENTTYPE,SUMMARY) VALUES (1,2,'summary 42');
UPDATE EVENT SET EVENTTYPE=3,SUMMARY='this is an updated summary' WHERE LUID=1;
INSERT INTO EVENT (LUID,EVENTTYPE,SUMMARY) VALUES (5,2,'summary 48');
UPDATE EVENT SET EVENTTYPE=3,SUMMARY='this is an updated summary' WHERE LUID=5;
INSERT INTO EVENT (LUID,EVENTTYPE,SUMMARY) VALUES (9,2,'summary 53');
UPDATE EVENT SET EVENTTYPE=3,SUMMARY='this is an updated summary' WHERE LUID=9;

SELECT * FROM EVENT;
SELECT * FROM EVENT WHERE LUID = 1;

DELETE FROM EVENT WHERE LUID=1;

SELECT * FROM EVENT;

SELECT * FROM EVENT WHERE LUID = 1;

DROP TABLE EVENT;

-------------------------------------------
--  Test uParentNode optimization (6585kmt)
-------------------------------------------

--
--  primary searching index
--
drop table t;

create table t (a int primary key, b int, c int, d int, e int);
create index i_b on t (b);
create index i_db on t (d, b);

insert into t values (98, 43, 43, 90, 62);
insert into t values (26, 96, 41, 30, 46);
insert into t values (99, 26, 18, 40, 28);
insert into t values (21, 13, 37, 3, 22);
insert into t values (41, 87, 44, 0, 41);
insert into t values (51, 76, 6, 49, 58);
insert into t values (69, 37, 62, 25, 99);
insert into t values (57, 96, 87, 14, 42);
insert into t values (48, 51, 28, 88, 61);
insert into t values (85, 63, 6, 38, 84);
insert into t values (36, 94, 52, 63, 93);
insert into t values (83, 16, 51, 48, 47);
insert into t values (38, 48, 96, 28, 64);
insert into t values (55, 37, 95, 68, 21);
insert into t values (84, 61, 40, 72, 19);
insert into t values (18, 49, 97, 30, 79);
insert into t values (29, 5, 6, 23, 5);
insert into t values (62, 33, 58, 7, 83);
insert into t values (2, 45, 44, 80, 59);
insert into t values (8, 54, 35, 58, 56);

select * from t order by a;

delete from t where a < 86 and a > 26;
select * from t where a < 86 and a > 26;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a = 86;
select * from t where a = 86;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a = 26;
select * from t where a = 26;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a < 68 and a > 67;
select * from t where a < 68 and a > 67;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a = 68;
select * from t where a = 68;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a = 67;
select * from t where a = 67;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a < 30 and a > 2;
select * from t where a < 30 and a > 2;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a = 30;
select * from t where a = 30;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a = 2;
select * from t where a = 2;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a < 16 and a > 16;
select * from t where a < 16 and a > 16;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a = 16;
select * from t where a = 16;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a < 56 and a > 56;
select * from t where a < 56 and a > 56;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

delete from t where a = 56;
select * from t where a = 56;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by d, b;

drop table t;

--
--  No searching index and no duplicates in the target record set
--
drop table t;

create table t (a int, b int, c int, d int, e int);
create index i_b on t (b);
create index i_c on t (c);
create index i_db on t (d, b);

insert into t values (111, 86, 24, 221, 194);
insert into t values (249, 243, 159, 171, 259);
insert into t values (223, 59, 199, 22, 97);
insert into t values (28, 268, 120, 54, 190);
insert into t values (88, 105, 35, 38, 150);
insert into t values (272, 199, 87, 185, 259);
insert into t values (16, 113, 235, 44, 168);
insert into t values (96, 161, 74, 255, 112);
insert into t values (289, 213, 221, 248, 213);
insert into t values (145, 21, 8, 94, 206);
insert into t values (203, 84, 199, 193, 273);
insert into t values (7, 67, 92, 103, 226);
insert into t values (62, 108, 109, 108, 114);
insert into t values (150, 227, 144, 216, 91);
insert into t values (17, 155, 263, 191, 235);
insert into t values (189, 224, 33, 107, 245);
insert into t values (296, 208, 73, 232, 2);
insert into t values (236, 72, 298, 27, 36);
insert into t values (1, 123, 262, 168, 169);
insert into t values (105, 3, 254, 180, 183);

select * from t order by a;

delete from t where a < 168 and a > 33;
select * from t where a < 168 and a > 33;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 168;
select * from t where a = 168;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 33;
select * from t where a = 33;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 188 and a > 83;
select * from t where a < 188 and a > 83;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 188;
select * from t where a = 188;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 83;
select * from t where a = 83;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 191 and a > 140;
select * from t where a < 191 and a > 140;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 191;
select * from t where a = 191;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 140;
select * from t where a = 140;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 29 and a > 29;
select * from t where a < 29 and a > 29;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 29;
select * from t where a = 29;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 289 and a > 289;
select * from t where a < 289 and a > 289;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 289;
select * from t where a = 289;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

drop table t;

--
--  No searching index and duplicates in the target record set
--
drop table t;

create table t (a int, b int, c int, d int, e int);
create index i_b on t (b);
create index i_c on t (c);
create index i_db on t (d, b);

insert into t values (106, 147, 104, 64, 52);
insert into t values (39, 226, 30, 235, 27);
insert into t values (115, 93, 198, 19, 261);
insert into t values (87, 105, 49, 131, 129);
insert into t values (10, 126, 110, 187, 233);
insert into t values (168, 44, 236, 160, 51);
insert into t values (252, 261, 88, 15, 250);
insert into t values (210, 92, 101, 224, 14);
insert into t values (266, 250, 54, 113, 298);
insert into t values (266, 131, 170, 279, 213);
insert into t values (87, 277, 39, 3, 48);
insert into t values (281, 116, 37, 253, 253);
insert into t values (250, 167, 167, 248, 64);
insert into t values (224, 101, 229, 33, 131);
insert into t values (39, 63, 100, 251, 156);
insert into t values (39, 188, 36, 72, 255);
insert into t values (252, 228, 263, 211, 53);
insert into t values (115, 33, 263, 70, 126);
insert into t values (252, 156, 170, 275, 30);
insert into t values (39, 96, 249, 248, 206);

select * from t order by a;

delete from t where a < 156 and a > 156;
select * from t where a < 156 and a > 156;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 156;
select * from t where a = 156;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 166 and a > 38;
select * from t where a < 166 and a > 38;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 166;
select * from t where a = 166;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 38;
select * from t where a = 38;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 103 and a > 45;
select * from t where a < 103 and a > 45;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 103;
select * from t where a = 103;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 45;
select * from t where a = 45;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 197 and a > 174;
select * from t where a < 197 and a > 174;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 197;
select * from t where a = 197;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 174;
select * from t where a = 174;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 293 and a > 262;
select * from t where a < 293 and a > 262;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 293;
select * from t where a = 293;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 262;
select * from t where a = 262;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

drop table t;

--
--  searching index and duplicates in the target record set
--
drop table t;

create table t (a int, b int, c int, d int, e int);
create index i_a on t (a);
create index i_b on t (b);
create index i_c on t (c);
create index i_db on t (d, b);

insert into t values (106, 288, 287, 82, 279);
insert into t values (139, 114, 105, 3, 286);
insert into t values (285, 13, 22, 269, 285);
insert into t values (139, 13, 248, 241, 2);
insert into t values (276, 235, 5, 138, 129);
insert into t values (90, 163, 115, 76, 130);
insert into t values (61, 3, 298, 29, 80);
insert into t values (287, 90, 155, 46, 81);
insert into t values (175, 84, 96, 45, 179);
insert into t values (4, 96, 153, 248, 266);
insert into t values (90, 7, 210, 127, 259);
insert into t values (257, 59, 241, 245, 93);
insert into t values (191, 238, 96, 25, 136);
insert into t values (4, 298, 120, 193, 87);
insert into t values (90, 176, 118, 198, 239);
insert into t values (90, 292, 180, 207, 21);
insert into t values (191, 87, 21, 191, 215);
insert into t values (155, 145, 129, 206, 255);
insert into t values (191, 200, 214, 236, 269);
insert into t values (186, 224, 247, 190, 163);

select * from t order by a;

delete from t where a < 241 and a > 241;
select * from t where a < 241 and a > 241;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 241;
select * from t where a = 241;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 267 and a > 200;
select * from t where a < 267 and a > 200;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 267;
select * from t where a = 267;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 200;
select * from t where a = 200;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 190 and a > 69;
select * from t where a < 190 and a > 69;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 190;
select * from t where a = 190;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 69;
select * from t where a = 69;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 224 and a > 88;
select * from t where a < 224 and a > 88;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 224;
select * from t where a = 224;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 88;
select * from t where a = 88;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 266 and a > 31;
select * from t where a < 266 and a > 31;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 266;
select * from t where a = 266;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 31;
select * from t where a = 31;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

drop table t;

--
--  searching index and no duplicates in the target record set
--
drop table t;

create table t (a int, b int, c int, d int, e int);
create index i_a on t (a);
create index i_b on t (b);
create index i_c on t (c);
create index i_db on t (d, b);

insert into t values (281, 297, 163, 30, 120);
insert into t values (112, 51, 180, 110, 178);
insert into t values (3, 221, 20, 179, 174);
insert into t values (227, 14, 151, 223, 38);
insert into t values (157, 117, 210, 282, 243);
insert into t values (223, 183, 284, 98, 202);
insert into t values (125, 207, 127, 156, 280);
insert into t values (54, 96, 177, 12, 241);
insert into t values (217, 0, 3, 143, 45);
insert into t values (174, 209, 154, 194, 41);
insert into t values (26, 181, 22, 168, 139);
insert into t values (76, 291, 102, 131, 119);
insert into t values (122, 197, 70, 180, 81);
insert into t values (95, 92, 138, 147, 158);
insert into t values (4, 228, 130, 180, 19);
insert into t values (180, 212, 125, 180, 289);
insert into t values (135, 38, 110, 137, 83);
insert into t values (176, 152, 109, 239, 15);
insert into t values (31, 128, 1, 96, 66);
insert into t values (206, 149, 212, 157, 160);

select * from t order by a;

delete from t where a < 54 and a > 26;
select * from t where a < 54 and a > 26;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 54;
select * from t where a = 54;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 26;
select * from t where a = 26;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 175 and a > 144;
select * from t where a < 175 and a > 144;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 175;
select * from t where a = 175;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 144;
select * from t where a = 144;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 99 and a > 99;
select * from t where a < 99 and a > 99;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 99;
select * from t where a = 99;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 274 and a > 166;
select * from t where a < 274 and a > 166;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 274;
select * from t where a = 274;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 166;
select * from t where a = 166;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a < 270 and a > 41;
select * from t where a < 270 and a > 41;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 270;
select * from t where a = 270;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

delete from t where a = 41;
select * from t where a = 41;
select * from t order by a;
select * from t;
select * from t order by b;
select * from t order by c;
select * from t order by d, b;

drop table t;


--
-- Test empty string (a7169kmt)
--
drop table t;

create table t (a varchar(200));
create index i on t (a);

insert into t values ('woehwohwew');

select * from t where a > '';
select * from t where a > '' order by a asc;
select * from t where a > '' order by a desc;

drop table t;

create table t (a varchar(200));
create index i on t (a);

insert into t values ('');

select * from t where a > '';
select * from t where a = '';
select * from t where a < '';
select * from t where a >= '';
select * from t where a <= '';

drop table t;

create table t (a varchar(200), b int);
create index i on t (a);

insert into t values ('a', 1);
insert into t values ('woehwohwew', 2);
insert into t values ('', 3);
insert into t values ('owhohwwro', 4);
insert into t values ('bbb', 5);
insert into t values ('', 6);
insert into t values ('prjrt', 7);
insert into t values ('', 8);

select * from t order by a asc;
select * from t order by a desc;

select * from t where a > '';
select * from t where a = '';
select * from t where a < '';
select * from t where a >= '';
select * from t where a <= '';

drop table t;
