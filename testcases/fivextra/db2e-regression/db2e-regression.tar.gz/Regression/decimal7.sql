-- ------------------ FILE: TRYOO1.SQL  -------------------
-- -                                                      - 
-- -          CHECK ALL ERROR IN DECIMAL DATA TYPE        -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE STAFF;
DROP TABLE PROJ;
DROP TABLE WORKS;
DROP TABLE PT004;
DROP TABLE CS001;
DROP TABLE CS002;
DROP TABLE EW002;
DROP TABLE EW003;
DROP TABLE LT001;
DROP TABLE LT002;
DROP TABLE LT003;
DROP TABLE LT004;
DROP TABLE LT005;
DROP TABLE PT005;

-- ------------------  PERFORMANCE TEST  ------------------
-- --------------------------------------------------------
-- 
-- --------------------------------------------------------
-- -----------------------  1PT001  -----------------------
-- --------------------------------------------------------
-- CREATE "STAFF" TABLE WITH [PRIMARY KEY NOT NULL] OPTION 
-- UDB2 RESULT = 42831

CREATE TABLE STAFF
 (EmpNum   VARCHAR(3) PRIMARY KEY NOT NULL,
  EmpName  VARCHAR(20),
  Grade    DECIMAL(5,2),
  City     CHAR(10));

-- --------------------------------------------------------
-- -----------------------  1PT002  -----------------------
-- --------------------------------------------------------
-- CREATE "PROJ" TABLE WITH [PRIMARY KEY NOT NULL] OPTION 
-- UDB2 RESULT = 42831

CREATE TABLE PROJ
 (PNum     VARCHAR(3) PRIMARY KEY NOT NULL,
  PName    VARCHAR(20),
  PType    VARCHAR(6),
  Budge    INT,
  City     CHAR(10));


-- --------------------------------------------------------
-- -----------------------  1PT003  -----------------------
-- --------------------------------------------------------
-- CREATE "WORKS" TABLE WITH [NOT NULL] OPTION
-- UDB2 RESULT = SUCC

CREATE TABLE WORKS
 (EmpNum   VARCHAR(3) NOT NULL,
  PNum     VARCHAR(3) NOT NULL,
  Hours    SMALLINT);


-- --------------------------------------------------------
-- -----------------------  1PT004  -----------------------
-- --------------------------------------------------------
-- CREATE "PT004" TABLE WITH DECIMAL DATA TYPE
-- UDB2 RESULT = SUCC

CREATE TABLE PT004
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(5,2) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- -----------------------  1PT005  -----------------------
-- --------------------------------------------------------
-- CREATE "PT005" TABLE WITH DEC DATA TYPE
-- UDB2 RESULT = SUCC

CREATE TABLE PT005
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(5,2) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));


-- --------------------------------------------------------
-- ------------  SYNTAX ERROR TEST (SPELLING)  ------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1SP001  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "DECIMAL"
-- UDB2 RESULT = 42601

CREATE TABLE SP001
 (EmpNum   VARCHAR(10),
  Salary1  DECMAL(5,2) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- -----------------------  1SP002  -----------------------
-- --------------------------------------------------------
-- SPELLING ERROR IN "DECIMAL"
-- UDB2 RESULT = 42601

CREATE TABLE SP002
 (EmpNum   VARCHAR(10),
  Salary1  DECMAL(5,2) NOT NULL PRIMARY KEY,
  Salary2  DECI(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));



-- --------------------------------------------------------
-- -----  SYNTAX ERROR TEST (EXTRA OR MISSING WORD)  ------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1EW001  -----------------------
-- --------------------------------------------------------
-- DATA TYPE "DECIMAL" IS MISSING
-- UDB2 RESULT = 42601

CREATE TABLE EW001
 (EmpNum   VARCHAR(10),
  Salary1  NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));


-- --------------------------------------------------------
-- -----------------------  1EW002  -----------------------
-- --------------------------------------------------------
-- ONE PARAMETER IN DATA TYPE "DECIMAL" IS MISSING
-- UDB2 RESULT = SUCC
-- DB2E RESULT = 42601

CREATE TABLE EW002
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(5) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));


-- --------------------------------------------------------
-- -----------------------  1EW003  -----------------------
-- --------------------------------------------------------
-- BOTH PARAMETER IN DATA TYPE "DECIMAL" IS MISSING
-- UDB2 RESULT = SUCC
-- DB2E RESULT = 42601

CREATE TABLE EW003
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));


-- --------------------------------------------------------
-- ---------  SYNTAX ERROR TEST (CASE SENSITIVE)  ---------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1CS001  -----------------------
-- --------------------------------------------------------
-- CHECK IF "DECIMAL" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

CREATE TABLE CS001
 (EmpNum   VARCHAR(10),
  Salary1  DeCiMaL(5,2) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- -----------------------  1CS002  -----------------------
-- --------------------------------------------------------
-- CHECK IF "DECIMAL" IS CASE SENSITIVE
-- UDB2 RESULT = SUCC

CREATE TABLE CS002
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(5,2) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));


-- --------------------------------------------------------
-- ----------------  RUN-TIME ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1RT001  -----------------------
-- --------------------------------------------------------
-- DECLARE VARCHAR DATA TYPE, SUCH AS "DECIMAL(0)"
-- UDB2 RESULT = 42611

CREATE TABLE LT001
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(0) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- -----------------------  1RT002  -----------------------
-- --------------------------------------------------------
-- DECLARE VARCHAR DATA TYPE, SUCH AS "DECIMAL(-1)"
-- UDB2 RESULT = 42601

CREATE TABLE LT002
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(-1) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- -----------------------  1RT003  -----------------------
-- --------------------------------------------------------
-- DECLARE VARCHAR DATA TYPE, SUCH AS "DECIMAL(-1,0)"
-- UDB2 RESULT = 42601

CREATE TABLE LT003
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(-1,0) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));


-- --------------------------------------------------------
-- -----------------------  1RT004  -----------------------
-- --------------------------------------------------------
-- DECLARE VARCHAR DATA TYPE, SUCH AS "DECIMAL(0,-1)"
-- UDB2 RESULT = 42601

CREATE TABLE LT004
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(0,-1) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- ------------------  LIMITATION TEST  -------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  1LT001  -----------------------
-- --------------------------------------------------------
-- WITHIN NUMBER OF DECIMAL ALLOWED IN DECLARATION
-- UDB2 RESULT = SUCC

CREATE TABLE LT001
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(14,2) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));


-- --------------------------------------------------------
-- -----------------------  1LT002  -----------------------
-- --------------------------------------------------------
-- EXACT NUMBER OF DECIMAL ALLOWED IN DECLARATION
-- UDB2 RESULT = SUCC

CREATE TABLE LT002
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(15,2) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- -----------------------  1LT003  -----------------------
-- --------------------------------------------------------
-- EXCEED NUMBER OF DECIMAL ALLOWED IN DECLARATION
-- UDB2 RESULT = SUCC
-- DB2E RESULT = 42611

CREATE TABLE LT003
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(16,2) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- -----------------------  1LT004  -----------------------
-- --------------------------------------------------------
-- WITHIN NUMBER OF DECIMAL ALLOWED IN DECLARATION
-- UDB2 RESULT = SUCC

CREATE TABLE LT004
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(15,14) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- -----------------------  1LT005  -----------------------
-- --------------------------------------------------------
-- EXACT NUMBER OF DECIMAL ALLOWED IN DECLARATION
-- UDB2 RESULT = SUCC

CREATE TABLE LT005
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(15,15) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));


-- --------------------------------------------------------
-- -----------------------  1LT006  -----------------------
-- --------------------------------------------------------
-- EXCEED NUMBER OF DECIMAL ALLOWED IN DECLARATION
-- UDB2 RESULT = 42611

CREATE TABLE LT004
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(15,16) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));

-- --------------------------------------------------------
-- -----------------------  1LT007  -----------------------
-- --------------------------------------------------------
-- SECOND PARAMETER EXCEED THE FIRST PARAMETER
-- UDB2 RESULT = 42611

CREATE TABLE LT004
 (EmpNum   VARCHAR(10),
  Salary1  DECIMAL(5,6) NOT NULL PRIMARY KEY,
  Salary2  DECIMAL(5,2) NOT NULL,
  Salary3  DECIMAL(5,2));


-- --------------------------------------------------------
-- ------------------------ CLEAR -------------------------
-- --------------------------------------------------------

DROP TABLE CS001;
DROP TABLE CS002;
DROP TABLE EW002;
DROP TABLE EW003;
DROP TABLE LT001;
DROP TABLE LT002;
DROP TABLE LT003;
DROP TABLE LT004;
DROP TABLE LT005;
DROP TABLE PT005;


-- --------------------------------------------------------
-- ------------------  PERFORMANCE TEST  ------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2PT001  -----------------------
-- --------------------------------------------------------
-- INSERT INTO VALUE INTO "STAFF" TABLE  
-- UDB2 RESULT = SUCC

INSERT INTO STAFF VALUES ('E1','Alice',12,'Deale');
INSERT INTO STAFF VALUES ('E2','Betty',10,'Vienna');
INSERT INTO STAFF VALUES ('E3','Carmen',13,'Vienna');
INSERT INTO STAFF VALUES ('E4','Don',12,'Deale');
INSERT INTO STAFF VALUES ('E5','Ed',13,'Akron');

     
-- --------------------------------------------------------
-- -----------------------  2PT002  -----------------------
-- --------------------------------------------------------
-- INSERT INTO VALUE INTO "PROJ" TABLE  
-- UDB2 RESULT = SUCC

INSERT INTO PROJ VALUES  ('P1','MXSS','Design',10000,'Deale');
INSERT INTO PROJ VALUES  ('P2','CALM','Code',30000,'Vienna');
INSERT INTO PROJ VALUES  ('P3','SDP','Test',30000,'Tampa');
INSERT INTO PROJ VALUES  ('P4','SDP','Design',20000,'Deale');
INSERT INTO PROJ VALUES  ('P5','IRM','Test',10000,'Vienna');
INSERT INTO PROJ VALUES  ('P6','PAYR','Design',50000,'Deale');


-- --------------------------------------------------------
-- -----------------------  2PT003  -----------------------
-- --------------------------------------------------------
-- INSERT INTO VALUE INTO "WORKS" TABLE 
-- UDB2 RESULT = SUCC

INSERT INTO WORKS VALUES  ('E1','P1',40);
INSERT INTO WORKS VALUES  ('E1','P2',20);
INSERT INTO WORKS VALUES  ('E1','P3',80);
INSERT INTO WORKS VALUES  ('E1','P4',20);
INSERT INTO WORKS VALUES  ('E1','P5',12);
INSERT INTO WORKS VALUES  ('E1','P6',12);
INSERT INTO WORKS VALUES  ('E2','P1',40);
INSERT INTO WORKS VALUES  ('E2','P2',80);
INSERT INTO WORKS VALUES  ('E3','P2',20);
INSERT INTO WORKS VALUES  ('E4','P2',20);
INSERT INTO WORKS VALUES  ('E4','P4',40);
INSERT INTO WORKS VALUES  ('E4','P5',80);


-- --------------------------------------------------------
-- -----------------------  2PT004  -----------------------
-- --------------------------------------------------------
-- INSERT INTO VALUE INTO "PT004" TABLE 
-- UDB2 RESULT = SUCC

INSERT INTO PT004 VALUES ('Alice', 100.00, 0.6, 1);
INSERT INTO PT004 VALUES ('Betty', 200.00, 0.5, 10);
INSERT INTO PT004 VALUES ('Carman', 300.00, 0.4, 100);
INSERT INTO PT004 VALUES ('Don', 400.00, 0.3, 200);
INSERT INTO PT004 VALUES ('Ed', 500.00, 0.2, 500);
INSERT INTO PT004 VALUES ('Ron', 600.00, 0.1, 900);

-- --------------------------------------------------------
-- -----------------  SEMATIC ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2ST001  -----------------------
-- --------------------------------------------------------
-- PASS VARCHAR WHEN DECIMAL IS THE INTENDED PARAMETER
-- UDB2 RESULT = 42821

INSERT INTO PT004 VALUES ('ST001', '11.11', 0.1, 11);

-- --------------------------------------------------------
-- -----------------------  2ST002  -----------------------
-- --------------------------------------------------------
-- PASS VARCHAR WHEN DECIMAL IS THE INTENDED PARAMETER
-- UDB2 RESULT = 42821

INSERT INTO PT004 VALUES ('ST002', '22.22', 0.2, 22);

-- --------------------------------------------------------
-- -----------------------  2ST003  -----------------------
-- --------------------------------------------------------
-- INSERT NULL IN PRIMARY KEY 
-- UDB2 RESULT = 23502

INSERT INTO PT004 VALUES ('ST003', NULL, 0.3, 33);


-- --------------------------------------------------------
-- -----------------------  2ST004  -----------------------
-- --------------------------------------------------------
-- INSERT NOTHING IN PRIMARY KEY
-- UDB2 RESULT = 42601

INSERT INTO PT004 VALUES ('ST004', , 0.4, 44);

-- --------------------------------------------------------
-- -----------------------  2ST005  -----------------------
-- --------------------------------------------------------
-- INSERT IDENTICAL "PRIMARY KEY"
-- UDB2 RESULT = 23505

INSERT INTO PT004 VALUES('ST005', 55.55, 0.5, 55);
INSERT INTO PT004 VALUES('ST005', 55.55, 0.5, 55);


-- --------------------------------------------------------
-- -----------------------  2ST006  -----------------------
-- --------------------------------------------------------
-- INSERT NULL IN NOT NULL COLUMN 
-- UDB2 RESULT = 23502

INSERT INTO PT004 VALUES('ST006', 66.66, NULL, 66);

-- --------------------------------------------------------
-- -----------------------  2ST007  -----------------------
-- --------------------------------------------------------
-- INSERT NOTHING IN NOT NULL COLUMN
-- UDB2 RESULT = 42601

INSERT INTO PT004 VALUES('ST007', 77.77, , 77);

-- --------------------------------------------------------
-- -----------------------  2ST008  -----------------------
-- --------------------------------------------------------
-- INSERT IDENTICAL VALUE IN NOT NULL COLUMN 
-- UDB2 RESULT = SUCC

INSERT INTO PT004 VALUES('ST008', 88.88, 88, 88);
INSERT INTO PT004 VALUES('ST008', 99.99, 99, 99);


-- --------------------------------------------------------
-- ------------------  LIMITATION TEST  -------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  2LT001  -----------------------
-- --------------------------------------------------------
-- WITHIN NUMBER OF "DECIMAL" ALLOWED IN FIRST PARAMETER
-- UDB2 RESULT = SUCC

INSERT INTO PT004 VALUES('LT001', 111.11, 111, 111);
INSERT INTO PT004 VALUES('LT001', 111, 111, 111);

-- --------------------------------------------------------
-- -----------------------  2LT002  -----------------------
-- --------------------------------------------------------
-- EXACT NUMBER OF "DECIMAL" ALLOWED IN FIRST PARAMETER
-- UDB2 RESULT = SUCC

INSERT INTO PT004 VALUES('LT002', 222.22, 222, 222);
INSERT INTO PT004 VALUES('LT002', 222, 222, 222);

-- --------------------------------------------------------
-- -----------------------  2LT003  -----------------------
-- --------------------------------------------------------
-- EXCEED NUMBER OF "DECIMAL" ALLOWED IN FIRST PARAMETER
-- UDB2 RESULT = 22003

INSERT INTO PT004 VALUES('LT003', 3000.00, 333, 333);
INSERT INTO PT004 VALUES('LT003', 3000, 333, 333);

-- --------------------------------------------------------
-- -----------------------  2LT004  -----------------------
-- --------------------------------------------------------
-- WITHIN NUMBER OF "DECIMAL" ALLOWED IN SECOND PARAMETER
-- UDB2 RESULT = SUCC

INSERT INTO PT004 VALUES('LT004', 444.4, 444, 444);

-- --------------------------------------------------------
-- -----------------------  2LT005  -----------------------
-- --------------------------------------------------------
-- EXACT NUMBER OF "DECIMAL" ALLOWED IN SECOND PARAMETER
-- UDB2 RESULT = SUCC

INSERT INTO PT004 VALUES('LT005', 555.55, 444, 555);

-- --------------------------------------------------------
-- -----------------------  2LT006  -----------------------
-- --------------------------------------------------------
-- EXCEED NUMBER OF "DECIMAL" ALLOWED IN SECOND PARAMETER
-- UDB2 RESULT = 22003

INSERT INTO PT004 VALUES('LT006', 666666, 666, 666);
INSERT INTO PT004 VALUES('LT006', 66666, 666, 666);
INSERT INTO PT004 VALUES('LT006', 6666.6, 666, 666);
INSERT INTO PT004 VALUES('LT006', 666.66, 666, 666);
INSERT INTO PT004 VALUES('LT006', 66.666, 666, 666);
INSERT INTO PT004 VALUES('LT006', 6.6666, 666, 666);
INSERT INTO PT004 VALUES('LT006', 0.66666, 666, 666);




-- ------------------  PERFROMMANCE TEST  ------------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3PT001  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM "STAFF" TABLE  
-- UDB2 RESULT = SUCC

SELECT * FROM STAFF;
     
-- --------------------------------------------------------
-- -----------------------  3PT002  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM "PROJ" TABLE  
-- UDB2 RESULT = SUCC

SELECT * FROM PROJ;


-- --------------------------------------------------------
-- -----------------------  3PT003  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM "WORKS" TABLE 
-- UDB2 RESULT = SUCC

SELECT * FROM WORKS;


-- --------------------------------------------------------
-- -----------------------  3PT004  -----------------------
-- --------------------------------------------------------
-- SELECT VALUE FROM "PT004" TABLE 
-- UDB2 RESULT = SUCC

SELECT * FROM PT004;


-- --------------------------------------------------------
-- ------  SYNTAX ERROR TEST (SEARCHING CONDITION) --------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3SC001  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (=) (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (2 SELECTED)

SELECT * FROM STAFF WHERE Grade = 12;
SELECT * FROM STAFF WHERE Grade = 12.0;
SELECT * FROM STAFF WHERE Grade = 12.00;
SELECT * FROM STAFF WHERE Grade = 12.01;

-- --------------------------------------------------------
-- -----------------------  3SC002  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (<) (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (1 SELECTED)

SELECT * FROM STAFF WHERE Grade < 12;
SELECT * FROM STAFF WHERE Grade < 12.00;


-- --------------------------------------------------------
-- -----------------------  3SC003  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (<=) (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (3 SELECTED)

SELECT * FROM STAFF WHERE Grade <= 12;
SELECT * FROM STAFF WHERE Grade <= 12.00;


-- --------------------------------------------------------
-- -----------------------  3SC004  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (>) (DATA TYPE DECIMAL)
-- UDB2 RESULT = SUCC (2 SELECTED)

SELECT * FROM STAFF WHERE Grade > 12;
SELECT * FROM STAFF WHERE Grade > 12.00;


-- --------------------------------------------------------
-- -----------------------  3SC005  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (>=) (DATA TYPE DECIMAL)
-- UDB2 RESULT =  SUCC (4 SELECTED)

SELECT * FROM STAFF WHERE Grade >= 12;
SELECT * FROM STAFF WHERE Grade >= 12.00;


-- --------------------------------------------------------
-- -----------------------  3SC006  -----------------------
-- --------------------------------------------------------
-- SELECT COMPARISON PREDICATOR (<>) (DATA TYPE DECIMAL)
-- UDB2 RESULT =  SUCC (3 SELECTED)

SELECT * FROM STAFF WHERE Grade <> 12;
SELECT * FROM STAFF WHERE Grade <> 12.0;
SELECT * FROM STAFF WHERE Grade <> 12.00;
SELECT * FROM STAFF WHERE Grade <> 12.01;

-- --------------------------------------------------------
-- -----------------------  3SC007  -----------------------
-- --------------------------------------------------------
-- SELECT "OR" COMPARISON PREDICATOR (DATA TYPE INT)
-- UDB2 RESULT = SUCC (3 SELECTED)

SELECT * FROM STAFF WHERE Grade < 12 OR Grade = 13;


-- --------------------------------------------------------
-- -----------------------  3SC008  -----------------------
-- --------------------------------------------------------
-- SELECT "OR NOT" COMPARISON PREDICATOR (DATA TYPE INT)
-- UDB2 RESULT = SUCC (5 SELECTED)

SELECT * FROM STAFF WHERE Grade < 13 OR NOT Grade = 12;

-- --------------------------------------------------------
-- -----------------------  3SC009  -----------------------
-- --------------------------------------------------------
-- SELECT "NOT" COMPARISON PREDICATOR (DATA TYPE INT)
-- UDB2 RESULT = SUCC (4 SELECTED)

SELECT * FROM STAFF WHERE NOT Grade < 12;



-- --------------------------------------------------------
-- -----------------  SEMATIC ERROR TEST  -----------------
-- --------------------------------------------------------
--
-- --------------------------------------------------------
-- -----------------------  3ST001  -----------------------
-- --------------------------------------------------------
-- PASS VARCHAR WHEN DECIMAL IS THE INTENDED PARAMETER
-- UDB2 RESULT = 42818

SELECT * FROM STAFF WHERE Grade = '10';


-- --------------------------------------------------------
-- -----------------------  3ST002  -----------------------
-- --------------------------------------------------------
-- SELECT WITH ORDER BY DECIMAL (0002)
-- UDB2 RESULT = SUCC

CREATE TABLE TMP1(NUM INT, C1 DECIMAL(5,2));
INSERT INTO TMP1 VALUES(1, 12.5);
INSERT INTO TMP1 VALUES(2, 10);
INSERT INTO TMP1 VALUES(3, 12.45);
INSERT INTO TMP1 VALUES(4, 111);
INSERT INTO TMP1 VALUES(5, 9.8);
SELECT * FROM TMP1;
SELECT NUM, C1 FROM TMP1 ORDER BY C1;
DROP TABLE TMP1;

-- --------------------------------------------------------
-- -----------------------  3ST003  -----------------------
-- --------------------------------------------------------
-- INSERT NULL VALUE INTO DECIMAL
-- UDB2 RESULT = SUCC

CREATE TABLE TMP1(NUM INT, C1 DECIMAL(5,2));
INSERT INTO TMP1 VALUES(1, 12.5);
INSERT INTO TMP1 VALUES(2, 10);
INSERT INTO TMP1 VALUES(3, 12.45);
INSERT INTO TMP1 VALUES(4, 111);
INSERT INTO TMP1 VALUES(5, 9.8);
INSERT INTO TMP1 VALUES(6, NULL);
INSERT INTO TMP1 VALUES(7, NULL);
SELECT * FROM TMP1;
SELECT NUM, C1 FROM TMP1 ORDER BY C1;
DROP TABLE TMP1;


-- --------------------------------------------------------
-- -----------------------  3ST004  -----------------------
-- --------------------------------------------------------
-- SELECT DISTINCT SYNTAX (0017)
-- UDB2 RESULT = SUCC

CREATE TABLE TMP1(NUM INT, C1 DECIMAL(5,3));
INSERT INTO TMP1 VALUES(1, 12.5);
INSERT INTO TMP1 VALUES(2, 12.50);
INSERT INTO TMP1 VALUES(3, 12.500);
INSERT INTO TMP1 VALUES(4, 12.45);
INSERT INTO TMP1 VALUES(5, 10);
INSERT INTO TMP1 VALUES(6, 10.0);
INSERT INTO TMP1 VALUES(7, 10.00);
INSERT INTO TMP1 VALUES(8, 10.000);
INSERT INTO TMP1 VALUES(9, 10.001);
SELECT * FROM TMP1;
SELECT DISTINCT NUM, C1 FROM TMP1 WHERE C1 = 12.5;
SELECT DISTINCT C1 FROM TMP1 WHERE C1 = 10;
DROP TABLE TMP1;

