-- This test segment deals with DDL statements executed in an
-- transactional context. The test plan is as follows:
-- A) Test creation of a table in isolation (wide table (multiple
-- pages)). Test commit and rollback.
-- B) Test deletion of a table in isolation (wide table (multiple
-- pages)). Test commit and rollback.
-- C) Test sequences of DDL statements using the same table name.
-- C.A) CREATE - DROP (rollback and commit)
-- C.B) DROP   - CREATE (rollback and commit, table 2 is smaller)
-- C.C) DROP   - CREATE (rollback and commit, table 2 is bigger)
-- D) Test creation of index. (many rows, multiple pages) Test commit
-- and rollback.
-- E) Test deletion of index. (many rows, multiple pages) Test commit
-- and rollback.
-- F) Test sequences of DDL statements using the same index name.
-- F.A) CREATE INDEX - DROP INDEX (rollback and commit)
-- F.B) DROP INDEX   - CREATE INDEX (rollback and commit)
-- G) Test the recovery code in this case (we 'crash' during commit)
-- Therefore we repeat steps A - F only the commit cases. We simulate
-- a crash after the shadow file has been written. Reconnecting to the
-- same database will start the recovery.
-- H) Test blastdb and blastdbplus in transaction mode
-- I) Test GRANT/REVOKE

-- let's clean up
blastdb;
-- let's create the sys tables physically
-- CREATE TABLE F (c int);
-- DROP TABLE F;
-- let's turn transaction mode on
autocommit off;
-- let's start with a wide table
CREATE TABLE foo (c INT, d CHAR(4096));
-- insert a few rows
INSERT INTO foo VALUES (1,'DDL In Transaction Test');
INSERT INTO foo VALUES (2,'DDL In Transaction Test');
INSERT INTO foo VALUES (3,'DDL In Transaction Test');
INSERT INTO foo VALUES (4,'DDL In Transaction Test');
INSERT INTO foo VALUES (5,'DDL In Transaction Test');
-- is it there?
LIST TABLES;
-- are the rows ok?
SELECT COUNT(*) FROM foo;
-- rollback
ROLLBACK;
-- should be gone again
LIST TABLES;
-- let's start with a wide table
CREATE TABLE foo (c INT, d CHAR(4096));
-- insert a few rows
INSERT INTO foo VALUES (1,'DDL In Transaction Test');
INSERT INTO foo VALUES (2,'DDL In Transaction Test');
INSERT INTO foo VALUES (3,'DDL In Transaction Test');
INSERT INTO foo VALUES (4,'DDL In Transaction Test');
INSERT INTO foo VALUES (5,'DDL In Transaction Test');
-- is it there?
LIST TABLES;
-- commit it
COMMIT;
-- is it still there?
LIST TABLES;
-- are the inserted rows ok?
SELECT count(*) FROM foo WHERE 1=1;
-- let's see how drop behaves in a transactional context
DROP TABLE foo;
-- is it really gone?
LIST TABLES;
-- I can't select from it, can I?
SELECT count(*) FROM foo WHERE 1=1;
-- I want it back, let's try
ROLLBACK;
-- is it here again?
LIST TABLES;
-- and the data should be ok too
SELECT count(*) FROM foo WHERE 1=1;
-- Now drop it again
DROP TABLE foo;
-- this time we say good buy for good
COMMIT;
-- is it still gone?
LIST TABLES;
-- I can't select from it, can I?
SELECT count(*) FROM foo WHERE 1=1;

-- Now we want to know, what happens
-- if we have a sequence of drop and
-- create statements.

-- let's start with a wide table
CREATE TABLE foo (c INT, d CHAR(4096));
-- insert a few rows
INSERT INTO foo VALUES (1,'DDL In Transaction Test');
INSERT INTO foo VALUES (2,'DDL In Transaction Test');
INSERT INTO foo VALUES (3,'DDL In Transaction Test');
INSERT INTO foo VALUES (4,'DDL In Transaction Test');
INSERT INTO foo VALUES (5,'DDL In Transaction Test');
-- is it there?
LIST TABLES;
-- Are the rows ok?
SELECT count(*) FROM foo WHERE 1=1;
-- let's drop it.
DROP TABLE foo;
-- Is it gone?
LIST TABLES;
-- I can't select from it, can I?
SELECT count(*) FROM foo WHERE 1=1;
-- Let's undo.
ROLLBACK;
-- Is it gone?
LIST TABLES;
-- I can't select from it, can I?
SELECT count(*) FROM foo WHERE 1=1;
-- let's start with a wide table
CREATE TABLE foo (c INT, d CHAR(4096));
-- insert a few rows
INSERT INTO foo VALUES (1,'DDL In Transaction Test');
INSERT INTO foo VALUES (2,'DDL In Transaction Test');
INSERT INTO foo VALUES (3,'DDL In Transaction Test');
INSERT INTO foo VALUES (4,'DDL In Transaction Test');
INSERT INTO foo VALUES (5,'DDL In Transaction Test');
-- I need it for real
COMMIT;
-- is it there?
LIST TABLES;
-- Are the rows ok?
SELECT count(*) FROM foo WHERE 1=1;
-- Now we drop it.
DROP TABLE foo;
-- is it gone?
LIST TABLES;
-- I can't select from it, can I?
SELECT count(*) FROM foo WHERE 1=1;
-- Let's create a table with the same name
-- and a different schema.
CREATE TABLE foo (c int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Are all the rows gone?
SELECT COUNT(*) FROM foo WHERE 1=1;
-- insert a few rows
INSERT INTO foo VALUES (1);
INSERT INTO foo VALUES (2);
INSERT INTO foo VALUES (3);
INSERT INTO foo VALUES (4);
-- Are they ok?
SELECT * FROM foo;
-- I liked the other table better
ROLLBACK;
-- is it back?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Are the five rows back?
SELECT COUNT(*) FROM foo WHERE 1=1;
-- Let's do that again.
DROP TABLE foo;
-- is it gone?
LIST TABLES;
-- I can't select from it, can I?
SELECT count(*) FROM foo WHERE 1=1;
-- Let's create a table with the same name
-- and a different schema.
CREATE TABLE foo (c int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Are all the rows gone?
SELECT COUNT(*) FROM foo WHERE 1=1;
-- insert a few rows
INSERT INTO foo VALUES (1);
INSERT INTO foo VALUES (2);
INSERT INTO foo VALUES (3);
INSERT INTO foo VALUES (4);
-- Are they ok?
SELECT * FROM foo;
-- This time we keep the new table.
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Are the four rows there?
SELECT * FROM foo;
-- now let's stress that recreation feature a little...
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int);
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42);
COMMIT;
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int, c9 int);
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int, c9 int, c10 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int, c9 int);
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int);
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int);
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int);
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int);
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42);
ROLLBACK;
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int, c9 int);
ROLLBACK;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- More columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int, c9 int, c10 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int, c9 int);
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int, c8 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int, c7 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int, c6 int);
ROLLBACK;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int, c5 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int, c4 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int, c3 int);
ROLLBACK;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int, c2 int);
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42,42);
-- Is the row there?
SELECT * FROM foo;
DROP TABLE foo;
-- Fewer columns this time
CREATE TABLE foo (c1 int);
COMMIT;
-- is it there?
LIST TABLES;
-- What about the columns?
LIST COLUMNS foo;
-- Insert a row
INSERT INTO foo VALUES (42);
-- Is the row there?
SELECT * FROM foo;
COMMIT;
-- Now lets create many tables and see how that goes.
CREATE TABLE foo1 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo2 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo3 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo4 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo5 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo6 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo7 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo8 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo9 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo0 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo01 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo02 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo03 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo04 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo05 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo06 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo07 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo08 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo09 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo00 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo11 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo12 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo13 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo14 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo15 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo16 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo17 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo18 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo19 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo10 (c int, d int, e int, f int, g int, h int, i int, j int);
LIST TABLES;
ROLLBACK;
LIST TABLES;
CREATE TABLE foo1 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo2 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo3 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo4 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo5 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo6 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo7 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo8 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo9 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo0 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo01 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo02 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo03 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo04 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo05 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo06 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo07 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo08 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo09 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo00 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo11 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo12 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo13 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo14 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo15 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo16 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo17 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo18 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo19 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo10 (c int, d int, e int, f int, g int, h int, i int, j int);
LIST TABLES;
COMMIT;
LIST TABLES;
DROP TABLE foo11;
DROP TABLE foo12;
DROP TABLE foo13;
DROP TABLE foo14;
DROP TABLE foo15;
DROP TABLE foo16;
DROP TABLE foo17;
DROP TABLE foo18;
DROP TABLE foo19;
DROP TABLE foo10;
CREATE TABLE foo21 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo22 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo23 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo24 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo25 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo26 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo27 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo28 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo29 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo20 (c int, d int, e int, f int, g int, h int, i int, j int);
LIST TABLES;
ROLLBACK;
LIST TABLES;
DROP TABLE foo11;
DROP TABLE foo12;
DROP TABLE foo13;
DROP TABLE foo14;
DROP TABLE foo15;
DROP TABLE foo16;
DROP TABLE foo17;
DROP TABLE foo18;
DROP TABLE foo19;
DROP TABLE foo10;
CREATE TABLE foo21 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo22 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo23 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo24 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo25 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo26 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo27 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo28 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo29 (c int, d int, e int, f int, g int, h int, i int, j int);
CREATE TABLE foo20 (c int, d int, e int, f int, g int, h int, i int, j int);
LIST TABLES;
COMMIT;
LIST TABLES;
DROP TABLE foo01;
DROP TABLE foo02;
DROP TABLE foo03;
DROP TABLE foo04;
DROP TABLE foo05;
DROP TABLE foo06;
DROP TABLE foo07;
DROP TABLE foo08;
DROP TABLE foo09;
DROP TABLE foo00;
DROP TABLE foo21;
DROP TABLE foo22;
DROP TABLE foo23;
DROP TABLE foo24;
DROP TABLE foo25;
DROP TABLE foo26;
DROP TABLE foo27;
DROP TABLE foo28;
DROP TABLE foo29;
DROP TABLE foo20;
LIST TABLES;
ROLLBACK;
LIST TABLES;
DROP TABLE foo01;
DROP TABLE foo02;
DROP TABLE foo03;
DROP TABLE foo04;
DROP TABLE foo05;
DROP TABLE foo06;
DROP TABLE foo07;
DROP TABLE foo08;
DROP TABLE foo09;
DROP TABLE foo00;
DROP TABLE foo21;
DROP TABLE foo22;
DROP TABLE foo23;
DROP TABLE foo24;
DROP TABLE foo25;
DROP TABLE foo26;
DROP TABLE foo27;
DROP TABLE foo28;
DROP TABLE foo29;
DROP TABLE foo20;
LIST TABLES;
COMMIT;
LIST TABLES;
-- No let's see how the create/drop index work
-- Let's use a table, which has enough entries 
-- to have two pages for the index.
DROP TABLE foo;
CREATE TABLE foo (c int, d int);
INSERT INTO foo VALUES (1,0);
INSERT INTO foo VALUES (2,0);
INSERT INTO foo VALUES (3,0);
INSERT INTO foo VALUES (4,0);
INSERT INTO foo VALUES (5,1);
INSERT INTO foo VALUES (6,1);
INSERT INTO foo VALUES (7,1);
INSERT INTO foo VALUES (8,1);
INSERT INTO foo VALUES (9,1);
INSERT INTO foo VALUES (10,2);
INSERT INTO foo VALUES (11,2);
INSERT INTO foo VALUES (12,2);
INSERT INTO foo VALUES (13,2);
INSERT INTO foo VALUES (14,2);
INSERT INTO foo VALUES (15,3);
INSERT INTO foo VALUES (16,3);
INSERT INTO foo VALUES (17,3);
INSERT INTO foo VALUES (18,3);
INSERT INTO foo VALUES (19,3);
INSERT INTO foo VALUES (20,4);
INSERT INTO foo VALUES (21,4);
INSERT INTO foo VALUES (22,4);
INSERT INTO foo VALUES (23,4);
INSERT INTO foo VALUES (24,4);
INSERT INTO foo VALUES (25,5);
INSERT INTO foo VALUES (26,5);
INSERT INTO foo VALUES (27,5);
INSERT INTO foo VALUES (28,5);
INSERT INTO foo VALUES (29,5);
INSERT INTO foo VALUES (30,6);
INSERT INTO foo VALUES (31,6);
INSERT INTO foo VALUES (32,6);
INSERT INTO foo VALUES (33,6);
INSERT INTO foo VALUES (34,6);
INSERT INTO foo VALUES (35,7);
INSERT INTO foo VALUES (36,7);
INSERT INTO foo VALUES (37,7);
INSERT INTO foo VALUES (38,7);
INSERT INTO foo VALUES (39,7);
INSERT INTO foo VALUES (40,8);
INSERT INTO foo VALUES (41,8);
INSERT INTO foo VALUES (42,8);
INSERT INTO foo VALUES (43,8);
INSERT INTO foo VALUES (44,8);
INSERT INTO foo VALUES (45,9);
INSERT INTO foo VALUES (46,9);
INSERT INTO foo VALUES (47,9);
INSERT INTO foo VALUES (48,9);
INSERT INTO foo VALUES (49,9);
INSERT INTO foo VALUES (50,10);
INSERT INTO foo VALUES (51,10);
INSERT INTO foo VALUES (52,10);
INSERT INTO foo VALUES (53,10);
INSERT INTO foo VALUES (54,10);
INSERT INTO foo VALUES (55,11);
INSERT INTO foo VALUES (56,11);
INSERT INTO foo VALUES (57,11);
INSERT INTO foo VALUES (58,11);
INSERT INTO foo VALUES (59,11);
INSERT INTO foo VALUES (60,12);
INSERT INTO foo VALUES (61,12);
INSERT INTO foo VALUES (62,12);
INSERT INTO foo VALUES (63,12);
INSERT INTO foo VALUES (64,12);
INSERT INTO foo VALUES (65,13);
INSERT INTO foo VALUES (66,13);
INSERT INTO foo VALUES (67,13);
INSERT INTO foo VALUES (68,13);
INSERT INTO foo VALUES (69,13);
INSERT INTO foo VALUES (70,14);
INSERT INTO foo VALUES (71,14);
INSERT INTO foo VALUES (72,14);
INSERT INTO foo VALUES (73,14);
INSERT INTO foo VALUES (74,14);
INSERT INTO foo VALUES (75,15);
INSERT INTO foo VALUES (76,15);
INSERT INTO foo VALUES (77,15);
INSERT INTO foo VALUES (78,15);
INSERT INTO foo VALUES (79,15);
INSERT INTO foo VALUES (80,16);
INSERT INTO foo VALUES (81,16);
INSERT INTO foo VALUES (82,16);
INSERT INTO foo VALUES (83,16);
INSERT INTO foo VALUES (84,16);
INSERT INTO foo VALUES (85,17);
INSERT INTO foo VALUES (86,17);
INSERT INTO foo VALUES (87,17);
INSERT INTO foo VALUES (88,17);
INSERT INTO foo VALUES (89,17);
INSERT INTO foo VALUES (90,18);
INSERT INTO foo VALUES (91,18);
INSERT INTO foo VALUES (92,18);
INSERT INTO foo VALUES (93,18);
INSERT INTO foo VALUES (94,18);
INSERT INTO foo VALUES (95,19);
INSERT INTO foo VALUES (96,19);
INSERT INTO foo VALUES (97,19);
INSERT INTO foo VALUES (98,19);
INSERT INTO foo VALUES (99,19);
INSERT INTO foo VALUES (100,20);
INSERT INTO foo VALUES (101,20);
INSERT INTO foo VALUES (102,20);
INSERT INTO foo VALUES (103,20);
INSERT INTO foo VALUES (104,20);
INSERT INTO foo VALUES (105,21);
INSERT INTO foo VALUES (106,21);
INSERT INTO foo VALUES (107,21);
INSERT INTO foo VALUES (108,21);
INSERT INTO foo VALUES (109,21);
INSERT INTO foo VALUES (110,22);
INSERT INTO foo VALUES (111,22);
INSERT INTO foo VALUES (112,22);
INSERT INTO foo VALUES (113,22);
INSERT INTO foo VALUES (114,22);
INSERT INTO foo VALUES (115,23);
INSERT INTO foo VALUES (116,23);
INSERT INTO foo VALUES (117,23);
INSERT INTO foo VALUES (118,23);
INSERT INTO foo VALUES (119,23);
INSERT INTO foo VALUES (120,24);
INSERT INTO foo VALUES (121,24);
INSERT INTO foo VALUES (122,24);
INSERT INTO foo VALUES (123,24);
INSERT INTO foo VALUES (124,24);
INSERT INTO foo VALUES (125,25);
INSERT INTO foo VALUES (126,25);
INSERT INTO foo VALUES (127,25);
INSERT INTO foo VALUES (128,25);
INSERT INTO foo VALUES (129,25);
INSERT INTO foo VALUES (130,26);
INSERT INTO foo VALUES (131,26);
INSERT INTO foo VALUES (132,26);
INSERT INTO foo VALUES (133,26);
INSERT INTO foo VALUES (134,26);
INSERT INTO foo VALUES (135,27);
INSERT INTO foo VALUES (136,27);
INSERT INTO foo VALUES (137,27);
INSERT INTO foo VALUES (138,27);
INSERT INTO foo VALUES (139,27);
INSERT INTO foo VALUES (140,28);
INSERT INTO foo VALUES (141,28);
INSERT INTO foo VALUES (142,28);
INSERT INTO foo VALUES (143,28);
INSERT INTO foo VALUES (144,28);
INSERT INTO foo VALUES (145,29);
INSERT INTO foo VALUES (146,29);
INSERT INTO foo VALUES (147,29);
INSERT INTO foo VALUES (148,29);
INSERT INTO foo VALUES (149,29);
INSERT INTO foo VALUES (150,30);
INSERT INTO foo VALUES (151,30);
INSERT INTO foo VALUES (152,30);
INSERT INTO foo VALUES (153,30);
INSERT INTO foo VALUES (154,30);
INSERT INTO foo VALUES (155,31);
INSERT INTO foo VALUES (156,31);
INSERT INTO foo VALUES (157,31);
INSERT INTO foo VALUES (158,31);
INSERT INTO foo VALUES (159,31);
INSERT INTO foo VALUES (160,32);
INSERT INTO foo VALUES (161,32);
INSERT INTO foo VALUES (162,32);
INSERT INTO foo VALUES (163,32);
INSERT INTO foo VALUES (164,32);
INSERT INTO foo VALUES (165,33);
INSERT INTO foo VALUES (166,33);
INSERT INTO foo VALUES (167,33);
INSERT INTO foo VALUES (168,33);
INSERT INTO foo VALUES (169,33);
INSERT INTO foo VALUES (170,34);
INSERT INTO foo VALUES (171,34);
INSERT INTO foo VALUES (172,34);
INSERT INTO foo VALUES (173,34);
INSERT INTO foo VALUES (174,34);
INSERT INTO foo VALUES (175,35);
INSERT INTO foo VALUES (176,35);
INSERT INTO foo VALUES (177,35);
INSERT INTO foo VALUES (178,35);
INSERT INTO foo VALUES (179,35);
INSERT INTO foo VALUES (180,36);
INSERT INTO foo VALUES (181,36);
INSERT INTO foo VALUES (182,36);
INSERT INTO foo VALUES (183,36);
INSERT INTO foo VALUES (184,36);
INSERT INTO foo VALUES (185,37);
INSERT INTO foo VALUES (186,37);
INSERT INTO foo VALUES (187,37);
INSERT INTO foo VALUES (188,37);
INSERT INTO foo VALUES (189,37);
INSERT INTO foo VALUES (190,38);
INSERT INTO foo VALUES (191,38);
INSERT INTO foo VALUES (192,38);
INSERT INTO foo VALUES (193,38);
INSERT INTO foo VALUES (194,38);
INSERT INTO foo VALUES (195,39);
INSERT INTO foo VALUES (196,39);
INSERT INTO foo VALUES (197,39);
INSERT INTO foo VALUES (198,39);
INSERT INTO foo VALUES (199,39);
INSERT INTO foo VALUES (200,40);
INSERT INTO foo VALUES (201,40);
INSERT INTO foo VALUES (202,40);
INSERT INTO foo VALUES (203,40);
INSERT INTO foo VALUES (204,40);
INSERT INTO foo VALUES (205,41);
INSERT INTO foo VALUES (206,41);
INSERT INTO foo VALUES (207,41);
INSERT INTO foo VALUES (208,41);
INSERT INTO foo VALUES (209,41);
INSERT INTO foo VALUES (210,42);
INSERT INTO foo VALUES (211,42);
INSERT INTO foo VALUES (212,42);
INSERT INTO foo VALUES (213,42);
INSERT INTO foo VALUES (214,42);
INSERT INTO foo VALUES (215,43);
INSERT INTO foo VALUES (216,43);
INSERT INTO foo VALUES (217,43);
INSERT INTO foo VALUES (218,43);
INSERT INTO foo VALUES (219,43);
INSERT INTO foo VALUES (220,44);
INSERT INTO foo VALUES (221,44);
INSERT INTO foo VALUES (222,44);
INSERT INTO foo VALUES (223,44);
INSERT INTO foo VALUES (224,44);
INSERT INTO foo VALUES (225,45);
INSERT INTO foo VALUES (226,45);
INSERT INTO foo VALUES (227,45);
INSERT INTO foo VALUES (228,45);
INSERT INTO foo VALUES (229,45);
INSERT INTO foo VALUES (230,46);
INSERT INTO foo VALUES (231,46);
INSERT INTO foo VALUES (232,46);
INSERT INTO foo VALUES (233,46);
INSERT INTO foo VALUES (234,46);
INSERT INTO foo VALUES (235,47);
INSERT INTO foo VALUES (236,47);
INSERT INTO foo VALUES (237,47);
INSERT INTO foo VALUES (238,47);
INSERT INTO foo VALUES (239,47);
INSERT INTO foo VALUES (240,48);
INSERT INTO foo VALUES (241,48);
INSERT INTO foo VALUES (242,48);
INSERT INTO foo VALUES (243,48);
INSERT INTO foo VALUES (244,48);
INSERT INTO foo VALUES (245,49);
INSERT INTO foo VALUES (246,49);
INSERT INTO foo VALUES (247,49);
INSERT INTO foo VALUES (248,49);
INSERT INTO foo VALUES (249,49);
INSERT INTO foo VALUES (250,50);
INSERT INTO foo VALUES (251,50);
INSERT INTO foo VALUES (252,50);
INSERT INTO foo VALUES (253,50);
INSERT INTO foo VALUES (254,50);
INSERT INTO foo VALUES (255,51);
INSERT INTO foo VALUES (256,51);
INSERT INTO foo VALUES (257,51);
INSERT INTO foo VALUES (258,51);
INSERT INTO foo VALUES (259,51);
INSERT INTO foo VALUES (260,52);
INSERT INTO foo VALUES (261,52);
INSERT INTO foo VALUES (262,52);
INSERT INTO foo VALUES (263,52);
INSERT INTO foo VALUES (264,52);
INSERT INTO foo VALUES (265,53);
INSERT INTO foo VALUES (266,53);
INSERT INTO foo VALUES (267,53);
INSERT INTO foo VALUES (268,53);
INSERT INTO foo VALUES (269,53);
INSERT INTO foo VALUES (270,54);
INSERT INTO foo VALUES (271,54);
INSERT INTO foo VALUES (272,54);
INSERT INTO foo VALUES (273,54);
INSERT INTO foo VALUES (274,54);
INSERT INTO foo VALUES (275,55);
INSERT INTO foo VALUES (276,55);
INSERT INTO foo VALUES (277,55);
INSERT INTO foo VALUES (278,55);
INSERT INTO foo VALUES (279,55);
INSERT INTO foo VALUES (280,56);
INSERT INTO foo VALUES (281,56);
INSERT INTO foo VALUES (282,56);
INSERT INTO foo VALUES (283,56);
INSERT INTO foo VALUES (284,56);
INSERT INTO foo VALUES (285,57);
INSERT INTO foo VALUES (286,57);
INSERT INTO foo VALUES (287,57);
INSERT INTO foo VALUES (288,57);
INSERT INTO foo VALUES (289,57);
INSERT INTO foo VALUES (290,58);
INSERT INTO foo VALUES (291,58);
INSERT INTO foo VALUES (292,58);
INSERT INTO foo VALUES (293,58);
INSERT INTO foo VALUES (294,58);
INSERT INTO foo VALUES (295,59);
INSERT INTO foo VALUES (296,59);
INSERT INTO foo VALUES (297,59);
INSERT INTO foo VALUES (298,59);
INSERT INTO foo VALUES (299,59);
INSERT INTO foo VALUES (300,60);
COMMIT;
-- Phew. Ok, now let's create the index
CREATE INDEX test ON foo (c);
-- Is it there?
LIST INDEX foo;
-- Let's use it!
SELECT COUNT(d) FROM foo WHERE c >=260 GROUP BY d;
-- Let's insert another row
INSERT INTO foo VALUES (301,61);
-- Is it there? Did the index get it?
SELECT COUNT(d) FROM foo WHERE c >=260 GROUP BY d;
-- I don't want an index. It's to much of a rush.
ROLLBACK;
-- Is it gone?
LIST INDEX foo;
-- Let's recreate it.
CREATE INDEX test ON foo (c);
-- Is it back?
LIST INDEX foo;
-- Let's use it!
SELECT COUNT(d) FROM foo WHERE c >=260 GROUP BY d;
-- Let's insert another row
INSERT INTO foo VALUES (301,61);
-- Is it there? Did the index get it?
SELECT COUNT(d) FROM foo WHERE c >=260 GROUP BY d;
-- Fine. Let's commit it.
COMMIT;
-- Is it still there?
LIST INDEX foo;
-- Let's use it!
SELECT COUNT(d) FROM foo WHERE c >=260 GROUP BY d;
-- Let's insert another row
INSERT INTO foo VALUES (301,61);
-- Is it there? Did the index get it?
SELECT COUNT(d) FROM foo WHERE c >=260 GROUP BY d;
-- Now we try to drop the index.
DROP INDEX test;
-- Is it gone?
LIST INDEX foo;
-- I want it back.
ROLLBACK;
-- Is it back?
LIST INDEX foo;
-- Let's use it!
SELECT COUNT(d) FROM foo WHERE c >=260 GROUP BY d;
-- Let's insert another row
INSERT INTO foo VALUES (302,61);
-- Is it there? Did the index get it?
SELECT COUNT(d) FROM foo WHERE c >=260 GROUP BY d;
-- Now drop it for good
DROP INDEX test;
COMMIT;
-- Is it gone?
LIST INDEX foo;
-- Let's drop the table for good
DROP TABLE foo;
COMMIT;

-- Now we want to know, what happens
-- if we have a sequence of drop and
-- create statements.

-- Now it's time to check GRANT/REVOKE
-- Let's reconnect first
CONNECT TO foo USER user USING passwd;
-- Let's turn autocommit off again
AUTOCOMMIT OFF;
-- Shouldn't be there
SELECT username, grantorname, privileges from "DB2eSYSUSERS";
-- Now we grant ourselves the right to encrypt
GRANT ENCRYPT ON DATABASE TO "user" USING "passwd" NEW "pwd";
-- We should be able to see that in the SYSUSERS table
SELECT username, grantorname, privileges from "DB2eSYSUSERS";
-- Let's create an encrypted table
CREATE TABLE foo (a INT, b INT) WITH ENCRYPTION;
-- Is it there?
LIST TABLES;
-- Let's also make an entry
INSERT INTO foo VALUES (42,42);
-- Let's see it
SELECT * FROM foo;
-- Now let's rollback all that
ROLLBACK;
-- Is the table gone?
LIST TABLES;
-- What about SYSUSERS?
SELECT username, grantorname, privileges from "DB2eSYSUSERS";
-- I can't create an encrypted table, can I?
CREATE TABLE foo (c INT) WITH ENCRYPTION;

-- Now we do that again and COMMIT this time
-- We grant ourselves the right to encrypt
GRANT ENCRYPT ON DATABASE TO "user" USING "passwd" NEW "pwd";
-- We should be able to see that in the SYSUSERS table
SELECT username, grantorname, privileges from "DB2eSYSUSERS";
-- Let's create an encrypted table
CREATE TABLE foo (a INT, b INT) WITH ENCRYPTION;
-- Is it there?
LIST TABLES;
-- Let's also make an entry
INSERT INTO foo VALUES (42,42);
-- Let's see it
SELECT * FROM foo;
-- Now let's commit
COMMIT;
-- Is the table still there?
LIST TABLES;
-- What about SYSUSERS?
SELECT username, grantorname, privileges from "DB2eSYSUSERS";
-- Now we try to REVOKE
REVOKE ENCRYPT ON DATABASE FROM "user";
-- Is user gone?
SELECT username, grantorname, privileges from "DB2eSYSUSERS";
-- I can't I drop the table, can I?
DROP TABLE foo;
-- Let's rollback, so we can delete the table
ROLLBACK;
-- Now I can drop the table, right?
DROP TABLE foo;
-- And revoke the rights
REVOKE ENCRYPT ON DATABASE FROM "user";
-- So let's commit the changes
COMMIT;

-- Let's try the explain statment next
-- Let's prepare a table for that
CREATE TABLE foo (c INT, d INT);
-- Now we execute an explain statement
EXPLAIN SET QUERYNO = 1 FOR SELECT COUNT(d),d FROM foo WHERE c>d GROUP BY d;
-- Should have created the DB2ePLANTABLE
LIST TABLES;
-- Let's have a look at our new entry
SELECT * FROM "DB2ePLANTABLE";
-- Let's uncreate it...
ROLLBACK;
-- Is it gone?
LIST TABLES;
-- I can't select from it, can I?
SELECT * FROM "DB2ePLANTABLE";
-- Let's do that again
EXPLAIN SET QUERYNO = 1 FOR SELECT COUNT(d),d FROM foo WHERE c>d GROUP BY d;
-- Should have created the DB2ePLANTABLE
LIST TABLES;
-- Let's have a look at our new entry
SELECT * FROM "DB2ePLANTABLE";
-- This time we commit it, though...
COMMIT;
-- Is it there?
LIST TABLES;
-- Let's see the entry
SELECT * FROM "DB2ePLANTABLE";

-- Let's test the multiple stmt handle thing
autocommit on;
blastdb;
create table t1 (a int, b int);
insert into t1 values (3, 3);
insert into t1 values (4, 4);
insert into t1 values (5, 5);
create index idx on t1(b);
create stmt handle :1;

-- impact on stmt handles by creating indexes
-- TMD will be updated by creating indexes, and rolling back the changes will likely affect various statement handles.
-- test 1: rollback creating an index
prepare :1 select * from t1 where b > 0;
autocommit off;
create index idx1 on t1(a);

execute :1;
fetch :1;
rollback;
-- fetch should fail?
fetch :1;
-- does execute fail?
execute :1;
fetch :1;

-- test 2: rollback creating an index
autocommit off;
create index idx1 on t1(a);

prepare :1 select * from t1 where a > 0;
execute :1;
fetch :1;
rollback;
-- fetch should fail?
fetch :1;
-- does execute fail?
execute :1;
fetch :1;

-- test 3: commit creating an index
autocommit off;
prepare :1 select * from t1 where b> 0;
create index idx1 on t1(a);

execute :1;
fetch :1;
commit;
-- fetch should fail?
fetch :1;
-- does execute fail?
execute :1;
fetch :1;

drop index idx1;
commit;

-- test 4: commit creating an index
autocommit off;
create index idx1 on t1(a);

prepare :1 select * from t1 where a > 0;
execute :1;
fetch :1;
commit;
-- fetch should fail?
fetch :1;
-- does execute fail?
execute :1;
fetch :1;

drop index idx1;
commit;

-------------------------------------------------------------------

-- impact on stmt handles by dropping index
-- test 5: rollback dropping an index
prepare :1 select * from t1 where b > 0;
autocommit off;

drop index idx;
-- re-prepare the query?
execute :1;

rollback;

-- test 6: rollback dropping an index
prepare :1 select * from t1 where b > 0;
autocommit off;

execute :1;
fetch :1;

drop index idx;

-- fail?
fetch :1;

-- re-prepare the query?
execute :1;

rollback;

-- test 7: rollback dropping an index that the query doesn't use
prepare :1 select * from t1 where a > 0;
autocommit off;

drop index idx;
-- re-prepare the query?
execute :1;

rollback;

-- test 8: rollback dropping an index that the query doesn't use
prepare :1 select * from t1 where a > 0;
autocommit off;

execute :1;
fetch :1;

drop index idx;

-- fail?
fetch :1;

-- re-prepare the query?
execute :1;

fetch :1;

rollback;

-------------------------------------------------------------------

-- impact on stmt handles by creating tables

-- test 20: rollback a newly created table
autocommit off;

create table s2 (a int, b int);
insert into s2 values (1, 2);
insert into s2 values (2, 3);
insert into s2 values (3, 4);

prepare :1 select * from s2 where b > 0;
execute :1;

fetch :1;

ROLLBACK;

-- ??
fetch :1;

-- syntax error?
execute :1;

-- test 21: drop an existing table, create a new table w/ the same name and rollback
create table s2 (a int, b int, c int);
insert into s2 values (20, 1, 2);
insert into s2 values (30, 2, 3);
insert into s2 values (40, 3, 4);
COMMIT;

autocommit off;

drop table s2;

create table s2 (a int, b int);
insert into s2 values (1, 2);
insert into s2 values (2, 3);
insert into s2 values (3, 4);

prepare :1 select * from s2 where b > 0;
execute :1;

fetch :1;

ROLLBACK;

-- ??
fetch :1;

-- syntax error?
-- which s2?
execute :1;

select * from s2;

drop table s2;

COMMIT;

-- test 22:
create table s2 (a int, b int, c int);
insert into s2 values (20, 1, 2);
insert into s2 values (30, 2, 3);
insert into s2 values (40, 3, 4);
COMMIT;

autocommit off;

-- should fail
create table s2 (a int, b int);

select * from s2;

ROLLBACK;

drop table s2;
COMMIT;


-- test 23: create a table w/ the same name
create table s2 (a int, b int, c int);
insert into s2 values (20, 1, 2);
insert into s2 values (30, 2, 3);
insert into s2 values (40, 3, 4);
COMMIT;

autocommit off;

-- should fail
create table s2 (a int, b int);

-- should see 3 columns
select * from s2;

ROLLBACK;

drop table s2;
COMMIT;

-- dropping tables

-- test 24: drop a non-existing table
autocommit off;

-- should fail
drop table s3;

ROLLBACK;

-- succeeded
create table s3 (a int);
insert into s3 values (1);
select * from s3;

ROLLBACK;

COMMIT;


-- test 25: dropping a table will invalidate a select cursor; rollback the drop
autocommit off;

create table s3 (a int);
insert into s3 values (1);
insert into s3 values (2);
insert into s3 values (3);
insert into s3 values (4);
insert into s3 values (5);
select * from s3;

COMMIT;

prepare :1 select * from s3;
execute :1;
fetch :1;
fetch :1;

-- should succeed
drop table s3;

-- should fail
fetch :1;

-- should fail
execute :1;

ROLLBACK;

-- should fail
fetch :1;

-- should succeed
execute :1;
fetch :1;

drop table s3;

COMMIT;

-- test 26: dropping an existing table will invalidate select stmt handle
autocommit off;

create table s3 (a int);
insert into s3 values (1);
insert into s3 values (2);
insert into s3 values (3);
insert into s3 values (4);
insert into s3 values (5);
select * from s3;

COMMIT;

prepare :1 select * from s3;
execute :1;
fetch :1;
fetch :1;

-- should
drop table s3;

-- should fail
fetch :1;

-- should fail
execute :1;

COMMIT;

-- should fail
fetch :1;

-- should fail
execute :1;

-- should succeed in re-using the statement handle
prepare :1 select tname from "DB2eSYSTABLES";
execute :1;
fetch :1;

COMMIT;

-- test: cannot create newly created tables or drop newly dropped tables
autocommit off;
create table t (a int);
insert into t values (1);

-- should expect an error
create table t (b int, c int);

commit;

-- should expect an error
create table t (d int, e decimal(10,2)); 

drop table t;

-- should expect an error
drop table t;

commit;

-- should expect an error
drop table t;

commit work;

-- create index on newly created table
create table t (a int)
insert into t values (1);
insert into t values (2);

create index idxi on t(a);

insert into t values (3);

select * from t where a = 2;

-- do an explain?

commit;

-- can we drop the index?

select * from t where a = 1;

drop index idx1;

select * from t where a = 3;

-- do an explain?

commit;

drop table t;

commit;

-- We're done. Let's turn autocommit back on.
autocommit on;
-- And finally, let's clean up.
blastdb;
-- Over and out. 