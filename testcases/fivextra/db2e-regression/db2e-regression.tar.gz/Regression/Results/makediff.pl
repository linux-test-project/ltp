#!/usr/bin/env perl

$RESULTMAX = 12;
$debug = 0;

sub broken_platform {
  local($base, $platform, $dir) = @_;
  # test if all executables are there
  local(%res) = ();
  # test if all result files are there and no diffs
  local($regdir) = "$base";
  foreach $t (0..$RESULTMAX) {
    local($b) = sprintf("Res%03d", $t);
    local($f) = "$b.$platform";

    if($debug){print "|--> looking for : $base/$f\n";}
    if (-f "$base/$f") {

      # prefer more specific db2e result file
      local($r) = "$b.$platform.db2e";
      $r = "$b.db2e" if !(-f "$regdir/$r");

      if($debug){print "|--> (X) diff -q -b $base/$f $regdir/$r >/dev/null\n";}
      local($diff) = system "diff -q -b $base/$f $regdir/$r";
#      local($diff) = 0;system "windiff $base/$f $regdir/$r -Sdx null";open(NL, "null");while(<NL>){if($_ =~ /different/){$diff=1;}};close(NL);system "rm null";
      if($debug){if($diff){print "|--> different\n";}else{print "|--> identical\n";}}
      if ($diff) {
	$res{"$platform"} .= "\t$f ($r) different. !=\n";
      }else{
	$res{"$platform"} .= "\t$f ($r) identical.\n";
      }

    } else {
      $res{"$platform"} .= "\tfile missing: $f\n";
    }
  }
  # test the result files
  return %res;
}

print "***************\n";
print "* makediff.pl *\n";
print "***************\n";

if (!$ARGV[0]){die "Please specify the result directory (eg 20021001_0100/Regression/Results) as first parameter.\n";}
$base = $ARGV[0];
if (!$ARGV[1]){die "Please specify the platform as second parameter (eg NT, NTO, LN, EP6, EP7, PALM, CE, NTU, ...).\n";}
$pf = $ARGV[1];

%res = (&broken_platform($base, $pf, "."));

foreach $k (sort keys %res) {
#  print "$k\n$res{$k}\n";
  if($debug){print "opening >$base/DiffReport.$k\n"}
  open(DST, ">$base/DiffReport.$k");
  print(DST "$k regression\n$res{$k}");
  close(DST);
}
