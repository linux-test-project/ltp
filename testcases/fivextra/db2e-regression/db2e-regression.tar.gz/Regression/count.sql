create table people (name varchar(20), age int);
insert into people values ('smith', 20);
insert into people values ('rosetta', 21);
insert into people values ('rosetta', 22);
create stmt handle :1;

prepare :1 select count(*) from people where name = ?;
bind :1 1 herbert;
execute :1;
fetch :1;
bind :1 1 smith; 
execute :1;
fetch :1;   

prepare :1 select count(*) from people where name = ? group by name;
bind :1 1 herbert;
execute :1;
fetch :1;
bind :1 1 smith; 
execute :1;
fetch :1; 

prepare :1 select count(*) from people where name = ? group by age;
bind :1 1 herbert;
execute :1;
fetch :1;
bind :1 1 smith; 
execute :1;
fetch :1; 

prepare :1 select sum(age), max(age), min(age), avg(age) from people where name = ?;
bind :1 1 herbert;
execute :1;
fetch :1;
bind :1 1 smith;
execute :1;
fetch :1;

insert into people values ('smith', 23);
bind :1 1 herbert;
execute :1;
fetch :1;
bind :1 1 smith;
execute :1;
fetch :1;
bind :1 1 rosetta;
execute :1;
fetch :1;

drop stmt handle :1;
drop table people;

CREATE TABLE TIME_RPT_SYNC(
LOG_TYPE_CD          CHARacter(18) NOT NULL ,
SYNC_SRC             CHARacter(6) NOT NULL ,
CRE_TIMESTAMP        TIMESTAMP NOT NULL DEFAULT CURRENT TIMESTAMP,
EMP_ID               CHARacter(5) NOT NULL,
TIME_RPT_DATE        DATE NOT NULL,
DATE_TYPE_CD         CHARacter(1) NOT NULL,
EMP_DATE_SEQ_NMBR    DECimal(2, 0) NOT NULL,
TIME_FUNC_CD         CHARacter(3) NOT NULL,
ACTVTY_CD            CHARacter(3) NOT NULL,
REG_HRS              DECimal(5, 2) NOT NULL DEFAULT 0,
OT_HRS               DECimal(4, 2) NOT NULL DEFAULT 0,
CASE_CNT             SMALLINT NOT NULL DEFAULT 0,
APPRV_IND            CHARacter(1),
UNIT_ID              CHARacter(3) ,
TARGET_TYPE_CD       CHARacter(1) NOT NULL,
TARGET_ID            CHARacter(9) NOT NULL
);


CREATE INDEX TIME_RPT_SYNC_IF3 ON TIME_RPT_SYNC(LOG_TYPE_CD, SYNC_SRC,
CRE_TIMESTAMP, EMP_ID, TIME_RPT_DATE, DATE_TYPE_CD);

insert into time_rpt_sync values('TIME', 'TEST',  '2003-03-03-10.23.15.000017', '60926',  '2003-03-01','D', 12, 'abc', 'abc', 5.2, 4.2, 10, 'a','bbb','c', '123456789');

insert into time_rpt_sync values('TIME', 'TEST',  '2003-03-03-11.23.15.000017', '60926',  '2003-03-02','D', 12, 'abc', 'abc', 5.2, 4.2, 10, 'a','bbb','c', '123456789');

insert into time_rpt_sync values('TIME', 'TEST',  '2003-03-03-11.23.15.000017', '60926',  '2003-03-02','D', 13, 'abc', 'abc', 5.2, 4.2, 10, 'a','bbb','c', '123456789');

insert into time_rpt_sync values('TIME', 'TEST',  '2003-03-03-10.23.15.000017', '60926',  '2003-03-01','D', 14, 'abc', 'abc', 5.2, 4.2, 10, 'a','bbb','c', '123456789');

select * from time_rpt_sync;
delete from time_rpt_sync where log_type_cd = 'TIME' and sync_src
= 'TEST'and cre_timestamp = '2003-03-03-10.23.15.000017';
select * from time_rpt_sync;

drop table time_rpt_sync;

