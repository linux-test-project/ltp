-- ----------------- FILE: INSER01.SQL -------------------
-- -                                                      - 
-- -          Validates INSERT statement	          -
-- -                                                      -
-- --------------------------------------------------------
--

-- --------------------------------------------------------
-- This set of test cases validates more complex inserts.
-- It tries also to validate some overflow or underflow cases
-- --------------------------------------------------------
-- --------------------------------------------------------
-- Delete tables
-- --------------------------------------------------------
DROP TABLE tA;

-- --------------------------------------------------------
-- INITIALIZE THE TABLES
-- --------------------------------------------------------
CREATE TABLE tA (c1 SMALLINT, c2 INT, c3 DECIMAL(15,0), c4 DECIMAL(3,2), c5 DECIMAL(15,14), c6 VARCHAR(1), C7 VARCHAR(7), C8 VARCHAR(1000), C9  CHAR(1), C10 CHAR(4), C11 CHAR(254), C12 DATE, C13 TIME); 


-- ********************************************************* 
-- 2BASIC0001-2BASIC0102
-- ********************************************************* 
-- TEST:2BASIC0001-2BASIC0102 INSERT INTO one column                     
-- PASS:2BASIC0001-2BASIC0102 EXPECTED FAILURE OCCURES                       

INSERT INTO tA VALUES (-32767, -2147483647, -123456789012345., -9.99, -9.99999999999999, 'A', 'AAAAAAA', 'ABCDEFGHIJKLMNOPQRSTUVWZYZ', 'F', 'ASDF', 'SADFASDGASGWERTWQETDSF32WQE345ERTGR2325SEFQWER25SGFAXDFASFR', '01.12.1999', '12:12:12');
INSERT INTO tA VALUES (0, 0, 0., 0, 0.0, '', '', '', '', '', '', '01.01.0100', '00:00:00');
INSERT INTO tA VALUES (32767, +2147483647, +123456789012345., +9.99, +9.99999999999999, '', 'AAAA', 'ABCDEFGHIJKLMNWZYZ', '', 'AS', 'SADFASDGASGEE345ERTGR2325SEFQWER25SGFAXDFASFR', '01.12.1999', '12:12:12');
INSERT INTO tA VALUES (-00007, -0000000007, -000000000000005., -9.99, -9.99999999999999, 'A', 'AAAAAAA', 'ABCDEFGHIJKLMNOPQRSTUVWZYZ', 'F', 'ASDF', 'SADFASDGASGWER5SEFQWER25SGFAXDFASFR', '01.12.1999', '12:12:12');

INSERT INTO tA (c1) VALUES (234);
INSERT INTO tA (c1) VALUES (-32767);
INSERT INTO tA (c1) VALUES (+32767);
INSERT INTO tA (c1) VALUES (-00000);
INSERT INTO tA (c1) VALUES (0000);
INSERT INTO tA (c1) VALUES (-67);
	SELECT c1 FROM tA ORDER BY c1;

INSERT INTO tA (c2) VALUES (+214748364);
INSERT INTO tA (c2) VALUES (-32767);
INSERT INTO tA (c2) VALUES (+32767);
INSERT INTO tA (c2) VALUES (-00000);
INSERT INTO tA (c2) VALUES (0000);
INSERT INTO tA (c2) VALUES (-2147483647);
	SELECT c2 FROM tA ORDER BY c2;

INSERT INTO tA (c3) VALUES (+999999999999999.);
INSERT INTO tA (c3) VALUES (-123456789012345.);
INSERT INTO tA (c3) VALUES (+123456789012345.);
INSERT INTO tA (c3) VALUES (-000000.000000);
INSERT INTO tA (c3) VALUES (000000.00);
INSERT INTO tA (c3) VALUES (-999999999999999.);
	SELECT c3 FROM tA ORDER BY c3;

INSERT INTO tA (c4) VALUES (+9.99);
INSERT INTO tA (c4) VALUES (-1.34);
INSERT INTO tA (c4) VALUES (+1.40);
INSERT INTO tA (c4) VALUES (-000000.000000);
INSERT INTO tA (c4) VALUES (000000.00);
INSERT INTO tA (c4) VALUES (-9.99);
	SELECT c4 FROM tA ORDER BY c4;

INSERT INTO tA (c5) VALUES (+9.99999999999999);
INSERT INTO tA (c5) VALUES (-1.345687687687);
INSERT INTO tA (c5) VALUES (+1.43456345634560);
INSERT INTO tA (c5) VALUES (-000000.000000000000000000);
INSERT INTO tA (c5) VALUES (000000.000000000000000000);
INSERT INTO tA (c5) VALUES (-9.99999999999999);
	SELECT c5 FROM tA ORDER BY c5;

INSERT INTO tA (c6) VALUES ('Y');
INSERT INTO tA (c6) VALUES ('');
INSERT INTO tA (c6) VALUES (' ');
INSERT INTO tA (c6) VALUES ('      ');
INSERT INTO tA (c6) VALUES ('abcdefg     h');
INSERT INTO tA (c6) VALUES ('             9');
	SELECT c6 FROM tA ORDER BY c6;

INSERT INTO tA (c7) VALUES ('abcdefg');
INSERT INTO tA (c7) VALUES ('');
INSERT INTO tA (c7) VALUES (' ');
INSERT INTO tA (c7) VALUES ('      ');
INSERT INTO tA (c7) VALUES ('abcdefg     h');
INSERT INTO tA (c7) VALUES ('             9');
	SELECT c7 FROM tA ORDER BY c7;

INSERT INTO tA (c8) VALUES ('abcdsfghsdfgsdfgsdfgsdfgdsfga');
INSERT INTO tA (c8) VALUES ('');
INSERT INTO tA (c8) VALUES (' ');
INSERT INTO tA (c8) VALUES ('      ');
INSERT INTO tA (c8) VALUES ('abcdefg     h');
INSERT INTO tA (c8) VALUES ('             9');
	SELECT c8 FROM tA ORDER BY c8;

INSERT INTO tA (c9) VALUES ('Y');
INSERT INTO tA (c9) VALUES ('');
INSERT INTO tA (c9) VALUES (' ');
INSERT INTO tA (c9) VALUES ('      ');
INSERT INTO tA (c9) VALUES ('abcdefg     h');
INSERT INTO tA (c9) VALUES ('             9');
	SELECT c9 FROM tA ORDER BY c9;

INSERT INTO tA (c10) VALUES ('abcd');
INSERT INTO tA (c10) VALUES ('');
INSERT INTO tA (c10) VALUES (' ');
INSERT INTO tA (c10) VALUES ('     ');
INSERT INTO tA (c10) VALUES ('abcdefg     h');
INSERT INTO tA (c10) VALUES ('             9');
	SELECT c10 FROM tA ORDER BY c10;

INSERT INTO tA (c11) VALUES ('abcdsfghsdfgsdfgsdfgsdfgdsfga');
INSERT INTO tA (c11) VALUES ('');
INSERT INTO tA (c11) VALUES (' ');
INSERT INTO tA (c11) VALUES ('      ');
INSERT INTO tA (c11) VALUES ('abcdefg     h');
INSERT INTO tA (c11) VALUES ('             9');
	SELECT c11 FROM tA ORDER BY c11;

INSERT INTO tA (c12) VALUES ('01.01.0100');
INSERT INTO tA (c12) VALUES ('02.29.1999');
INSERT INTO tA (c12) VALUES ('02.29.2000');
INSERT INTO tA (c12) VALUES ('12.31.1245');
INSERT INTO tA (c12) VALUES ('02.31.3000');
INSERT INTO tA (c12) VALUES ('31.08.1939');
INSERT INTO tA (c12) VALUES ('01/01/0100');
INSERT INTO tA (c12) VALUES ('02/29/1999');
INSERT INTO tA (c12) VALUES ('02/29/2000');
INSERT INTO tA (c12) VALUES ('12/31/1255');
INSERT INTO tA (c12) VALUES ('02/31/3001');
INSERT INTO tA (c12) VALUES ('31/08/1938');
INSERT INTO tA (c12) VALUES ('0100-01-01');
INSERT INTO tA (c12) VALUES ('02.29.1999');
INSERT INTO tA (c12) VALUES ('1984.02.29');
INSERT INTO tA (c12) VALUES ('2000.01.01');
INSERT INTO tA (c12) VALUES ('4000.08.31');
INSERT INTO tA (c12) VALUES ('1999.11.31');
	SELECT c12 FROM tA ORDER BY c12;

INSERT INTO tA (c13) VALUES ('00:00 AM');
INSERT INTO tA (c13) VALUES ('00:00 PM');
INSERT INTO tA (c13) VALUES ('12:00 AM');
INSERT INTO tA (c13) VALUES ('12:00 PM');
INSERT INTO tA (c13) VALUES ('06:59 PM');
INSERT INTO tA (c13) VALUES ('00:01 AM');
INSERT INTO tA (c13) VALUES ('24:00:00');
INSERT INTO tA (c13) VALUES ('00:00:00');
INSERT INTO tA (c13) VALUES ('10:34:45');
INSERT INTO tA (c13) VALUES ('23:59:59');
INSERT INTO tA (c13) VALUES ('00:00:01');
INSERT INTO tA (c13) VALUES ('12:00:00');
INSERT INTO tA (c13) VALUES ('24.00.00');
INSERT INTO tA (c13) VALUES ('23.59.59');
INSERT INTO tA (c13) VALUES ('15.59.23');
INSERT INTO tA (c13) VALUES ('00.00.01');
INSERT INTO tA (c13) VALUES ('12.45.32');
INSERT INTO tA (c13) VALUES ('06.06.06');
	SELECT c13 FROM tA ORDER BY c13;

DELETE FROM tA;

-- -----------------------------------------------

INSERT INTO tA (c1, c2, c3, c4, c5) VALUES (234, +214748364, +999999999999999., +9.99, +9.99999999999999);
INSERT INTO tA (c1, c2, c3, c4, c5) VALUES (-32767, -32767, -123456789012345., -1.34, -1.345687687687);
INSERT INTO tA (c1, c2, c3, c4, c5) VALUES (+32767, +32767, +123456789012345., +1.40, +1.43456345634560); 
INSERT INTO tA (c1, c2, c3, c4, c5) VALUES (-00000, -00000, -000000.000000, -000000.000000, -000000.000000000000000000); 
INSERT INTO tA (c1, c2, c3, c4, c5) VALUES (0000, 0000, 000000.00, 000000.00, 000000.000000000000000000);
INSERT INTO tA (c1, c2, c3, c4, c5) VALUES (-67, -2147483647, -999999999999999., -9.99, -9.99999999999999); 
	SELECT c1 FROM tA ORDER BY c1;
	SELECT c2 FROM tA ORDER BY c2;
	SELECT c3 FROM tA ORDER BY c3;
	SELECT c4 FROM tA ORDER BY c4;
	SELECT c5 FROM tA ORDER BY c5

-- -----------------------------------------------

INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('Y', 'abcdsfghsdfgsdfgsdfgsdfgdsfga', 'abcd', '','');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('', '', 'abcdefg     h', 'abcdsfghsdfgsdfgsdfgsdfgdsfga', ' ');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES (' ', ' ', '             9', 'abcdefg     h', 'abcdefg     h');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('      ', '      ', '', '             9', 'abcdefg');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('abcdefg     h', 'abcdefg     h', '     ', '      ', '             9');
INSERT INTO tA (c6, c8, c10, c11, c7) VALUES ('             9', '             9', '     ', ' ', '');
	SELECT c6 FROM tA ORDER BY c6;
	SELECT c7 FROM tA ORDER BY c7;
	SELECT c8 FROM tA ORDER BY c8;
	SELECT c10 FROM tA ORDER BY c10;
	SELECT c11 FROM tA ORDER BY c11;

-- -------------------------------------------------


INSERT INTO tA (c13, c12) VALUES ('00:00 AM', '02.29.1999');
INSERT INTO tA (c13, c12) VALUES ('00:00 PM', '31.08.1939');
INSERT INTO tA (c13, c12) VALUES ('12:00 AM', '02/31/3001');
INSERT INTO tA (c13, c12) VALUES ('12:00 PM', '02.29.2000');
INSERT INTO tA (c13, c12) VALUES ('06:59 PM', '02/29/2000');
INSERT INTO tA (c13, c12) VALUES ('00:01 AM', '01/01/0100');
INSERT INTO tA (c13, c12) VALUES ('24:00:00', '4000.08.31');
INSERT INTO tA (c13, c12) VALUES ('00:00:00', '02.31.3000');
INSERT INTO tA (c13, c12) VALUES ('10:34:45', '31/08/1938');
INSERT INTO tA (c13, c12) VALUES ('23:59:59', '1984.02.29');
INSERT INTO tA (c13, c12) VALUES ('00:00:01', '1999.11.31');
INSERT INTO tA (c13, c12) VALUES ('12:00:00', '01.01.0100');
INSERT INTO tA (c13, c12) VALUES ('24.00.00', '02.29.1999');
INSERT INTO tA (c13, c12) VALUES ('23.59.59', '02/29/1999');
INSERT INTO tA (c13, c12) VALUES ('15.59.23', '0100-01-01');
INSERT INTO tA (c13, c12) VALUES ('00.00.01', '2000.01.01');
INSERT INTO tA (c13, c12) VALUES ('12.45.32', '12/31/1255');
INSERT INTO tA (c13, c12) VALUES ('06.06.06', '12.31.1245'); 
	SELECT c13 FROM tA ORDER BY c13;
	SELECT c12 FROM tA ORDER BY c12;

DELETE FROM tA;
















