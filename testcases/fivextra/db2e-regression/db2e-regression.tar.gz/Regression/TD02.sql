-- ------------------- FILE: TD02.SQL  --------------------
-- -                                                      - 
-- -       INSERT SOME SAMPLE DATA INOT USER TABLE        -
-- -                                                      -
-- --------------------------------------------------------

insert into UserTable(UserId,Name,Age) values ('00001','Andy',37);
insert into UserTable(UserId,Name,Age) values ('00002','Jyh-Herng',36);
insert into UserTable(UserId,Name,Age) values ('00003','HongHai',35);
insert into UserTable(UserId,Name,Age) values ('00004','Thanh',38);
insert into UserTable(UserId,Name,Age) values ('00005','Josephine',43);
insert into UserTable(UserId,Name,Age) values ('00006','Carol',47);
insert into UserTable(UserId,Name,Age) values ('00007','Markus',27);
insert into UserTable values ('00008','Carol',20);
insert into UserTable(UserId,Name,Age) values ('11111',null,98);
insert into UserTable (UserID,Age) values ('11112',99);
insert into UserTable values ('22221','Dummy1',1);
insert into UserTable values ('22222','Dummy2',2);
insert into UserTable values ('22223','Dummy3',3);
insert into UserTable values ('22224','Dummy4',4);
insert into UserTable values ('22225','Dummy5',5);
insert into UserTable values ('22226','Dummy6',6);
insert into UserTable values ('22227','Dummy7',7);
insert into UserTable values ('22228','Dummy8',8);
insert into UserTable values ('22229','Dummy9',9);


-- -------------------------------------------------------- 
-- -      INSERT SOME SAMPLE DATA INOT DEMAND TABLE       -
-- --------------------------------------------------------

insert into DemandTable(UserId,Subject) values ('00001','Locking');
insert into DemandTable(UserId,Subject) values ('00001','CMVC');
insert into DemandTable(UserId,Subject) values ('00002','EPOC32');
insert into DemandTable(UserId,Subject) values ('00004','SQL');
insert into DemandTable(UserId,Subject) values ('00007','CMVC');
insert into DemandTable(UserId,Subject) values ('00007','IBDB2');
insert into DemandTable(UserId,Subject) values ('00004','WinCE');
insert into DemandTable(UserId,Subject) values ('00005','Unicode');
insert into DemandTable(UserId,Subject) values ('00007','Testing');


-- -------------------------------------------------------- 
-- -       INSERT SOME SAMPLE DATA INOT TEACHTABLE        -
-- --------------------------------------------------------

insert into TutorTable(Teacher,Student,Subject) values ('00001','00002','WinCE');
insert into TutorTable(Teacher,Student,Subject) values ('00002','00003','PalmOS');
insert into TutorTable(Teacher,Student,Subject) values ('00001','00004','DMS');
insert into TutorTable(Teacher,Student,Subject) values ('00002','00004','PalmOS');
insert into TutorTable(Teacher,Student,Subject) values ('00004','00003','Test Plan');
insert into TutorTable(Teacher,Student,Subject) values ('00004','00001','Unicode');
insert into TutorTable(Teacher,Student,Subject) values ('00005','00002','Transaction');
insert into TutorTable(Teacher,Student,Subject) values ('00006','00005','Customer');
insert into TutorTable(Teacher,Student,Subject) values ('00006','00004','Application');
insert into TutorTable(Teacher,Student,Subject) values ('00006','00005','Application');
insert into TutorTable(Teacher,Student,Subject) values ('00006','00001','Application');
insert into TutorTable(Teacher,Student,Subject) values (null,'00008','Nothing');
insert into TutorTable(Teacher,Student,Subject) values ('00001','00007','WinCE');
insert into TutorTable(Teacher,Student,Subject) values ('00002','00007','PalmOS');
insert into TutorTable(Teacher,Student,Subject) values ('00003','00007','CLI');
insert into TutorTable(Teacher,Student,Subject) values (null,'00007','Security');
insert into TutorTable(Teacher,Student,Subject) values (null,'00101','Dummy Subject 1');
insert into TutorTable(Teacher,Student,Subject) values ('00102',null,'Dummy Subject 2');
insert into TutorTable(Teacher,Student,Subject) values ('00103','00104','Dummy Subject 3');
insert into TutorTable(Teacher,Student,Subject) values (null,'00105','Dummy Item 1');
insert into TutorTable(Teacher,Student,Subject) values (null,'00106','Dummy Item 2');
insert into TutorTable(Teacher,Student,Subject) values (null,'00107','Dummy Item 3');
