-- ----------------- FILE: SELECT04.SQL -------------------
-- -                                                      - 
-- -              Validates UPDATE statement	          -
-- -                                                      -
-- --------------------------------------------------------
--

-- --------------------------------------------------------
-- This set of test cases validates sorting.
-- --------------------------------------------------------
-- --------------------------------------------------------
-- Delete tables
-- --------------------------------------------------------
DROP TABLE tI;

-- --------------------------------------------------------
-- INITIALIZE THE TABLES
-- --------------------------------------------------------
CREATE TABLE tI (c1 INT, c2 INT, c3 int);

INSERT INTO tI VALUES (-2147483647, +2147483647, 1);
INSERT INTO tI VALUES (-1234, +1234, 2);
INSERT INTO tI VALUES (-21, 0, 3);
INSERT INTO tI VALUES (-21, -0, 4);
INSERT INTO tI VALUES (0, 0, 5);
INSERT INTO tI VALUES (-0, -0, 6);
INSERT INTO tI VALUES (0, -34, 7);
INSERT INTO tI VALUES (123, -34, 8);
INSERT INTO tI VALUES (12345, -34534, 9);
INSERT INTO tI VALUES (2147483647, -2147483647,10);


SELECT c1 FROM tI ORDER BY c1;
SELECT c2 FROM tI ORDER BY c2;
SELECT c1+c2 FROM tI ORDER BY 1;
SELECT c2, sum(c3) from tI GROUP BY c2 ORDER BY 2;
SELECT c2, sum(c3-c1) from tI GROUP BY c2 ORDER BY 2;
SELECT c2+c1, max(c3) from tI GROUP BY c1,c2 ORDER BY 2;
