-- ------------------- FILE: TD05.SQL  --------------------
-- -                                                      - 
-- -              Delete DATA FROM TABLES                 -
-- -                                                      -
-- --------------------------------------------------------


delete from UserTable where UserId='22224';
select * from UserTable;
delete from UserTable where Name is null;
select * from UserTable;
--
delete from UserTable where Age<5;
select * from UserTable;
delete from TutorTable where Teacher is null;
select * from TutorTable;
delete from TutorTable where Subject like '%ummy S%';
select * from TutorTable;
