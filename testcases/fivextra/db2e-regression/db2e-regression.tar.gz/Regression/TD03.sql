-- ------------------- FILE: TD03.SQL  --------------------
-- -                                                      - 
-- -                 PERFORMS SOME QUERY                  -
-- -                                                      -
-- --------------------------------------------------------
 

select Name from UserTable where UserId ='00004';
select UserId from UserTable where Age<40;
select UserId from DemandTable where Subject='CMVC';
--
select Name,Age 
  from UserTable 
  where UserId like '00%';
select Subject from DemandTable;
select * from UserTable;
--
select * from TutorTable where Teacher>'00004';
select * from UserTable where Name is null;
select * from UserTable where Name is not null;
select * from TutorTable where Teacher is null;
