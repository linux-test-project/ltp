-- ----------------- FILE: SELECT10.SQL -------------------
-- -                                                      - 
-- -        CHECK ALL ERROR IN "SELECT" STATEMENT         -
-- -                                                      -
-- --------------------------------------------------------
--

DROP TABLE TB;
DROP TABLE TC;
DROP TABLE TD;
DROP TABLE TE;
DROP TABLE TI;
DROP TABLE TS;
DROP TABLE TT;
DROP TABLE TV;