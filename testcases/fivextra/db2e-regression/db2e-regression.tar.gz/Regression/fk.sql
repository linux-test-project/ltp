--------------------------------------------------------------------------------
-- TESTING FOR FOREIGN KEYS (these tests are incomplete)
--------------------------------------------------------------------------------

create table fortest
(
	forone char(10) not null,
	fortwo char(10) not null,
	forthree char(10) not null,
	forfour char(10) not null,
	primary key(forthree, forfour)
);

drop table fortest;

create table pritest
(
	prione char(10) not null primary key,
	pritwo char(10) not null,
	prithree char(10) not null,
	prifour char(10) not null,
	foreign key(pritwo, prithree) references fortest
);

drop table pritest;

create table xp(a int not null, b int not null, c int not null, primary key(b,a,c));
create table xc(a int, b int, c int, foreign key(b,a,c) references xp);
create table yp1(a int not null, b char(2) not null, c smallint not null, d int not null, primary key(b,a,c));
create table yp2(a int not null, b date not null, c time not null, primary key(a,b));
create table yc1(a char(2), b int, c smallint, d date, e int, foreign key(a,e,c) references yp1, foreign key(e,d) references yp2);
insert into yc1 values('ab',2,3,'02/21/2000',8);
insert into yp2 values(3,'02/02/1929','3:30:30');
insert into xc values(1,1,1);
select * from yc1;
select * from yp2;
select * from xc;

drop table xc;
drop table xp;
drop table yc1;
drop table yp1;
drop table yp2;

--------------------------------------------------------------------------------


