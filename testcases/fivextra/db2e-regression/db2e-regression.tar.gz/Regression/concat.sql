-- ----------------------------------
-- TESTS FOR THE CONCAT OPERATOR (||)
-- ----------------------------------

create table tConcat (a varchar(32), b varchar(32), c int, d int, e varchar(10));

insert into tConcat values ('Hello ', 'World', 3,4, ' !');

select a||b from tConcat;

select a || b from tConcat;

select a|| b from tConcat;

select a ||b from tConcat;

select a||b||e from tConcat;

select a|b from tConcat;

select a|||b from tConcat;

||;

select a||;

select a || from tConcat;

select || b from tConcat;

select a || c from tConcat;

select c || d from tConcat;

insert into tConcat values ('Hello /|/| ', '||World', 3,4, '.');

select a||b from tConcat;

select a || b from tConcat;

select a|| b from tConcat;

select a ||b from tConcat;

drop table tConcat;

-- check recompile select after index is dropped

drop table t;
create table t (a int, b int);
create index idx on t (a);
insert into t values (1, 1);
insert into t values (2, 2);
insert into t values (3, 3);
create stmt handle :1;
prepare :1 select * from t order by a;
execute :1;
fetch :1;
drop index idx;
fetch :1;
execute :1;
fetch :1;
create index idx on t (a);
fetch :1;
drop index idx;
fetch :1;
drop stmt handle :1;
drop table t;
