int main() {
	printf("Hello, Sailor!\n");
	return 0;
}
